<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/** single column page **/
$route['get_single_column_page'] = 'single_column_page_api/get_single_column_page';
$route['add_single_column_page'] = 'single_column_page_api/add_single_column_page';
$route['edit_single_column_page'] = 'single_column_page_api/edit_single_column_page';
$route['delete_single_column_page'] = 'single_column_page_api/delete_single_column_page';
$route['restore_single_column_page'] = 'single_column_page_api/restore_single_column_page';
$route['set_status_single_column_page'] = 'single_column_page_api/set_status_single_column_page';
$route['import_single_column_page'] = 'single_column_page_api/import_single_column_page';


/** Career Goals **/
$route['view_career_goals'] = 'career_goals_api/view_career_goals';
$route['add_career_goals'] = 'career_goals_api/add_career_goals';
$route['edit_career_goals'] = 'career_goals_api/edit_career_goals';
$route['delete_career_goals'] = 'career_goals_api/delete_career_goals';
$route['restore_career_goals'] = 'career_goals_api/restore_career_goals';
$route['set_status_career_goals'] = 'career_goals_api/set_status_career_goals';
$route['set_standard_career_goals'] = 'career_goals_api/set_standard_career_goals';
$route['import_career_goals'] = 'career_goals_api/import_career_goals';


/** Countries **/
$route['view_countries'] = 'countries_api/view_countries';
$route['add_countries'] = 'countries_api/add_countries';
$route['edit_countries'] = 'countries_api/edit_countries';
$route['delete_countries'] = 'countries_api/delete_countries';
$route['restore_countries'] = 'countries_api/restore_countries';
$route['set_status_countries'] = 'countries_api/set_status_countries';
$route['import_countries'] = 'countries_api/import_countries';

/** Curriculums **/
$route['view_curriculums'] = 'curriculums_api/view_curriculums';
$route['add_curriculums'] = 'curriculums_api/add_curriculums';
$route['edit_curriculums'] = 'curriculums_api/edit_curriculums';
$route['delete_curriculums'] = 'curriculums_api/delete_curriculums';
$route['restore_curriculums'] = 'curriculums_api/restore_curriculums';
$route['set_status_curriculums'] = 'curriculums_api/set_status_curriculums';
$route['import_curriculums'] = 'curriculums_api/import_curriculums';
$route['get_curriculum_categories'] = 'curriculums_api/get_curriculum_categories';

/** Subject Types **/
$route['view_subject_types'] = 'subject_types_api/view_subject_types';
$route['add_subject_types'] = 'subject_types_api/add_subject_types';
$route['edit_subject_types'] = 'subject_types_api/edit_subject_types';
$route['delete_subject_types'] = 'subject_types_api/delete_subject_types';
$route['restore_subject_types'] = 'subject_types_api/restore_subject_types';
$route['set_status_subject_types'] = 'subject_types_api/set_status_subject_types';
$route['import_subject_types'] = 'subject_types_api/import_subject_types';

/** Subjects **/
$route['view_subjects'] = 'subjects_api/view_subjects';
$route['add_subjects'] = 'subjects_api/add_subjects';
$route['edit_subjects'] = 'subjects_api/edit_subjects';
$route['delete_subjects'] = 'subjects_api/delete_subjects';
$route['restore_subjects'] = 'subjects_api/restore_subjects';
$route['set_status_subjects'] = 'subjects_api/set_status_subjects';
$route['import_subjects'] = 'subjects_api/import_subjects';
$route['get_subject_categories'] = 'subjects_api/get_subject_categories';
$route['get_subject_types'] = 'subjects_api/get_subject_types';

/** Curriculums **/
$route['get_curriculums'] = 'curriculum_items_api/get_curriculums';
$route['get_subjects'] = 'curriculum_items_api/get_subjects';
$route['get_curriculum_item_types'] = 'curriculum_items_api/get_curriculum_item_types';
$route['get_competence_levels'] = 'curriculum_items_api/get_competence_levels';
$route['get_curriculum_item_cycles'] = 'curriculum_items_api/get_curriculum_item_cycles';
$route['view_curriculum_items'] = 'curriculum_items_api/view_curriculum_items';
$route['add_curriculum_items'] = 'curriculum_items_api/add_curriculum_items';
$route['edit_curriculum_items'] = 'curriculum_items_api/edit_curriculum_items';
$route['delete_curriculum_items'] = 'curriculum_items_api/delete_curriculum_items';
$route['restore_curriculum_items'] = 'curriculum_items_api/restore_curriculum_items';
$route['set_status_curriculum_items'] = 'curriculum_items_api/set_status_curriculum_items';
$route['import_curriculum_items'] = 'curriculum_items_api/import_curriculum_items';

/** Disciplinary Categories **/
$route['view_disciplinary_categories'] = 'disciplinary_categories_api/view_disciplinary_categories';
$route['add_disciplinary_categories'] = 'disciplinary_categories_api/add_disciplinary_categories';
$route['edit_disciplinary_categories'] = 'disciplinary_categories_api/edit_disciplinary_categories';
$route['delete_disciplinary_categories'] = 'disciplinary_categories_api/delete_disciplinary_categories';
$route['restore_disciplinary_categories'] = 'disciplinary_categories_api/restore_disciplinary_categories';
$route['set_status_disciplinary_categories'] = 'disciplinary_categories_api/set_status_disciplinary_categories';
$route['import_disciplinary_categories'] = 'disciplinary_categories_api/import_disciplinary_categories';

/** Weekdays **/
$route['view_weekdays'] = 'weekdays_api/view_weekdays';
$route['add_weekdays'] = 'weekdays_api/add_weekdays';
$route['edit_weekdays'] = 'weekdays_api/edit_weekdays';
$route['delete_weekdays'] = 'weekdays_api/delete_weekdays';
$route['restore_weekdays'] = 'weekdays_api/restore_weekdays';
$route['set_status_weekdays'] = 'weekdays_api/set_status_weekdays';
$route['import_weekdays'] = 'weekdays_api/import_weekdays';

/** Dossier Languages **/
$route['view_dossier_languages'] = 'dossier_languages_api/view_dossier_languages';
$route['add_dossier_languages'] = 'dossier_languages_api/add_dossier_languages';
$route['edit_dossier_languages'] = 'dossier_languages_api/edit_dossier_languages';
$route['delete_dossier_languages'] = 'dossier_languages_api/delete_dossier_languages';
$route['restore_dossier_languages'] = 'dossier_languages_api/restore_dossier_languages';
$route['set_status_dossier_languages'] = 'dossier_languages_api/set_status_dossier_languages';

$route['import_dossier_languages'] = 'dossier_languages_api/import_dossier_languages';

/** Lesson Numbers **/
$route['view_lesson_numbers'] = 'lesson_numbers_api/view_lesson_numbers';
$route['add_lesson_numbers'] = 'lesson_numbers_api/add_lesson_numbers';
$route['edit_lesson_numbers'] = 'lesson_numbers_api/edit_lesson_numbers';
$route['delete_lesson_numbers'] = 'lesson_numbers_api/delete_lesson_numbers';
$route['restore_lesson_numbers'] = 'lesson_numbers_api/restore_lesson_numbers';
$route['set_status_lesson_numbers'] = 'lesson_numbers_api/set_status_lesson_numbers';
$route['import_lesson_numbers'] = 'lesson_numbers_api/import_lesson_numbers';

/** Marks Categories **/
$route['view_mark_categories'] = 'mark_categories_api/view_mark_categories';
$route['add_mark_categories'] = 'mark_categories_api/add_mark_categories';
$route['edit_mark_categories'] = 'mark_categories_api/edit_mark_categories';
$route['delete_mark_categories'] = 'mark_categories_api/delete_mark_categories';
$route['restore_mark_categories'] = 'mark_categories_api/restore_mark_categories';
$route['set_status_mark_categories'] = 'mark_categories_api/set_status_mark_categories';
$route['set_default_mark_categories'] = 'mark_categories_api/set_default_mark_categories';
$route['import_mark_categories'] = 'mark_categories_api/import_mark_categories';

/** Marks **/
$route['view_marks'] = 'marks_api/view_marks';
$route['add_marks'] = 'marks_api/add_marks';
$route['edit_marks'] = 'marks_api/edit_marks';
$route['delete_marks'] = 'marks_api/delete_marks';
$route['restore_marks'] = 'marks_api/restore_marks';
$route['set_status_marks'] = 'marks_api/set_status_marks';
$route['import_marks'] = 'marks_api/import_marks';

/** Personnel Functions **/
$route['view_personnel_functions'] = 'personnel_functions_api/view_personnel_functions';
$route['add_personnel_functions'] = 'personnel_functions_api/add_personnel_functions';
$route['edit_personnel_functions'] = 'personnel_functions_api/edit_personnel_functions';
$route['delete_personnel_functions'] = 'personnel_functions_api/delete_personnel_functions';
$route['restore_personnel_functions'] = 'personnel_functions_api/restore_personnel_functions';
$route['set_status_personnel_functions'] = 'personnel_functions_api/set_status_personnel_functions';
$route['set_standard_personnel_functions'] = 'personnel_functions_api/set_standard_personnel_functions';
$route['import_personnel_functions'] = 'personnel_functions_api/import_personnel_functions';

/** Rooms **/
$route['view_rooms'] = 'rooms_api/view_rooms';
$route['add_rooms'] = 'rooms_api/add_rooms';
$route['edit_rooms'] = 'rooms_api/edit_rooms';
$route['delete_rooms'] = 'rooms_api/delete_rooms';
$route['restore_rooms'] = 'rooms_api/restore_rooms';
$route['set_status_rooms'] = 'rooms_api/set_status_rooms';
$route['import_rooms'] = 'rooms_api/import_rooms';
$route['get_room_functions'] = 'rooms_api/get_room_functions';

/** Terms **/
$route['view_terms'] = 'terms_api/view_terms';
$route['add_terms'] = 'terms_api/add_terms';
$route['edit_terms'] = 'terms_api/edit_terms';
$route['delete_terms'] = 'terms_api/delete_terms';
$route['restore_terms'] = 'terms_api/restore_terms';
$route['set_status_terms'] = 'terms_api/set_status_terms';
$route['import_terms'] = 'terms_api/import_terms';

/** school **/
$route['view_school'] = 'school_api/view_school';
$route['add_school'] = 'school_api/add_school';
$route['edit_school'] = 'school_api/edit_school';
$route['delete_school'] = 'school_api/delete_school';
$route['restore_school'] = 'school_api/restore_school';
$route['set_status_school'] = 'school_api/set_status_school';
$route['get_countries'] = 'school_api/get_countries';
$route['get_school_data'] = 'school_api/get_school_data';

/** Users **/
$route['view_users'] = 'users_api/view_users';
$route['add_users'] = 'users_api/add_users';
$route['edit_users'] = 'users_api/edit_users';
$route['delete_users'] = 'users_api/delete_users';
$route['restore_users'] = 'users_api/restore_users';
$route['set_status_users'] = 'users_api/set_status_users';
$route['import_users'] = 'users_api/import_users';
$route['get_personnel_functions'] = 'users_api/get_personnel_functions';
$route['get_gender'] = 'users_api/get_gender';
$route['load_languages'] = 'users_api/load_languages';

/** parents **/
$route['view_parents'] = 'parents_api/view_parents';
$route['add_parents'] = 'parents_api/add_parents';
$route['edit_parents'] = 'parents_api/edit_parents';
$route['delete_parents'] = 'parents_api/delete_parents';
$route['restore_parents'] = 'parents_api/restore_parents';
$route['set_status_parents'] = 'parents_api/set_status_parents';
$route['import_parents'] = 'parents_api/import_parents';

/** Courses **/
$route['view_courses'] = 'courses_api/view_courses';
$route['add_courses'] = 'courses_api/add_courses';
$route['edit_courses'] = 'courses_api/edit_courses';
$route['delete_courses'] = 'courses_api/delete_courses';
$route['restore_courses'] = 'courses_api/restore_courses';
$route['set_status_courses'] = 'courses_api/set_status_courses';
$route['set_individual_courses'] = 'courses_api/set_individual_courses';
$route['import_courses'] = 'courses_api/import_courses';
$route['get_teachers'] = 'courses_api/get_teachers';

/** students **/
$route['view_students'] = 'students_api/view_students';
$route['view_student_assignments'] = 'students_api/view_student_assignments';
$route['add_students'] = 'students_api/add_students';
$route['edit_students'] = 'students_api/edit_students';
$route['delete_students'] = 'students_api/delete_students';
$route['restore_students'] = 'students_api/restore_students';
$route['set_status_students'] = 'students_api/set_status_students';
$route['set_resigned_students'] = 'students_api/set_resigned_students';
$route['import_students'] = 'students_api/import_students';
$route['get_grades'] = 'students_api/get_grades';
$route['get_study_level'] = 'students_api/get_study_level';
$route['get_professions'] = 'students_api/get_professions';
$route['get_career_goals'] = 'students_api/get_career_goals';
$route['get_parents'] = 'students_api/get_parents';
$route['get_terms'] = 'students_api/get_terms';
$route['get_parent_info'] = 'students_api/get_parent_info';

/** students terms **/
$route['view_students_terms'] = 'students_terms_api/view_students_terms';
$route['add_students_terms'] = 'students_terms_api/add_students_terms';
$route['edit_students_terms'] = 'students_terms_api/edit_students_terms';
$route['delete_students_terms'] = 'students_terms_api/delete_students_terms';
$route['import_students_terms'] = 'students_terms_api/import_students_terms';
$route['get_students'] = 'students_terms_api/get_students';
$route['get_active_terms'] = 'students_terms_api/get_active_terms';
$route['view_all_students_terms'] = 'students_terms_api/view_all_students_terms';
$route['view_selected_students_terms'] = 'students_terms_api/view_selected_students_terms';
$route['view_final_students_terms'] = 'students_terms_api/view_final_students_terms';
$route['duplicate_student_terms'] = 'students_terms_api/duplicate_student_terms';

/** Students Courses **/
$route['view_students_courses'] = 'students_courses_api/view_students_courses';
$route['add_students_courses'] = 'students_courses_api/add_students_courses';
$route['edit_students_courses'] = 'students_courses_api/edit_students_courses';
$route['delete_students_courses'] = 'students_courses_api/delete_students_courses';
$route['import_students_courses'] = 'students_courses_api/import_students_courses';
$route['view_all_students_courses'] = 'students_courses_api/view_all_students_courses';
$route['view_selected_students_courses'] = 'students_courses_api/view_selected_students_courses';
$route['view_all_courses'] = 'students_courses_api/view_all_courses';
$route['view_all_selected_courses'] = 'students_courses_api/view_all_selected_courses';
$route['view_final_students_courses'] = 'students_courses_api/view_final_students_courses';
$route['get_courses'] = 'students_courses_api/get_courses';
$route['get_student_course_status'] = 'students_courses_api/get_student_course_status';
$route['duplicate_student_courses'] = 'students_courses_api/duplicate_student_courses';

/** timetable **/
$route['get_weekdays'] = 'timetable_api/get_weekdays';
$route['view_daily_timetable'] = 'timetable_api/view_daily_timetable';
$route['view_weekly_timetable'] = 'timetable_api/view_weekly_timetable';
$route['add_timetable'] = 'timetable_api/add_timetable';
$route['edit_timetable'] = 'timetable_api/edit_timetable';
$route['delete_timetable'] = 'timetable_api/delete_timetable';
$route['clear_timetable'] = 'timetable_api/clear_timetable';
$route['duplicate_timetable'] = 'timetable_api/duplicate_timetable';
$route['import_timetable'] = 'timetable_api/import_timetable';

/** timetable_weekly **/
$route['get_weekly_timetable'] = 'timetable_weekly_api/get_weekly_timetable';
$route['get_student_teacher'] = 'timetable_weekly_api/get_student_teacher';

/** absences **/
$route['view_absences'] = 'absences_api/view_absences';
$route['add_absences'] = 'absences_api/add_absences';
$route['edit_absences'] = 'absences_api/edit_absences';
$route['delete_absences'] = 'absences_api/delete_absences';
$route['restore_absences'] = 'absences_api/restore_absences';
$route['excuse_absences'] = 'absences_api/excuse_absences';
$route['import_absences'] = 'absences_api/import_absences';
$route['get_absences_type'] = 'absences_api/get_absences_type';
$route['get_reported_by'] = 'absences_api/get_reported_by';
$route['get_students_for_search'] = 'absences_api/get_students_for_search';
$route['view_students_for_absences'] = 'absences_api/view_students_for_absences';


/** disciplinary **/
$route['view_disciplinary'] = 'disciplinary_api/view_disciplinary';
$route['add_disciplinary'] = 'disciplinary_api/add_disciplinary';
$route['edit_disciplinary'] = 'disciplinary_api/edit_disciplinary';
$route['delete_disciplinary'] = 'disciplinary_api/delete_disciplinary';
$route['restore_disciplinary'] = 'disciplinary_api/restore_disciplinary';
$route['import_disciplinary'] = 'disciplinary_api/import_disciplinary';
$route['get_disciplinary_type'] = 'disciplinary_api/get_disciplinary_type';


/** coaching **/
$route['view_coaching'] = 'coaching_api/view_coaching';
$route['add_coaching'] = 'coaching_api/add_coaching';
$route['edit_coaching'] = 'coaching_api/edit_coaching';
$route['delete_coaching'] = 'coaching_api/delete_coaching';
$route['restore_coaching'] = 'coaching_api/restore_coaching';
$route['excuse_coaching'] = 'coaching_api/excuse_coaching';
$route['import_coaching'] = 'coaching_api/import_coaching';
$route['get_coaching_type'] = 'coaching_api/get_coaching_type';
$route['view_students_for_coaching'] = 'coaching_api/view_students_for_coaching';
$route['get_student_details'] = 'coaching_api/get_student_details';
$route['get_student_marks'] = 'coaching_api/get_student_marks';
$route['get_student_disciplinary'] = 'coaching_api/get_student_disciplinary';
$route['get_student_absences'] = 'coaching_api/get_student_absences';
$route['get_student_marks_data'] = 'coaching_api/get_student_marks_data';
$route['get_max_mark'] = 'coaching_api/get_max_mark';

/** dossiers **/
$route['view_dossiers'] = 'dossiers_api/view_dossiers';
$route['add_dossiers'] = 'dossiers_api/add_dossiers';
$route['edit_dossiers'] = 'dossiers_api/edit_dossiers';
$route['duplicate_dossiers'] = 'dossiers_api/duplicate_dossiers';
$route['send_task_dossiers'] = 'dossiers_api/send_task_dossiers';
$route['delete_dossiers'] = 'dossiers_api/delete_dossiers';
$route['restore_dossiers'] = 'dossiers_api/restore_dossiers';
$route['excuse_dossiers'] = 'dossiers_api/excuse_dossiers';
$route['import_dossiers'] = 'dossiers_api/import_dossiers';
$route['get_dossiers_type'] = 'dossiers_api/get_dossiers_type';
$route['get_dossiers_type_global'] = 'dossiers_api/get_dossiers_type_global';
$route['update_dossiers_pdf_status'] = 'dossiers_api/update_dossiers_pdf_status';
$route['get_curriculum_items'] = 'dossiers_api/get_curriculum_items';
$route['get_dossier_preview_by_id'] = 'dossiers_api/get_dossier_preview_by_id';


/** file_manager **/
$route['file_manager'] = 'file_manager_api/file_manager';
$route['view_files'] = 'file_manager_api/view_files';
$route['add_files'] = 'file_manager_api/add_files';
$route['delete_files'] = 'file_manager_api/delete_files';
$route['rename_files'] = 'file_manager_api/rename_files';
$route['move_to_folder_files'] = 'file_manager_api/move_to_folder_files';
$route['edit_file_manager'] = 'file_manager_api/edit_file_manager';
$route['view_folders'] = 'file_manager_api/view_folders';
$route['add_new_folder'] = 'file_manager_api/add_new_folder';
$route['delete_folder'] = 'file_manager_api/delete_folder';
$route['move_or_copy_folder'] = 'file_manager_api/move_or_copy_folder';
$route['move_to_folder'] = 'file_manager_api/move_to_folder';
$route['copy_to_folder'] = 'file_manager_api/copy_to_folder';
$route['rename_folder'] = 'file_manager_api/rename_folder';

/** course_attendants_marks **/
$route['view_course_attendants_marks'] = 'course_attendants_marks_api/view_course_attendants_marks';
$route['view_students_for_course_attendants_marks'] = 'course_attendants_marks_api/view_students_for_course_attendants_marks';
$route['view_student_marks'] = 'course_attendants_marks_api/view_student_marks';
$route['view_general_marks'] = 'course_attendants_marks_api/view_general_marks';
$route['add_course_attendants_marks'] = 'course_attendants_marks_api/add_course_attendants_marks';
$route['add_student_attendants_marks'] = 'course_attendants_marks_api/add_student_attendants_marks';
$route['edit_course_attendants_marks'] = 'course_attendants_marks_api/edit_course_attendants_marks';
$route['delete_course_attendants_marks'] = 'course_attendants_marks_api/delete_course_attendants_marks';
$route['restore_course_attendants_marks'] = 'course_attendants_marks_api/restore_course_attendants_marks';
$route['excuse_course_attendants_marks'] = 'course_attendants_marks_api/excuse_course_attendants_marks';
$route['import_course_attendants_marks'] = 'course_attendants_marks_api/import_absences';
$route['get_mark_points'] = 'course_attendants_marks_api/get_mark_points';
$route['get_mark_categories'] = 'course_attendants_marks_api/get_mark_categories';
$route['get_dossiers'] = 'course_attendants_marks_api/get_dossiers';
$route['get_course_attendants_marks'] = 'course_attendants_marks_api/get_course_attendants_marks';


/** Timeline **/
$route['view_timeline'] = 'timeline_api/view_timeline';
$route['add_timeline_absence'] = 'timeline_api/add_timeline_absence';
$route['add_timeline_disciplinary'] = 'timeline_api/add_timeline_disciplinary';
$route['add_timeline_marks'] = 'timeline_api/add_timeline_marks';
$route['view_timeline_student_details'] = 'timeline_api/view_timeline_student_details';
$route['view_timeline_student_files'] = 'timeline_api/view_timeline_student_files';
$route['view_timeline_teacher_details'] = 'timeline_api/view_timeline_teacher_details';
$route['view_timeline_student_file_details'] = 'timeline_api/view_timeline_student_file_details';
$route['add_timeline_teacher_uploads'] = 'timeline_api/add_timeline_teacher_uploads';
$route['add_timeline_student_uploads'] = 'timeline_api/add_timeline_student_uploads';
$route['update_course_upload_settings'] = 'timeline_api/update_course_upload_settings';
$route['update_course_uploads'] = 'timeline_api/update_course_uploads';
$route['delete_course_uploads'] = 'timeline_api/delete_course_uploads';
$route['get_dossier_by_id'] = 'timeline_api/get_dossier_by_id';
$route['update_student_course_uploads'] = 'timeline_api/update_student_course_uploads';
$route['get_upload_count'] = 'timeline_api/get_upload_count';
$route['get_students_for_timeline'] = 'timeline_api/get_students_for_timeline';

/** team_meetings **/
$route['view_team_meetings'] = 'team_meetings_api/view_team_meetings';
$route['add_team_meetings'] = 'team_meetings_api/add_team_meetings';
$route['add_team_notifications'] = 'team_meetings_api/add_team_notifications';
$route['delete_team_meetings'] = 'team_meetings_api/delete_team_meetings';
$route['restore_team_meetings'] = 'team_meetings_api/restore_team_meetings';
$route['get_personnel'] = 'team_meetings_api/get_personnel';
$route['get_meeting_categories'] = 'team_meetings_api/get_meeting_categories';

/** Notifications **/
$route['notifications'] = 'notifications_api/notifications';
$route['view_inbox_messages'] = 'notifications_api/view_inbox_messages';
$route['view_outbox_messages'] = 'notifications_api/view_outbox_messages';
$route['view_inbox_task'] = 'notifications_api/view_inbox_task';
$route['view_outbox_task'] = 'notifications_api/view_outbox_task';
$route['view_inbox_meetings'] = 'notifications_api/view_inbox_meetings';
$route['view_outbox_meetings'] = 'notifications_api/view_outbox_meetings';
$route['view_inbox_feedback'] = 'notifications_api/view_inbox_feedback';
$route['view_outbox_feedback'] = 'notifications_api/view_outbox_feedback';
$route['view_inbox_document'] = 'notifications_api/view_inbox_document';
$route['view_outbox_document'] = 'notifications_api/view_outbox_document';
$route['view_inbox_archive'] = 'notifications_api/view_inbox_archive';
$route['view_outbox_archive'] = 'notifications_api/view_outbox_archive';
$route['get_student_by_course'] = 'notifications_api/get_student_by_course';
$route['get_parent_by_course'] = 'notifications_api/get_parent_by_course';
$route['add_notifications'] = 'notifications_api/add_notifications';
$route['archive_notifications'] = 'notifications_api/archive_notifications';
$route['restore_notifications'] = 'notifications_api/restore_notifications';
$route['preview_notifications'] = 'notifications_api/preview_notifications';
$route['reply_notifications'] = 'notifications_api/reply_notifications';
$route['mark_as_unread_notifications'] = 'notifications_api/mark_as_unread_notifications';
$route['mark_as_read_notifications'] = 'notifications_api/mark_as_read_notifications';
$route['mark_as_read_or_unread_notifications'] = 'notifications_api/mark_as_read_or_unread_notifications';
$route['get_inbox_count'] = 'notifications_api/get_inbox_count';
$route['update_is_seen'] = 'notifications_api/update_is_seen';
$route['get_subjects_for_search'] = 'notifications_api/get_subjects_for_search';
$route['get_un_seen_messages'] = 'notifications_api/get_un_seen_messages';
$route['get_msg_count'] = 'notifications_api/get_msg_count';
$route['update_is_seen_all'] = 'notifications_api/update_is_seen_all';

/** email templates **/
$route['view_email_templates'] = 'email_templates_api/view_email_templates';
$route['edit_email_templates'] = 'email_templates_api/edit_email_templates';
$route['get_languages'] = 'email_templates_api/get_languages';
$route['get_email_template_by_id'] = 'email_templates_api/get_email_template_by_id';
/** email settings **/
$route['email_settings'] = 'email_templates_api/email_settings';
$route['update_email_settings'] = 'email_templates_api/update_email_settings';

/** Language **/
$route['view_languages'] = 'languages_api/view_languages';
$route['add_languages'] = 'languages_api/add_languages';
$route['edit_languages'] = 'languages_api/edit_languages';
$route['delete_languages'] = 'languages_api/delete_languages';
$route['restore_languages'] = 'languages_api/restore_languages';
$route['set_status_languages'] = 'languages_api/set_status_languages';

/** System Settings **/
$route['system_settings'] = 'system_settings_api/system_settings';
$route['view_system_settings'] = 'system_settings_api/view_system_settings';
$route['add_system_settings'] = 'system_settings_api/add_system_settings';
$route['edit_system_settings'] = 'system_settings_api/edit_system_settings';
$route['delete_system_settings'] = 'system_settings_api/delete_system_settings';
$route['restore_system_settings'] = 'system_settings_api/restore_system_settings';
$route['set_status_system_settings'] = 'system_settings_api/set_status_system_settings';

/** Bulk Labeling **/
$route['bulk_labeling'] = 'bulk_labeling_api/bulk_labeling';
$route['view_modules'] = 'bulk_labeling_api/view_modules';
$route['view_filter_section'] = 'bulk_labeling_api/view_filter_section';
$route['view_filter_sub_section'] = 'bulk_labeling_api/view_filter_sub_section';
$route['edit_bulk_labeling'] = 'bulk_labeling_api/edit_bulk_labeling';
$route['edit_modules'] = 'bulk_labeling_api/edit_modules';

/** ACL Groups **/
$route['view_acl_groups'] = 'acl_groups_api/view_acl_groups';
$route['edit_acl_groups'] = 'acl_groups_api/edit_acl_groups';
$route['get_roles'] = 'acl_groups_api/get_roles';

/** Change Password **/
$route['edit_password'] = 'users_api/edit_password';
$route['admin_reset_password'] = 'users_api/admin_reset_password';

/** Forgot Password **/
$route['send_forgot_password'] = 'users_api/send_forgot_password';

/** Labels **/
$route['view_labels'] = 'labels_api/view_labels';
$route['add_labels'] = 'labels_api/add_labels';
$route['edit_labels'] = 'labels_api/edit_labels';
$route['set_status_labels'] = 'labels_api/set_status_labels';
$route['get_pages'] = 'labels_api/get_pages';
$route['get_sections'] = 'labels_api/get_sections';
$route['get_labels_language'] = 'labels_api/get_labels_language';

/** reports **/
$route['get_presets'] = 'reports_api/get_presets';
$route['save_report'] = 'reports_api/save_report';
$route['filter_report'] = 'reports_api/filter_report';
$route['open_preset_report'] = 'reports_api/open_preset_report';
$route['delete_reports'] = 'reports_api/delete_reports';

/** Builds **/
$route['view_builds'] = 'builds_api/view_builds';
$route['add_builds'] = 'builds_api/add_builds';
$route['edit_builds'] = 'builds_api/edit_builds';
$route['delete_builds'] = 'builds_api/delete_builds';

/** Builds Gogomo **/
$route['view_builds_gogomo'] = 'builds_gogomo_api/view_builds_gogomo';
$route['release_builds_gogomo'] = 'builds_gogomo_api/release_builds_gogomo';

/** Builds PS **/
$route['view_builds_ps'] = 'builds_ps_api/view_builds_ps';
$route['deploy_builds_ps'] = 'builds_ps_api/deploy_builds_ps';
$route['deploy_live_builds_ps'] = 'builds_ps_api/deploy_live_builds_ps';

/** Builds Box **/
$route['view_builds_box'] = 'builds_box_api/view_builds_box';
$route['download_builds_box'] = 'builds_box_api/download_builds_box';

/** Box **/
$route['view_box'] = 'box_api/view_box';
$route['repair_builds'] = 'box_api/repair_builds';

/** task **/
$route['view_tasks'] = 'tasks_api/view_tasks';
$route['add_tasks'] = 'tasks_api/add_tasks';
$route['change_tasks_status'] = 'tasks_api/change_tasks_status';
$route['get_task_categories'] = 'tasks_api/get_task_categories';
$route['view_students_task'] = 'tasks_api/view_students_task';
$route['check_task_user'] = 'tasks_api/check_task_user';
$route['set_task_rating'] = 'tasks_api/set_task_rating';
$route['set_task_comment'] = 'tasks_api/set_task_comment';
$route['set_annotations'] = 'tasks_api/set_annotations';
$route['get_annotations'] = 'tasks_api/get_annotations';
$route['check_task_dates'] = 'tasks_api/check_task_dates';
$route['get_view_annotations'] = 'tasks_api/get_view_annotations';
$route['view_task_logs'] = 'tasks_api/view_task_logs';
$route['update_task_pdf_status'] = 'tasks_api/update_task_pdf_status';
$route['check_annotation'] = 'tasks_api/check_annotation';


