<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Absences_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    //Absences API
	function index() 
	{		
		
	} 
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=42 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		return $label_details;
    }
	//absences
	function view_absences(){
		
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$type_fld = $data['type_fld'];
		$student_fld = $data['student_fld'];
		$reported_by_fld = $data['reported_by_fld'];
		$excusable_fld = $data['excusable_fld'];
		$excused_fld = $data['excused_fld'];
		$excused_by_parent_fld = $data['excused_by_parent_fld'];
		$start_date_fld = $data['start_date_fld'];
		$end_date_fld = $data['end_date_fld'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$delQuery = "";
		if($columnName=="")
		{
			$columnName = "a.created_at";
			$columnSortOrder = "desc";
		}
		if($term_fld=="")
		{
			$cond="select * from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
				$term_fld=$term_details[0]['id'];
			else
				$term_fld="";
		}
		/* if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		} */
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and a.is_active=".$status_fld;			
	    }
		if($excusable_fld != ''&&$excusable_fld != 'all'){
			$searchQuery .= " and a.is_excusable=".$excusable_fld;			
	    }
		if($excused_fld != ''&&$excused_fld != 'all'){
			$searchQuery .= " and a.is_excused=".$excused_fld;			
	    }
		if($excused_by_parent_fld != ''&&$excused_by_parent_fld != 'all'){
			$searchQuery .= " and a.is_excused_by_parent=".$excused_by_parent_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and a.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and a.is_deleted=0";	
		}
		$per_query='';
		$flag=true;
		$group_arr=explode(",",$group_id);
		if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
			{
				$per_query = " and st.student_id in(".$par_details[0]['student_id'].")";
				$cond="SELECT a.* FROM absences a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
			}
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and st.student_id=".$id;
			$cond="SELECT a.* FROM absences a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
		}
		else
		{
			$cond="SELECT a.* FROM absences a where 1".$delQuery.$searchQuery;
		}
		if($flag)
		{
			$totalRecord="";$totalRecordwithFilter="";$page_details=array();
			$page_details = $this->absences_model->special_fetch($cond);
			$totalRecord = count($page_details);
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$absence_category_id=$student['absence_category_id'];
				$student_term_id=$student['student_term_id'];
				$personnel_id =$student['personnel_id'];
				$cond="select student_id,term_id,coach_id,class_id,main_level_id from students_terms where id=".$student_term_id;
				$student_term_details = $this->absences_model->special_fetch($cond);
				if(count($student_term_details)>0)
				{
					$term_id=$student_term_details[0]['term_id'];
					$student_id=$student_term_details[0]['student_id'];
					$coach_id=$student_term_details[0]['coach_id'];
					$grade_id=$student_term_details[0]['class_id'];
					$study_level_id=$student_term_details[0]['main_level_id'];
					if($grade_id!="")
					{
						$cond="select name from classes where id=".$grade_id;
						$grade_details = $this->absences_model->special_fetch($cond);
						if(count($grade_details)>0)
							$grade=$grade_details[0]['name'];
						else
							$grade="";
					}
					else
						$grade="";
					if($study_level_id!="0"&&$study_level_id!="")
					{
						$cond="select name from main_levels where id=".$study_level_id;
						$study_level_details = $this->absences_model->special_fetch($cond);
						if(count($study_level_details)>0)
							$study_level=$study_level_details[0]['name'];
						else
							$study_level="";
					}
					else
						$study_level="";
					if($term_id!="")
					{
						$cond="select name from terms where id=".$term_id;
						$term_details = $this->absences_model->special_fetch($cond);
						if(count($term_details)>0)
							$term=$term_details[0]['name'];
						else
							$term="";
					}
					else
						$term="";
					if($student_id!="")
					{
						$cond="select first_name,last_name from users where id=".$student_id;
						$stu_details = $this->absences_model->special_fetch($cond);
						if(count($stu_details)>0)
							$student_name=$stu_details[0]['first_name']." ".$stu_details[0]['last_name'];
						else
							$student_name="";
					}
					else
						$student_name="";
					if($personnel_id!="")
					{
						$cond="select first_name,last_name from users where id=".$personnel_id;
						$per_details = $this->absences_model->special_fetch($cond);
						if(count($per_details)>0)
							$reported_by=$per_details[0]['first_name']." ".$per_details[0]['last_name'];
						else
							$reported_by="";
					}
					else
						$reported_by="";
					if($coach_id!="")
					{	
						$cond="select first_name,last_name from users where id=".$coach_id;
						$tutor_details = $this->absences_model->special_fetch($cond);
						if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
					}
					else
						$tutor="";
					$cond="select name from absence_categories where id=".$absence_category_id;
					$ab_details = $this->absences_model->special_fetch($cond);
					if(count($ab_details)>0)
						$absence_category=$ab_details[0]['name'];
					else
						$absence_category="";
					$st_timestamp=strtotime($student['datetime_from']);
					$en_timestamp=strtotime($student['datetime_to']);
					$start_date=date("F jS, Y", $st_timestamp);
					$end_date=date("F jS, Y", $en_timestamp);
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"absence_category"=>$absence_category,
						"start_date"=>$start_date,
						"end_date"=>$end_date,
						"dis_start_date"=>$student['datetime_from'],
						"dis_end_date"=>$student['datetime_to'],
						"startdate_timestamp"=>$student['startdate_timestamp'],
						"enddate_timestamp"=>$student['enddate_timestamp'],
						"justification"=>$student['justification'],
						"is_excusable"=>$student['is_excusable'],
						"is_excused"=>$student['is_excused'],
						"is_set_by_parent"=>$student['is_set_by_parent'],
						"is_excused_by_parent"=>$student['is_excused_by_parent'],
						"is_active"=>$student['is_active'],
						"is_deleted"=>$student['is_deleted'],
						"tutor"=>$tutor,
						"grade"=>$grade,
						"study_level"=>$study_level,
						"term_id"=>$term_id,
						"student_id"=>$student_id,
						"absence_category_id"=>$absence_category_id,
						"personnel_id"=>$personnel_id,
						"reported_by"=>$reported_by
					);
				}
			}
			$totalRecordwithFilter = $totalRecord;
			$student_filter_details=array();
			$filter_count=0;
			if($term_fld!=""||$type_fld!=""||$student_fld!=""||$reported_by_fld!=""||$start_date_fld!=""||$end_date_fld!="")
			{
				for($i=0;$i<count($student_all_details);$i++)
				{				
					$term_flag=true;$type_flag=true;$student_flag=true;$reported_by_flag=true;$start_date_flag=true;$end_date_flag=true;
					if($term_fld!="")
					{
						if($term_fld!=$student_all_details[$i]['term_id'])
							$term_flag=false;
					}
					if($student_fld!="")
					{
						$student_fld_arr=explode(",",$student_fld);
						if (!in_array($student_all_details[$i]['student_id'], $student_fld_arr))
							$student_flag=false;
					}
					if($type_fld!="")
					{
						if($type_fld!=$student_all_details[$i]['absence_category_id'])
							$type_flag=false;
					}
					if($reported_by_fld!="")
					{
						if($reported_by_fld!=$student_all_details[$i]['personnel_id'])
							$reported_by_flag=false;
					}
					if($start_date_fld!=""&&$end_date_fld=="")
					{
						$start_date=date("F jS, Y", strtotime($start_date_fld));
						if($start_date!=$student_all_details[$i]['start_date'])
							$start_date_flag=false;
					}
					else if($start_date_fld==""&&$end_date_fld!="")
					{
						$end_date=date("F jS, Y", strtotime($end_date_fld));
						if($end_date!=$student_all_details[$i]['end_date'])
						$end_date_flag=false;
					}
					else if($start_date_fld!=""&&$end_date_fld!="")
					{
						$start_timestamp=strtotime($start_date_fld);
						$end_timestamp=strtotime($end_date_fld);
						$end_timestamp = strtotime("tomorrow", $end_timestamp) - 1;
						$cur_st=$student_all_details[$i]['startdate_timestamp'];
						$cur_et=$student_all_details[$i]['enddate_timestamp'];
						if(!(($cur_st>$start_timestamp&&$cur_st<$end_timestamp)&&($cur_et>$start_timestamp&&$cur_et<$end_timestamp)))
						{
							$end_date_flag=false;
							$start_date_flag=false;
						}						
					}
					if($term_flag&&$student_flag&&$type_flag&&$reported_by_flag&&$end_date_flag&&$start_date_flag)
					{
						$student_filter_details[]=$student_all_details[$i];
					}
				}
				$filter_count=count($student_filter_details);
			}
			else
			{
				$student_filter_details=$student_all_details;
			}
			
			$search_count=0;
			$absences_details=array();
			if($searchValue != ''){
				for($i=0;$i<count($student_filter_details);$i++)
				{
					if(strpos(strtolower($student_filter_details[$i]['student_name']), strtolower($searchValue)) !== false||strpos(strtolower($student_filter_details[$i]['term']), strtolower($searchValue)) !== false||strpos(strtolower($student_filter_details[$i]['absence_category']), strtolower($searchValue)) !== false||strpos(strtolower($student_filter_details[$i]['start_date']), strtolower($searchValue)) !== false||strpos(strtolower($student_filter_details[$i]['end_date']), strtolower($searchValue)) !== false)
					{
						$absences_details[]=$student_filter_details[$i];
					}
				}
				$search_count=count($absences_details);
			}
			else{
				$absences_details=$student_filter_details;
			}
			
			if($filter_count==0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			else if($filter_count!=0&&$search_count==0)
				$totalRecordwithFilter=$filter_count;
			else if($filter_count!=0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($absences_details)<=0)
			{
				$absences_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($absences_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $absences_details);
			}
			$output = array_slice($absences_details, $limit, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function convert_date($date)
    {
		$new_date="";
		if(strpos($date, "/") !== false){
        	$str_date=explode("/",$date);
			$new_date=$str_date[1]."/".$str_date[0]."/".$str_date[2];
			return strtotime($new_date);
		}
		else if(strpos($date, "-") !== false){
        	$str_date=explode("-",$date);
			$new_date=$str_date[1]."-".$str_date[0]."-".$str_date[2];
			return strtotime($new_date);
		}
        return "";
    }
	function view_students_for_absences(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld_list = $data['term_fld_list'];
		$teacher_fld_list = $data['teacher_fld_list'];
		$grade_fld_list = $data['grade_fld_list'];
		$study_level_fld_list = $data['study_level_fld_list'];
		$student_fld_list = $data['student_fld_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($student_fld_list != ''){
			$searchQuery .= " and s.id=".$student_fld_list;			
	    }
		$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0".$searchQuery;
		$page_details = $this->students_terms_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$student_name=$student['first_name']." ".$student['last_name'];
			$grade="";$grade_id="";$study_level="";$study_level_id="";$tutor="";$tutor_id="";$term="";$term_id="";
			$cond="select * from students_terms where student_id=".$student['id'];
			$student_term_details = $this->students_terms_model->special_fetch($cond);
			if(count($student_term_details)>0)
			{
				$term_id=$student_term_details[0]['term_id'];
				$grade_id=$student_term_details[0]['class_id'];
				$study_level_id=$student_term_details[0]['main_level_id'];
				$tutor_id=$student_term_details[0]['coach_id'];
				$cond="select name from terms where id=".$term_id;
				$term_details = $this->students_terms_model->special_fetch($cond);
				$term=$term_details[0]['name'];				
				if($grade_id!="")
				{
					$cond="select name from classes where id=".$grade_id;
					$class_details = $this->students_terms_model->special_fetch($cond);
					if(count($class_details)>0)
						$grade=$class_details[0]['name'];
					else
						$grade="";
				}
				else
					$grade="";
				if($study_level_id!="0"&&$study_level_id!="")
				{
					$cond="select name from main_levels where id=".$study_level_id;
					$study_level_details = $this->students_terms_model->special_fetch($cond);
					if(count($study_level_details)>0)
						$study_level=$study_level_details[0]['name'];
					else
						$study_level="";
				}
				else
					$study_level="";
				if($tutor_id!="")
				{
					$cond="select first_name,last_name from users where id=".$tutor_id;
					$tutor_details = $this->students_terms_model->special_fetch($cond);
					if(count($tutor_details)>0)
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					else
						$tutor="";
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"class_id"=>$grade_id,
					"main_level_id"=>$study_level_id,
					"coach_id"=>$tutor_id
				);
			}
		}
		
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($grade_fld_list!=""||$teacher_fld_list!=""||$study_level_fld_list!=""||$term_fld_list!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;
				if($term_fld_list!="")
				{
					if($term_fld_list!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($grade_fld_list!="")
				{
					if($grade_fld_list!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld_list!="")
				{
					if($teacher_fld_list!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld_list!="")
				{
					if($study_level_fld_list!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		
		$search_count=0;
		$students_terms_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_terms_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_terms_details);
		}
		else{
			$students_terms_details=$student_filter_details;
		}
		
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count==0&&$search_count==0)
			$totalRecordwithFilter=0;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_terms_details)<=0)
		{
			$students_terms_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($students_terms_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_terms_details);
		}
		$output = array_slice($students_terms_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	
	function add_absences(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		$reported_by_id = $data['reported_by_id'];
		$type_id = $data['type_id'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$justification = $data['justification'];
		$excusable = $data['excusable'];
		$excused = $data['excused'];
		$status = $data['status'];
		$cond="select id from students_terms where student_id=".$student_id." and term_id=".$term_id;
		$student_term_details = $this->absences_model->special_fetch($cond);
		if(count($student_term_details)>0)
		{
			$student_term_id=$student_term_details[0]['id'];
			$start_timestamp=strtotime($start_date);
			$end_timestamp=strtotime($end_date);
			$input = array(
				'student_term_id'=>$student_term_id,
				'absence_category_id'=>$type_id,
				'personnel_id'=>$reported_by_id,
				'datetime_from'=>$start_date,
				'datetime_to'=>$end_date,
				'startdate_timestamp'=>$start_timestamp,
				'enddate_timestamp'=>$end_timestamp,
				'justification'=>$justification,
				'is_excusable'=>$excusable,
				'is_excused'=>$excused,
				'is_active'=>$status
			);
			$this->absences_model->add($input);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[155]['name']);		
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[270]['name']);	
		}
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function edit_absences(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$reported_by_id = $data['reported_by_id'];
		$type_id = $data['type_id'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$justification = $data['justification'];
		$excusable = $data['excusable'];
		$excused = $data['excused'];
		$status = $data['status'];
		$start_timestamp=strtotime($start_date);
		$end_timestamp=strtotime($end_date);
		$input = array(
			'absence_category_id'=>$type_id,
			'personnel_id'=>$reported_by_id,
			'datetime_from'=>$start_date,
			'datetime_to'=>$end_date,
			'startdate_timestamp'=>$start_timestamp,
			'enddate_timestamp'=>$end_timestamp,
			'justification'=>$justification,
			'is_excusable'=>$excusable,
			'is_excused'=>$excused,
			'is_active'=>$status
		);
		$this->absences_model->edit($input,$id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[156]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    	    
    function delete_absences(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id']; 
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->absences_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[157]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function restore_absences(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->absences_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[158]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function excuse_absences(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_excusable,is_excused from absences where id=".$id;
			$absence_details = $this->absences_model->special_fetch($cond);
			if(count($absence_details)>0)
			{
				if($absence_details[0]['is_excusable']==1)
				{
					if($absence_details[0]['is_excused']==1)
						$excused=0;
					else
						$excused=1;
					$input = array(
						'is_excused'=>$excused
					);
					$this->absences_model->edit($input,$id);
				}	
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[159]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_absences(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['student_name']==""||$page['reported_by']==""||$page['absence_category']==""||$page['start_date']==""||$page['end_date']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['reported_by'];
				$corrupt_arr[] =$page['absence_category'];
				$corrupt_arr[] =$page['start_date'];
				$corrupt_arr[] =$page['end_date'];
				$corrupt_arr[] =$page['justification'];
				$corrupt_arr[] =$page['excusable'];
				$corrupt_arr[] =$page['excused'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[271]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[161]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['reported_by_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[162]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['absence_category_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[163]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['start_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[164]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['end_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[165]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$term_id=0;
					$cond="select * from terms where is_deleted=0";
					$term_details = $this->users_model->special_fetch($cond);
					$cur_time=time();
					foreach($term_details as $term)
					{
						if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
						{
							$term_id=$term['id'];
						}
					}
					$cond="select id from students_terms where student_id=".$page['student_id']." and term_id=".$term_id;
					$student_term_details = $this->absences_model->special_fetch($cond);
					if(count($student_term_details)>0)
					{
						$student_term_id=$student_term_details[0]['id'];
						$start_timestamp=strtotime($page['start_date']);
						$end_timestamp=strtotime($page['end_date']);
						$input = array(
							'student_term_id'=>$student_term_id,
							'absence_category_id'=>$page['absence_category_id'],
							'personnel_id'=>$page['student_id'],
							'datetime_from'=>$page['start_date'],
							'datetime_to'=>$page['end_date'],
							'startdate_timestamp'=>$start_timestamp,
							'enddate_timestamp'=>$end_timestamp,
							'justification'=>$page['justification'],
							'is_excusable'=>$page['excusable_val'],
							'is_excused'=>$page['excused_val'],
							'is_active'=>$page['status_val']
						);	
						$this->absences_model->add($input);
						$flag=true;
					}
					else
					{
						$error_arr=array();
						$error_arr[] =$page['student_name'];
						$error_arr[] =$page['reported_by'];
						$error_arr[] =$page['absence_category'];
						$error_arr[] =$page['start_date'];
						$error_arr[] =$page['end_date'];
						$error_arr[] =$page['justification'];
						$error_arr[] =$page['excusable'];
						$error_arr[] =$page['excused'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[248]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[166]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function validateDate($date, $format = 'd-m-Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
	function get_absences_type(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from absence_categories where is_deleted=0 and is_active=1 order by name asc";
		$absence_type_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','absence_type_details'=>$absence_type_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }	
	function get_students_for_search(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$id = $data['id'];
		$group_id = $data['group_id'];
		$stu_details=array();
		$cond="select id from user_groups where user_id=".$id." and group_id=4";
		$usr_details = $this->users_model->special_fetch($cond);
		if($group_id==4)
		{
			$cond="select distinct u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id." order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
			$stu_details=array();	
			foreach($student_details as $student)
			{
				$name=$student['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$stu_details[]=array("id"=>$student['id'],"name"=>$name);
				}
			}
		}
		else if($group_id==5)
		{
			$cond="select u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0 and s.id=".$id." order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
			$stu_details=array();	
			foreach($student_details as $student)
			{
				$name=$student['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$stu_details[]=array("id"=>$student['id'],"name"=>$name);
				}
			}
		}
		else
		{
			$cond="select u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0 order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
			$stu_details=array();	
			foreach($student_details as $student)
			{
				$name=$student['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$stu_details[]=array("id"=>$student['id'],"name"=>$name);
				}
			}
		}
		$total_count=count($stu_details);
		$out = array('total_count'=>$total_count,'items'=>$stu_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_reported_by(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$cond="select u.id,concat(u.first_name,' ',u.last_name) as name from users u,personnel p where u.id=p.id and u.is_active=1 and p.is_deleted=0 order by name asc";
		$personnel_details = $this->users_model->special_fetch($cond);
		$per_details=array();	
		foreach($personnel_details as $personnel)
		{
			$name=$personnel['name'];
			if(strpos(strtolower($name), $search_term)!==false)
			{
				$per_details[]=array("id"=>$personnel['id'],"name"=>$name);
			}
		}
		$total_count=count($per_details);
		$out = array('total_count'=>$total_count,'items'=>$per_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
}
