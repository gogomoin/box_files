<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Acl_groups_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=56 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		return $label_details;
    }
	//acl_groups
	function view_acl_groups(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(name) like '%".$searchValue."%' or lower(group_key) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "c.created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from groups where 1".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from groups";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(id) as cnt from groups where 1".$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function get_roles()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$group_id = $data['group_id'];
		$cond="select id,page_name from inner_pages where order_no<>'' order by order_no asc";
        $page_details = $this->users_model->special_fetch($cond);
		if($lang_id!=1)
		{
			$i=0;
			foreach($page_details as $pages)
			{
				$cond="select name from labels where page_id=".$pages['id']." and lang_id=".$lang_id." and section_id=25 limit 1";
        		$lbl_details = $this->users_model->special_fetch($cond);
				if(count($lbl_details)>0)
					$page_details[$i]['page_name']=$lbl_details[0]['name'];
				$i++;
			}
		}
		if($lang_id!=1)
			$cond="select r.label_id as id,r.role,r.page_id from roles r where r.lang_id=".$lang_id;
		else
			$cond="select * from roles where lang_id=".$lang_id;
        $role_details = $this->users_model->special_fetch($cond);
		$cond="select * from group_roles where group_id=".$group_id;
        $group_role_details = $this->users_model->special_fetch($cond);
		if($lang_id!=1)
			$cond="select r.label_id as id,r.role,r.page_id from roles r where r.page_id=0 and r.lang_id=".$lang_id;
		else
			$cond="select * from roles where page_id=0 and lang_id=".$lang_id;
		$custom_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','page_details'=>$page_details,'role_details'=>$role_details,'group_role_details'=>$group_role_details,'custom_details'=>$custom_details);
		header('Content-Type:application/json');
        echo json_encode($out);
	}
    
    function edit_acl_groups(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$name = $data['name'];
		$roles_str = $data['roles'];
		$roles=explode(",",$roles_str);
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from groups where name='".$name."' and id<>".$id;
        $group_details = $this->users_model->special_fetch($cond);
		if(count($group_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'is_active'=>1
			);
			$this->acl_groups_model->edit($input,$id);
			$cond="select role_id from group_roles where group_id=".$id;
			$group_role_details = $this->users_model->special_fetch($cond);
			$old_roles=array();
			foreach($group_role_details as $role)
			{
				$old_roles[]=$role['role_id'];
			}
			$add_arr=array_diff($roles,$old_roles);
			$delete_arr=array_diff($old_roles,$roles);
			foreach($add_arr as $role)
			{
				$input = array(
					'role_id'=>$role,
					'group_id'=>$id
				);
				$this->group_roles_model->add($input);
			}
			foreach($delete_arr as $role)
			{
				$input = array(
					'role_id'=>$role,
					'group_id'=>$id
				);
				$this->group_roles_model->delete_role($input);
			}
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[26]['name']);
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[27]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
}
