<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Admin extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
			
		    $user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];			
            $this->get_include();
			$this->load->view($this->view_dir . 'admin/dashboard', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'admin/login', $this->data);
        }
	}    
    //Login and Logout
    function login(){
        $username = $this->input->post('username');
        $password = $this->input->post('password');
		$data_arr=array(
				'username'=>$username,
				'password'=>$password
			);
        $admin_details = $this->admin_model->get_records($data_arr);
		if(count($admin_details)>0){
			$data_arr=array(
				'username'=>$username,
				'status'=>0
			);
			$adm_details = $this->admin_model->get_records($data_arr);
			if(count($adm_details)>0)
			{
				$user_det = array('id'=>$admin_details[0]['admin_id'],'username'=>$username,'name'=>'Admin');
				$this->session->set_userdata('user_det',$user_det);
				redirect('/admin');
			}
			else
			{
				$this->data['error_message'] = 'Account Deactivated - Please Contact Administrator';
				$this->data['username'] = $username;
				$this->load->view($this->view_dir . 'admin/login', $this->data);
			}
		}
		else{
             $this->data['error_message'] = 'Invalid Username/Password';
             $this->data['username'] = $username;
             $this->load->view($this->view_dir . 'admin/login', $this->data);
		}        
    }
    
    function logout(){
         $this->session->sess_destroy();
         $this->data['error_message'] = 'Successfully Logged Out';
         $this->data['username'] = "";
         $this->load->view($this->view_dir . 'admin/login', $this->data); 
    }  
	//Address Fields
	function get_country(){
        
		$country_details = $this->admin_model->get_table_records('sbx_country',$data_field=array());
        if(count($country_details)>0){
            $out = array('statuscode'=>'200','country'=>$country_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function address_fields() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
            $this->get_include();
            $this->load->view($this->view_dir . 'admin/address_fields', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'admin/login', $this->data);
        }
	}
	function add_address_fields(){
        
        $country = $this->input->post('country');
        $fields = $this->input->post('fields');
        $admin_id = $this->input->post('admin_id');
		$data_arr=array(
				'country'=>$country
			);
        $address_fields_details = $this->admin_model->get_table_records('sbx_address_fields',$data_arr);
		if(count($address_fields_details)<=0)
		{
			$input = array(
				'country'=>$country,
				'fields'=>$fields,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->address_fields_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'Address Fields Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Create Address Fields');
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Address Fields Already Exists');
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_address_fields(){
       $country = $this->input->post('country');
        $fields = $this->input->post('fields');
        $address_fields_id = $this->input->post('address_fields_id');
		$cond="select address_fields_id from sbx_address_fields where country='".$country."' and address_fields_id<>".$address_fields_id;
        $address_fields_details = $this->admin_model->special_fetch($cond);
		if(count($address_fields_details)<=0)
		{
			$input = array(
				'country'=>$country,
				'fields'=>$fields
			);
			$mid = $this->address_fields_model->edit($input,$address_fields_id);        
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'Address Fields Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Update Address Fields');
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Address Fields Already Exists');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
    
    function delete_address_fields(){
        
        $address_fields_id = $this->input->post('address_fields_id');
		$cond="select country from sbx_address_fields where address_fields_id=".$address_fields_id;
        $address_fields_details = $this->admin_model->special_fetch($cond);
		$cond="select address_id from sbx_address where country_id=".$address_fields_details[0]['country'];
        $address_details = $this->admin_model->special_fetch($cond);
		if(count($address_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Unable To Delete - Address Fields Already Allocated');
		}
		else
		{
			$mid = $this->address_fields_model->delete($address_fields_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'Address Fields Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Delete Address Fields');
			}
		}        
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
     function view_address_fields(){
        
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
        
        $searchQuery = "";
        if($searchValue != ''){
             $searchQuery = " and (c.name like '%".$searchValue."%' or FIND_IN_SET('".$searchValue."', a.fields))";
        }        
		$cond="select a.*,c.name as country_name,c.country_id,ad.username as admin from sbx_address_fields a,sbx_country c,sbx_admin ad where a.country=c.country_id and ad.admin_id=a.admin_id ".$searchQuery." order by a.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);        
        $cond="select COUNT(address_fields_id) as cnt from sbx_address_fields";
        $maps_count = $this->admin_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(a.address_fields_id) as cnt from sbx_address_fields a,sbx_country c where a.country=c.country_id ".$searchQuery;
            $maps_count = $this->admin_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		
        $response = array(
          "draw" => intval($draw),
          "iTotalRecords" => $totalRecord,
          "iTotalDisplayRecords" => $totalRecordwithFilter,
          "aaData" => $customer_details
        );
        echo json_encode($response);        
    }
	function get_address_fields(){		
		$data_arr=array(
				'country'=>$this->input->post('country_id')
			);
		$address_fields_details = $this->admin_model->get_table_records('sbx_address_fields',$data_arr);
        if(count($address_fields_details)>0){
            $out = array('statuscode'=>'200','address_fields_details'=>$address_fields_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	//Address	
	function address() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
            $this->get_include();
            $this->load->view($this->view_dir . 'admin/address', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'admin/login', $this->data);
        }
	}
	
	function add_address(){        
        $country_id = $this->input->post('country');
        $fields = $this->input->post('fields');
        $admin_id = $this->input->post('admin_id');
		$data_arr=array(
				'country_id'=>$country_id,
				'fields'=>$fields,
				'admin_id'=>$admin_id,
			);
        $address_details = $this->admin_model->get_table_records('sbx_address',$data_arr);
		if(count($address_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'fields'=>$fields,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->address_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Address Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create Address');
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Address Already Exists');
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_address(){
        $country_id = $this->input->post('country');
        $fields = $this->input->post('fields');
        $admin_id = $this->input->post('admin_id');
        $address_id = $this->input->post('address_id');
		$cond="select address_id from sbx_address where country_id=".$country_id." and fields='".$fields."' and address_id<>".$address_id;
        $address_details = $this->admin_model->special_fetch($cond);
		if(count($address_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'fields'=>$fields
			);
			$mid = $this->address_model->edit($input,$address_id);        
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Address Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Address');
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Address Already Exists');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
    
    function delete_address(){
        
        $address_id = $this->input->post('address_id');
		$cond="select user_id from sbx_user where address_id=".$address_id;
        $user_details = $this->admin_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Address Already Allocated To User');
		}
		else
		{
			$mid = $this->address_model->delete($address_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Address Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Address');
			}
		}        
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
     function view_address(){
        
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
        
        $searchQuery = "";
        if($searchValue != ''){
             $searchQuery = " and (c.name like '%".$searchValue."%'  or FIND_IN_SET('".$searchValue."', a.fields))";
        }        
		$cond="select a.*,c.name as country_name,c.country_id,ad.username as admin from sbx_address a,sbx_country c,sbx_admin ad where a.country_id=c.country_id and ad.admin_id=a.admin_id ".$searchQuery." order by a.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);        
        $cond="select COUNT(address_id) as cnt from sbx_address";
        $maps_count = $this->admin_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(a.address_id) as cnt from sbx_address a,sbx_country c where a.country_id=c.country_id ".$searchQuery;
            $maps_count = $this->admin_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
        $response = array(
          "draw" => intval($draw),
          "iTotalRecords" => $totalRecord,
          "iTotalDisplayRecords" => $totalRecordwithFilter,
          "aaData" => $customer_details
        );
        echo json_encode($response);        
    }
	function get_address(){
    	$country_id=$this->input->post('country_id');
		$cond="select a.*,c.name as country from sbx_address a,sbx_country c where a.country_id=c.country_id and a.country_id=".$country_id;
		$address_details = $this->admin_model->special_fetch($cond);
		if(count($address_details)>0){
            $out = array('statuscode'=>'200','address_details'=>$address_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function import_address(){
		$country_id=$this->input->post('country_id_imp');
		$user_det = $this->session->userdata('user_det');
		$admin_id=$user_det['id'];
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$address_details = $this->admin_model->special_fetch($cond);
		$cond="select name from sbx_country where country_id=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$country=$con_details[0]['name'];
		$fld_arr=explode(",",$address_details[0]['fields']);
		$num=count($fld_arr);
		$path = $_FILES["import_address_file"]["tmp_name"];
		$target_dir = "./assets/uploads/address/";
		$target_file = $target_dir . time().'.xls';

		move_uploaded_file($path, $target_file);

		$excel = new Excel_Reader();
		$excel->read($target_file);
		$user_det = $this->session->userdata('user_det');
		$corrupt = array();
		$error_rows = array();
		$data = array();
		$out = array();
		$k=0;
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				$require_flag=true;
				$keys = array_keys($sheet['cells'][$r]);
				if(count($keys)>0)
				{
					if(count($keys)==$num+1)
					{
						$fields='';
						for($i=2;$i<=$num+1;$i++)
						{
							if($fields=="")
								$fields=trim($sheet['cells'][$r][$i]);
							else
								$fields=$fields.",".trim($sheet['cells'][$r][$i]);
						}
						$data[]=$fields;
					}
					else
					{
						$corrupt_arr=array();
						for($i=1;$i<=$num+1;$i++)
						{
							if(in_array($i, $keys))
								$corrupt_arr[] =trim($sheet['cells'][$r][$i]);
							else
								$corrupt_arr[] ="";
						}
						$corrupt_arr[] ='Please Fill Required Fields';
						$corrupt[$k]=$corrupt_arr;
						$k++;
					}
				}
			}
		}
		//unlink($target_file);
		if(count($data)>0)
		{
			$i=0;
			foreach($data as $flds)
			{
				$cond="select address_id from sbx_address where fields='".$flds."' and admin_id=".$admin_id;
				$address_details = $this->admin_model->special_fetch($cond);
				if(count($address_details)<=0)
				{
					$input = array(
						'country_id'=>$country_id,
						'fields'=>$flds,
						'admin_id'=>$admin_id,
						'created_on'=>time()
					);
					$this->address_model->add($input);
				}
				else
				{
					$error_rows_arr=array();
					$error_rows_arr[]=$country;
					$field_arr=explode(",",$flds);
					for($i=0;$i<count($field_arr);$i++)
					{
						$error_rows_arr[]=$field_arr[$i];
					}
					$error_rows_arr[]='Address Already Exists';
					$error_rows[$i]=$error_rows_arr;
					$i++;
				}
			}
			$out = array(
				'statuscode' => "200",
				'statusdescription'=>'Address Imported Successfully',
				'error_rows'=>$error_rows
			);
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Unable To Import Address - No Address Found','error_rows'=>array());
		}
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}

	//Roles
	function roles() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
            $this->get_include();
            $this->load->view($this->view_dir . 'admin/roles', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'admin/login', $this->data);
        }
	}
	function add_role(){
		$role_name = join(',', array_map('ucwords', explode(',', $this->input->post('role_name'))));
		$admin_id = $this->input->post('admin_id');
		$data_arr=array(
			'role_name'=>$role_name
		);
		$role_details = $this->admin_model->get_table_records('sbx_roles',$data_arr);
		if(count($role_details)<=0) {
			$input = array(
				'role_name' => $role_name,
				'admin_id' => $admin_id,
				'created_on' => time()
			);
			if (isset($_POST['chk_all']))
				$input['select_all'] = 0;
			if (isset($_POST['chk_settings']))
				$input['settings'] = 0;
			if (isset($_POST['chk_address_fields']))
				$input['address_fields'] = 0;
			if (isset($_POST['chk_address']))
				$input['address'] = 0;
			if (isset($_POST['chk_company']))
				$input['company'] = 0;
			if (isset($_POST['chk_id_proof']))
				$input['id_proof'] = 0;
			if (isset($_POST['chk_roles']))
				$input['roles'] = 0;
			if (isset($_POST['chk_sub_admin']))
				$input['sub_admin'] = 0;
			if (isset($_POST['chk_smart_box']))
				$input['chk_smart_box'] = 0;
			if (isset($_POST['chk_user']))
				$input['chk_user'] = 0;
			if (isset($_POST['chk_components']))
				$input['chk_components'] = 0;
			if (isset($_POST['chk_category']))
				$input['category'] = 0;
			if (isset($_POST['chk_sub_category_fields']))
				$input['address_fields'] = 0;
			if(isset($_POST['grp_address_fields'])) {
				$grp_address_fields = $_POST['grp_address_fields'];
				for ($i = 0; $i < count($grp_address_fields); $i++) {
					$input[$grp_address_fields[$i]] = 0;
				}
			}
			if(isset($_POST['grp_address'])) {
				$grp_address = $_POST['grp_address'];
				for ($i = 0; $i < count($grp_address); $i++) {
					$input[$grp_address[$i]] = 0;
				}
			}
			if(isset($_POST['grp_company'])) {
				$grp_company = $_POST['grp_company'];
				for ($i = 0; $i < count($grp_company); $i++) {
					$input[$grp_company[$i]] = 0;
				}
			}
			if(isset($_POST['grp_id_proof'])) {
				$grp_id_proof = $_POST['grp_id_proof'];
				for ($i = 0; $i < count($grp_id_proof); $i++) {
					$input[$grp_id_proof[$i]] = 0;
				}
			}
			if(isset($_POST['grp_role']))
			{
				$grp_role = $_POST['grp_role'];
				for ($i = 0; $i < count($grp_role); $i++) {
					$input[$grp_role[$i]] = 0;
				}
			}
			if(isset($_POST['grp_smart_box']))
			{
				$grp_smart_box = $_POST['grp_smart_box'];
				for ($i = 0; $i < count($grp_smart_box); $i++) {
					$input[$grp_smart_box[$i]] = 0;
				}
			}
			if(isset($_POST['grp_components']))
			{
				$grp_components = $_POST['grp_components'];
				for ($i = 0; $i < count($grp_components); $i++) {
					$input[$grp_components[$i]] = 0;
				}
			}
			if(isset($_POST['grp_user']))
			{
				$grp_user = $_POST['grp_user'];
				for ($i = 0; $i < count($grp_user); $i++) {
					$input[$grp_user[$i]] = 0;
				}
			}
			if(isset($_POST['grp_sub_admin']))
			{
				$grp_sub_admin = $_POST['grp_sub_admin'];
				for ($i = 0; $i < count($grp_sub_admin); $i++) {
					$input[$grp_sub_admin[$i]] = 0;
				}
			}
			if(isset($_POST['grp_category']))
			{
				$grp_category = $_POST['grp_category'];
				for ($i = 0; $i < count($grp_category); $i++) {
					$input[$grp_category[$i]] = 0;
				}
			}
			if(isset($_POST['grp_sub_category_fields'])) {
				$grp_sub_category_fields = $_POST['grp_sub_category_fields'];
				for ($i = 0; $i < count($grp_sub_category_fields); $i++) {
					$input[$grp_sub_category_fields[$i]] = 0;
				}
			}
			$this->role_model->add($input);
			$out = array('statuscode'=>'200','statusdescription'=>' Role Created Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Role Already Exists');
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_role(){
		$role_name = join(',', array_map('ucwords', explode(',', $this->input->post('role_name'))));
		$role_id = $this->input->post('role_id');
		$cond="select role_id from sbx_roles where role_name='".$role_name."' and role_id<>".$role_id;
		$role_details = $this->admin_model->special_fetch($cond);
		if(count($role_details)<=0)
		{
			$input = array(
				'role_name' => $role_name
			);
			if (isset($_POST['chk_all_up']))
				$input['select_all'] = 0;
			else
				$input['select_all'] = 1;
			if (isset($_POST['chk_settings_up']))
				$input['settings'] = 0;
			else
				$input['settings'] = 1;
			if (isset($_POST['chk_address_fields_up']))
				$input['address_fields'] = 0;
			else
				$input['address_fields'] = 1;
			if (isset($_POST['chk_address_up']))
				$input['address'] = 0;
			else
				$input['address'] = 1;
			if (isset($_POST['chk_company_up']))
				$input['company'] = 0;
			else
				$input['company'] = 1;
			if (isset($_POST['chk_id_proof_up']))
				$input['id_proof'] = 0;
			else
				$input['id_proof'] = 1;
			if (isset($_POST['chk_roles_up']))
				$input['roles'] = 0;
			else
				$input['roles'] = 1;
			if (isset($_POST['chk_sub_admin_up']))
				$input['sub_admin'] = 0;
			else
				$input['sub_admin'] = 1;
			if (isset($_POST['chk_components_up']))
				$input['components'] = 0;
			else
				$input['components'] = 1;
			if (isset($_POST['chk_user_up']))
				$input['user'] = 0;
			else
				$input['user'] = 1;
			if (isset($_POST['chk_smart_box_up']))
				$input['smart_box'] = 0;
			else
				$input['smart_box'] = 1;
			if (isset($_POST['chk_category_up']))
				$input['category'] = 0;
			else
				$input['category'] = 1;
			if (isset($_POST['chk_sub_category_fields_up']))
				$input['sub_category_fields'] = 0;
			else
				$input['sub_category_fields'] = 1;
			//Address Fields
			$grp_address_fields_arr=array("s_af_add","s_af_edit","s_af_del","s_af_view");
			if(isset($_POST['grp_address_fields_up'])) {
				$grp_address_fields = $_POST['grp_address_fields_up'];
				for ($i = 0; $i < count($grp_address_fields); $i++) {
					$input[$grp_address_fields[$i]] = 0;
					unset($grp_address_fields_arr[array_search($grp_address_fields[$i], $grp_address_fields_arr)]);
				}
				$grp_address_fields_arr_set = array_values($grp_address_fields_arr);
				for ($i = 0; $i < count($grp_address_fields_arr_set); $i++) {
					$input[$grp_address_fields_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_address_fields_arr); $i++) {
					$input[$grp_address_fields_arr[$i]] = 1;
				}
			}
			//Address
			$grp_address_arr=array("s_a_add","s_a_edit","s_a_del","s_a_view","s_a_export","s_a_import");
			if(isset($_POST['grp_address_up'])) {
				$grp_address = $_POST['grp_address_up'];
				for ($i = 0; $i < count($grp_address); $i++) {
					$input[$grp_address[$i]] = 0;
					unset($grp_address_arr[array_search($grp_address[$i], $grp_address_arr)]);
				}
				$grp_address_arr_set = array_values($grp_address_arr);
				for ($i = 0; $i < count($grp_address_arr_set); $i++) {
					$input[$grp_address_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_address_arr); $i++) {
					$input[$grp_address_arr[$i]] = 1;
				}
			}
			//Company
			$grp_company_arr=array("s_com_add","s_com_edit","s_com_delete","s_com_view");
			if(isset($_POST['grp_company_up'])) {
				$grp_company = $_POST['grp_company_up'];
				for ($i = 0; $i < count($grp_company); $i++) {
					$input[$grp_company[$i]] = 0;
					unset($grp_company_arr[array_search($grp_company[$i], $grp_company_arr)]);
				}
				$grp_company_arr_set = array_values($grp_company_arr);
				for ($i = 0; $i < count($grp_company_arr_set); $i++) {
					$input[$grp_company_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_company_arr); $i++) {
					$input[$grp_company_arr[$i]] = 1;
				}
			}
			//ID Proof
			$grp_id_proof_arr=array("s_id_add","s_id_edit","s_id_delete","s_id_view");
			if(isset($_POST['grp_id_proof_up'])) {
				$grp_id_proof = $_POST['grp_id_proof_up'];
				for ($i = 0; $i < count($grp_id_proof); $i++) {
					$input[$grp_id_proof[$i]] = 0;
					unset($grp_id_proof_arr[array_search($grp_id_proof[$i], $grp_id_proof_arr)]);
				}
				$grp_id_proof_arr_set = array_values($grp_id_proof_arr);
				for ($i = 0; $i < count($grp_id_proof_arr_set); $i++) {
					$input[$grp_id_proof_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_id_proof_arr); $i++) {
					$input[$grp_id_proof_arr[$i]] = 1;
				}
			}
			//Roles
			$grp_role_arr=array("ro_add","ro_edit","ro_view","ro_delete");
			if(isset($_POST['grp_role_up']))
			{
				$grp_role = $_POST['grp_role_up'];
				for ($i = 0; $i < count($grp_role); $i++) {
					$input[$grp_role[$i]] = 0;
					unset($grp_role_arr[array_search($grp_role[$i], $grp_role_arr)]);
				}
				$grp_role_arr_set = array_values($grp_role_arr);
				for ($i = 0; $i < count($grp_role_arr_set); $i++) {
					$input[$grp_role_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_role_arr); $i++) {
					$input[$grp_role_arr[$i]] = 1;
				}
			}
			//Smart Box
			$grp_smart_box_arr=array("sm_add","sm_edit","sm_view","sm_delete","sm_status","sm_components","sm_cmp_allocate","sm_admin");
			if(isset($_POST['grp_smart_box_up']))
			{
				$grp_smart_box = $_POST['grp_smart_box_up'];
				for ($i = 0; $i < count($grp_smart_box); $i++) {
					$input[$grp_smart_box[$i]] = 0;
					unset($grp_smart_box_arr[array_search($grp_smart_box[$i], $grp_smart_box_arr)]);
				}
				$grp_smart_box_arr_set = array_values($grp_smart_box_arr);
				for ($i = 0; $i < count($grp_smart_box_arr_set); $i++) {
					$input[$grp_smart_box_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_smart_box_arr); $i++) {
					$input[$grp_smart_box_arr[$i]] = 1;
				}
			}

			//Components
			$grp_user_arr=array("cmp_add","cmp_edit","cmp_view","cmp_delete","cmp_status","cmp_export","cmp_import");
			if(isset($_POST['grp_components_up']))
			{
				$grp_components = $_POST['grp_components_up'];
				for ($i = 0; $i < count($grp_components); $i++) {
					$input[$grp_components[$i]] = 0;
					unset($grp_components_arr[array_search($grp_components[$i], $grp_components_arr)]);
				}
				$grp_components_arr_set = array_values($grp_components_arr);
				for ($i = 0; $i < count($grp_components_arr_set); $i++) {
					$input[$grp_components_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_components_arr); $i++) {
					$input[$grp_components_arr[$i]] = 1;
				}
			}

			//User
			$grp_user_arr=array("u_add","u_edit","u_view","u_delete","u_status","u_export","u_import");
			if(isset($_POST['grp_user_up']))
			{
				$grp_user = $_POST['grp_user_up'];
				for ($i = 0; $i < count($grp_user); $i++) {
					$input[$grp_user[$i]] = 0;
					unset($grp_user_arr[array_search($grp_user[$i], $grp_user_arr)]);
				}
				$grp_user_arr_set = array_values($grp_user_arr);
				for ($i = 0; $i < count($grp_user_arr_set); $i++) {
					$input[$grp_user_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_user_arr); $i++) {
					$input[$grp_user_arr[$i]] = 1;
				}
			}
			//Sub Admin
			$grp_sub_admin_arr=array("ad_add","ad_edit","ad_view","ad_delete","ad_status");
			if(isset($_POST['grp_sub_admin_up']))
			{
				$grp_sub_admin = $_POST['grp_sub_admin_up'];
				for ($i = 0; $i < count($grp_sub_admin); $i++) {
					$input[$grp_sub_admin[$i]] = 0;
					unset($grp_sub_admin_arr[array_search($grp_sub_admin[$i], $grp_sub_admin_arr)]);
				}
				$grp_sub_admin_arr_set = array_values($grp_sub_admin_arr);
				for ($i = 0; $i < count($grp_sub_admin_arr_set); $i++) {
					$input[$grp_sub_admin_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_sub_admin_arr); $i++) {
					$input[$grp_sub_admin_arr[$i]] = 1;
				}
			}
			//Category
			$grp_category_arr=array("cat_add","cat_edit","cat_view","cat_delete");
			if(isset($_POST['grp_category_up']))
			{
				$grp_category = $_POST['grp_category_up'];
				for ($i = 0; $i < count($grp_category); $i++) {
					$input[$grp_category[$i]] = 0;
					unset($grp_category_arr[array_search($grp_category[$i], $grp_category_arr)]);
				}
				$grp_category_arr_set = array_values($grp_category_arr);
				for ($i = 0; $i < count($grp_category_arr_set); $i++) {
					$input[$grp_category_arr_set[$i]] = 1;
				}
			}
			else
			{
				for ($i = 0; $i < count($grp_category_arr); $i++) {
					$input[$grp_category_arr[$i]] = 1;
				}
			}
			
			$this->role_model->edit($input,$role_id);
			$out = array('statuscode'=>'200','statusdescription'=>' Role Updated Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Role Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
    }
    
    function delete_role(){

		$role_id = $this->input->post('role_id');
		$cond="select admin_id from sbx_admin where role_id=".$role_id;
        $role_details = $this->admin_model->special_fetch($cond);
		if(count($role_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Role Already Allocated');
		}
		else
		{
			$mid = $this->role_model->delete($role_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Role Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Role');
			}
		}        
        header('Content-Type:application/json');
        echo json_encode($out);        
    }

    function view_roles(){
        
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
        
        $searchQuery = "";
        if($searchValue != ''){
             $searchQuery = " and (r.role_name like '%".$searchValue."%')";
        }        
		$cond="select r.*,ad.username as admin from sbx_roles r,sbx_admin ad where ad.admin_id=r.admin_id ".$searchQuery." order by r.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);        
        $cond="select COUNT(role_id) as cnt from sbx_roles";
        $maps_count = $this->admin_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(role_id) as cnt from sbx_roles where 1".$searchQuery;
            $maps_count = $this->admin_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		
        $response = array(
          "draw" => intval($draw),
          "iTotalRecords" => $totalRecord,
          "iTotalDisplayRecords" => $totalRecordwithFilter,
          "aaData" => $customer_details
        );
        echo json_encode($response);        
    }
	function get_role(){		
		$data_arr=array(
				'role_id'=>$this->input->post('role_id')
			);
		$role_details = $this->admin_model->get_table_records('sbx_roles',$data_arr);
        if(count($role_details)>0){
            $out = array('statuscode'=>'200','role_details'=>$role_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function get_roles(){
		$cond="select role_id,role_name from sbx_roles";
		$role_details = $this->admin_model->special_fetch($cond);
		if(count($role_details)>0){
			$out = array('statuscode'=>'200','role_details'=>$role_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
    //Company
	function company()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/company', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_company(){

		$com_name = $this->input->post('com_name');
		$com_email = $this->input->post('com_email');
		$com_conact_no = $this->input->post('com_conact_no');
		$com_address = $this->input->post('com_address');
		$contact_person_name = $this->input->post('contact_person_name');
		$admin_id = $this->input->post('admin_id');
		$com_logo = '';
		if($_FILES['com_logo_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/company';
			$com_logo = time().'_'.basename($_FILES["com_logo_file"]["name"]);
			move_uploaded_file($_FILES["com_logo_file"]["tmp_name"], "$uploads_dir/$com_logo");
		}
		$data_arr=array(
			'com_name'=>$com_name
		);
		$com_details = $this->admin_model->get_table_records('sbx_company',$data_arr);
		if(count($com_details)<=0)
		{
			$input = array(
				'com_name'=>$com_name,
				'com_email'=>$com_email,
				'com_conact_no'=>$com_conact_no,
				'com_address'=>$com_address,
				'contact_person_name'=>$contact_person_name,
				'admin_id'=>$admin_id,
				'com_logo'=>$com_logo,
				'created_on'=>time()
			);
			$this->company_model->add($input);
			$out = array('statuscode'=>'200','statusdescription'=>'Company Created Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Company Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_company(){

		$com_name = $this->input->post('com_name');
		$com_id = $this->input->post('com_id');
		$cond="select com_id from sbx_company where com_name='".$com_name."' and com_id<>".$com_id;
		$com_details = $this->admin_model->special_fetch($cond);
		if(count($com_details)<=0)
		{
			$cond="select com_logo from sbx_company where com_id=".$com_id;
			$com_details = $this->admin_model->special_fetch($cond);
			$com_email = $this->input->post('com_email');
			$com_conact_no = $this->input->post('com_conact_no');
			$com_address = $this->input->post('com_address');
			$contact_person_name = $this->input->post('contact_person_name');
			$com_logo = $com_details[0]['com_logo'];
			if($_FILES['com_logo_file']['name'] != ''){
				$uploads_dir = 'assets/uploads/company';
				$com_logo = time().'_'.basename($_FILES["com_logo_file"]["name"]);
				move_uploaded_file($_FILES["com_logo_file"]["tmp_name"], "$uploads_dir/$com_logo");
			}
			$input = array(
				'com_name'=>$com_name,
				'com_email'=>$com_email,
				'com_conact_no'=>$com_conact_no,
				'com_address'=>$com_address,
				'contact_person_name'=>$contact_person_name,
				'com_logo'=>$com_logo
			);
			$this->company_model->edit($input,$com_id);
			$out = array('statuscode'=>'200','statusdescription'=>' Company Updated Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Company Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_company(){
		$com_id = $this->input->post('com_id');
		$cond="select user_id from sbx_user where com_id=".$com_id;
		$user_details = $this->admin_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Company Already Allocated');
		}
		else
		{
			$mid = $this->company_model->delete($com_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Company Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Company');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function view_company(){
		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (r.com_name like '%".$searchValue."%')";
		}
		$cond="select c.*,ad.username as admin from sbx_company c,sbx_admin ad where ad.admin_id=c.admin_id ".$searchQuery." order by c.created_on desc limit ".$start.",".$rowperpage;
		$com_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(com_id) as cnt from sbx_company";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(com_id) as cnt from sbx_company where 1".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $com_details
		);
		echo json_encode($response);
	}
	function get_company(){
		$data_arr=array(
			'com_id'=>$this->input->post('com_id')
		);
		$com_details = $this->admin_model->get_table_records('sbx_company',$data_arr);
		if(count($com_details)>0){
			$out = array('statuscode'=>'200','com_details'=>$com_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_companies(){
		$cond="select * from sbx_company";
		$com_details = $this->admin_model->special_fetch($cond);
		if(count($com_details)>0){
			$out = array('statuscode'=>'200','com_details'=>$com_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	//ID Proof
	function id_proof()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/id_proof', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_id_proof(){
		$country_id = $this->input->post('country_id');
		$id_proof = join(',', array_map('ucwords', explode(',', $this->input->post('id_proof'))));
		$admin_id = $this->input->post('admin_id');
		$data_arr=array(
			'country_id'=>$country_id,
			'id_proof'=>$id_proof
		);
		$id_proof_details = $this->admin_model->get_table_records('sbx_id_proof',$data_arr);
		if(count($id_proof_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'id_proof'=>$id_proof,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->id_proof_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'ID Proof Name Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Create ID Proof Name');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'ID Proof Name Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_id_proof(){
		$country_id = $this->input->post('country_id');
		$id_proof = join(',', array_map('ucwords', explode(',', $this->input->post('id_proof_up'))));
		$admin_id = $this->input->post('admin_id');
		$id_proof_id = $this->input->post('id_proof_id');
		$cond="select id_proof_id from sbx_id_proof where country_id=".$country_id." and id_proof='".$id_proof."' and id_proof_id<>".$id_proof_id;
		$id_proof_details = $this->admin_model->special_fetch($cond);
		if(count($id_proof_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'id_proof'=>$id_proof
			);
			$mid = $this->id_proof_model->edit($input,$id_proof_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'ID Proof Name Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Update ID Proof Name');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'ID Proof Name Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_id_proof(){

		$id_proof_id = $this->input->post('id_proof_id');
		$cond="select admin_id from sbx_admin where id_proof_id=".$id_proof_id;
		$admin_details = $this->admin_model->special_fetch($cond);
		if(count($admin_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - ID Proof Name Already Allocated');
		}
		else
		{
			$mid = $this->id_proof_model->delete($id_proof_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' ID Proof Name Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete ID Proof Name');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function view_id_proof(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (c.name like '%".$searchValue."%'  or i.id_proof like '%".$searchValue."%')";
		}
		$cond="select i.*,c.name as country_name,c.country_id,ad.username as admin from sbx_id_proof i,sbx_country c,sbx_admin ad where i.country_id=c.country_id and ad.admin_id=i.admin_id ".$searchQuery." order by i.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(id_proof_id) as cnt from sbx_id_proof";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(i.id_proof) as cnt from sbx_id_proof i,sbx_country c where i.country_id=c.country_id ".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}

		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $customer_details
		);
		echo json_encode($response);
	}
	function get_id_proof(){
		$country_id=$this->input->post('country_id');
		$cond="select i.*,c.name as country from sbx_id_proof i,sbx_country c where i.country_id=c.country_id and i.country_id=".$country_id;
		$id_proof_details = $this->admin_model->special_fetch($cond);
		if(count($id_proof_details)>0){
			$out = array('statuscode'=>'200','id_proof_details'=>$id_proof_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_id_proofs(){
		$cond="select * from sbx_id_proof";
		$id_proof_details = $this->admin_model->special_fetch($cond);
		if(count($id_proof_details)>0){
			$out = array('statuscode'=>'200','id_proof_details'=>$id_proof_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	//Admin
	function sub_admin()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/sub_admin', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_sub_admin(){

		$username = $this->input->post('username');
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$phone_no = $this->input->post('phone_no');
		$id_proof_id = $this->input->post('id_proof_name');
		$date_of_birth = $this->input->post('date_of_birth');
		$gender = $this->input->post('gender');
		$dept_name = $this->input->post('dept_name');
		$designation = $this->input->post('designation');
		$address = $this->input->post('address');
		$role_id = $this->input->post('role_name');
		$com_id = $this->input->post('com_name');
		$country_id = $this->input->post('country');
		$created_by = $this->input->post('admin_id');
		$photo = '';
		if($_FILES['photo_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/photos';
			$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
			move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
		}
		$id_proof = '';
		if($_FILES['id_proof_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/photos';
			$id_proof = time().'_'.basename($_FILES["id_proof_file"]["name"]);
			move_uploaded_file($_FILES["id_proof_file"]["tmp_name"], "$uploads_dir/$id_proof");
		}
		$data_arr=array(
			'username'=>$username
		);
		$admin_details = $this->admin_model->get_table_records('sbx_admin',$data_arr);
		if(count($admin_details)<=0)
		{
			$input = array(
				'username'=>$username,
				'password'=>'1234',
				'name'=>$name,
				'email'=>$email,
				'phone_no'=>$phone_no,
				'photo'=>$photo,
				'id_proof'=>$id_proof,
				'id_proof_id'=>$id_proof_id,
				'date_of_birth'=>$date_of_birth,
				'gender'=>$gender,
				'dept_name'=>$dept_name,
				'designation'=>$designation,
				'address'=>$address,
				'com_id'=>$com_id,
				'role_id'=>$role_id,
				'country_id'=>$country_id,
				'created_by'=>$created_by,
				'created_on'=>time()
			);
			$mid = $this->sub_admin_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Admin Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create Admin');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Admin Username Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_sub_admin(){
		$admin_id = $this->input->post('admin_id');
		$username = $this->input->post('username');
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$phone_no = $this->input->post('phone_no');
		$id_proof_id = $this->input->post('id_proof_name');
		if($id_proof_id=="")
			$id_proof_id=0;
		$date_of_birth = $this->input->post('date_of_birth');
		$gender = $this->input->post('gender');
		$dept_name = $this->input->post('dept_name');
		$designation = $this->input->post('designation');
		$address = $this->input->post('address');
		$role_id = $this->input->post('role_name');
		if($role_id=="")
			$role_id=0;
		$com_id = $this->input->post('com_name');
		if($com_id=="")
			$com_id=0;
		$country_id = $this->input->post('country');
		if($country_id=="")
			$country_id=0;
		$photo_file_name = $this->input->post('photo_file_name');
		$id_proof_file_name = $this->input->post('id_proof_file_name');
		$cond="select admin_id from sbx_admin where admin_id<>".$admin_id." and username='".$username."'";
		$admin_details = $this->admin_model->special_fetch($cond);
		if(count($admin_details)<=0)
		{
			$cond="select photo,id_proof from sbx_admin where admin_id=".$admin_id;
			$adm_details = $this->admin_model->special_fetch($cond);
			if($adm_details[0]['photo']=="")
			{
				$photo = '';
				if($_FILES['photo_file']['name'] != ''){
					$uploads_dir = 'assets/uploads/photos';
					$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
					move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
				}
			}
			else{
				if($adm_details[0]['photo']!=$photo_file_name)
				{
					$photo = '';
					if($_FILES['photo_file']['name'] != ''){
						$uploads_dir = 'assets/uploads/photos';
						$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
						move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
					}
				}
				else
					$photo = $adm_details[0]['photo'];
			}
			if($adm_details[0]['id_proof']=="")
			{
				$id_proof = '';
				if ($_FILES['id_proof_file']['name'] != '') {
					$uploads_dir = 'assets/uploads/photos';
					$id_proof = time() . '_' . basename($_FILES["id_proof_file"]["name"]);
					move_uploaded_file($_FILES["id_proof_file"]["tmp_name"], "$uploads_dir/$id_proof");
				}
			}
			else {
				if ($adm_details[0]['id_proof'] != $id_proof_file_name) {
					$id_proof = '';
					if ($_FILES['id_proof_file']['name'] != '') {
						$uploads_dir = 'assets/uploads/photos';
						$id_proof = time() . '_' . basename($_FILES["id_proof_file"]["name"]);
						move_uploaded_file($_FILES["id_proof_file"]["tmp_name"], "$uploads_dir/$id_proof");
					}
				} else
					$id_proof = $adm_details[0]['id_proof'];
			}
			$input = array(
				'username'=>$username,
				'name'=>$name,
				'email'=>$email,
				'phone_no'=>$phone_no,
				'photo'=>$photo,
				'id_proof'=>$id_proof,
				'id_proof_id'=>$id_proof_id,
				'date_of_birth'=>$date_of_birth,
				'gender'=>$gender,
				'dept_name'=>$dept_name,
				'designation'=>$designation,
				'address'=>$address,
				'com_id'=>$com_id,
				'role_id'=>$role_id,
				'country_id'=>$country_id
			);
			$mid = $this->sub_admin_model->edit($input,$admin_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Admin Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Admin');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Admin Username Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_sub_admin(){

		$admin_id = $this->input->post('admin_id');
		$cond="select user_id from sbx_user where admin_id=".$admin_id;
		$user_details = $this->admin_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Admin Already Allocated');
		}
		else
		{
			$mid = $this->sub_admin_model->delete($admin_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Admin Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Admin');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function view_sub_admin(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];

		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (a.name like '%".$searchValue."%'  or a.username like '%".$searchValue."%' or a.phone_no like '%".$searchValue."%')";
		}
		$cond="select * from sbx_admin a where 1".$searchQuery." order by a.created_on desc limit ".$start.",".$rowperpage;
		$admin_details = $this->admin_model->special_fetch($cond);
		$i=0;
		foreach($admin_details as $admin)
		{
			if($admin['created_by']!="") {

				$cond = "select name from sbx_admin where admin_id=".$admin['created_by'];
				$adm_details = $this->admin_model->special_fetch($cond);
				if (count($adm_details) > 0)
					$admin_details[$i]['created_by'] = $adm_details[0]['name'];
				else
					$admin_details[$i]['created_by'] = "";
			}
			else
				$admin_details[$i]['created_by'] = "";
			if($admin['id_proof_id']!="") {
			$cond="select id_proof from sbx_id_proof where id_proof_id=".$admin['id_proof_id'];
			$id_proof_details = $this->admin_model->special_fetch($cond);
			if(count($id_proof_details)>0)
				$admin_details[$i]['id_proof_name']=$id_proof_details[0]['id_proof'];
			else
				$admin_details[$i]['id_proof_name']="";
			}
			else
				$admin_details[$i]['id_proof_name'] = "";
			if($admin['country_id']!="") {
			$cond="select name from sbx_country where country_id=".$admin['country_id'];
			$country_details = $this->admin_model->special_fetch($cond);
			if(count($country_details)>0)
				$admin_details[$i]['country_name']=$country_details[0]['name'];
			else
				$admin_details[$i]['country_name']="";
			}
			else
				$admin_details[$i]['country_name'] = "";
			if($admin['role_id']!="") {
			$cond="select role_name from sbx_roles where role_id =".$admin['role_id'];
			$role_details = $this->admin_model->special_fetch($cond);
			if(count($role_details)>0)
				$admin_details[$i]['role_name']=$role_details[0]['role_name'];
			else
				$admin_details[$i]['role_name']="";
			}
			else
				$admin_details[$i]['role_name'] = "";

			if($admin['com_id']!="") {
				$cond = "select * from sbx_company where com_id=". $admin['com_id'];
				$company_details = $this->admin_model->special_fetch($cond);
				if (count($company_details) > 0) {
					$admin_details[$i]['com_name'] = $company_details[0]['com_name'];
					$admin_details[$i]['com_email'] = $company_details[0]['com_email'];
					$admin_details[$i]['com_conact_no'] = $company_details[0]['com_conact_no'];
					$admin_details[$i]['com_address'] = $company_details[0]['com_address'];
					$admin_details[$i]['contact_person_name'] = $company_details[0]['contact_person_name'];
					$admin_details[$i]['com_logo'] = $company_details[0]['com_logo'];
				} else {
					$admin_details[$i]['com_name'] = "";
					$admin_details[$i]['com_email'] = "";
					$admin_details[$i]['com_conact_no'] = "";
					$admin_details[$i]['com_address'] = "";
					$admin_details[$i]['contact_person_name'] = "";
					$admin_details[$i]['com_logo'] = "";
				}
			}
			else
			{
				$admin_details[$i]['com_name'] = "";
				$admin_details[$i]['com_email'] = "";
				$admin_details[$i]['com_conact_no'] = "";
				$admin_details[$i]['com_address'] = "";
				$admin_details[$i]['contact_person_name'] = "";
				$admin_details[$i]['com_logo'] = "";
			}
			$i++;
		}

		$cond="select COUNT(admin_id) as cnt from sbx_admin";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(admin_id) as cnt from sbx_admin where 1".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}

		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $admin_details
		);
		echo json_encode($response);
	}
	function set_admin_status(){
		$admin_id = $this->input->post('admin_id');
		$status = $this->input->post('status');
		$input = array(
			'status'=>$status
		);
		$mid = $this->sub_admin_model->edit($input,$admin_id);
		if($mid){
			$out = array('statuscode'=>'200','statusdescription'=>' Admin Status Updated Successfully');
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Admin Status');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_sub_admin(){
		$admin_id=$this->input->post('admin_id');
		$cond="select * from sbx_admin a where a.admin_id=".$admin_id;
		$admin_details = $this->admin_model->special_fetch($cond);
		$i=0;
		foreach($admin_details as $admin)
		{
			$cond="select name from sbx_admin where admin_id=".$admin['created_by'];
			$adm_details = $this->admin_model->special_fetch($cond);
			if(count($adm_details)>0)
				$admin_details[$i]['created_by']=$adm_details[0]['name'];
			else
				$admin_details[$i]['created_by']="";
			$cond="select id_proof from sbx_id_proof where id_proof_id=".$admin['id_proof_id'];
			$id_proof_details = $this->admin_model->special_fetch($cond);
			if(count($id_proof_details)>0)
				$admin_details[$i]['id_proof_name']=$id_proof_details[0]['id_proof'];
			else
				$admin_details[$i]['id_proof_name']="";
			$cond="select name from sbx_country where country_id=".$admin['country_id'];
			$country_details = $this->admin_model->special_fetch($cond);
			if(count($country_details)>0)
				$admin_details[$i]['country_name']=$country_details[0]['name'];
			else
				$admin_details[$i]['country_name']="";
			$cond="select role_name from sbx_roles where role_id =".$admin['role_id '];
			$role_details = $this->admin_model->special_fetch($cond);
			if(count($role_details)>0)
				$admin_details[$i]['role_name']=$role_details[0]['role_name'];
			else
				$admin_details[$i]['role_name']="";
			$cond="select * from sbx_company where com_id =".$admin['com_id '];
			$company_details = $this->admin_model->special_fetch($cond);
			if(count($company_details)>0) {
				$admin_details[$i]['com_name'] = $company_details[0]['com_name'];
				$admin_details[$i]['com_email'] = $company_details[0]['com_email'];
				$admin_details[$i]['com_conact_no'] = $company_details[0]['com_conact_no'];
				$admin_details[$i]['com_address'] = $company_details[0]['com_address'];
				$admin_details[$i]['contact_person_name'] = $company_details[0]['contact_person_name'];
				$admin_details[$i]['com_logo'] = $company_details[0]['com_logo'];
			}
			else
			{
				$admin_details[$i]['com_name'] = "";
				$admin_details[$i]['com_email'] = "";
				$admin_details[$i]['com_conact_no'] = "";
				$admin_details[$i]['com_address'] = "";
				$admin_details[$i]['contact_person_name'] = "";
				$admin_details[$i]['com_logo'] = "";
			}
			$i++;
		}
		if(count($admin_details)>0){
			$out = array('statuscode'=>'200','admin_details'=>$admin_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	//Category
	function category()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/category', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}
	function add_category(){
		$category_name = join(',', array_map('ucwords', explode(',', $this->input->post('category_name'))));
		$admin_id = $this->input->post('admin_id');
		$country_id = $this->input->post('country_id');
		$data_arr=array(
			'country_id'=>$country_id,
			'category_name'=>$category_name
		);
		$category_details = $this->admin_model->get_table_records('sbx_category',$data_arr);
		if(count($category_details)<=0)
		{
			$input = array(
				'category_name'=>$category_name,
				'country_id'=>$country_id,
				'parent_id'=>0,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->category_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'Category Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Create Category');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Category Name Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_category(){
		$category_name = join(',', array_map('ucwords', explode(',', $this->input->post('category_name_up'))));
		$category_id = $this->input->post('category_id');
		$country_id = $this->input->post('country_id');
		$cond="select category_id from sbx_category where category_name='".$category_name."' and country_id=".$country_id." and category_id<>".$category_id;
		$category_details = $this->admin_model->special_fetch($cond);
		if(count($category_details)<=0)
		{
			$input = array(
				'category_name'=>$category_name,
				'country_id'=>$country_id
			);
			$mid = $this->category_model->edit($input,$category_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>'Category Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>'Failed To Update Category');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Category Name Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_category(){

		$category_id = $this->input->post('category_id');
		$cond="select user_category_id from sbx_user_category where category_id=".$category_id;
		$user_cat_details = $this->admin_model->special_fetch($cond);
		if(count($user_cat_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Category Already Allocated To User');
		}
		else
		{
			$mid = $this->category_model->delete($category_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Category Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Category');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function view_category(){
		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (c.category_name like '%".$searchValue."%' or co.name like '%".$searchValue."%')";
		}
		$cond="select c.*,ad.username as admin,co.name as country from sbx_category c,sbx_admin ad,sbx_country co where ad.admin_id=c.admin_id and co.country_id=c.country_id ".$searchQuery." order by c.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(category_id) as cnt from sbx_category";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(category_id) as cnt from sbx_category c where 1".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}

		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $customer_details
		);
		echo json_encode($response);
	}
	function get_category(){
		$category_id=$this->input->post('category_id');
		$cond="select c.*,ad.username as admin from sbx_category c,sbx_admin ad where ad.admin_id=c.admin_id and c.category_id=".$category_id;
		$category_details = $this->admin_model->special_fetch($cond);
		if(count($category_details)>0){
			$out = array('statuscode'=>'200','category_details'=>$category_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_category_by_country(){
		$country_id=$this->input->post('country_id');
		$cond="select * from sbx_category where country_id=".$country_id;
		$category_details = $this->admin_model->special_fetch($cond);
		if(count($category_details)>0){
			$out = array('statuscode'=>'200','category_details'=>$category_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_categories(){
		$cond="select * from sbx_category";
		$category_details = $this->admin_model->special_fetch($cond);
		if(count($category_details)>0){
			$out = array('statuscode'=>'200','category_details'=>$category_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	
	//Sub Category
	function sub_category()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/sub_category', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_sub_category(){
		$country_id = $this->input->post('country_id');
		$category_id = $this->input->post('category_id');
		$sub_category_name = $this->input->post('sub_category_name');
		$admin_id = $this->input->post('admin_id');
		$data_arr=array(
			'country_id'=>$country_id,
			'parent_id'=>$category_id,
			'category_name'=>$sub_category_name
		);
		$sub_category_details = $this->admin_model->get_table_records('sbx_category',$data_arr);
		if(count($sub_category_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'parent_id'=>$category_id,
				'category_name'=>$sub_category_name,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->category_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Sub Category Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create Sub Category');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Sub Category Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_sub_category(){
		$country_id = $this->input->post('country_id');
		$category_id = $this->input->post('category_id');
		$parent_id = $this->input->post('category_id_up');
		$sub_category_name = $this->input->post('sub_category_name_up');
		$admin_id = $this->input->post('admin_id');
		$cond="select category_id from sbx_category where country_id=".$country_id." and parent_id=".$parent_id." and category_name='".$sub_category_name."' and category_id<>".$category_id;
		$sub_category_details = $this->admin_model->special_fetch($cond);
		if(count($sub_category_details)<=0)
		{
			$input = array(
				'country_id'=>$country_id,
				'parent_id'=>$parent_id,
				'category_name'=>$sub_category_name
			);
			$mid = $this->category_model->edit($input,$category_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Sub Category Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Sub Category');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Sub Category Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_sub_category(){

		$category_id = $this->input->post('category_id');		
		$cond="select user_category_id from sbx_user_category where category_id=".$category_id;
		$user_cat_details = $this->admin_model->special_fetch($cond);
		if(count($user_cat_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Sub Category Already Allocated');
		}
		else
		{
			$mid = $this->category_model->delete($category_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Sub Category Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Sub Category');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function view_sub_category(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (co.name like '%".$searchValue."%' or s.category_name like '%".$searchValue."%')";
		}
		$cond="select c.category_id,c.created_on,c.parent_id,co.name as country_name,co.country_id,ad.username as admin,s.category_name as category_name,c.category_name as sub_category_name from sbx_category s,sbx_category c,sbx_country co,sbx_admin ad where s.country_id=co.country_id and s.category_id=c.parent_id and ad.admin_id=s.admin_id and c.parent_id<>0 ".$searchQuery." order by s.created_on desc limit ".$start.",".$rowperpage;
		$customer_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(category_id) as cnt from sbx_category where parent_id<>0";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(s.category_id) as cnt from sbx_category s,sbx_country co where s.country_id=co.country_id and parent_id<>0 ".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}

		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $customer_details
		);
		echo json_encode($response);
	}
	function get_sub_category(){
		$data_arr=array(
			'country_id'=>$this->input->post('country_id'),
			'category_id'=>$this->input->post('category_id'),
		);
		$sub_category_details = $this->admin_model->get_table_records('sbx_sub_category',$data_arr);
		if(count($sub_category_details)>0){
			$out = array('statuscode'=>'200','sub_category_details'=>$sub_category_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function import_sub_category(){
		$country_id=$this->input->post('country_id_imp');
		$user_det = $this->session->userdata('user_det');
		$admin_id=$user_det['id'];
		$cond="select name from sbx_country where country_id=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$country=$con_details[0]['name'];
		$path = $_FILES["import_sub_category_file"]["tmp_name"];
		$target_dir = "./assets/uploads/address/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$user_det = $this->session->userdata('user_det');
		$corrupt = array();
		$error_rows = array();
		$data = array();
		$out = array();
		$k=0;
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				$parent_category=$sheet['cells'][$r][1];
				$sub_category=$sheet['cells'][$r][2];
				if($parent_category==""||$sub_category=="")
				{
					$corrupt_arr=array();
					$corrupt_arr[] =trim($sheet['cells'][$r][1]);
					$corrupt_arr[] =trim($sheet['cells'][$r][2]);
					$corrupt_arr[] ='Please Fill Required Fields';
					$corrupt[$r]=$corrupt_arr;
				}
				else
				{
					$cond="select category_id from sbx_category where category_name='".$parent_category."' and country_id=".$country_id;
					$cat_details = $this->admin_model->special_fetch($cond);
					if(count($cat_details)<=0)
					{
						$error_arr=array();
						$error_arr[] =trim($sheet['cells'][$r][1]);
						$error_arr[] =trim($sheet['cells'][$r][2]);
						$error_arr[] ='Parent Category Doesnt Exists';
						$error_rows[$r]=$error_arr;
					}
					else
					{
						$parent_id=$cat_details[0]['category_id'];
						$cond="select category_id from sbx_category where category_name='".$sub_category."' and country_id=".$country_id." and parent_id=".$parent_id;
						$sub_cat_details = $this->admin_model->special_fetch($cond);
						if(count($sub_cat_details)>0)
						{
							$error_arr=array();
							$error_arr[] =trim($sheet['cells'][$r][1]);
							$error_arr[] =trim($sheet['cells'][$r][2]);
							$error_arr[] ='Sub Category Already Exists';
							$error_rows[$r]=$error_arr;
						}
						else
						{
							$input = array(
								'country_id'=>$country_id,
								'parent_id'=>$parent_id,
								'category_name'=>$sub_category,
								'admin_id'=>$admin_id,
								'created_on'=>time()
							);
							$this->category_model->add($input);
						}
					}
				}				
			}
		}
		$out = array(
			'statuscode' => "200",
			'statusdescription'=>'Sub Category Imported Successfully',
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	//User
	function get_nationality()
	{
		$nationality_details = $this->admin_model->get_table_records('sbx_nationality',$data_field=array());
		if(count($nationality_details)>0){
			$out = array('statuscode'=>'200','nationality'=>$nationality_details);
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>'Not Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function user()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/user', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_user(){
		$name = $this->input->post('name');
		$phone_no = $this->input->post('phone_no');
		$email = $this->input->post('email');
		$date_of_birth = $this->input->post('date_of_birth');
		$gender = $this->input->post('gender');
		$nationality = $this->input->post('nationality');
		$house_no = $this->input->post('house_no');
		$street_name = $this->input->post('street_name');
		$pin_code = $this->input->post('pin_code');
		$skills = $this->input->post('skills');
		$country_id = $this->input->post('country_id');
		$created_by = $this->input->post('admin_id');
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$fields=explode(",",$con_details[0]['fields']);
		$address='';
		for($i=0;$i<count($fields);$i++){
			$address_field="address_".$i;
			if($address=="")
				$address=$this->input->post($address_field);
			else
				$address=$address.",".$this->input->post($address_field);
		}
		$cond="select address_id from sbx_address where fields='".$address."'";
		$add_details = $this->admin_model->special_fetch($cond);
		$address_id=$add_details[0]['address_id'];
		$photo = '';
		if($_FILES['user_photo_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/photos';
			$photo = time().'_'.basename($_FILES["user_photo_file"]["name"]);
			move_uploaded_file($_FILES["user_photo_file"]["tmp_name"], "$uploads_dir/$photo");
		}		
		$data_arr=array(
			'phone_no'=>$phone_no
		);
		$user_details = $this->admin_model->get_table_records('sbx_user',$data_arr);
		if(count($user_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'phone_no'=>$phone_no,
				'email'=>$email,
				'phone_no'=>$phone_no,
				'photo'=>$photo,
				'address_id'=>$address_id,
				'date_of_birth'=>$date_of_birth,
				'gender'=>$gender,
				'nationality'=>$nationality,
				'house_no'=>$house_no,
				'street_name'=>$street_name,
				'pin_code'=>$pin_code,
				'country_id'=>$country_id,
				'admin_id'=>$created_by,
				'created_on'=>time()
			);
			$user_id = $this->user_model->add($input);
			$skills_arr=explode(",",$skills);
			foreach($skills_arr as $cat)
			{
				$cond="select category_id from sbx_category where category_name='".trim($cat)."'";
				$cat_details = $this->admin_model->special_fetch($cond);
				if(count($cat_details)>0)
				{
					$category_id=$cat_details[0]['category_id'];
					$cond="select user_category_id from sbx_user_category where category_id=".$category_id." and user_id=".$user_id;
					$user_cat_details = $this->admin_model->special_fetch($cond);
					if(count($user_cat_details)<=0)
					{
						$input = array(
							'category_id'=>$category_id,
							'user_id'=>$user_id
						);
						$this->user_category_model->add($input);
					}
				}
			}
			if($user_id){
				$out = array('statuscode'=>'200','statusdescription'=>' User Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create User');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'User Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_user(){
		$user_id = $this->input->post('user_id');
		$name = $this->input->post('name');
		$phone_no = $this->input->post('phone_no');
		$email = $this->input->post('email');
		$date_of_birth = $this->input->post('date_of_birth');
		$gender = $this->input->post('gender');
		$nationality = $this->input->post('nationality');
		$house_no = $this->input->post('house_no');
		$street_name = $this->input->post('street_name');
		$pin_code = $this->input->post('pin_code');
		$skills = $this->input->post('skills');
		$country_id = $this->input->post('country_id');
		$user_photo_file_name = $this->input->post('user_photo_file_name');
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$fields=explode(",",$con_details[0]['fields']);
		$address='';
		$cond="select photo from sbx_user where user_id=".$user_id;
		$u_details = $this->admin_model->special_fetch($cond);
		$user_photo=$u_details[0]['photo'];
		for($i=0;$i<count($fields);$i++){
			$address_field="address_up_".$i;
			if($address=="")
				$address=$this->input->post($address_field);
			else
				$address=$address.",".$this->input->post($address_field);
		}
		$cond="select address_id from sbx_address where fields='".$address."'";
		$add_details = $this->admin_model->special_fetch($cond);
		if(count($add_details)>0)
			$address_id=$add_details[0]['address_id'];
		$photo = '';
		if($user_photo==$user_photo_file_name)
		{
			$photo=$user_photo_file_name;
		}
		else{
			if($_FILES['user_photo_file']['name'] != ''){
				$uploads_dir = 'assets/uploads/photos';
				$photo = time().'_'.basename($_FILES["user_photo_file"]["name"]);
				move_uploaded_file($_FILES["user_photo_file"]["tmp_name"], "$uploads_dir/$photo");
			}
		}
		
		$cond="select user_id from sbx_user where phone_no='".$phone_no."' and user_id<>".$user_id;
		$user_details = $this->admin_model->special_fetch($cond);
		if(count($user_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'phone_no'=>$phone_no,
				'email'=>$email,
				'phone_no'=>$phone_no,
				'photo'=>$photo,
				'address_id'=>$address_id,
				'date_of_birth'=>$date_of_birth,
				'gender'=>$gender,
				'nationality'=>$nationality,
				'house_no'=>$house_no,
				'street_name'=>$street_name,
				'pin_code'=>$pin_code,
				'country_id'=>$country_id
			);
			$this->user_model->edit($input,$user_id);
			$cond="select group_concat(category_id) as old_skills from sbx_user_category where user_id=".$user_id;
			$old_cat_details = $this->admin_model->special_fetch($cond);
			$old_skills=explode(",",$old_cat_details[0]['old_skills']);
			$skills_arr=explode(",",$skills);
			$cur_skills=array();
			foreach($skills_arr as $cat)
			{
				$cond="select category_id from sbx_category where category_name='".trim($cat)."'";
				$cat_details = $this->admin_model->special_fetch($cond);
				if(count($cat_details)>0)
				{
					$cur_skills[]=$cat_details[0]['category_id'];
				}
			}
			$new_skills=array_diff($cur_skills, $old_skills);
			$del_skills=array_diff($old_skills, $cur_skills);
			foreach($new_skills as $newsk)
			{
				$input = array(
					'category_id'=>$newsk,
					'user_id'=>$user_id
				);
				$this->user_category_model->add($input);
			}
			foreach($del_skills as $delsk)
			{
				$input = array(
					'category_id'=>$delsk,
					'user_id'=>$user_id
				);
				$this->user_category_model->del_cat($input);
			}
			$out = array('statuscode'=>'200','statusdescription'=>' User Updated Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'User Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_user(){
		$user_id = $this->input->post('user_id');		
		$cond="select smart_box_id from sbx_smart_box where user_id=".$user_id;
		$smbox_details = $this->admin_model->special_fetch($cond);
		if(count($smbox_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Smart Box Already Allocated To User');
		}
		else
		{
			$mid = $this->user_model->delete($user_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' User Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete User');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function set_user_status(){
		$user_id = $this->input->post('user_id');
		$status = $this->input->post('status');
		$input = array(
			'status'=>$status
		);
		$mid = $this->user_model->edit($input,$user_id);
		if($mid){
			$out = array('statuscode'=>'200','statusdescription'=>' User Status Updated Successfully');
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update User Status');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function view_user(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (name like '%".$searchValue."%' or phone_no like '%".$searchValue."%')";
		}
		$user_details=array();
		$cond="select * from sbx_user where 1".$searchQuery." order by created_on desc limit ".$start.",".$rowperpage;
		$user_det = $this->admin_model->special_fetch($cond);
		foreach($user_det as $users)
		{
			$cond="select name from sbx_admin where admin_id=".$users['admin_id'];
			$admin_details = $this->admin_model->special_fetch($cond);
			$cond="select country_id,fields from sbx_address where address_id=".$users['address_id'];
			$add_details = $this->admin_model->special_fetch($cond);
			$cond="select name from sbx_country where country_id=".$add_details[0]['country_id'];
			$con_details = $this->admin_model->special_fetch($cond);
			$address=$users['house_no'].",".$users['street_name']."<br />".$add_details[0]['fields']."-".$users['pin_code']."<br />".$con_details[0]['name'];
			$cond="select distinct c.category_name as category_name from sbx_user_category uc,sbx_category c where uc.category_id=c.category_id and user_id=".$users['user_id'];
			$cat_details = $this->admin_model->special_fetch($cond);
			$categories='';$skills='';
			foreach($cat_details as $category)
			{
				if($categories=="")
					$categories=$category['category_name'];
				else
					$categories=$categories.", ".$category['category_name'];				
			}
			$user_details[]=array(
				"user_id"=>$users['user_id'],
				"name"=>$users['name'],
				"phone_no"=>$users['phone_no'],
				"email"=>$users['email'],
				"gender"=>$users['gender'],
				"date_of_birth"=>$users['date_of_birth'],
				"nationality"=>$users['nationality'],
				"house_no"=>$users['house_no'],
				"street_name"=>$users['street_name'],
				"pin_code"=>$users['pin_code'],
				"photo"=>$users['photo'],
				"country_id"=>$users['country_id'],
				"address"=>$address,
				"address_id"=>$users['address_id'],
				"address_fields"=>$add_details[0]['fields'],
				"skills"=>$categories,
				"created_by"=>$admin_details[0]['name'],
				"created_on"=>$users['created_on'],
				"status"=>$users['status']
			);
		}
		$cond="select COUNT(user_id) as cnt from sbx_user";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(user_id) as cnt from sbx_user where 1".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $user_details
		);
		echo json_encode($response);
	}
		
	function get_sub_categories($id,$country_id)
	{
		$cond="select * from sbx_category where parent_id=".$id." and country_id=".$country_id;
		$sub_cat_details = $this->admin_model->special_fetch($cond);
		$categories = array();
		foreach($sub_cat_details as $sub_cat)
		{
			$categories[] = array(
				'id' => $sub_cat['category_id'],
				'title' => $sub_cat['category_name'],
				'subs' => $this->get_sub_categories($sub_cat['category_id'],$country_id),
			);
		}
		return $categories;
	}
	function get_all_categories($country_id)
	{
		$cond="select * from sbx_category where parent_id=0 and country_id=".$country_id;
		$sub_cat_details = $this->admin_model->special_fetch($cond);
		$categories = array();
		foreach($sub_cat_details as $sub_cat)
		{
			$categories[] = array(
				'id' => $sub_cat['category_id'],
				'title' => $sub_cat['category_name'],
				'subs' => $this->get_sub_categories($sub_cat['category_id'],$country_id),
			);
		}
		return $categories;
	}
	function get_sub_categories_by_id($id,$country_id)
	{
		$cond="select * from sbx_category where parent_id=".$id." and country_id=".$country_id;
		$sub_cat_details = $this->admin_model->special_fetch($cond);
		$categories = "";
		foreach($sub_cat_details as $sub_cat)
		{
			$categories = $categories.",".$sub_cat['category_id'];
			$categories = $categories.",".$this->get_sub_categories_by_id($sub_cat['category_id'],$country_id);			
		}
		return $categories;
	}
	
	function get_categories_by_id($country_id,$category_id)
	{
		$cond="select * from sbx_category where category_id=".$category_id;
		$sub_cat_details = $this->admin_model->special_fetch($cond);
		$categories = "";
		$categories = $sub_cat_details[0]['category_id'];
		$categories = $categories.",".$this->get_sub_categories_by_id($sub_cat_details[0]['category_id'],$country_id);			
		return $categories;
	}
	function get_category_tree_by_id($country_id,$category_id)
	{
		$categories = $this->get_categories_by_id($country_id,$category_id);
		$categories_arr=explode(",",$categories);
		$categories = implode(",", array_filter($categories_arr));
		return $categories;		
	}
	function get_category_tree()
	{
		$country_id=$this->input->post('country_id');
		$categories = $this->get_all_categories($country_id);
		header('Content-Type:application/json');
		echo json_encode($categories);
	}
	function get_user_category_tree()
	{
		$category=array();
		$user_id=$this->input->post('user_id');
		$cond="select * from sbx_user_category where user_id=".$user_id;
		$user_cat_details = $this->admin_model->special_fetch($cond);
		foreach($user_cat_details as $cat)
		{
			$category[]=$cat['category_id'];
		}
		if(count($category)>0){
			$out = array('statuscode'=>'200','category'=>$category);
		}
		else{
			$out = array('statuscode'=>'201');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_address_id()
	{
		$address=array();
		$country_id=$this->input->post('country_id');
		$address_id=$this->input->post('address_id');
		$cond="select fields from sbx_address where address_id=".$address_id;
		$address_details = $this->admin_model->special_fetch($cond);
		$address_details_arr =explode(",",$address_details[0]['fields']);
		$cond="select * from sbx_address_fields where country=".$country_id;
		$add_fld_details = $this->admin_model->special_fetch($cond);
		$heading_arr=explode(",",$add_fld_details[0]['fields']);
		$cond="select fields from sbx_address where country_id=".$country_id;
		$address_all_details = $this->admin_model->special_fetch($cond);
		$all_adderss=array();
		for($i=0;$i<count($heading_arr);$i++)
		{
			$heading=$heading_arr[$i];
			$address_filed=array();
			$address=array();
			$cond="select * from sbx_address where country_id=".$country_id;
			$add_details = $this->admin_model->special_fetch($cond);		
			foreach($add_details as $addr)
			{
				$add_arr=explode(",",$addr['fields']);
				if($i>=1)
				{
					if($address_details_arr[$i-1]==$add_arr[$i-1])
						$address[]=$add_arr[$i];
				}
				else
				{					
					$address[]=$add_arr[$i];
				}
			}
			$address_field=array_values(array_unique($address,SORT_STRING));
			$all_adderss[]=array('heading'=>$heading,'address_field'=>$address_field);
		}
		if(count($all_adderss)>0){
			$out = array('statuscode'=>'200','address'=>$all_adderss,'address_all_fields'=>$add_fld_details,'address_all_details'=>$address_all_details);
		}
		else{
			$out = array('statuscode'=>'201');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function get_address_country(){
        $cond="select c.country_id,c.name from sbx_country c,sbx_address_fields a where a.country=c.country_id";
		$country_details = $this->admin_model->special_fetch($cond);
		if(count($country_details)>0){
            $out = array('statuscode'=>'200','country'=>$country_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function export_users(){

		$country_id=$this->input->post('country_id');
		$category_id=$this->input->post('category_id');
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$add_details = $this->admin_model->special_fetch($cond);
		$address="";
		$fields_arr=explode(",",$add_details[0]['fields']);
		for($i=0;$i<count($fields_arr);$i++)
		{
			$address_id="address_exp_".$i;
			$address_val=$this->input->post($address_id);
			if($address_val!="")
			{
				if(address=="")
					$address=$address_val;
				else
					$address=$address.",".$address_val;
			}
		}
		$address_ids="";
		if($address!="")
		{
			$cond="select group_concat(address_id) as address_ids from sbx_address where fields like '%".$address."%'";
			$address_id_details = $this->admin_model->special_fetch($cond);
			$address_ids=$address_id_details[0]['address_ids'];
		}
		$searchQuery="";
		if($address_ids!="")
		{
			$searchQuery=" and address_id in(".$address_ids.")";
		}
		$categories="";
		if($category_id!="")
		{
			$cond="select category_id from sbx_category where category_name='".$category_id."'";
			$cat_details = $this->admin_model->special_fetch($cond);
			$categories=$this->get_category_tree_by_id($country_id,$category_id);
		}
		$user_details=array();
		$cond="select * from sbx_user where country_id=".$country_id.$searchQuery." order by created_on desc";
		$user_det = $this->admin_model->special_fetch($cond);
		foreach($user_det as $users)
		{
			$cond="select user_category_id  from sbx_user_category where user_id=".$users['user_id']." and category_id in(".$categories.") limit 1";			
			$user_cat_details = $this->admin_model->special_fetch($cond);
			if(count($user_cat_details)>0)
			{
				$cond="select nationality from sbx_nationality where nationality_id=".$users['nationality_id'];			
				$nat_details = $this->admin_model->special_fetch($cond);
				$nationality=$nat_details[0]['nationality'];
				$cond="select country_id,fields from sbx_address where address_id=".$users['address_id'];
				$add_details = $this->admin_model->special_fetch($cond);
				$address=$add_details[0]['fields'];
				$cond="select distinct c.category_name as category_name from sbx_user_category uc,sbx_category c where uc.category_id=c.category_id and user_id=".$users['user_id'];
				$cat_details = $this->admin_model->special_fetch($cond);
				$categories='';$skills='';
				foreach($cat_details as $category)
				{
					if($categories=="")
						$categories=$category['category_name'];
					else
						$categories=$categories.", ".$category['category_name'];				
				}
				$dateOfBirth = $users['date_of_birth'];
				$today = date("Y-m-d");
				$diff = date_diff(date_create($dateOfBirth), date_create($today));
				$age=$diff->format('%y');
				$user_details[]=array(
					"name"=>$users['name'],
					"phone_no"=>$users['phone_no'],
					"email"=>$users['email'],
					"gender"=>$users['gender'],
					"date_of_birth"=>$users['date_of_birth'],
					"age"=>$age,
					"nationality"=>$nationality,
					"house_no"=>$users['house_no'],
					"street_name"=>$users['street_name'],
					"pin_code"=>$users['pin_code'],
					"address"=>$address,
					"skills"=>$categories,
					"status"=>$users['status']
				);
			}
		}
		if(count($user_details)>0){
            $out = array('statuscode'=>'200','statusdescription'=>"User Details Exported Successfully",'user_details'=>$user_details);
        }
        else{
            $out = array('statuscode'=>'201','statusdescription'=>'User Not Found');
        }
        header('Content-Type:application/json');
        echo json_encode($out);		
	}
	function import_user(){
		$country_id=$this->input->post('country_id_imp');
		$user_det = $this->session->userdata('user_det');
		$admin_id=$user_det['id'];
		$cond="select name from sbx_country where country_id=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$country=$con_details[0]['name'];
		$path = $_FILES["import_user_file"]["tmp_name"];
		$target_dir = "./assets/uploads/address/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$user_det = $this->session->userdata('user_det');
		$corrupt = array();
		$error_rows = array();
		$data = array();
		$out = array();
		$k=0;
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				$name=trim($sheet['cells'][$r][1]);
				$phone_no=trim($sheet['cells'][$r][2]);
				$email=trim($sheet['cells'][$r][3]);
				$skills=trim($sheet['cells'][$r][4]);
				$house_no=trim($sheet['cells'][$r][5]);
				$street_name=trim($sheet['cells'][$r][6]);
				$address=trim($sheet['cells'][$r][7]);
				$pin_code=trim($sheet['cells'][$r][8]);
				$date_of_birth=trim($sheet['cells'][$r][9]);
				$nationality=trim($sheet['cells'][$r][10]);
				$gender=trim($sheet['cells'][$r][11]);
				if($name==""||$phone_no==""||$skills==""||$address=="")
				{
					$corrupt_arr=array();
					$corrupt_arr[] =$name;
					$corrupt_arr[] =$phone_no;
					$corrupt_arr[] =$email;
					$corrupt_arr[] =$skills;
					$corrupt_arr[] =$house_no;
					$corrupt_arr[] =$street_name;
					$corrupt_arr[] =$address;
					$corrupt_arr[] =$pin_code;
					$corrupt_arr[] =$date_of_birth;
					$corrupt_arr[] =$nationality;
					$corrupt_arr[] =$gender;
					$corrupt_arr[] ='Please Fill Required Fields';
					$corrupt[$r]=$corrupt_arr;
				}
				else
				{

					$cond="select category_id from sbx_category where find_in_set(category_name,'".$skills."') and country_id=".$country_id;
					$cat_details = $this->admin_model->special_fetch($cond);
					if(count($cat_details)<=0)
					{
						$error_arr=array();
						$error_arr[] =$name;
						$error_arr[] =$phone_no;
						$error_arr[] =$email;
						$error_arr[] =$skills;
						$error_arr[] =$house_no;
						$error_arr[] =$street_name;
						$error_arr[] =$address;
						$error_arr[] =$pin_code;
						$error_arr[] =$date_of_birth;
						$error_arr[] =$nationality;
						$error_arr[] =$gender;
						$error_arr[] ='Skills Doesnt Exists';
						$error_rows[$r]=$error_arr;
					}
					else
					{
						$cond="select address_id from sbx_address where fields='".$address."' and country_id=".$country_id;
						$address_details = $this->admin_model->special_fetch($cond);
						if(count($address_details)<=0)
						{
							$error_arr=array();
							$error_arr[] =$name;
							$error_arr[] =$phone_no;
							$error_arr[] =$email;
							$error_arr[] =$skills;
							$error_arr[] =$house_no;
							$error_arr[] =$street_name;
							$error_arr[] =$address;
							$error_arr[] =$pin_code;
							$error_arr[] =$date_of_birth;
							$error_arr[] =$nationality;
							$error_arr[] =$gender;
							$error_arr[] =$status;					
							$error_arr[] ='Address Doesnt Exists';
							$error_rows[$r]=$error_arr;
						}
						else
						{
							$address_id=$address_details[0]['address_id'];
							$cond="select nationality_id from sbx_nationality where nationality='".$nationality."'";
							$address_details = $this->admin_model->special_fetch($cond);
							$input = array(
								'name'=>$name,
								'phone_no'=>$phone_no,
								'email'=>$email,
								'address_id'=>$address_id,
								'date_of_birth'=>$date_of_birth,
								'gender'=>$gender,
								'nationality'=>$nationality,
								'house_no'=>$house_no,
								'street_name'=>$street_name,
								'pin_code'=>$pin_code,
								'country_id'=>$country_id,
								'admin_id'=>$admin_id,
								'created_on'=>time()
							);
							$user_id = $this->user_model->add($input);
							foreach($cat_details as $cat)
							{	
								$category_id=$cat['category_id'];
								$cond="select user_category_id from sbx_user_category where category_id=".$category_id." and user_id=".$user_id;
								$user_cat_details = $this->admin_model->special_fetch($cond);
								if(count($user_cat_details)<=0)
								{
									$input = array(
										'category_id'=>$category_id,
										'user_id'=>$user_id
									);
									$this->user_category_model->add($input);
								}								
							}
						}
					}
				}				
			}
		}
		$out = array(
			'statuscode' => "200",
			'statusdescription'=>'User Imported Successfully',
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	//Smart Box
	function smart_box()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/smart_box', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}
	function add_smart_box(){
		$box_no = $this->input->post('box_no');
		$country_id = $this->input->post('country_id');
		$created_by = $this->input->post('admin_id');
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$fields=explode(",",$con_details[0]['fields']);
		$address='';
		for($i=0;$i<count($fields);$i++){	
			$address_field="address_".$i;		
			if($address=="")
				$address=$this->input->post($address_field);
			else
				$address=$address.",".$this->input->post($address_field);
		}
		$address_arr=explode(',',trim($address,","));
		$len = count($address_arr);
		$address_field="";
		$address_id="";
		if($len==count($fields))
		{
			$cond="select address_id from sbx_address where fields='".$address."' and country_id=".$country_id;
			$add_details = $this->admin_model->special_fetch($cond);
			$address_id=$add_details[0]['address_id'];
		}
		else
		{
			$address_field="\"".$address_arr[$len-1]."\"";
			$cond="select group_concat(address_id) as address_id from sbx_address where find_in_set(".$address_field.",fields) and country_id=".$country_id;
			$add_details = $this->admin_model->special_fetch($cond);
			$address_id=$add_details[0]['address_id'];
		}
		$photo = '';
		if($_FILES['smart_box_photo_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/photos';
			$photo = time().'_'.basename($_FILES["smart_box_photo_file"]["name"]);
			move_uploaded_file($_FILES["smart_box_photo_file"]["tmp_name"], "$uploads_dir/$photo");
		}		
		$data_arr=array(
			'box_no'=>$box_no
		);
		$smart_box_details = $this->admin_model->get_table_records('sbx_smart_box',$data_arr);
		if(count($smart_box_details)<=0)
		{
			$input = array(
				'box_no'=>$box_no,
				'address_id'=>$address_id,
				'country_id'=>$country_id,
				'photo'=>$photo,
				'admin_id'=>$created_by,
				'created_on'=>time()
			);
			$smart_box_id = $this->smart_box_model->add($input);			
			if($smart_box_id){
				$out = array('statuscode'=>'200','statusdescription'=>' Smart Box Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create Smart Box');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Smart Box Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_smart_box(){
		$smart_box_id = $this->input->post('smart_box_id');
		$box_no = $this->input->post('box_no');
		$country_id = $this->input->post('country_id');
		$smart_box_photo_file_name = $this->input->post('smart_box_photo_file_name');
		$cond="select fields from sbx_address_fields where country=".$country_id;
		$con_details = $this->admin_model->special_fetch($cond);
		$fields=explode(",",$con_details[0]['fields']);
		$address='';
		for($i=0;$i<count($fields);$i++){
			$address_field="address_up_".$i;			
			if($address=="")
				$address=$this->input->post($address_field);
			else
				$address=$address.",".$this->input->post($address_field);
		}
		$address_arr=explode(',',$address);
		$len = count($address_arr);
		$address_field="";
		$address_id="";		
		if($len==count($fields))
		{
			$cond="select address_id from sbx_address where fields='".$address."' and country_id=".$country_id;
			$add_details = $this->admin_model->special_fetch($cond);
			$address_id=$add_details[0]['address_id'];			
		}
		else
		{
			$address_field="\"".$address_arr[$len-1]."\"";
			$cond="select group_concat(address_id) as address_id from sbx_address where find_in_set(".$address_field.",fields) and country_id=".$country_id;
			$add_details = $this->admin_model->special_fetch($cond);
			$address_id=$add_details[0]['address_id'];
		}
		$cond="select photo from sbx_smart_box where smart_box_id=".$smart_box_id;
		$sm_details = $this->admin_model->special_fetch($cond);
		$smart_box_photo=$sm_details[0]['photo'];
		$photo = '';
		if($smart_box_photo==$smart_box_photo_file_name)
		{
			$photo=$smart_box_photo_file_name;
		}
		else{
			if($_FILES['smart_box_photo_file']['name'] != ''){
				$uploads_dir = 'assets/uploads/photos';
				$photo = time().'_'.basename($_FILES["smart_box_photo_file"]["name"]);
				move_uploaded_file($_FILES["smart_box_photo_file"]["tmp_name"], "$uploads_dir/$photo");
			}
		}				
		$cond="select smart_box_id from sbx_smart_box where box_no='".$box_no."' and smart_box_id<>".$smart_box_id;
		$smart_box_details = $this->admin_model->special_fetch($cond);
		if(count($smart_box_details)<=0)
		{
			$input = array(
				'box_no'=>$box_no,
				'address_id'=>$address_id,
				'country_id'=>$country_id,
				'photo'=>$photo
			);
			$this->smart_box_model->edit($input,$smart_box_id);			
			$out = array('statuscode'=>'200','statusdescription'=>' Smart Box Updated Successfully');
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Smart Box Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_smart_box(){
		$smart_box_id = $this->input->post('smart_box_id');		
		$cond="select smart_box_admin_id from sbx_smart_box_admin where smart_box_id=".$smart_box_id;
		$smbox_details = $this->admin_model->special_fetch($cond);
		if(count($smbox_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Smart Box Already Allocated To Admin');
		}
		else
		{
			$mid = $this->smart_box_model->delete($smart_box_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Smart Box Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Smart Box');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function set_smart_box_status(){
		$smart_box_id = $this->input->post('smart_box_id');
		$status = $this->input->post('status');
		$input = array(
			'status'=>$status
		);
		$mid = $this->smart_box_model->edit($input,$smart_box_id);
		if($mid){
			$out = array('statuscode'=>'200','statusdescription'=>' Smart Box Status Updated Successfully');
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Smart Box Status');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function view_smart_box(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and box_no like '%".$searchValue."%'";
		}
		$smart_box_details=array();
		$cond="select * from sbx_smart_box where 1".$searchQuery." order by created_on desc limit ".$start.",".$rowperpage;
		$smart_box_det = $this->admin_model->special_fetch($cond);
		foreach($smart_box_det as $smart_box)
		{			
			$cond="select name from sbx_admin where admin_id=".$smart_box['admin_id'];
			$admin_details = $this->admin_model->special_fetch($cond);
			$cond="select admin_ids from sbx_smart_box_admin where smart_box_id=".$smart_box['smart_box_id'];
			$smart_box_admin_details = $this->admin_model->special_fetch($cond);
			$cond="select name from sbx_country where country_id=".$smart_box['country_id'];
			$con_details = $this->admin_model->special_fetch($cond);
			$address_id_arr=explode(",",$smart_box['address_id']);
			$address="";$address_flds="";
			$cond="select fields from sbx_address where address_id=".$address_id_arr[0];
			$add_id_details = $this->admin_model->special_fetch($cond);
			if(count($address_id_arr)>1)
			{
				$add_id_fld_arr=explode(',', $add_id_details[0]['fields']);
				array_pop($add_id_fld_arr);
				$address_flds=implode(",",$add_id_fld_arr);
			}
			else
			{
				$address_flds=$add_id_details[0]['fields'];
			}
			foreach($address_id_arr as $address_id)
			{
				$cond="select fields from sbx_address where address_id=".$smart_box['address_id'];
				$add_details = $this->admin_model->special_fetch($cond);
				$add_fld_arr=explode(',', $add_details[0]['fields']);
				if($address=="")
					$address = end($add_fld_arr);
				else
					$address = $address.",".end($add_fld_arr);				
			}			
			$smart_box_details[]=array(
				"smart_box_id"=>$smart_box['smart_box_id'],
				"box_no"=>$smart_box['box_no'],
				"photo"=>$smart_box['photo'],
				"address_id"=>$smart_box['address_id'],
				"address"=>$address,
				"address_flds"=>$address_flds,
				"country"=>$con_details[0]['name'],
				"country_id"=>$smart_box['country_id'],
				"admin_ids"=>$smart_box_admin_details[0]['admin_ids'],
				"created_by"=>$admin_details[0]['name'],
				"created_on"=>$smart_box['created_on'],
				"status"=>$smart_box['status']
			);
		}
		$cond="select COUNT(smart_box_id) as cnt from sbx_smart_box";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(smart_box_id) as cnt from sbx_smart_box where 1".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $smart_box_details
		);
		echo json_encode($response);
	}
	function get_all_admin(){
		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (a.name like '%".$searchValue."%' or r.role_name like '%".$searchValue."%')";
		}
		$cond="select a.admin_id,a.name,r.role_name from sbx_admin a,sbx_roles r where a.role_id=r.role_id".$searchQuery." order by a.created_on desc limit ".$start.",".$rowperpage;
		$admin_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(a.admin_id) as cnt from sbx_admin a,sbx_roles r where a.role_id=r.role_id";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(a.admin_id) as cnt from sbx_admin a,sbx_roles r where a.role_id=r.role_id".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $admin_details
		);
		echo json_encode($response);
	}
	function allocate_smart_box_admin(){
		$admin_ids = $this->input->post('admin_ids');
		$smart_box_id = $this->input->post('smart_box_id');				
		$data_arr=array(
			'smart_box_id'=>$smart_box_id
		);
		$smart_box_details = $this->admin_model->get_table_records('sbx_smart_box_admin',$data_arr);
		if(count($smart_box_details)<=0)
		{
			$input = array(
				'admin_ids'=>$admin_ids,
				'smart_box_id'=>$smart_box_id
			);
			$this->smart_box_admin_model->add($input);
		}
		else
		{
			$input = array(
				'admin_ids'=>$admin_ids
			);
			$this->smart_box_admin_model->edit($input,$smart_box_id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>' Smart Box Allocated Successfully');
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	//Components
	function components()
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/components', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}

	function add_components(){

		$serial_no = $this->input->post('serial_no');
		$name = $this->input->post('name');
		$quantity = $this->input->post('quantity');
		$specifications = $this->input->post('specifications');
		$price = $this->input->post('price');
		$date_of_purchase = $this->input->post('date_of_purchase');
		$date_of_expiry = $this->input->post('date_of_expiry');
		$notes = $this->input->post('notes');		
		$admin_id = $this->input->post('admin_id');
		$photo = '';
		if($_FILES['photo_file']['name'] != ''){
			$uploads_dir = 'assets/uploads/photos';
			$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
			move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
		}		
		$data_arr=array(
			'serial_no'=>$serial_no
		);
		$component_details = $this->admin_model->get_table_records('sbx_components',$data_arr);
		if(count($component_details)<=0)
		{
			$input = array(
				'serial_no'=>$serial_no,
				'name'=>$name,
				'quantity'=>$quantity,
				'specifications'=>$specifications,
				'photo'=>$photo,
				'price'=>$price,
				'date_of_purchase'=>$date_of_purchase,
				'date_of_expiry'=>$date_of_expiry,
				'notes'=>$notes,
				'admin_id'=>$admin_id,
				'created_on'=>time()
			);
			$mid = $this->components_model->add($input);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Component Created Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Create Component');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Component Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function edit_components(){
		$component_id = $this->input->post('component_id');
		$serial_no = $this->input->post('serial_no');
		$name = $this->input->post('name');
		$quantity = $this->input->post('quantity');
		$specifications = $this->input->post('specifications');
		$price = $this->input->post('price');
		$date_of_purchase = $this->input->post('date_of_purchase');
		$date_of_expiry = $this->input->post('date_of_expiry');
		$notes = $this->input->post('notes');
		$photo_file_name = $this->input->post('photo_file_name');
		$cond="select component_id from sbx_components where component_id<>".$component_id." and serial_no='".$serial_no."'";
		$component_details = $this->admin_model->special_fetch($cond);
		if(count($component_details)<=0)
		{
			$cond="select photo from sbx_components where component_id=".$component_id;
			$cmp_details = $this->admin_model->special_fetch($cond);
			if($cmp_details[0]['photo']=="")
			{
				$photo = '';
				if($_FILES['photo_file']['name'] != ''){
					$uploads_dir = 'assets/uploads/photos';
					$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
					move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
				}
			}
			else{
				if($cmp_details[0]['photo']!=$photo_file_name)
				{
					$photo = '';
					if($_FILES['photo_file']['name'] != ''){
						$uploads_dir = 'assets/uploads/photos';
						$photo = time().'_'.basename($_FILES["photo_file"]["name"]);
						move_uploaded_file($_FILES["photo_file"]["tmp_name"], "$uploads_dir/$photo");
					}
				}
				else
					$photo = $cmp_details[0]['photo'];
			}			
			$input = array(
				'serial_no'=>$serial_no,
				'name'=>$name,
				'quantity'=>$quantity,
				'specifications'=>$specifications,
				'photo'=>$photo,
				'price'=>$price,
				'date_of_purchase'=>$date_of_purchase,
				'date_of_expiry'=>$date_of_expiry,
				'notes'=>$notes
			);
			$mid = $this->components_model->edit($input,$component_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Component Updated Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Component');
			}
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Component Already Exists');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function delete_components(){

		$component_id = $this->input->post('component_id');
		$cond="select smart_box_component_id from sbx_smart_box_components where component_id=".$component_id;
		$cmp_details = $this->admin_model->special_fetch($cond);
		if(count($cmp_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>' Unable To Delete - Component Already Allocated');
		}
		else
		{
			$mid = $this->components_model->delete($component_id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>' Component Deleted Successfully');
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>' Failed To Delete Component');
			}
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}

	function view_components(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (c.name like '%".$searchValue."%'  or c.serial_no like '%".$searchValue."%')";
		}
		$cond="select c.*,a.name as created_by from sbx_components c,sbx_admin a where c.admin_id=a.admin_id".$searchQuery." order by created_on desc limit ".$start.",".$rowperpage;
		$component_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(component_id) as cnt from sbx_components";
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(component_id) as cnt from sbx_components c,sbx_admin a where c.admin_id=a.admin_id".$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $component_details
		);
		echo json_encode($response);
	}
	function set_components_status(){
		$component_id = $this->input->post('component_id');
		$status = $this->input->post('status');
		$input = array(
			'status'=>$status
		);
		$mid = $this->components_model->edit($input,$component_id);
		if($mid){
			$out = array('statuscode'=>'200','statusdescription'=>' Component Status Updated Successfully');
		}
		else{
			$out = array('statuscode'=>'201','statusdescription'=>' Failed To Update Component Status');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}	
	function get_components(){

		$cond="select * from sbx_components";
		$component_details = $this->admin_model->special_fetch($cond);
		if(count($component_details)>0)
		{
			$out = array('statuscode'=>'200','component_details'=>$component_details);
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>' No Components Found');
		}
		header('Content-Type:application/json');
		echo json_encode($out);
	}
	function import_components(){
		$user_det = $this->session->userdata('user_det');
		$admin_id=$user_det['id'];
		$path = $_FILES["import_components_file"]["tmp_name"];
		$target_dir = "./assets/uploads/components/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$user_det = $this->session->userdata('user_det');
		$corrupt = array();
		$error_rows = array();
		$data = array();
		$out = array();
		$k=0;
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				$serial_no='';$name='';$quantity='';$specifications='';$price='';$date_of_purchase='';$date_of_expiry='';$notes='';
				if(isset($sheet['cells'][$r][1]))
					$serial_no=trim($sheet['cells'][$r][1]);
				if(isset($sheet['cells'][$r][2]))
					$name=trim($sheet['cells'][$r][2]);
				if(isset($sheet['cells'][$r][3]))
					$quantity=trim($sheet['cells'][$r][3]);
				if(isset($sheet['cells'][$r][4]))
					$specifications=trim($sheet['cells'][$r][4]);
				if(isset($sheet['cells'][$r][5]))
					$price=$sheet['cells'][$r][5];
				if(isset($sheet['cells'][$r][6]))
					$date_of_purchase=trim($sheet['cells'][$r][6]);
				if(isset($sheet['cells'][$r][7]))
					$date_of_expiry=trim($sheet['cells'][$r][7]);
				if(isset($sheet['cells'][$r][8]))
					$notes=trim($sheet['cells'][$r][8]);
				if($name==""||$serial_no=="")
				{
					$corrupt_arr=array();
					$corrupt_arr[] =$serial_no;
					$corrupt_arr[] =$name;
					$corrupt_arr[] =$quantity;
					$corrupt_arr[] =$specifications;
					$corrupt_arr[] =$price;
					$corrupt_arr[] =$date_of_purchase;
					$corrupt_arr[] =$date_of_expiry;
					$corrupt_arr[] =$notes;
					$corrupt_arr[] ='Please Fill Required Fields';
					$corrupt[$r]=$corrupt_arr;
				}
				else
				{
					$cond="select component_id from sbx_components where serial_no='".$serial_no."'";
					$comp_details = $this->admin_model->special_fetch($cond);
					if(count($comp_details)>0)
					{
						$error_arr=array();
						$error_arr[] =$serial_no;
						$error_arr[] =$name;
						$error_arr[] =$quantity;
						$error_arr[] =$specifications;
						$error_arr[] =$price;
						$error_arr[] =$date_of_purchase;
						$error_arr[] =$date_of_expiry;
						$error_arr[] =$notes;
						$error_arr[] ='Component Already Exists';
						$error_rows[$r]=$error_arr;
					}
					else
					{
						$input = array(
							'serial_no'=>$serial_no,
							'name'=>$name,
							'quantity'=>$quantity,
							'specifications'=>$specifications,
							'price'=>$price,
							'date_of_purchase'=>$date_of_purchase,
							'date_of_expiry'=>$date_of_expiry,
							'notes'=>$notes,
							'admin_id'=>$admin_id,
							'created_on'=>time()
						);
						$this->components_model->add($input);
					}
				}				
			}
		}
		$out = array(
			'statuscode' => "200",
			'statusdescription'=>'Components Imported Successfully',
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	//Smart Box Components
	function smart_box_components($smart_box_id)
	{
		if($this->session->userdata('user_det') != ''
			&& $this->session->userdata('user_det') != 'undefined'
			&& $this->session->userdata('user_det') != null){
			$user_det = $this->session->userdata('user_det');
			$cond="select r.* from sbx_roles r,sbx_admin a where a.role_id=r.role_id and a.admin_id=".$user_det['id'];
			$role_details=$this->admin_model->special_fetch($cond);
			$this->data['roles'] = $role_details[0];
			$this->data['smart_box_id'] = $smart_box_id;
			$this->get_include();
			$this->load->view($this->view_dir . 'admin/smart_box_components', $this->data);
		}
		else{
			$this->data['error_message'] = '';
			$this->data['username'] = '';
			$this->load->view($this->view_dir . 'admin/login', $this->data);
		}
	}
	function view_smart_box_components(){

		$draw = $_POST['draw'];
		$start = $_POST['start'];
		$rowperpage = $_POST['length'];
		$searchValue = $_POST['search']['value'];
		$smart_box_id = $_POST['smart_box_id'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchQuery = " and (c.name like '%".$searchValue."%'  or c.serial_no like '%".$searchValue."%')";
		}
		$cond="select c.* from sbx_components c,sbx_smart_box_components sm where c.component_id=sm.component_id and sm.smart_box_id=".$smart_box_id.$searchQuery." order by c.component_id desc limit ".$start.",".$rowperpage;
		$component_details = $this->admin_model->special_fetch($cond);
		$cond="select COUNT(smart_box_component_id) as cnt from sbx_smart_box_components where smart_box_id=".$smart_box_id;
		$maps_count = $this->admin_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''){
			$cond="select COUNT(sm.smart_box_component_id) as cnt from sbx_components c,sbx_smart_box_components sm where c.component_id=sm.component_id and sm.smart_box_id=".$smart_box_id.$searchQuery;
			$maps_count = $this->admin_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $totalRecord,
			"iTotalDisplayRecords" => $totalRecordwithFilter,
			"aaData" => $component_details
		);
		echo json_encode($response);
	}
	function allocate_smart_box_components(){

		$smart_box_id = $this->input->post('smart_box_id');
		$component_ids = $this->input->post('component_ids');
		$comp_id_arr=explode(",",$component_ids);
		$flag=false;
		foreach($comp_id_arr as $comp_ids)
		{
			$cond="select smart_box_component_id from sbx_smart_box_components where smart_box_id=".$smart_box_id." and component_id=".$comp_ids;
			$comp_details=$this->admin_model->special_fetch($cond);
			if(count($comp_details)<=0)
			{
				$input = array(
					'smart_box_id'=>$smart_box_id,
					'component_id'=>$comp_ids
				);
				$this->smart_box_components_model->add($input);
				$flag=true;
			}
		}
		if($flag)
			$out = array('statuscode'=>'200','statusdescription'=>' Components Allocated Successfully');
		else	
			$out = array('statuscode'=>'201','statusdescription'=>' Components Already Allocated');	
		header('Content-Type:application/json');
		echo json_encode($out);
	}
}
