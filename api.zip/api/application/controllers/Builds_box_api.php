<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Builds_box_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function view_builds_box(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(build_no) like '%".$searchValue."%' or lower(item_no) like '%".$searchValue."%' or lower(description) like '%".$searchValue."%' or DATE_FORMAT(build_date, '%d-%m-%Y') LIKE '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "build_date";
			$columnSortOrder = "desc";
		}		
		$cond="select * from builds where 1".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from builds";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(id) as cnt from builds where 1".$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }	
	function download_builds_box(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		//$builds_folder="/var/www/proscola.com/builds/";
		//$zip_path="/var/www/proscola.com/builds/builds_zip/";
		$builds_folder="C:\\xampp\\htdocs\\builds\\";
		$zip_path="C:\\xampp\\htdocs\\builds\\builds_zip\\";
		$build_no = $data['build_no'];
		$file_path = $zip_path.$build_no.'.zip';
		if (file_exists($file_path)) {
			$out = array('statuscode'=>'200','statusdescription'=>'Zip File Already Exists');
		}
		else
		{
			$cond="select * from builds where build_no<=".$build_no." and is_box_deployed=1 order by build_no desc";
			$build_details = $this->users_model->special_fetch($cond);
			if(count($build_details)>0)
			{
				if(count($build_details)>1)
					$last_build_no=$build_details[1]['build_no']+1;
				else
					$last_build_no=$build_no;
				// Initialize a new ZipArchive object
				$zip = new ZipArchive();
				$zip_file_name = $zip_path.$build_no.'.zip';
				// Open the zip file for writing
				if ($zip->open($zip_file_name, ZipArchive::CREATE) === TRUE) 
				{
					for($i=$last_build_no;$i<=$build_no;$i++)
					{
						$folder_path =$builds_folder.$i;
						$zip->addEmptyDir($i);
						$files = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($folder_path));
						foreach ($files as $file) {
							// Skip '.' and '..' folders
							if ($file->isDir()) continue;
							// Get the relative path of the file inside the "1001" folder
							$file_path = substr($file->getPathname(), strlen($folder_path) + 1);
							// Add the file to the zip file
							$zip_folder=$i."/";
							$zip->addFile($file->getPathname(), $zip_folder . $file_path);
						}
					}
					$zip->close();
					$out = array('statuscode'=>'200','statusdescription'=>'Zip File Created Successfully');
				} 
				else 
				{			
					$out = array('statuscode'=>'201','statusdescription'=>'Unable To Download Build - Please Contact Development Team');
				}			
			}
			else
				$out = array('statuscode'=>'201','statusdescription'=>'Unable To Locate Build - Please Contact Development Team');	
		}
		header('Content-Type:application/json');
		echo json_encode($out);	
	}
}
