<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Builds_ps_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function view_builds_ps(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(build_no) like '%".$searchValue."%' or lower(item_no) like '%".$searchValue."%' or lower(description) like '%".$searchValue."%' or DATE_FORMAT(build_date, '%d-%m-%Y') LIKE '%".$searchValue."%' or DATE_FORMAT(release_date, '%d-%m-%Y') LIKE '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "build_date";
			$columnSortOrder = "desc";
		}		
		$cond="select * from builds where 1".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from builds";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(id) as cnt from builds where 1".$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function deploy_builds_ps(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="select * from builds where id=".$id;
        $build_details = $this->users_model->special_fetch($cond);
		if(count($build_details)>0)
		{	
			$build_no=$build_details[0]['build_no'];
			$cur_build_no="";
			$cond="select min(build_no) as cur_build_no from builds where is_deployed=0";
        	$old_build_details = $this->users_model->special_fetch($cond);
			if($old_build_details[0]['cur_build_no']!="")
				$cur_build_no=$old_build_details[0]['cur_build_no'];
			if($cur_build_no!=$build_no&&$cur_build_no!="")
			{
				$msg="Please Deploy Build ".$cur_build_no." Before Deploying ".$build_no;
				$out = array('statuscode'=>'201','statusdescription'=>$msg);
			}
			else
			{				
				$parent_folder="/var/www/proscola.com/builds";
				$target_folder="/var/www/proscola.com/ps_test";
				$target_folder_api="/var/www/proscola.com/ps_test_api";
				$sub_folder_name=$parent_folder. '/' .$build_no;
				$upload_flag=false;
				if (file_exists($sub_folder_name) && is_dir($sub_folder_name)) 
				{
					$file_path = $sub_folder_name."/builds_no.txt";
					$file_contents = file_get_contents($file_path);
					if($file_contents==$build_no)
					{
						$dir = $sub_folder_name."/build_files";
						$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
						foreach ($iterator as $file) 
						{
							if ($file->isFile()) 
							{
								$file_path = $file->getPathname();
								$dirs = explode(DIRECTORY_SEPARATOR, $file_path);
								$build_files_index = array_search('build_files', $dirs);
								$build_files_api_index = array_search('api', $dirs);
								if ($build_files_index !== false) 
								{
									$sub_dirs = array_slice($dirs, $build_files_index+1);
									$sub_path = implode(DIRECTORY_SEPARATOR, $sub_dirs);
									if ($build_files_api_index !== false) 
									{
										$final_target_folder=$target_folder_api.'/'.$sub_path;
										$second_api_pos = strpos($final_target_folder, 'api/', strpos($final_target_folder, 'api/') + 1);
										if ($second_api_pos !== false) {
											// Remove the second occurrence of "api/"
											$final_target_folder = substr_replace($final_target_folder, '', $second_api_pos, 4);
										}										
									}
									else
									{
										$final_target_folder=$target_folder.'/'.$sub_path;
									}
									$extension = strtolower(pathinfo($final_target_folder, PATHINFO_EXTENSION));
									if($extension=='zip')
									{
										$destination_folder = dirname($final_target_folder);
										$zip = new ZipArchive;
										if ($zip->open($file_path) === TRUE) 
										{
											$zip->extractTo($destination_folder);
											$zip->close();        
											$upload_flag=true;
										}
									}
									else
									{
										if (copy($file_path, $final_target_folder)) {
											$upload_flag=true;
										}	
									}
								}
							}
						} 
						$file_path = $sub_folder_name."/ps_test_instance.txt";
						$file_contents = file_get_contents($file_path);  // read the contents of the file
						$db_arr=explode(";",$file_contents);
						$file_flag=true;
						if($file_contents!="")
						{	
							$db_debug = $this->db->db_debug; //save setting
							$this->db->db_debug = FALSE; //disable debugging for queries							
							foreach($db_arr as $sql)
							{
								if($sql!="")
								{
									$file_contents_temp = file_get_contents($file_path);
									$query=$this->db->query($sql);
									if ($query === FALSE) {}
									else
									{
										$sql=$sql.";";
										$new_file_contents = str_replace($sql, "", $file_contents_temp);
										file_put_contents($file_path, $new_file_contents);
									}
								}
							}	
							$this->db->db_debug = $db_debug;
							$file_contents_temp = file_get_contents($file_path);
							if($file_contents_temp!="")
								$file_flag=false;
						}
						if($file_flag)	
						{					
							$input = array(
								'is_deployed'=>1
							);
							$this->builds_model->edit($input,$id);								
							$out = array('statuscode'=>'200','statusdescription'=>'Build Deployed Successfully');
						}
						else
							$out = array('statuscode'=>'201','statusdescription'=>'Unable To Update Database Instance - Please Check For DB Errors');
					}
					else
					{
						$out = array('statuscode'=>'201','statusdescription'=>'Invalid Build Number - Build Might Be Corrupted - Please Verify');
					}
				} 
				else 
				{
					$out = array('statuscode'=>'201','statusdescription'=>'Build Not Found - Please Make Sure Build Is Upgraded');
				}	
			}			
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Unable To Locate Build - Please Contact Development Team');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function deploy_live_builds_ps(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="select * from builds where id=".$id;
        $build_details = $this->users_model->special_fetch($cond);
		if(count($build_details)>0)
		{		
			if($build_details[0]['is_deployed']==0)
			{
				$out = array('statuscode'=>'201','statusdescription'=>'Build Is Not Deployed Yet In PS Test - Please Make Sure Build Is Deployed In PS Test For Live Deployment');
			}	
			else
			{
				$cond="select * from builds where build_no<=".$build_details[0]['build_no']." and is_live=0 order by build_no asc";
        		$all_build_details = $this->users_model->special_fetch($cond);
				$build_error=false;
				$build_err_msg="";
				foreach($all_build_details as $build)
				{
					if($build['is_deployed']==0)
					{
						$build_error=true;
						if($build_err_msg=="")
							$build_err_msg=$build['build_no'];
						else
							$build_err_msg=$build_err_msg.",".$build['build_no'];
					}
				}
				if($build_error)
				{
					$msg=$build_err_msg." Builds Are Not Deployed Yet In PS Test - Please Make Sure Build Is Deployed In PS Test For Live Deployment";
					$out = array('statuscode'=>'201','statusdescription'=>$msg);
				}
				else
				{
					$build_done_flag=true;$error_msg="";
					foreach($all_build_details as $build)
					{
						$build_no=$build_details[0]['build_no'];
						$parent_folder="/var/www/proscola.com/builds";
						$target_folder="/var/www/proscola.com";
						$sub_folder_name=$parent_folder. '/' .$build_no;
						$upload_flag=false;
						$file_path = $sub_folder_name."/builds_no.txt";
						$file_contents = file_get_contents($file_path);
						if($file_contents==$build_no)
						{
							$dir = $sub_folder_name."/build_files";
							$iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir));
							foreach ($iterator as $file) 
							{
								if ($file->isFile()) 
								{
									$file_path = $file->getPathname();
									$dirs = explode(DIRECTORY_SEPARATOR, $file_path);
									$build_files_index = array_search('build_files', $dirs);
									if ($build_files_index !== false) 
									{
										$sub_dirs = array_slice($dirs, $build_files_index+1);
										$sub_path = implode(DIRECTORY_SEPARATOR, $sub_dirs);
										$final_target_folder=$target_folder.'/'.$sub_path;
										$extension = strtolower(pathinfo($final_target_folder, PATHINFO_EXTENSION));
										if($extension=='zip')
										{
											$destination_folder = dirname($final_target_folder);
											$zip = new ZipArchive;
											if ($zip->open($file_path) === TRUE) 
											{
												$zip->extractTo($destination_folder);
												$zip->close();        
												$upload_flag=true;
											}
										}
										else
										{
											if (copy($file_path, $final_target_folder)) {
												$upload_flag=true;
											}	
										}
									}
								}
							} 
							$this->load_database('proscola_school_live');
							$cond="select domain_id from admin where is_active=1";
							$admin_details = $this->users_model->special_fetch($cond);
							$file_flag=true;
							foreach($admin_details as $admin)
							{
								$domain_id=$admin['domain_id'];
								$db_file=$domain_id."_instance.txt";
								$file_path = $sub_folder_name."/".$db_file;
								$file_contents = file_get_contents($file_path);  // read the contents of the file
								$db_arr=explode(";",$file_contents);
								$this->load_database($domain_id);
								if($file_contents!="")
								{	
									$db_debug = $this->db->db_debug; //save setting
									$this->db->db_debug = FALSE; //disable debugging for queries							
									foreach($db_arr as $sql)
									{
										if($sql!="")
										{
											$file_contents_temp = file_get_contents($file_path);
											$query=$this->db->query($sql);
											if ($query === FALSE) {}
											else
											{
												$sql=$sql.";";
												$new_file_contents = str_replace($sql, "", $file_contents_temp);
												file_put_contents($file_path, $new_file_contents);
											}
										}
									}	
									$this->db->db_debug = $db_debug;
									$file_contents_temp = file_get_contents($file_path);
									if($file_contents_temp!="")
									{
										$file_flag=false;
										break;
									}
								}
							}
							if($file_flag)	
							{	
								$this->load_database(2);				
								$timestamp = time(); 
								$build_date = date('Y-m-d', $timestamp);
								$input = array(
									'release_date'=>$build_date,
									'is_live'=>1
								);
								$this->builds_model->edit($input,$id);
							}
							else
							{
								$error_msg="Unable To Update Database Instance For ".$build_no." Build - Please Contact Development Team For More Information";
								$build_done_flag=false;	
								break;
							}
						}
						else
						{
							$error_msg="Unable To Locate ".$build_no." In Repository - Please Contact Development Team For More Information";	
							$build_done_flag=false;						
							break;
						}							
					}
					if($build_done_flag)
					{
						$out = array('statuscode'=>'200','statusdescription'=>'Build Deployed Successfully In Live Envrionment');
					}
					else
					{
						$out = array('statuscode'=>'201','statusdescription'=>$error_msg);
					}
				}
			}		
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Unable To Locate Build - Please Contact Development Team For More Information');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    } 	
}
