<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Bulk_labeling_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	function get_labels_page($lang_id)
    { 
		$cond="select name,label_id from labels where page_id=54 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
    function view_modules(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$lang_fld = $data['lang_fld'];
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and lower(module) like '%".$searchValue."%'";
	   	}
		if($lang_fld == ''){
			$searchQuery .= " and lang_id=1";			
	    }
		else
		{
			$searchQuery .= " and lang_id=".$lang_fld;	
		}
		if($columnName=="")
		{
			$columnName = "module";
			$columnSortOrder = "asc";
		}
		$cond="select * from modules where 1".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from modules";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from modules where 1".$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    } 
	function view_filter_section(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$lang_id = $data['lang_id'];
		$module_id = $data['module_id'];
		$section_id = $data['section'];				
		$cond="select page_id from modules where id=".$module_id;
		$mod_details = $this->users_model->special_fetch($cond);
		$page_id=$mod_details[0]['page_id'];
		$bulk_label_details=array();
		if($lang_id=="")
			$lang_id=1;
		if($page_id=='57')
			$section_id=25;
		$cond="SELECT id,name,type FROM labels WHERE page_id=".$page_id." and section_id=".$section_id." and lang_id=1 and status=0 order by label_id asc";
		$label_details = $this->users_model->special_fetch($cond);
		$cond="SELECT id,name,type FROM labels WHERE page_id=".$page_id." and section_id=".$section_id." and lang_id=".$lang_id." and status=0 order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$i=0;
		foreach($label_details as $label)
		{
			$field_type=$label['type'];
			$value=$label['name'];
			$editable_value="";
			$id=$label['id'];
			if($lang_id==1)
			{
				$editable_value=$value;
				$field_type_editable=$field_type;
			}
			else
			{	
				$editable_value=$lbl_details[$i]['name'];
				$id=$lbl_details[$i]['id'];
				$field_type_editable=$lbl_details[$i]['type'];
			}
			$bulk_label_details[]=array(
				"id"=>$id,
				"field_type"=>$field_type,
				"field_type_editable"=>$field_type_editable,
				"value"=>$value,
				"editable_value"=>$editable_value
			);
			$i++;
		}
		$totalRecord=count($bulk_label_details);
		$totalRecordwithFilter = $totalRecord;
		$search_count=0;
		$bulk_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($bulk_label_details);$i++)
			{
				if(strpos(strtolower($bulk_label_details[$i]['field_type']), $searchValue) !== false||strpos(strtolower($bulk_label_details[$i]['value']), $searchValue) !== false||strpos(strtolower($bulk_label_details[$i]['editable_value']), $searchValue) !== false)
				{
					$bulk_details[]=$bulk_label_details[$i];
				}
			}
			$search_count=count($bulk_details);
		}
		else{
			$bulk_details=$bulk_label_details;
		}
		if($search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($bulk_details)<=0)
			$bulk_details=array();
		$output = array_slice($bulk_details, $start, $rowperpage); 
		$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_filter_sub_section(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$lang_id = $data['lang_id'];
		$page_id = $data['page_id'];
		$section_id = $data['section_id'];				
		$bulk_label_details=array();
		if($lang_id=="")
			$lang_id=1;
		if($page_id=='57')
			$section_id=25;
		$cond="SELECT id,name,type FROM labels WHERE page_id=".$page_id." and section_id=".$section_id." and lang_id=1 and status=0";
		$label_details = $this->users_model->special_fetch($cond);
		$cond="SELECT id,name,type FROM labels WHERE page_id=".$page_id." and section_id=".$section_id." and lang_id=".$lang_id." and status=0";
		$lbl_details = $this->users_model->special_fetch($cond);
		$i=0;
		foreach($label_details as $label)
		{
			$field_type=$label['type'];
			$value=$label['name'];
			$editable_value="";
			$id=$label['id'];
			if($lang_id==1)
			{
				$editable_value=$value;
				$field_type_editable=$field_type;
			}
			else
			{	
				$editable_value=$lbl_details[$i]['name'];
				$id=$lbl_details[$i]['id'];
				$field_type_editable=$lbl_details[$i]['type'];
			}
			$bulk_label_details[]=array(
				"id"=>$id,
				"field_type"=>$field_type,
				"field_type_editable"=>$field_type_editable,
				"value"=>$value,
				"editable_value"=>$editable_value
			);
			$i++;
		}
		$totalRecord=count($bulk_label_details);
		$totalRecordwithFilter = $totalRecord;
		$search_count=0;
		$bulk_details=array();
		if($searchValue != ''){
			for($i=0;$i<count($bulk_label_details);$i++)
			{
				if(strpos($bulk_label_details[$i]['field_type'], $searchValue) !== false||strpos($bulk_label_details[$i]['value'], $searchValue) !== false||strpos($bulk_label_details[$i]['editable_value'], $searchValue) !== false)
				{
					$bulk_details[]=$bulk_label_details[$i];
				}
			}
			$search_count=count($bulk_details);
		}
		else{
			$bulk_details=$bulk_label_details;
		}
		if($search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($bulk_details)<=0)
		{
			$bulk_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		$output = array_slice($bulk_details, $start, $rowperpage); 
		$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
    
    function edit_bulk_labeling(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id=$data[0]['lang_id'];
		$label_details_str = $this->get_labels_page($lang_id); 
		$id=$data[0]['id'];
		$cond="select page_id,section_id,lang_id from labels where id=".$id;
		$lbl_details = $this->users_model->special_fetch($cond);
		foreach($data as $labels)
		{
			if($labels['change_all']==1)
			{
				$cond="select name,type from labels where id=".$labels['id'];
				$label_details = $this->users_model->special_fetch($cond);
				if($labels['value']!=$label_details[0]['name'])
				{
					$input = array(
						'new_name'=>$labels['value'],
						'old_name'=>$label_details[0]['name'],
						'section_id'=>$lbl_details[0]['section_id'],
						'lang_id'=>$lbl_details[0]['lang_id']
					);
					$this->bulk_labeling_model->edit_labels_name($input);
				}
				if($labels['field_type']!=$label_details[0]['type'])
				{
					$input = array(
						'new_type'=>$labels['field_type'],
						'old_type'=>$label_details[0]['type'],
						'section_id'=>$lbl_details[0]['section_id'],
						'lang_id'=>$lbl_details[0]['lang_id']
					);
					$this->bulk_labeling_model->edit_labels_type($input);
				}
			}
			else
			{
				$input = array(
					'name'=>$labels['value'],
					'type'=>$labels['field_type']
				);
				$this->bulk_labeling_model->edit($input,$labels['id']);
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details_str[114]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
}
