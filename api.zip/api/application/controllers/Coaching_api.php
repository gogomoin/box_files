<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Coaching_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=44 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//coaching
	function view_coaching(){
		
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$tutor_fld = $data['tutor_fld'];
		$student_fld = $data['student_fld'];
		$deadline_fld = $data['deadline_fld'];
		$coaching_date_fld = $data['coaching_date_fld'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$delQuery = "";
		if($columnName=="")
		{
			$columnName = "a.created_at";
			$columnSortOrder = "desc";
		}
		if($term_fld=="")
		{
			$cond="select * from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
				$term_fld=$term_details[0]['id'];
			else
				$term_fld="";
		}
		/* if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		} */
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and a.is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and a.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and a.is_deleted=0";	
		}
		$per_query='';
		$flag=true;
		$group_arr=explode(",",$group_id);
		if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
			{
				$per_query = " and st.student_id in(".$par_details[0]['student_id'].")";
				$cond="SELECT a.* FROM coaching_protocols a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
			}
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and st.student_id=".$id;
			$cond="SELECT a.* FROM coaching_protocols a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
		}
		else
		{
			$cond="SELECT a.* FROM coaching_protocols a where 1".$delQuery.$searchQuery;
		}
		if($flag)
		{
			$totalRecord="";$totalRecordwithFilter="";$page_details=array();
			$page_details = $this->coaching_model->special_fetch($cond);
			
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$coaching_category_id =$student['coaching_category_id'];
				$student_term_id=$student['student_term_id'];
				$cond="select student_id,term_id,coach_id,class_id,main_level_id from students_terms where id=".$student_term_id;
				$student_term_details = $this->coaching_model->special_fetch($cond);
				if(count($student_term_details)>0)
				{
					$student_id=$student_term_details[0]['student_id'];
					$view_flag=true;
					if (in_array(5, $group_arr))
					{
						if($student_id!=$id)
							$view_flag=false;
					}
					if($view_flag)
					{
						$term_id=$student_term_details[0]['term_id'];
						$coach_id=$student_term_details[0]['coach_id'];
						$cond="select name from terms where id=".$term_id;
						$term_details = $this->coaching_model->special_fetch($cond);
						if(count($term_details)>0)
							$term=$term_details[0]['name'];
						else
							$term="";
						$cond="select first_name,last_name from users where id=".$student_id;
						$stu_details = $this->coaching_model->special_fetch($cond);
						if(count($stu_details)>0)
							$student_name=$stu_details[0]['first_name']." ".$stu_details[0]['last_name'];
						else
							$student_name="";
						$cond="select first_name,last_name from users where id=".$coach_id;
						$tutor_details = $this->coaching_model->special_fetch($cond);
						if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
						$cond="select name from coaching_categories where id=".$coaching_category_id;
						$ab_details = $this->coaching_model->special_fetch($cond);
						$coaching_category=$ab_details[0]['name'];
						$student_all_details[]=array(
							"id"=>$student['id'],
							"term"=>$term,
							"student_name"=>$student_name,
							"coaching_category"=>$coaching_category,
							"deadline_date"=>$student['deadline_date'],
							"coaching_date"=>$student['coaching_date'],
							"student_agenda"=>$student['student_agenda'],
							"personnel_agenda"=>$student['personnel_agenda'],
							"arrangement"=>$student['arrangement'],
							"initiator"=>$student['initiator'],
							"protocol"=>$student['protocol'],
							"is_active"=>$student['is_active'],
							"is_deleted"=>$student['is_deleted'],
							"is_fulfilled"=>$student['is_fulfilled'],
							"tutor"=>$tutor,
							"term_id"=>$term_id,
							"student_id"=>$student_id,
							"coaching_category_id"=>$coaching_category_id,
							"tutor_id"=>$coach_id
						);
					}
				}
			}
			
			$totalRecord = count($student_all_details);
			$totalRecordwithFilter = $totalRecord;
			$student_filter_details=array();
			$filter_count=0;
			if($term_fld!=""||$tutor_fld!=""||$student_fld!=""||$deadline_fld!=""||$coaching_date_fld!="")
			{
				for($i=0;$i<count($student_all_details);$i++)
				{				
					$term_flag=true;$tutor_flag=true;$student_flag=true;$deadline_flag=true;$coaching_date_flag=true;
					if($term_fld!="")
					{
						if($term_fld!=$student_all_details[$i]['term_id'])
							$term_flag=false;
					}
					if($student_fld!="")
					{
						if($student_fld!=$student_all_details[$i]['student_id'])
							$student_flag=false;
					}
					if($tutor_fld!="")
					{
						if($tutor_fld!=$student_all_details[$i]['tutor_id'])
							$tutor_flag=false;
					}
					if($deadline_fld!="")
					{
						if($deadline_fld!=$student_all_details[$i]['deadline_date'])
							$deadline_flag=false;
					}
					if($coaching_date_fld!="")
					{
						if($coaching_date_fld!=$student_all_details[$i]['coaching_date'])
							$coaching_date_flag=false;
					}
					if($term_flag&&$student_flag&&$tutor_flag&&$deadline_flag&&$coaching_date_flag)
					{
						$student_filter_details[]=$student_all_details[$i];
					}
				}
				$filter_count=count($student_filter_details);
			}
			else
			{
				$student_filter_details=$student_all_details;
			}
			$search_count=0;
			$coaching_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($student_filter_details);$i++)
				{
					if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['deadline_date']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['coaching_date']), $searchValue) !== false)
					{
						$coaching_details[]=$student_filter_details[$i];
					}
				}
				$search_count=count($coaching_details);
			}
			else{
				$coaching_details=$student_filter_details;
			}
			if($filter_count==0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			else if($filter_count!=0&&$search_count==0)
				$totalRecordwithFilter=$filter_count;
			else if($filter_count!=0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($coaching_details)<=0)
			{
				$coaching_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($coaching_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $coaching_details);
			}
			$output = array_slice($coaching_details, $limit, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function view_students_for_coaching(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld_list = $data['term_fld_list'];
		$status_fld_list = $data['status_fld_list'];
		$student_fld_list = $data['student_fld_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($student_fld_list != ''){
			$searchQuery .= " and s.id=".$student_fld_list;			
	    }
		if($status_fld_list != ''&&$status_fld_list != 'all'){
			$searchQuery .= " and u.is_active=".$status_fld_list;			
	    }
		$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id and s.is_deleted=0".$searchQuery;
		$page_details = $this->students_terms_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$student_name=$student['first_name']." ".$student['last_name'];
			$grade="";$grade_id="";$study_level="";$study_level_id="";$tutor="";$tutor_id="";$term="";$term_id="";
			$cond="select * from students_terms where student_id=".$student['id'];
			$student_term_details = $this->students_terms_model->special_fetch($cond);
			if(count($student_term_details)>0)
			{
				$term_id=$student_term_details[0]['term_id'];
				$grade_id=$student_term_details[0]['class_id'];
				$study_level_id=$student_term_details[0]['main_level_id'];
				$tutor_id=$student_term_details[0]['coach_id'];
				$cond="select name from terms where id=".$term_id;
				$term_details = $this->students_terms_model->special_fetch($cond);
				if(count($term_details)>0)
					$term=$term_details[0]['name'];	
				else
					$term="";
				if($grade_id!="")
				{
					$cond="select name from classes where id=".$grade_id;
					$class_details = $this->students_terms_model->special_fetch($cond);
					if(count($class_details)>0)
						$grade=$class_details[0]['name'];
					else
						$grade="";
				}
				else
					$grade="";
				if($study_level_id!="0"&&$study_level_id!="")
				{
					$cond="select name from main_levels where id=".$study_level_id;
					$study_level_details = $this->students_terms_model->special_fetch($cond);
					if(count($study_level_details)>0)
						$study_level=$study_level_details[0]['name'];
					else
						$study_level="";
				}
				else
					$study_level="";
				if($tutor_id!="")
				{
					$cond="select first_name,last_name from users where id=".$tutor_id;
					$tutor_details = $this->students_terms_model->special_fetch($cond);
					if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"class_id"=>$grade_id,
					"main_level_id"=>$study_level_id,
					"coach_id"=>$tutor_id
				);
			}
		}
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($term_fld_list!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$term_flag=true;
				if($term_fld_list!="")
				{
					if($term_fld_list!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($term_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		$search_count=0;
		$students_terms_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_terms_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_terms_details);
		}
		else{
			$students_terms_details=$student_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_terms_details)<=0)
			$students_terms_details=array();
		else
		{
			foreach ($students_terms_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_terms_details);
		}
		$output = array_slice($students_terms_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }

	function get_student_marks(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		if($student_id=="")
		{
			$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
		}
		else
		{
			$cond="SELECT group_concat(c.id) as ids FROM course_attendants c,students_terms st WHERE c.student_term_id=st.id and st.student_id=".$student_id." and st.term_id=".$term_id;
			$student_details = $this->students_terms_model->special_fetch($cond);
			$course_att_ids=$student_details[0]['ids'];
			if($course_att_ids!="")
			{
				
				$totalRecord="";$totalRecordwithFilter="";$page_details=array();
				$cond="SELECT DISTINCT(m.mark_id),c.course_id,m.evaluation_date,m.mark_category_id FROM course_attendants_marks m,course_attendants c WHERE m.course_attendant_id=c.id and m.course_attendant_id in(".$course_att_ids.") group by m.mark_id limit ".$start.",".$rowperpage;
				$page_details = $this->students_terms_model->special_fetch($cond);
				$totalRecord = count($page_details);
				$student_all_details=array();
				$total_avg=0;$mrk_avg=0;$wt_avg=0;
				foreach($page_details as $student)
				{
					if($student['mark_id']!="")
					{
						$cond="select number_value from marks where id=".$student['mark_id'];
						$mar_details = $this->students_terms_model->special_fetch($cond);
						if(count($mar_details)>0)
							$mark=$mar_details[0]['number_value'];
						else
							$mark=0;
					}
					else
							$mark=0;
					if($student['course_id']!="")
					{
						$cond="select name from courses where id=".$student['course_id'];
						$course_details = $this->students_terms_model->special_fetch($cond);
						if(count($course_details)>0)
							$course=$course_details[0]['name'];
						else
							$course="";
					}
					else
						$course="";
					$cond="select factor from mark_categories where id=".$student['mark_category_id'];
					$mrk_cat_details = $this->students_terms_model->special_fetch($cond);
					$wt1=0;
					if(count($mrk_cat_details)>0)
						$wt1=$mrk_cat_details[0]['factor'];
					$cond="select assessment_value from subject_types st,subjects s,courses c where c.subject_id=s.id and st.id=s.subject_type_id and c.id=".$student['course_id'];
					$mrk_sub_details = $this->students_terms_model->special_fetch($cond);
					$wt2=0;
					if(count($mrk_sub_details)>0)
						$wt2=$mrk_sub_details[0]['assessment_value'];	
					if($mark!=0&&$wt1&&$wt2!=0)	
					{				
						$mrk_avg=$mrk_avg+($mark*$wt1*$wt2);
						$wt_avg=$wt_avg+($wt1*$wt2);
					}
					$student_all_details[]=array(
						"mark"=>$mark,
						"course"=>$course,
						"eval_date"=>$student['evaluation_date']
					);
				}
				if(count($student_all_details)>0)
				{
					if($wt_avg>0)
						$total_avg=round(($mrk_avg/$wt_avg),2);
					$student_all_details[0]['total_avg']=$total_avg;
					$totalRecordwithFilter = $totalRecord;
				}
				else
				{
					$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
				}
			}
			else
			{
				$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$student_all_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function get_student_disciplinary(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$student_id = $data['student_id'];
		$student_all_details=array();
		if($student_id=="")
		{
			$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
		}
		else
		{
			$cond="SELECT count(d.disciplinary_category_id) as counts,d.disciplinary_category_id as id FROM disciplinary_protocols d,students_terms st where st.id=d.student_term_id and student_id=".$student_id." group by d.disciplinary_category_id";
			$page_details = $this->students_terms_model->special_fetch($cond);
			if(count($page_details)>0)
			{
				if($page_details[0]['id']!="")
				{
					$totalRecord = count($page_details);
					$totalRecordwithFilter = $totalRecord;
					foreach($page_details as $student)
					{
						$cond="select name from disciplinary_categories where id=".$student['id'];
						$dis_details = $this->students_terms_model->special_fetch($cond);
						if(count($dis_details)>0)
							$category=$dis_details[0]['name'];
						else
							$category="N/A";
						$student_all_details[]=array(
							"counts"=>$student['counts'],
							"category"=>$category
						);
					}
				}
				else
				{
					$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
				}
			}
			else
			{
				$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$student_all_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function get_student_absences(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$student_id = $data['student_id'];
		$student_all_details=array();
		if($student_id=="")
		{
			$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
		}
		else
		{
			$cond="SELECT count(d.absence_category_id) as counts,d.absence_category_id as id FROM absences d,students_terms st where st.id=d.student_term_id and student_id=".$student_id." group by d.absence_category_id";
			$page_details = $this->students_terms_model->special_fetch($cond);
			if(count($page_details)>0)
			{
				if($page_details[0]['id']!="")
				{
					$totalRecord = count($page_details);
					$totalRecordwithFilter = $totalRecord;
					foreach($page_details as $student)
					{
						$cond="select name from absence_categories where id=".$student['id'];
						$dis_details = $this->students_terms_model->special_fetch($cond);
						if(count($dis_details)>0)
							$category=$dis_details[0]['name'];
						else
							$category="N/A";
						$student_all_details[]=array(
							"counts"=>$student['counts'],
							"category"=>$category
						);
					}
				}
				else
				{
					$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
				}
			}
			else
			{
				$totalRecord=0;$totalRecordwithFilter=0;$student_all_details=array();
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$student_all_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_coaching(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		$coaching_category_id = $data['coaching_category_id'];
		$deadline_date = $data['deadline_date'];
		$coaching_date = $data['coaching_date'];
		$student_agenda = $data['student_agenda'];
		$personnel_agenda = $data['personnel_agenda'];
		$protocol = $data['protocol'];
		$arrangement = $data['arrangement'];
		$is_fulfilled = $data['is_fulfilled'];
		$status = $data['status'];
		$cond="select id from students_terms where student_id=".$student_id." and term_id=".$term_id;
		$student_term_details = $this->coaching_model->special_fetch($cond);
		if(count($student_term_details)>0)
		{
			$student_term_id=$student_term_details[0]['id'];
			$input = array(
				'student_term_id'=>$student_term_id,
				'coaching_category_id'=>$coaching_category_id,
				'deadline_date'=>$deadline_date,
				'coaching_date'=>$coaching_date,
				'student_agenda'=>$student_agenda,
				'personnel_agenda'=>$personnel_agenda,
				'protocol'=>$protocol,
				'arrangement'=>$arrangement,
				'is_fulfilled'=>$is_fulfilled,
				'is_active'=>$status
			);
			$this->coaching_model->add($input);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[164]['name']);	
		}		
		else
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[265]['name']);	
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function edit_coaching(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		$coaching_category_id = $data['coaching_category_id'];
		$deadline_date = $data['deadline_date'];
		$coaching_date = $data['coaching_date'];
		$student_agenda = $data['student_agenda'];
		$personnel_agenda = $data['personnel_agenda'];
		$protocol = $data['protocol'];
		$arrangement = $data['arrangement'];
		$is_fulfilled = $data['is_fulfilled'];
		$status = $data['status'];
		$input = array(
			'coaching_category_id'=>$coaching_category_id,
			'deadline_date'=>$deadline_date,
			'coaching_date'=>$coaching_date,
			'student_agenda'=>$student_agenda,
			'personnel_agenda'=>$personnel_agenda,
			'protocol'=>$protocol,
			'arrangement'=>$arrangement,
			'is_fulfilled'=>$is_fulfilled,
			'is_active'=>$status
		);
		$this->coaching_model->edit($input,$id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[165]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    	    
    function delete_coaching(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->coaching_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[166]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function restore_coaching(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->coaching_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[167]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_coaching(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['student_name']==""||$page['coaching_category']==""||$page['coaching_date']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['coaching_category'];
				$corrupt_arr[] =$page['coaching_date'];
				$corrupt_arr[] =$page['deadline_date'];
				$corrupt_arr[] =$page['student_agenda'];
				$corrupt_arr[] =$page['personnel_agenda'];
				$corrupt_arr[] =$page['protocol'];
				$corrupt_arr[] =$page['arrangement'];
				$corrupt_arr[] =$page['is_fulfilled'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[264]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['coaching_category'];
					$error_arr[] =$page['coaching_date'];
					$error_arr[] =$page['deadline_date'];
					$error_arr[] =$page['student_agenda'];
					$error_arr[] =$page['personnel_agenda'];
					$error_arr[] =$page['protocol'];
					$error_arr[] =$page['arrangement'];
					$error_arr[] =$page['is_fulfilled'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[169]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['coaching_category_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['coaching_category'];
					$error_arr[] =$page['coaching_date'];
					$error_arr[] =$page['deadline_date'];
					$error_arr[] =$page['student_agenda'];
					$error_arr[] =$page['personnel_agenda'];
					$error_arr[] =$page['protocol'];
					$error_arr[] =$page['arrangement'];
					$error_arr[] =$page['is_fulfilled'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[170]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['coaching_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['coaching_category'];
					$error_arr[] =$page['coaching_date'];
					$error_arr[] =$page['deadline_date'];
					$error_arr[] =$page['student_agenda'];
					$error_arr[] =$page['personnel_agenda'];
					$error_arr[] =$page['protocol'];
					$error_arr[] =$page['arrangement'];
					$error_arr[] =$page['is_fulfilled'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[171]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['deadline_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['coaching_category'];
					$error_arr[] =$page['coaching_date'];
					$error_arr[] =$page['deadline_date'];
					$error_arr[] =$page['student_agenda'];
					$error_arr[] =$page['personnel_agenda'];
					$error_arr[] =$page['protocol'];
					$error_arr[] =$page['arrangement'];
					$error_arr[] =$page['is_fulfilled'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[172]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$term_id=0;
					$cond="select * from terms where is_deleted=0";
					$term_details = $this->users_model->special_fetch($cond);
					$cur_time=time();
					foreach($term_details as $term)
					{
						if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
						{
							$term_id=$term['id'];
						}
					}
					$cond="select id from students_terms where student_id=".$page['student_id']." and term_id=".$term_id;
					$student_term_details = $this->coaching_model->special_fetch($cond);
					if(count($student_term_details)>0)
					{
						$student_term_id=$student_term_details[0]['id'];
						$input = array(
							'student_term_id'=>$student_term_id,
							'coaching_category_id'=>$page['coaching_category_id'],
							'deadline_date'=>$page['deadline_date'],
							'coaching_date'=>$page['coaching_date'],
							'student_agenda'=>$page['student_agenda'],
							'personnel_agenda'=>$page['personnel_agenda'],
							'protocol'=>$page['protocol'],
							'arrangement'=>$page['arrangement'],
							'is_fulfilled'=>$page['is_fulfilled_val'],
							'is_active'=>$page['status_val']
						);	
						$this->coaching_model->add($input);
						$flag=true;
					}
					else
					{
						$error_arr=array();
						$error_arr[] =$page['student_name'];
						$error_arr[] =$page['coaching_category'];
						$error_arr[] =$page['coaching_date'];
						$error_arr[] =$page['deadline_date'];
						$error_arr[] =$page['student_agenda'];
						$error_arr[] =$page['personnel_agenda'];
						$error_arr[] =$page['protocol'];
						$error_arr[] =$page['arrangement'];
						$error_arr[] =$page['is_fulfilled'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[249]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[173]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function validateDate($date, $format = 'd-m-Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
	function get_coaching_type(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from coaching_categories where is_deleted=0 and is_active=1 order by name asc";
		$coaching_type_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','coaching_type_details'=>$coaching_type_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_student_details(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$student_details=array();
		$student_id = $data['id'];
		$cond="select s.*,u.first_name,u.last_name,u.avatar from students s,users u where u.id=s.id and s.id=".$student_id;
		$stu_details = $this->users_model->special_fetch($cond);
		foreach($stu_details as $student)
		{
			$cond="select class_id from students_terms st,terms t where st.term_id=t.id and t.is_active=1 and st.student_id=".$student_id;
			$class_details = $this->users_model->special_fetch($cond);
			if(count($class_details)>0)
			{
				$cond="select name from classes where id=".$class_details[0]['class_id'];
				$grade_details = $this->users_model->special_fetch($cond);
				if(count($grade_details)>0)
					$grade=$grade_details[0]['name'];
				else
					$grade="";
			}
			else
				$grade="";
			$student_name=$student['first_name']." ".$student['last_name'];
			$cond="SELECT GROUP_CONCAT(DISTINCT(cr.subject_id)) as subject_ids FROM course_attendants c,students_terms st,courses cr WHERE st.id=c.student_term_id and c.course_id=cr.id and st.student_id=".$student_id;
			$sub_details = $this->users_model->special_fetch($cond);
			$subject_ids=$sub_details[0]['subject_ids'];
			if($subject_ids!="")
			{	
				$cond="SELECT GROUP_CONCAT(name) as names FROM subjects WHERE id in(".$subject_ids.")";
				$sub_details = $this->users_model->special_fetch($cond);
				$subject_names=$sub_details[0]['names'];
			}
			else
			{
				$subject_ids="";
				$subject_names="";
			}
			$student_details[]=array(
				"student_name"=>$student_name,
				"avatar"=>$student['avatar'],
				"remarks"=>$student['remarks'],
				"grade"=>$grade,
				"subject_ids"=>$subject_ids,
				"subject_names"=>$subject_names,
				"personal_weaknesses"=>$student['personal_weaknesses'],
				"personal_strengths"=>$student['personal_strengths'],
				"detailed_career_goals"=>$student['detailed_career_goals'],
				"has_smoking_permission"=>$student['has_smoking_permission'],
				"has_outgoing_permission"=>$student['has_outgoing_permission']
			);
		}
		$out = array('statuscode'=>'200','student_details'=>$student_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_student_marks_data(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$student_details=array();
		$student_id = $data['id'];
		$subject_id = $data['subject_id'];
		$student_term_id = $data['student_term_id'];
		if(!is_array($student_term_id))
		{
			$student_term_id=array();
			$term_id=0;
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_id=$term['id'];
				}
			}
			$student_term_id[]=$term_id;
		}
		$mark_data=array();
		foreach($student_term_id as $terms)
		{
			$data_arr=array();
			if(!is_array($subject_id))
			{
				$cond="SELECT group_concat(c.id) as ids FROM course_attendants c,students_terms st WHERE c.student_term_id=st.id and st.student_id=".$student_id." and st.term_id=".$terms;
				$stu_details = $this->users_model->special_fetch($cond);
				$ids=$stu_details[0]['ids'];
				if($ids!="")
				{
					$cond="select round((sum(m.number_value*mc.factor)/sum(mc.factor)),2) as marks from course_attendants_marks c,marks m,mark_categories mc where c.mark_id=m.id and mc.id=c.mark_category_id and c.course_attendant_id in (".$ids.")";
					$mark_details = $this->students_terms_model->special_fetch($cond);
					if(count($mark_details)>0)
					{
						if($mark_details[0]['marks']!="")
							$data_arr[]=$mark_details[0]['marks'];
					}
					/* $cond="SELECT avg(m.number_value) as total_value FROM course_attendants_marks c,marks m WHERE c.mark_id=m.id and c.course_attendant_id in (".$ids.")";
					$mark_details = $this->users_model->special_fetch($cond);
					$data_arr[]=$mark_details[0]['total_value']; */
				}
			}
			else
			{
				foreach($subject_id as $subject)
				{
					$cond="SELECT group_concat(c.id) as ids FROM course_attendants c,students_terms st,courses cr WHERE c.student_term_id=st.id and c.course_id=cr.id and st.student_id=".$student_id." and st.term_id=".$terms." and subject_id=".$subject;
					$stu_details = $this->users_model->special_fetch($cond);
					$ids=$stu_details[0]['ids'];
					if($ids!="")
					{
						$cond="select round((sum(m.number_value*mc.factor)/sum(mc.factor)),2) as marks from course_attendants_marks c,marks m,mark_categories mc where c.mark_id=m.id and mc.id=c.mark_category_id and c.course_attendant_id in (".$ids.")";
						$mark_details = $this->students_terms_model->special_fetch($cond);
						if(count($mark_details)>0)
						{
							if($mark_details[0]['marks']!="")
								$data_arr[]=$mark_details[0]['marks'];
						}
						/* $cond="SELECT avg(m.number_value) as total_value FROM course_attendants_marks c,marks m WHERE c.mark_id=m.id and c.course_attendant_id in (".$ids.")";
						$mark_details = $this->users_model->special_fetch($cond);
						$data_arr[]=round($mark_details[0]['total_value'],2); */
					}
				}
			}
			$mark_data[]=$data_arr;
		}
		$out = array('statuscode'=>'200','mark_data'=>$mark_data);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_max_mark(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select round(min(number_value)) as min_mark,round(max(number_value)) as max_mark from marks where is_deleted=0 and is_active=1";
		$mark_num_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','min_mark'=>$mark_num_details[0]['min_mark'],'max_mark'=>$mark_num_details[0]['max_mark']);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
}
