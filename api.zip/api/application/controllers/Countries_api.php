<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Countries_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=5 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }	
     
	//Career Goals
	function view_countries(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and lower(name) like '%".$searchValue."%'";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from countries where 1".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from countries where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from countries where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_countries(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$iso = $data['iso'];
		$iso3 = $data['iso3'];
		$num_code = $data['num_code'];
		$phone_code = $data['phone_code'];
		$status = $data['status'];
		$data_arr=array(
				'name'=>$name
			);
        $countries_details = $this->countries_model->get_records($data_arr);
		if(count($countries_details)<=0)
		{
			$data_arr=array(
				'phone_code'=>$phone_code
			);
        	$phone_details = $this->countries_model->get_records($data_arr);
			if(count($phone_details)<=0)
			{
				$input = array(
					'name'=>$name,
					'iso'=>$iso,
					'iso3'=>$iso3,
					'num_code'=>$num_code,
					'phone_code'=>$phone_code,
					'is_active'=>$status,
					'created_at'=>time()
				);
				$mid = $this->countries_model->add($input);
				if($mid){				
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[114]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[115]['name']);
				}
			}
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[116]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[117]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_countries(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$iso = $data['iso'];
		$iso3 = $data['iso3'];
		$num_code = $data['num_code'];
		$phone_code = $data['phone_code'];
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from countries where name='".$name."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$cond="select id from countries where phone_code='".$phone_code."' and id<>".$id;
        	$phone_details = $this->users_model->special_fetch($cond);
			if(count($phone_details)<=0)
			{
				$input = array(
					'name'=>$name,
					'iso'=>$iso,
					'iso3'=>$iso3,
					'num_code'=>$num_code,
					'phone_code'=>$phone_code,
					'is_active'=>$status,
					'updated_at'=>time()
				);
				$mid = $this->countries_model->edit($input,$id);
				if($mid){
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[118]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[119]['name']);
				} 
			}  
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[120]['name']);
			}
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[121]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_countries(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select name from countries where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			if(count($p_details)>0)
				$name=$p_details[0]['name'];
			else
				$name="";
			$cond="select id from students where country=".$id;
			$ab_details = $this->countries_model->special_fetch($cond);
			$cond="select id from personnel	where country=".$id;
			$per_details = $this->countries_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($per_details)<=0)
			{
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->countries_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,",")." ". $label_details[122]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ". $label_details[123]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_countries(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->countries_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[124]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_countries(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from countries where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->countries_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[125]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
    function import_countries(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['iso'];
				$corrupt_arr[] =$page['iso3'];
				$corrupt_arr[] =$page['num_code'];
				$corrupt_arr[] =$page['phone_code'];
				$corrupt_arr[] =$page['status'];					
				$corrupt_arr[] =$label_details[152]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from countries where name='".$page['name']."'";
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['name'];
					$error_arr[] =$page['iso'];
					$error_arr[] =$page['iso3'];
					$error_arr[] =$page['num_code'];
					$error_arr[] =$page['phone_code'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[153]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$input = array(
						'name'=>$page['name'],
						'iso'=>$page['iso'],
						'iso3'=>$page['iso3'],
						'num_code'=>$page['num_code'],
						'phone_code'=>$page['phone_code'],
						'is_active'=>$page['status_val'],
						'created_at'=>time()
					);
					$this->countries_model->add($input);
					$flag=true;
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[128]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
}
