<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Course_attendants_marks_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=41 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	function view_course_attendants_marks(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$evaluation_date_fld = $data['evaluation_date_fld'];
		$has_mark_fld = $data['has_mark_fld'];
		$cond="select c.id,st.student_id from course_attendants c,students_terms st where c.student_term_id=st.id and st.term_id=".$term_fld." and c.course_id=".$course_fld;
		$course_attendant_details = $this->course_attendants_marks_model->special_fetch($cond);
		$course_ids="";
		foreach($course_attendant_details as $course_att)
		{
			if($course_ids=="") 
				$course_ids=$course_att['id'];
			else
			$course_ids=$course_ids.",".$course_att['id'];
		}
		$eval_date_details=array();
		if($course_ids!="")
		{
			$cond="SELECT DISTINCT(evaluation_date) as eval_date FROM course_attendants_marks where course_attendant_id in(".$course_ids.") order by evaluation_date desc";
			$eval_date_details = $this->course_attendants_marks_model->special_fetch($cond);
		}
		$marks_column_details=array();
		$marks_column_details[]=array("title"=>"","data"=>" ");
		$marks_column_details[]=array("title"=>"Student Name","data"=>"student_name");
		$marks_column_details[]=array("title"=>"Avg. Mark","data"=>"avg_mark");
		$i=1;
		foreach($eval_date_details as $eval_date)
		{
			if($evaluation_date_fld!="")
			{
				if($eval_date['eval_date']==$evaluation_date_fld)
				{
					$col_name="col".$i;
					$marks_column_details[]=array("title"=>$eval_date['eval_date'],"data"=>$col_name);
					$i++;
				}
			}
			else
			{
				$col_name="col".$i;
				$marks_column_details[]=array("title"=>$eval_date['eval_date'],"data"=>$col_name);
				$i++;
			}
		}
		$marks_row_details=array();
		$avg_val=0;
		$k=0;
		if(count($course_attendant_details)>0)
		{
			foreach($course_attendant_details as $course_att)
			{
				$row_arr=array();
				$student_id=$course_att['student_id'];
				$course_attendant_id=$course_att['id'];
				if($student_id!=""&&$course_attendant_id!="")
				{
					$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$student_id;
					$stu_details = $this->course_attendants_marks_model->special_fetch($cond);
					if(count($stu_details)>0)
						$student_name=$stu_details[0]['name'];
					else
						$student_name="";
					$row_arr['student_name']=$student_name;
					$cond="SELECT avg(m.number_value) as avg_mark FROM course_attendants_marks c,marks m where c.mark_id=m.id and course_attendant_id=".$course_attendant_id;
					$avg_mark_details = $this->course_attendants_marks_model->special_fetch($cond);
					$avg_mark=$avg_mark_details[0]['avg_mark'];
					if($avg_mark=="")
						$avg_mark=0;
					$row_arr['avg_mark']=$avg_mark;
					$avg_val=$avg_val+$avg_mark;
					$cond="SELECT c.evaluation_date,group_concat(m.number_value) as number_value,group_concat(c.id) as att_id FROM course_attendants_marks c,marks m where c.mark_id=m.id and course_attendant_id=".$course_attendant_id." group by evaluation_date order by evaluation_date desc";
					$course_attendant_details = $this->course_attendants_marks_model->special_fetch($cond);
					$i=1;
					foreach($eval_date_details as $eval_date)
					{
						if($evaluation_date_fld!="")
						{
							if($eval_date['eval_date']==$evaluation_date_fld)
							{
								$col_name="col".$i;
								$eval_flag=true;
								foreach($course_attendant_details as $course_attendant)
								{
									if($eval_date['eval_date']==$course_attendant['evaluation_date'])
									{
										$row_arr[$col_name]=$course_attendant['number_value']."*".$course_attendant['att_id'];
										$eval_flag=false;
										break;
									}					
								}
								if($eval_flag)
									$row_arr[$col_name]="";
								$i++;
							}
						}
						else
						{
							$col_name="col".$i;
							$eval_flag=true;
							foreach($course_attendant_details as $course_attendant)
							{
								if($eval_date['eval_date']==$course_attendant['evaluation_date'])
								{
									$row_arr[$col_name]=$course_attendant['number_value']."*".$course_attendant['att_id'];
									$eval_flag=false;
									break;
								}					
							}
							if($eval_flag)
								$row_arr[$col_name]="";
							$i++;
						}
					}
					$row_arr['student_id']=$student_id;
					$row_arr['course_attendant_id']=$course_attendant_id;
					$marks_row_details[]=$row_arr;
				}
				$k++;
			}
		}
		if($k!=0)
			$avg_val=round($avg_val/$k, 2);
		if(count($marks_row_details)<=0)
		{
			//$marks_column_details=array();
			$avg_val="0.0";
		}
		$out = array('statuscode'=>'200','marks_column_details'=>$marks_column_details,'marks_row_details'=>$marks_row_details,'total_avg'=>$avg_val);
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	//course_attendants_marks
	
	
	function view_students_for_course_attendants_marks(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$student_fld = $data['student_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		}		
		if($student_fld != ''){
			$searchQuery .= " and st.student_id=".$student_fld;			
	    }
		if($course_fld != ''){
			$searchQuery .= " and c.course_id=".$course_fld;			
	    }
		$per_query='';
		$flag=true;
		if($term_fld == ''){
			$flag=false;
		}
		$group_arr=explode(",",$group_id);
		if (in_array(1, $group_arr)||in_array(3, $group_arr))
		{
			$per_query='';
		}
		else if ($group_id=="2")
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT id) as course_id FROM courses WHERE personnel_id=".$id;
			$per_details = $this->users_model->special_fetch($cond);
			if($per_details[0]['course_id']!='')
			{
				$cond="SELECT DISTINCT st.student_id FROM course_attendants c,students_terms st WHERE st.id=c.student_term_id and c.course_id in (".$per_details[0]['course_id'].")";
				$stu_details = $this->users_model->special_fetch($cond);
				if($stu_details[0]['student_id']!='')
					$per_query = " and st.student_id in(".$stu_details[0]['student_id'].")";
				else
					$flag=false;
			}
			else
				$flag=false;
		}
		else if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
				$per_query = " and st.student_id in(".$par_details[0]['student_id'].")";
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and st.student_id=".$id;
		}
		if($flag)
		{
			$total_avg=0;
			$cond="select c.id,st.student_id,st.term_id,c.course_id from course_attendants c,students_terms st where c.student_term_id=st.id and st.term_id=".$term_fld.$searchQuery.$per_query;
			$page_details = $this->course_attendants_marks_model->special_fetch($cond);
			$totalRecord = count($page_details);
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$cond="select concat(first_name,' ',last_name) as student_name from users where id=".$student['student_id'];
				$student_details = $this->students_terms_model->special_fetch($cond);
				if(count($student_details)>0)
					$student_name=$student_details[0]['student_name'];
				else
					$student_name="";
				$cond="select name from terms where id=".$student['term_id'];
				$term_details = $this->students_terms_model->special_fetch($cond);
				if(count($term_details)>0)
					$term=$term_details[0]['name'];
				else
					$term="";
				$cond="select name from courses where id=".$student['course_id'];
				$course_details = $this->students_terms_model->special_fetch($cond);
				if(count($course_details)>0)
					$course=$course_details[0]['name'];
				else
					$course="";					
				$cond="select round((sum(m.number_value*mc.factor)/sum(mc.factor)),2) as marks from course_attendants_marks c,marks m,mark_categories mc where c.mark_id=m.id and mc.id=c.mark_category_id and c.course_attendant_id=".$student['id'];
				$mark_details = $this->students_terms_model->special_fetch($cond);
				$avg_mark=0;
				if(count($mark_details)>0)
				{
					if($mark_details[0]['marks']!="")
						$avg_mark=$mark_details[0]['marks'];
				}
				$cond="select m.number_value as mark,c.evaluation_date,c.is_counted,c.id from course_attendants_marks c,marks m where c.mark_id=m.id and c.course_attendant_id =".$student['id'];
				$stu_details = $this->course_attendants_marks_model->special_fetch($cond);
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"course_id"=>$student['course_id'],
					"course"=>$course,
					"student_details"=>$stu_details,
					"avg_mark"=>$avg_mark
				);
			}
			$totalRecordwithFilter = $totalRecord;
			$search_count=0;
			$student_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($student_all_details);$i++)
				{
					if(strpos(strtolower($student_all_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['course']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['avg_mark']), $searchValue) !== false)
					{
						$student_details[]=$student_all_details[$i];
					}
				}
				$search_count=count($student_details);
			}
			else{
				$student_details=$student_all_details;
			}
			if($search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($student_details)<=0)
			{
				$student_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($student_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $student_details);
				$total_sub_wt=0;$total_mrk=0;$total_avg=0;
				foreach($student_details as $mrk)
				{
					$cond="select assessment_value from subject_types st,subjects s,courses c where c.subject_id=s.id and st.id=s.subject_type_id and c.id=".$mrk['course_id'];
					$mrk_details = $this->students_terms_model->special_fetch($cond);
					if(count($mrk_details)>0)
					{
						if($mrk['avg_mark']!=0)
						{
							$sub_wt=$mrk_details[0]['assessment_value'];
							$total_mrk=$total_mrk+($mrk['avg_mark']*$sub_wt);
							$total_sub_wt=$total_sub_wt+$sub_wt;
						}
					}
				}
				if($total_sub_wt>0)
					$total_avg=round(($total_mrk/$total_sub_wt),2);
				$student_details[0]['total_avg']=$total_avg;
			}
			$output = array_slice($student_details, $start, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output,'total_avg'=>0);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_general_marks(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$student_fld = $data['student_fld'];
		$evaluation_date_fld = $data['evaluation_date_fld'];
		$del_fld = $data['del_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$delQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		}		
		if($student_fld != ''){
			$searchQuery .= " and st.student_id=".$student_fld;			
	    }
		if($course_fld != ''){
			$searchQuery .= " and c.course_id=".$course_fld;			
	    }
		if($evaluation_date_fld != ''){
			$searchQuery .= " and m.evaluation_date='".$evaluation_date_fld."'";			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and m.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and m.is_deleted=0";	
		}
		$per_query='';
		$flag=true;
		if($term_fld == ''){
			$flag=false;
		}
		$group_arr=explode(",",$group_id);
		if (in_array(1, $group_arr)||in_array(3, $group_arr))
		{
			$per_query='';
		}
		else if ($group_id=="2")
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT id) as course_id FROM courses WHERE personnel_id=".$id;
			$per_details = $this->users_model->special_fetch($cond);
			if($per_details[0]['course_id']!='')
			{
				$cond="SELECT GROUP_CONCAT(DISTINCT st.student_id) as student_id FROM course_attendants c,students_terms st WHERE st.id=c.student_term_id and c.course_id in (".$per_details[0]['course_id'].")";
				$stu_details = $this->users_model->special_fetch($cond);
				if($stu_details[0]['student_id']!='')
					$per_query = " and st.student_id in(".$stu_details[0]['student_id'].")";
				else
					$flag=false;
			}
			else
				$flag=false;
		}
		else if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
				$per_query = " and st.student_id in(".$par_details[0]['student_id'].")";
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and st.student_id=".$id;
		}
		if($flag)
		{
			$total_avg=0;
			$cond="select m.id,st.student_id,st.term_id,c.course_id,m.mark_id,m.evaluation_date from course_attendants_marks m,course_attendants c,students_terms st where c.student_term_id=st.id and m.course_attendant_id=c.id and st.term_id=".$term_fld.$searchQuery.$delQuery.$per_query;
			$page_details = $this->course_attendants_marks_model->special_fetch($cond);
			$totalRecord = count($page_details);
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$cond="select concat(first_name,' ',last_name) as student_name from users where id=".$student['student_id'];
				$student_details = $this->students_terms_model->special_fetch($cond);
				if(count($student_details)>0)
					$student_name=$student_details[0]['student_name'];
				else
					$student_name="";
				$cond="select name from courses where id=".$student['course_id'];
				$course_details = $this->students_terms_model->special_fetch($cond);
				if(count($course_details)>0)
					$course=$course_details[0]['name'];
				else
					$course="";
				$cond="select mc.factor from mark_categories mc,course_attendants_marks c where mc.id=c.mark_category_id and c.id=".$student['id'];
				$mrk_cat_details = $this->students_terms_model->special_fetch($cond);
				$wt1=0;
				if(count($mrk_cat_details)>0)
					$wt1=$mrk_cat_details[0]['factor'];
				$cond="select assessment_value from subject_types st,subjects s,courses c where c.subject_id=s.id and st.id=s.subject_type_id and c.id=".$student['course_id'];
				$mrk_sub_details = $this->students_terms_model->special_fetch($cond);
				$wt2=0;
				if(count($mrk_sub_details)>0)
					$wt2=$mrk_sub_details[0]['assessment_value'];
				$cond="select number_value from marks where id=".$student['mark_id'];
				$mark_details = $this->students_terms_model->special_fetch($cond);
				$mark=round($mark_details[0]['number_value'],2);
				$total_avg=$total_avg+$mark;
				$student_all_details[]=array(
					"id"=>$student['id'],
					"evaluation_date"=>$student['evaluation_date'],
					"student_name"=>$student_name,
					"course"=>$course,
					"wt1"=>$wt1,
					"wt2"=>$wt2,
					"mark"=>$mark
				);
			}
			$totalRecordwithFilter = $totalRecord;
			$search_count=0;
			$student_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($student_all_details);$i++)
				{
					if(strpos(strtolower($student_all_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['course']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['mark']), $searchValue) !== false||strpos(strtolower($student_all_details[$i]['evaluation_date']), $searchValue) !== false)
					{
						$student_details[]=$student_all_details[$i];
					}
				}
				$search_count=count($student_details);
			}
			else{
				$student_details=$student_all_details;
			}
			if($search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($student_details)<=0)
			{
				$student_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($student_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $student_details);
				$total_avg=0;$mrk_avg=0;$wt_avg=0;
				foreach($student_details as $mrk)
				{
					if($mrk['mark']>0)
					{
						$mrk_avg=$mrk_avg+($mrk['mark']*$mrk['wt1']*$mrk['wt2']);
						$wt_avg=$wt_avg+($mrk['wt1']*$mrk['wt2']);
					}
				}
				$total_avg=round(($mrk_avg/$wt_avg),2);
				$student_details[0]['total_avg']=$total_avg;
			}
			$output = array_slice($student_details, $start, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output,'total_avg'=>0);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_student_marks(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$id = $data['id'];
		$cond="select m.number_value as mark,c.evaluation_date,c.is_counted,c.id from course_attendants_marks c,marks m where c.mark_id=m.id and c.course_attendant_id =".$id;
		$student_details = $this->course_attendants_marks_model->special_fetch($cond);
		if(count($student_details)>0)
        {
			$out = array('statuscode'=>'200','student_details'=>$student_details);
		}
		else
		{
			$out = array('statuscode'=>'201');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_course_attendants_marks(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$term_id = $data['term_id'];
		$course_id = $data['course_id'];
		$mark_category_id = $data['mark_category_id'];
		$remark = $data['remark'];
		$evaluation_date = $data['evaluation_date'];
		$dossier_id = $data['dossier_id'];
		$mark_counts = $data['mark_counts'];
		$students = $data['students'];
		$marks = $data['marks'];
		$mark_type = $data['mark_type'];
		$mark_schema = $data['mark_schema'];
		$mark_schema =json_encode($mark_schema);
		$flag=false;
		for($i=0;$i<count($students);$i++)
		{
			$cond="SELECT c.id FROM course_attendants c,students_terms st where c.student_term_id=st.id and st.student_id=".$students[$i]." and c.course_id=".$course_id." and st.term_id=".$term_id;
			$course_details = $this->course_attendants_marks_model->special_fetch($cond);
			if(count($course_details)>0)
			{
				$course_attendant_id=$course_details[0]['id'];
				$input = array(
					'course_attendant_id'=>$course_attendant_id,
					'mark_id'=>$marks[$i],
					'mark_category_id'=>$mark_category_id,
					'remark'=>$remark,
					'evaluation_date'=>$evaluation_date,
					'dossier_id'=>$dossier_id,
					'mark_type'=>$mark_type,
					'mark_schema'=>$mark_schema,
					'is_counted'=>$mark_counts
				);
				$this->course_attendants_marks_model->add($input);
				$flag=true;
			}
		}
		if($flag)
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[141]['name']);		
		else
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[142]['name']);		
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function add_student_attendants_marks(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$term_id = $data['term_id'];
		$course_id = $data['course_id'];
		$mark_category_id = $data['mark_category_id'];
		$remark = $data['remark'];
		$evaluation_date = $data['evaluation_date'];
		$dossier_id = $data['dossier_id'];
		$mark_counts = $data['mark_counts'];
		$student_id = $data['student_id'];
		$course_attendant_id = $data['course_attendant_id'];
		$course_attendant_marks_id = $data['course_attendant_marks_id'];
		$marks = $data['marks'];
		$mark_type = $data['mark_type'];
		$mark_schema = $data['mark_schema'];
		$mark_schema =json_encode($mark_schema);
		if($student_id!="")
		{
			$flag=false;
			$cond="SELECT c.id FROM course_attendants c,students_terms st where c.student_term_id=st.id and st.student_id=".$student_id." and c.course_id=".$course_id." and st.term_id=".$term_id;
			$course_details = $this->course_attendants_marks_model->special_fetch($cond);
			if(count($course_details)>0)
			{
				$course_attendant_id=$course_details[0]['id'];
				$input = array(
					'course_attendant_id'=>$course_attendant_id,
					'mark_id'=>$marks,
					'mark_category_id'=>$mark_category_id,
					'remark'=>$remark,
					'evaluation_date'=>$evaluation_date,
					'dossier_id'=>$dossier_id,
					'mark_type'=>$mark_type,
					'mark_schema'=>$mark_schema,
					'is_counted'=>$mark_counts
				);
				$this->course_attendants_marks_model->add($input);
				$flag=true;
			}
			if($flag)
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[141]['name']);		
			else
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[142]['name']);	
		}	
		else if($course_attendant_id!="")
		{
			$input = array(
				'course_attendant_id'=>$course_attendant_id,
				'mark_id'=>$marks,
				'mark_category_id'=>$mark_category_id,
				'remark'=>$remark,
				'evaluation_date'=>$evaluation_date,
				'dossier_id'=>$dossier_id,
				'mark_type'=>$mark_type,
				'mark_schema'=>$mark_schema,
				'is_counted'=>$mark_counts
			);
			$this->course_attendants_marks_model->add($input);
			$out = array('statuscode'=>'202','statusdescription'=>$label_details[141]['name']);	
		}
		else if($course_attendant_marks_id!="")
		{	
			$cond="SELECT course_attendant_id FROM course_attendants_marks where id=".$course_attendant_marks_id;
			$course_details = $this->course_attendants_marks_model->special_fetch($cond);
			$input = array(
				'course_attendant_id'=>$course_details[0]['course_attendant_id'],
				'mark_id'=>$marks,
				'mark_category_id'=>$mark_category_id,
				'remark'=>$remark,
				'evaluation_date'=>$evaluation_date,
				'dossier_id'=>$dossier_id,
				'mark_type'=>$mark_type,
				'mark_schema'=>$mark_schema,
				'is_counted'=>$mark_counts
			);
			$this->course_attendants_marks_model->add($input);
			$out = array('statuscode'=>'202','statusdescription'=>$label_details[141]['name']);	
		}
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function edit_course_attendants_marks(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$mark_category_id = $data['mark_category_id'];
		$remark = $data['remark'];
		$evaluation_date = $data['evaluation_date'];
		$dossier_id = $data['dossier_id'];
		$mark_counts = $data['mark_counts'];
		$course_attendant_id = $data['course_attendant_id'];
		$marks = $data['marks'];
		$mark_type = $data['mark_type'];
		$mark_schema = $data['mark_schema'];
		$mark_schema =json_encode($mark_schema);
		$input = array(
			'mark_id'=>$marks,
			'mark_category_id'=>$mark_category_id,
			'remark'=>$remark,
			'evaluation_date'=>$evaluation_date,
			'dossier_id'=>$dossier_id,
			'mark_type'=>$mark_type,
			'mark_schema'=>$mark_schema,
			'is_counted'=>$mark_counts
		);
		$this->course_attendants_marks_model->edit($input,$course_attendant_id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[144]['name']);
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    	    
    function delete_course_attendants_marks(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$id = $data['id'];
		$this->course_attendants_marks_model->delete($id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[145]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function validateDate($date, $format = 'd/m/Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
	function get_course_attendants_marks_type(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from absence_categories where is_deleted=0 and is_active=1 order by name asc";
		$absence_type_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','absence_type_details'=>$absence_type_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_mark_points(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select s.value from system_settings s where s.key='marks-evaluation-descending'";
		$sys_details = $this->users_model->special_fetch($cond);
		$ord_query=' order by name desc';
		if(count($sys_details)>0)
		{
			if($sys_details[0]['value']==1)
				$ord_query=' order by name asc';
		}
		$cond="select id,concat(name,' - ',number_value) as mark_value from marks where is_deleted=0 and is_active=1".$ord_query;
		$mark_details = $this->users_model->special_fetch($cond);
		$cond="select round(min(number_value)) as min_mark,round(max(number_value)) as max_mark from marks where is_deleted=0 and is_active=1";
		$mark_num_details = $this->users_model->special_fetch($cond);
		$medium_mark=round(($mark_num_details[0]['max_mark']-$mark_num_details[0]['min_mark'])/2)+1;
		$out = array('statuscode'=>'200','min_mark'=>$mark_num_details[0]['min_mark'],'max_mark'=>$mark_num_details[0]['max_mark'],'medium_mark'=>$medium_mark,'mark_details'=>$mark_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
		
	function get_mark_categories(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from mark_categories where is_deleted=0 and is_active=1 order by name asc";
		$mark_categories_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','mark_categories_details'=>$mark_categories_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_dossiers(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select d.id,d.name,t.name as term,c.name as course,c.id as course_id from dossiers d,courses c,terms t where d.course_id=c.id and t.id=d.term_id and d.is_deleted=0 and d.is_active=1";
		$dossier_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','dossier_details'=>$dossier_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_course_attendants_marks(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="select * from course_attendants_marks where id=".$id;
		$student_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','student_details'=>$student_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_students_for_search(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$personnel_details=array();
		$cond="select u.id,u.first_name,u.last_name from users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0";
		$student_details = $this->users_model->special_fetch($cond);
		$stu_details=array();	
		foreach($student_details as $student)
		{
			$name=$student['first_name']." ".$student['last_name'];
			if(strpos(strtolower($name), $search_term)!==false)
			{
				$stu_details[]=array("id"=>$student['id'],"name"=>$name);
			}
		}
		$total_count=count($stu_details);
		$out = array('total_count'=>$total_count,'items'=>$stu_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_reported_by(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$cond="select u.id,u.first_name,u.last_name from users u,personnel p where u.id=p.id and u.is_active=1 and p.is_deleted=0";
		$personnel_details = $this->users_model->special_fetch($cond);
		$per_details=array();	
		foreach($personnel_details as $personnel)
		{
			$name=$personnel['first_name']." ".$personnel['last_name'];
			if(strpos(strtolower($name), $search_term)!==false)
			{
				$per_details[]=array("id"=>$personnel['id'],"name"=>$name);
			}
		}
		$total_count=count($per_details);
		$out = array('total_count'=>$total_count,'items'=>$per_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
