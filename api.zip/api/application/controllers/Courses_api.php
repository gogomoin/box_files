<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Courses_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=6 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
     
	//courses
	function view_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$individual_fld = $data['individual_fld'];
		$del_fld = $data['del_fld'];
		$teacher_fld = $data['teacher_fld'];
		$subject_fld = $data['subject_fld'];
		$competence_level_fld = $data['competence_level_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(c.name) like '%".$searchValue."%' or lower(s.name) like '%".$searchValue."%' or lower(u.first_name) like '%".$searchValue."%' or lower(u.last_name) like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and c.is_active=".$status_fld;			
	    }
		if($individual_fld != ''&&$individual_fld != 'all'){
			$searchQuery .= " and c.is_individual=".$individual_fld;			
	    }
		if($teacher_fld != ''){
			$searchQuery .= " and u.id=".$teacher_fld;			
	    }
		if($subject_fld != ''){
			$searchQuery .= " and c.subject_id=".$subject_fld;			
	    }
		if($competence_level_fld != ''){
			$searchQuery .= " and c.competence_level_id=".$competence_level_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and c.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and c.is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "c.created_at";
			$columnSortOrder = "desc";
		}
		$cond="select c.*,CONCAT(u.first_name, ' ', u.last_name) as teacher,s.name as subject from courses c,users u,subjects s where c.personnel_id=u.id and c.subject_id=s.id".$delQuery.$searchQuery." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(c.id) as cnt from courses c where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(c.id) as cnt from courses c,users u,subjects s where c.personnel_id=u.id and c.subject_id=s.id".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		$i=0;
		foreach($page_details as $pages)
		{
			if($pages['competence_level_id']!="")
			{
				$cond="select name from competence_levels where id=".$pages['competence_level_id'];
        		$comp_details = $this->users_model->special_fetch($cond);
				if(count($comp_details)>0)
					$page_details[$i]['competence_level']=$comp_details[0]['name'];
				else
					$page_details[$i]['competence_level']="";
			}
			else
				$page_details[$i]['competence_level']="";
			$i++;
		}
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
		$totalRecordwithFilter=0;
		if(count($page_details)<=0)
		{
			$page_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($page_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $page_details);
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$personnel_id = $data['personnel_id'];
		$subject_id = $data['subject_id'];
		$competence_level_id = $data['competence_level_id'];
		if($competence_level_id=="")
			$competence_level_id=NULL;
		$status = $data['status'];
		$individual = $data['individual'];
		$data_arr=array(
				'name'=>$name
			);
        $courses_details = $this->courses_model->get_records($data_arr);
		if(count($courses_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'personnel_id'=>$personnel_id,
				'subject_id'=>$subject_id,
				'competence_level_id'=>$competence_level_id,
				'is_individual'=>$individual,
				'is_active'=>$status,
				'created_at'=>time()
			);
			$mid = $this->courses_model->add($input);
			if($mid){				
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[129]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[130]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[131]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$personnel_id = $data['personnel_id'];
		$subject_id = $data['subject_id'];
		$competence_level_id = $data['competence_level_id'];
		if($competence_level_id=="")
			$competence_level_id=NULL;
		$status = $data['status'];
		$individual = $data['individual'];
		$id = $data['id'];
		$cond="select id from courses where name='".$name."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'personnel_id'=>$personnel_id,
				'subject_id'=>$subject_id,
				'competence_level_id'=>$competence_level_id,
				'is_individual'=>$individual,
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$mid = $this->courses_model->edit($input,$id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[132]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[133]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[134]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_courses(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select name from courses where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			if(count($p_details)>0)
				$name=$p_details[0]['name'];
			else
				$name="";
			$cond="select id from course_attendants	where course_id=".$id." limit 1";
			$cor_details = $this->users_model->special_fetch($cond);
			$cond="select id from course_upload_settings where course_id=".$id." limit 1";
			$cur_details = $this->users_model->special_fetch($cond);
			$cond="select id from dossiers where course_id=".$id." limit 1";
			$dos_details = $this->users_model->special_fetch($cond);
			$cond="select id from timetable	where course_id=".$id." limit 1";
			$tab_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)<=0&&count($cur_details)<=0&&count($dos_details)<=0&&count($tab_details)<=0)
			{	
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->courses_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[55]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[59]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg); 
		header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_courses(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->courses_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[136]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_individual_courses(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_individual from courses where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_individual']==0)
				$individual=1;
			else
				$individual=0;
			$input = array(
				'is_individual'=>$individual,
				'updated_at'=>time()
			);
			$this->courses_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[137]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);     
    }
	function set_status_courses(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from courses where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->courses_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[138]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	
    function import_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']==""||$page['personnel']==""||$page['subject']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['personnel'];
				$corrupt_arr[] =$page['subject'];
				$corrupt_arr[] =$page['competence_level'];
				$corrupt_arr[] =$page['individual'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[139]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from courses where name='".$page['name']."'";
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['name'];
					$error_arr[] =$page['personnel'];
					$error_arr[] =$page['subject'];
					$error_arr[] =$page['competence_level'];
					$error_arr[] =$page['individual'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[140]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					if($page['personnel_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['personnel'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['individual'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[141]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else if($page['subject_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['personnel'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['individual'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[142]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						if($page['competence_level_id']=="")
							$page['competence_level_id']=NULL;
						$input = array(
							'name'=>$page['name'],
							'personnel_id'=>$page['personnel_id'],
							'subject_id'=>$page['subject_id'],
							'competence_level_id'=>$page['competence_level_id'],
							'is_individual'=>$page['individual_val'],
							'is_active'=>$page['status_val'],
							'created_at'=>time()
						);
						$this->courses_model->add($input);
						$flag=true;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[143]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function get_teachers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$group_id = $data['group_id'];
		$user_details=array();
		if($group_id==4)
		{
			$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
			$student_details = $this->users_model->special_fetch($cond);
			if($student_details[0]['id']!="")
			{
				$cond="select group_concat(distinct c.id) as course_id from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id in(".$student_details[0]['id'].")";
				$course_details = $this->users_model->special_fetch($cond);
				if($course_details[0]['course_id']!="")
				{
					$cond="select group_concat(distinct personnel_id) as personnel_id from courses where id in(".$course_details[0]['course_id'].")";
					$per_details = $this->users_model->special_fetch($cond);
					if($per_details[0]['personnel_id']!="")
					{
						$cond="select u.id,CONCAT(u.first_name, ' ',u.last_name) as name from users u,personnel p where u.id=p.id and u.id in(".$per_details[0]['personnel_id'].") and p.is_deleted=0 and u.is_active=1 order by name asc";
						$user_details = $this->users_model->special_fetch($cond);
					}	
				}
			}
		}
		else if($group_id==5)
		{
			$cond="select group_concat(distinct c.id) as course_id from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id=".$id;
			$course_details = $this->users_model->special_fetch($cond);
			if($course_details[0]['course_id']!="")
			{
				$cond="select group_concat(distinct personnel_id) as personnel_id from courses where id in(".$course_details[0]['course_id'].")";
				$per_details = $this->users_model->special_fetch($cond);
				if($per_details[0]['personnel_id']!="")
				{
					$cond="select u.id,CONCAT(u.first_name, ' ',u.last_name) as name from users u,personnel p where u.id=p.id and u.id in(".$per_details[0]['personnel_id'].") and p.is_deleted=0 and u.is_active=1 order by name asc";
					$user_details = $this->users_model->special_fetch($cond);
				}	
			}
		}
		else
		{
			$cond="select u.id,CONCAT(u.first_name, ' ', u.last_name) as name from users u,user_groups ug, personnel p where u.id=p.id and ug.user_id=u.id and ug.group_id=2 and p.is_deleted=0 and u.is_active=1 order by name asc";
			$user_details = $this->users_model->special_fetch($cond);		
		}
		$out = array('statuscode'=>'200','user_details'=>$user_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
