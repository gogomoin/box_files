<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Curriculum_items_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=11 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
    function view_curriculum_items(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$curriculum_fld = $data['curriculum_fld'];
		$subject_fld = $data['subject_fld'];
		$curriculum_item_type_fld = $data['curriculum_item_type_fld'];
		$curriculum_item_cycle_fld = $data['curriculum_item_cycle_fld'];
		$competence_level_fld = $data['competence_level_fld'];				
		$searchQuery = "";
		$delQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($curriculum_fld != ''){
			$searchQuery .= " and curriculum_id=".$curriculum_fld;			
	    }
		if($subject_fld != ''){
			$searchQuery .= " and subject_id=".$subject_fld;			
	    }
		if($curriculum_item_type_fld != ''){
			$searchQuery .= " and curriculum_item_type_id=".$curriculum_item_type_fld;			
	    }
		if($curriculum_item_cycle_fld != ''){
			$searchQuery .= " and curriculum_item_cycle_id=".$curriculum_item_cycle_fld;			
	    }
		if($competence_level_fld != ''){
			$searchQuery .= " and competence_level_id=".$competence_level_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from curriculum_item where 1".$delQuery.$searchQuery;
		$page_details = $this->users_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$curriculum_details=array();
		$i=0;
		foreach($page_details as $cur)
		{
			if($cur['curriculum_id']!="")
			{
				$cond="select name from curriculums where id=".$cur['curriculum_id'];
				$curriculum_details = $this->students_terms_model->special_fetch($cond);
				if(count($curriculum_details)>0)
					$page_details[$i]['curriculum']=$curriculum_details[0]['name'];
				else
					$page_details[$i]['curriculum']="";
			}
			else
				$page_details[$i]['curriculum']="";
			if($cur['subject_id']!="")
			{
				$cond="select name from subjects where id=".$cur['subject_id'];
				$sub_details = $this->students_terms_model->special_fetch($cond);
				if(count($sub_details)>0)
					$page_details[$i]['subject']=$sub_details[0]['name'];
				else
					$page_details[$i]['subject']="";
			}
			else
				$page_details[$i]['subject']="";
			if($cur['curriculum_item_type_id']!="")
			{
				$cond="select name from curriculum_item_types where id=".$cur['curriculum_item_type_id'];
				$item_details = $this->students_terms_model->special_fetch($cond);
				if(count($item_details)>0)
					$page_details[$i]['curriculum_item_type']=$item_details[0]['name'];
				else
					$page_details[$i]['curriculum_item_type']="";
			}
			else
				$page_details[$i]['curriculum_item_type']="";
			if($cur['curriculum_item_cycle_id']!="")
			{
				$cond="select name from curriculum_item_cycles where id=".$cur['curriculum_item_cycle_id'];
				$cycle_details = $this->students_terms_model->special_fetch($cond);
				if(count($cycle_details)>0)
					$page_details[$i]['curriculum_item_cycle']=$cycle_details[0]['name'];
				else
					$page_details[$i]['curriculum_item_cycle']="";
			}
			else
				$page_details[$i]['curriculum_item_cycle']="";
			if($cur['competence_level_id']!="")
			{
				$cond="select name from competence_levels where id=".$cur['competence_level_id'];
				$com_details = $this->users_model->special_fetch($cond);
				if(count($com_details)>0)
					$page_details[$i]['competence_level']=$com_details[0]['name'];
				else
					$page_details[$i]['competence_level']="";
			}
			else
				$page_details[$i]['competence_level']="";
			$i++;
		}
		$totalRecordwithFilter = $totalRecord;
		$search_count=0;
		$curriculum_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($page_details);$i++)
			{
				if(strpos(strtolower($page_details[$i]['title']), $searchValue) !== false||strpos(strtolower($page_details[$i]['curriculum']), $searchValue) !== false||strpos(strtolower($page_details[$i]['subject']), $searchValue) !== false||strpos(strtolower($page_details[$i]['curriculum_item_type']), $searchValue) !== false||strpos(strtolower($page_details[$i]['curriculum_item_cycle']), $searchValue) !== false||strpos(strtolower($page_details[$i]['competence_level']), $searchValue) !== false||strpos(strtolower($page_details[$i]['description']), $searchValue) !== false||strpos(strtolower($page_details[$i]['example']), $searchValue) !== false||strpos(strtolower($page_details[$i]['additional_category']), $searchValue) !== false)
				{
					$curriculum_details[]=$page_details[$i];
				}
			}
			$search_count=count($curriculum_details);
		}
		else{
			$curriculum_details=$page_details;
		}
		if($search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($curriculum_details)<=0)
		{
			$curriculum_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($curriculum_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $curriculum_details);
		}
		$output = array_slice($curriculum_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    } 
	
	
	function add_curriculum_items(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$title = $data['title'];
		$curriculum_id = $data['curriculum_id'];
		$subject_id = $data['subject_id'];
		$curriculum_item_type_id = $data['curriculum_item_type_id'];
		$competence_level_id = $data['competence_level_id'];
		$curriculum_item_cycle_id = $data['curriculum_item_cycle_id'];
		$description = $data['description'];
		$example = $data['example'];
		$status = $data['status'];
		$additional_category = $data['additional_category'];
		if($competence_level_id=="")
			$competence_level_id=0;
		$data_arr=array(
				'title'=>$title
			);
        $curriculum_items_details = $this->curriculum_items_model->get_records($data_arr);
		if(count($curriculum_items_details)<=0)
		{
			$input = array(
				'title'=>$title,
				'curriculum_id'=>$curriculum_id,
				'subject_id'=>$subject_id,
				'curriculum_item_type_id'=>$curriculum_item_type_id,
				'competence_level_id'=>$competence_level_id,
				'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
				'description'=>$description,
				'example'=>$example,
				'additional_category'=>$additional_category,
				'is_active'=>$status,
				'created_at'=>time()
			);
			$mid = $this->curriculum_items_model->add($input);
			if($mid){				
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[121]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[122]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[123]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_curriculum_items(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$title = $data['title'];
		$curriculum_id = $data['curriculum_id'];
		$subject_id = $data['subject_id'];
		$curriculum_item_type_id = $data['curriculum_item_type_id'];
		$competence_level_id = $data['competence_level_id'];
		$curriculum_item_cycle_id = $data['curriculum_item_cycle_id'];
		$description = $data['description'];
		$example = $data['example'];
		$additional_category = $data['additional_category'];
		$id = $data['id'];
		$status = $data['status'];
		if($competence_level_id=="")
			$competence_level_id=0;
		$cond="select id from curriculum_item where title='".$title."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$input = array(
				'title'=>$title,
				'curriculum_id'=>$curriculum_id,
				'subject_id'=>$subject_id,
				'curriculum_item_type_id'=>$curriculum_item_type_id,
				'competence_level_id'=>$competence_level_id,
				'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
				'description'=>$description,
				'example'=>$example,
				'additional_category'=>$additional_category,
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$mid = $this->curriculum_items_model->edit($input,$id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[124]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[125]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[126]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_curriculum_items(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select title from curriculum_item where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			if(count($p_details)>0)
				$name=$p_details[0]['title'];
			else
				$name="";
			$cond="select id from dossiers where curriculum_item_id=".$id;
			$ab_details = $this->disciplinary_categories_model->special_fetch($cond);
			if(count($ab_details)<=0)
			{
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->curriculum_items_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[55]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[59]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);             
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_curriculum_items(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->curriculum_items_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[128]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_curriculum_items(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from curriculum_item where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->curriculum_items_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[129]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_curriculums(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from curriculums where is_deleted=0 and is_active=1 order by name asc";
		$curriculum_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','curriculum_details'=>$curriculum_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_subjects(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from subjects where is_deleted=0 and is_active=1 order by name asc";
		$subject_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','subject_details'=>$subject_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_curriculum_item_types(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from curriculum_item_types where is_deleted=0 and is_active=1 order by name asc";
		$curriculum_item_type_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','curriculum_item_type_details'=>$curriculum_item_type_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_curriculum_item_cycles(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from curriculum_item_cycles where is_deleted=0 and is_active=1 order by name asc";
		$curriculum_item_cycle_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','curriculum_item_cycle_details'=>$curriculum_item_cycle_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_competence_levels(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from competence_levels where is_deleted=0 and is_active=1 order by name asc";
		$competence_level_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','competence_level_details'=>$competence_level_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
    function import_curriculum_items(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['title']==""||$page['curriculum']==""||$page['subject']==""||$page['curriculum_item_type']==""||$page['curriculum_item_cycle']==""||$page['competence_level']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['title'];
				$corrupt_arr[] =$page['curriculum'];
				$corrupt_arr[] =$page['subject'];
				$corrupt_arr[] =$page['curriculum_item_type'];
				$corrupt_arr[] =$page['curriculum_item_cycle'];
				$corrupt_arr[] =$page['competence_level'];
				$corrupt_arr[] =$page['description'];
				$corrupt_arr[] =$page['example'];
				$corrupt_arr[] =$page['additional_category'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[130]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from curriculum_item where title='".$page['title']."'";
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['title'];
					$error_arr[] =$page['curriculum'];
					$error_arr[] =$page['subject'];
					$error_arr[] =$page['curriculum_item_type'];
					$error_arr[] =$page['curriculum_item_cycle'];
					$error_arr[] =$page['competence_level'];
					$error_arr[] =$page['description'];
					$error_arr[] =$page['example'];
					$error_arr[] =$page['additional_category'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[131]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					if($page['curriculum_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['title'];
						$error_arr[] =$page['curriculum'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['curriculum_item_type'];
						$error_arr[] =$page['curriculum_item_cycle'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['description'];
						$error_arr[] =$page['example'];
						$error_arr[] =$page['additional_category'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[132]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else if($page['subject_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['title'];
						$error_arr[] =$page['curriculum'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['curriculum_item_type'];
						$error_arr[] =$page['curriculum_item_cycle'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['description'];
						$error_arr[] =$page['example'];
						$error_arr[] =$page['additional_category'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[133]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else if($page['curriculum_item_type_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['title'];
						$error_arr[] =$page['curriculum'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['curriculum_item_type'];
						$error_arr[] =$page['curriculum_item_cycle'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['description'];
						$error_arr[] =$page['example'];
						$error_arr[] =$page['additional_category'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[134]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else if($page['curriculum_item_cycle_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['title'];
						$error_arr[] =$page['curriculum'];
						$error_arr[] =$page['subject'];
						$error_arr[] =$page['curriculum_item_type'];
						$error_arr[] =$page['curriculum_item_cycle'];
						$error_arr[] =$page['competence_level'];
						$error_arr[] =$page['description'];
						$error_arr[] =$page['example'];
						$error_arr[] =$page['additional_category'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[135]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						$input = array(
							'title'=>$page['title'],
							'curriculum_id'=>$page['curriculum_id'],
							'subject_id'=>$page['subject_id'],
							'curriculum_item_type_id'=>$page['curriculum_item_type_id'],
							'competence_level_id'=>$page['competence_level_id'],
							'curriculum_item_cycle_id'=>$page['curriculum_item_cycle_id'],
							'description'=>$page['description'],
							'example'=>$page['example'],
							'additional_category'=>$page['additional_category'],
							'is_active'=>$page['status_val'],
							'created_at'=>time()
						);
						$this->curriculum_items_model->add($input);
						$flag=true;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[137]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
}
