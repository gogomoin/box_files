<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Disciplinary_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=43 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//disciplinary
	function view_disciplinary(){
		
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$type_fld = $data['type_fld'];
		$student_fld = $data['student_fld'];
		$reported_by_fld = $data['reported_by_fld'];
		$parent_check_needed_fld = $data['parent_check_needed_fld'];
		$parents_check_fld = $data['parents_check_fld'];
		$remark_date_fld = $data['remark_date_fld'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$delQuery = "";
		if($columnName=="")
		{
			$columnName = "a.created_at";
			$columnSortOrder = "desc";
		}
		if($term_fld=="")
		{
			$cond="select * from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
				$term_fld=$term_details[0]['id'];
			else
				$term_fld="";
		}
		/* if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		} */
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and a.is_active=".$status_fld;			
	    }
		if($parent_check_needed_fld != ''&&$parent_check_needed_fld != 'all'){
			$searchQuery .= " and a.is_parent_check_needed=".$parent_check_needed_fld;			
	    }
		if($parents_check_fld != ''&&$parents_check_fld != 'all'){
			$searchQuery .= " and a.is_checked_by_parent=".$parents_check_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and a.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and a.is_deleted=0";	
		}
		$per_query='';
		$flag=true;
		$group_arr=explode(",",$group_id);
		if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
			{
				$per_query = " and st.student_id in(".$par_details[0]['student_id'].")";
				$cond="SELECT a.* FROM disciplinary_protocols a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
			}
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and st.student_id=".$id;
			$cond="SELECT a.* FROM disciplinary_protocols a,students_terms st where a.student_term_id=st.id".$delQuery.$searchQuery.$per_query;
		}
		else
		{
			$cond="SELECT a.* FROM disciplinary_protocols a where 1".$delQuery.$searchQuery;
		}
		if($flag)
		{
			$totalRecord="";$totalRecordwithFilter="";$page_details=array();
			$page_details = $this->disciplinary_model->special_fetch($cond);
			$totalRecord = count($page_details);
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$disciplinary_category_id =$student['disciplinary_category_id'];
				$student_term_id=$student['student_term_id'];
				$personnel_id =$student['personnel_id'];
				$cond="select student_id,term_id,coach_id,class_id,main_level_id from students_terms where id=".$student_term_id;
				$student_term_details = $this->disciplinary_model->special_fetch($cond);
				if(count($student_term_details)>0)
				{
					$term_id=$student_term_details[0]['term_id'];
					$student_id=$student_term_details[0]['student_id'];
					$coach_id=$student_term_details[0]['coach_id'];
					$grade_id=$student_term_details[0]['class_id'];
					$study_level_id=$student_term_details[0]['main_level_id'];
					$cond="select name from classes where id=".$grade_id;
					$grade_details = $this->disciplinary_model->special_fetch($cond);
					if(count($grade_details)>0)
						$grade=$grade_details[0]['name'];
					else
						$grade="";
					if($study_level_id!="0"&&$study_level_id!="")
					{
						$cond="select name from main_levels where id=".$study_level_id;
						$study_level_details = $this->disciplinary_model->special_fetch($cond);
						if(count($study_level_details)>0)
							$study_level=$study_level_details[0]['name'];
						else
							$study_level="";
					}
					else
						$study_level="";
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->disciplinary_model->special_fetch($cond);
					if(count($term_details)>0)
						$term=$term_details[0]['name'];
					else
						$term="";
					$cond="select first_name,last_name from users where id=".$student_id;
					$stu_details = $this->disciplinary_model->special_fetch($cond);
					if(count($stu_details)>0)
						$student_name=$stu_details[0]['first_name']." ".$stu_details[0]['last_name'];
					else
						$student_name="";
					$cond="select first_name,last_name from users where id=".$personnel_id;
					$per_details = $this->disciplinary_model->special_fetch($cond);
					if(count($per_details)>0)
						$reported_by=$per_details[0]['first_name']." ".$per_details[0]['last_name'];
					else
						$reported_by="";
					$cond="select first_name,last_name from users where id=".$coach_id;
					$tutor_details = $this->disciplinary_model->special_fetch($cond);
					if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
					$cond="select name from disciplinary_categories where id=".$disciplinary_category_id;
					$ab_details = $this->disciplinary_model->special_fetch($cond);
					if(count($ab_details)>0)
						$disciplinary_category=$ab_details[0]['name'];
					else
						$disciplinary_category="";
					$st_timestamp=strtotime($student['protocol_date']);
					$remark_date=date("F jS, Y", $st_timestamp);
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"disciplinary_category"=>$disciplinary_category,
						"points"=>$student['points_value'],
						"remark_date"=>$remark_date,
						"dis_remark_date"=>$student['protocol_date'],
						"remarkdate_timestamp"=>$student['remarkdate_timestamp'],
						"description"=>$student['description'],
						"is_parent_check_needed"=>$student['is_parent_check_needed'],
						"is_checked_by_parent"=>$student['is_checked_by_parent'],
						"is_active"=>$student['is_active'],
						"is_deleted"=>$student['is_deleted'],
						"tutor"=>$tutor,
						"grade"=>$grade,
						"study_level"=>$study_level,
						"term_id"=>$term_id,
						"student_id"=>$student_id,
						"disciplinary_category_id"=>$disciplinary_category_id,
						"personnel_id"=>$personnel_id,
						"reported_by"=>$reported_by
					);
				}
			}
			$totalRecordwithFilter = $totalRecord;
			$student_filter_details=array();
			$filter_count=0;
			if($term_fld!=""||$type_fld!=""||$student_fld!=""||$reported_by_fld!=""||$remark_date_fld!="")
			{
				for($i=0;$i<count($student_all_details);$i++)
				{				
					$term_flag=true;$type_flag=true;$student_flag=true;$reported_by_flag=true;$remark_date_flag=true;
					if($term_fld!="")
					{
						if($term_fld!=$student_all_details[$i]['term_id'])
							$term_flag=false;
					}
					if($student_fld!="")
					{
						if($student_fld!=$student_all_details[$i]['student_id'])
							$student_flag=false;
					}
					if($type_fld!="")
					{
						if($type_fld!=$student_all_details[$i]['disciplinary_category_id'])
							$type_flag=false;
					}
					if($reported_by_fld!="")
					{
						if($reported_by_fld!=$student_all_details[$i]['personnel_id'])
							$reported_by_flag=false;
					}
					if($remark_date_fld!="")
					{	
						$start_timestamp=strtotime($remark_date_fld);
						$end_timestamp=strtotime($remark_date_fld);
						$end_timestamp = strtotime("tomorrow", $end_timestamp) - 1;
						$cur_st=$student_all_details[$i]['remarkdate_timestamp'];
						if(!(($cur_st>=$start_timestamp&&$cur_st<=$end_timestamp)))
						{
							$remark_date_flag=false;
						}
					}
					if($term_flag&&$student_flag&&$type_flag&&$reported_by_flag&&$remark_date_flag)
					{
						$student_filter_details[]=$student_all_details[$i];
					}
				}
				$filter_count=count($student_filter_details);
			}
			else
			{
				$student_filter_details=$student_all_details;
			}
			$search_count=0;
			$disciplinary_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($student_filter_details);$i++)
				{
					if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['disciplinary_category']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['remark_date']), $searchValue) !== false)
					{
						$disciplinary_details[]=$student_filter_details[$i];
					}
				}
				$search_count=count($disciplinary_details);
			}
			else{
				$disciplinary_details=$student_filter_details;
			}
			if($filter_count==0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			else if($filter_count!=0&&$search_count==0)
				$totalRecordwithFilter=$filter_count;
			else if($filter_count!=0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($disciplinary_details)<=0)
			{
				$disciplinary_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($disciplinary_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $disciplinary_details);
			}
			$output = array_slice($disciplinary_details, $limit, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function convert_date($date)
    {
		$new_date="";
		if(strpos($date, "/") !== false){
        	$str_date=explode("/",$date);
			$new_date=$str_date[1]."/".$str_date[0]."/".$str_date[2];
			return strtotime($new_date);
		}
		else if(strpos($date, "-") !== false){
        	$str_date=explode("-",$date);
			$new_date=$str_date[1]."-".$str_date[0]."-".$str_date[2];
			return strtotime($new_date);
		}
        return "";
    }
	function view_students_for_disciplinary(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld_list = $data['term_fld_list'];
		$teacher_fld_list = $data['teacher_fld_list'];
		$grade_fld_list = $data['grade_fld_list'];
		$study_level_fld_list = $data['study_level_fld_list'];
		$student_fld_list = $data['student_fld_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($student_fld_list != ''){
			$searchQuery .= " and s.id=".$student_fld_list;			
	    }
		$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0".$searchQuery;
		$page_details = $this->students_terms_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$student_name=$student['first_name']." ".$student['last_name'];
			$grade="";$grade_id="";$study_level="";$study_level_id="";$tutor="";$tutor_id="";$term="";$term_id="";
			$cond="select * from students_terms where student_id=".$student['id'];
			$student_term_details = $this->students_terms_model->special_fetch($cond);
			if(count($student_term_details)>0)
			{
				$term_id=$student_term_details[0]['term_id'];
				$grade_id=$student_term_details[0]['class_id'];
				$study_level_id=$student_term_details[0]['main_level_id'];
				$tutor_id=$student_term_details[0]['coach_id'];
				$cond="select name from terms where id=".$term_id;
				$term_details = $this->students_terms_model->special_fetch($cond);
				if(count($term_details)>0)
					$term=$term_details[0]['name'];
				else
					$term="";
				if($grade_id!="")
				{
					$cond="select name from classes where id=".$grade_id;
					$class_details = $this->students_terms_model->special_fetch($cond);
					if(count($class_details)>0)
						$grade=$class_details[0]['name'];
					else
						$grade="";
				}
				else
					$grade="";
				if($study_level_id!="0"&&$study_level_id!="")
				{
					$cond="select name from main_levels where id=".$study_level_id;
					$study_level_details = $this->students_terms_model->special_fetch($cond);
					if(count($study_level_details)>0)
						$study_level=$study_level_details[0]['name'];
					else
						$study_level="";
				}
				else
					$study_level="";
				if($tutor_id!="")
				{
					$cond="select first_name,last_name from users where id=".$tutor_id;
					$tutor_details = $this->students_terms_model->special_fetch($cond);
					if(count($tutor_details)>0)
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					else
						$tutor="";
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"class_id"=>$grade_id,
					"main_level_id"=>$study_level_id,
					"coach_id"=>$tutor_id
				);
			}
		}
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($grade_fld_list!=""||$teacher_fld_list!=""||$study_level_fld_list!=""||$term_fld_list!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;
				if($term_fld_list!="")
				{
					if($term_fld_list!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($grade_fld_list!="")
				{
					if($grade_fld_list!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld_list!="")
				{
					if($teacher_fld_list!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld_list!="")
				{
					if($study_level_fld_list!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		$search_count=0;
		$students_terms_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_terms_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_terms_details);
		}
		else{
			$students_terms_details=$student_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_terms_details)<=0)
			$students_terms_details=array();
		else
		{
			foreach ($students_terms_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_terms_details);
		}
		$output = array_slice($students_terms_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_disciplinary(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		$reported_by_id = $data['reported_by_id'];
		$type_id = $data['type_id'];
		$remark_date = $data['remark_date'];
		$points = $data['points'];
		$description = $data['description'];
		$is_parent_check_needed = $data['is_parent_check_needed'];
		$status = $data['status'];
		$cond="select id from students_terms where student_id=".$student_id." and term_id=".$term_id;
		$student_term_details = $this->disciplinary_model->special_fetch($cond);
		if(count($student_term_details)>0)
		{		
			$student_term_id=$student_term_details[0]['id'];
			$remarkdate_timestamp=strtotime($remark_date);
			$input = array(
				'student_term_id'=>$student_term_id,
				'disciplinary_category_id'=>$type_id,
				'points_value'=>$points,
				'personnel_id'=>$reported_by_id,
				'protocol_date'=>$remark_date,
				'remarkdate_timestamp'=>$remarkdate_timestamp,
				'description'=>$description,
				'is_parent_check_needed'=>$is_parent_check_needed,
				'is_active'=>$status
			);
			$this->disciplinary_model->add($input);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[194]['name']);	
		}	
		else
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[243]['name']);	
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function edit_disciplinary(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$student_id = $data['student_id'];
		$term_id = $data['term_id'];
		$reported_by_id = $data['reported_by_id'];
		$type_id = $data['type_id'];
		$remark_date = $data['remark_date'];
		$description = $data['description'];
		$points = $data['points'];
		$is_parent_check_needed = $data['is_parent_check_needed'];
		$status = $data['status'];
		$remarkdate_timestamp=strtotime($remark_date);
		$input = array(
			'disciplinary_category_id'=>$type_id,
			'points_value'=>$points,
			'personnel_id'=>$reported_by_id,
			'protocol_date'=>$remark_date,
			'remarkdate_timestamp'=>$remarkdate_timestamp,
			'description'=>$description,
			'is_parent_check_needed'=>$is_parent_check_needed,
			'is_active'=>$status
		);
		$this->disciplinary_model->edit($input,$id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[143]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    	    
    function delete_disciplinary(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->disciplinary_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[144]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function restore_disciplinary(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->disciplinary_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[145]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_disciplinary(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['student_name']==""||$page['reported_by']==""||$page['disciplinary_category']==""||$page['remark_date']==""||$page['description']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['reported_by'];
				$corrupt_arr[] =$page['disciplinary_category'];
				$corrupt_arr[] =$page['remark_date'];
				$corrupt_arr[] =$page['description'];
				$corrupt_arr[] =$page['points_value'];
				$corrupt_arr[] =$page['is_parent_check_needed'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[242]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['disciplinary_category'];
					$error_arr[] =$page['remark_date'];
					$error_arr[] =$page['description'];
					$error_arr[] =$page['points_value'];
					$error_arr[] =$page['is_parent_check_needed'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[147]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['reported_by_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['disciplinary_category'];
					$error_arr[] =$page['remark_date'];
					$error_arr[] =$page['description'];
					$error_arr[] =$page['points_value'];
					$error_arr[] =$page['is_parent_check_needed'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[148]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['disciplinary_category_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['disciplinary_category'];
					$error_arr[] =$page['remark_date'];
					$error_arr[] =$page['description'];
					$error_arr[] =$page['points_value'];
					$error_arr[] =$page['is_parent_check_needed'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[149]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['remark_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['disciplinary_category'];
					$error_arr[] =$page['remark_date'];
					$error_arr[] =$page['description'];
					$error_arr[] =$page['points_value'];
					$error_arr[] =$page['is_parent_check_needed'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[150]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$term_id=0;
					$cond="select * from terms where is_deleted=0";
					$term_details = $this->users_model->special_fetch($cond);
					$cur_time=time();
					foreach($term_details as $term)
					{
						if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
						{
							$term_id=$term['id'];
						}
					}
					$cond="select id from students_terms where student_id=".$page['student_id']." and term_id=".$term_id;
					$student_term_details = $this->disciplinary_model->special_fetch($cond);
					if(count($student_term_details)>0)
					{
						$student_term_id=$student_term_details[0]['id'];
						$remarkdate_timestamp=strtotime($page['remark_date']);
						if($page['points_value']=="")
							$page['points_value']=0;
						$input = array(
							'student_term_id'=>$student_term_id,
							'disciplinary_category_id'=>$page['disciplinary_category_id'],
							'personnel_id'=>$page['reported_by_id'],
							'protocol_date'=>$page['remark_date'],
							'remarkdate_timestamp'=>$remarkdate_timestamp,
							'description'=>$page['description'],
							'points_value'=>$page['points_value'],
							'is_parent_check_needed'=>$page['is_parent_check_needed_val'],
							'is_active'=>$page['status_val']
						);	
						$this->disciplinary_model->add($input);
						$flag=true;
					}
					else
					{
						$error_arr=array();
						$error_arr[] =$page['student_name'];
						$error_arr[] =$page['reported_by'];
						$error_arr[] =$page['disciplinary_category'];
						$error_arr[] =$page['remark_date'];
						$error_arr[] =$page['description'];
						$error_arr[] =$page['points_value'];
						$error_arr[] =$page['is_parent_check_needed'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[216]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[151]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function validateDate($date, $format = 'd-m-Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
	function get_disciplinary_type(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name,points_value from disciplinary_categories where is_deleted=0 and is_active=1 order by name asc";
		$disciplinary_type_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','disciplinary_type_details'=>$disciplinary_type_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
}
