<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Dossiers_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		echo getcwd();
		echo $_SERVER["DOCUMENT_ROOT"];
	}
	
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=40 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//dossiers
	function view_dossiers(){
		
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$type_fld = $data['type_fld'];
		$teacher_fld = $data['teacher_fld'];
		$course_fld = $data['course_fld'];
		$del_fld = $data['del_fld'];
		$local_fld = $data['local_fld'];
		$search_fld = $data['search_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		if($local_fld==1)
		{
			$searchQuery = "";
			$delQuery = "";
			if($columnName=="")
			{
				$columnName = "d.id";
				$columnSortOrder = "desc";
			}
			if($columnName=="course")
			{
				$columnName = "c.name";
				if($columnSortOrder=="desc")
					$columnSortOrder = "asc";
				else
					$columnSortOrder = "desc";
			}
			if($teacher_fld != ''){
				$searchQuery .= " and d.personnel_id=".$teacher_fld;			
			}
			if($term_fld=="")
			{
				$cond="select * from terms where is_deleted=0 and is_active=1";
				$term_details = $this->users_model->special_fetch($cond);
				if(count($term_details)>0)
					$term_fld=$term_details[0]['id'];
				else
					$term_fld="";
			}
			if($term_fld != ''){
				$searchQuery .= " and d.term_id =".$term_fld;			
			}
			if($course_fld != ''){
				$searchQuery .= " and d.course_id=".$course_fld;			
			}
			if($type_fld != ''){
				$searchQuery .= " and d.dossier_language_id=".$type_fld;			
			}
			if($del_fld != ''){
				if($del_fld != 'all')
					$delQuery = " and d.is_deleted=".$del_fld;
			}
			else
			{
				$delQuery = " and d.is_deleted=0";	
			}
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				$searchQuery = " and (lower(t.name) like '%".$searchValue."%' or lower(c.name) like '%".$searchValue."%' or lower(d.name) like '%".$searchValue."%' or lower(d.start_date) like '%".$searchValue."%')";
			}
			$per_query='';
			$filter_query='';
			$group_arr=explode(",",$group_id);
			if (in_array(2, $group_arr))
			{
				if($teacher_fld!="")
				{
					$cond="SELECT GROUP_CONCAT(DISTINCT id) as course_id FROM courses WHERE personnel_id=".$teacher_fld;
					$cor_details = $this->users_model->special_fetch($cond);
					if($cor_details[0]['course_id']!="")
					{
						$filter_query=" and (d.personnel_id=".$teacher_fld." or d.course_id in(".$cor_details[0]['course_id'].") or (local_share like '%view%'))";
					}
					else
					{
						$filter_query=" and (d.personnel_id=".$teacher_fld." or (local_share like '%view%'))";
					}
				}
				else
				{
					$cond="SELECT GROUP_CONCAT(DISTINCT id) as course_id FROM courses WHERE personnel_id=".$id;
					$cor_details = $this->users_model->special_fetch($cond);
					if($cor_details[0]['course_id']!="")
					{
						$filter_query=" and (d.personnel_id=".$id." or d.course_id in(".$cor_details[0]['course_id'].") or (local_share like '%view%'))";
					}
					else
					{
						$filter_query=" and (d.personnel_id=".$id." or (local_share like '%view%'))";
					}
				}
			}
			else if (in_array(4, $group_arr))
			{
				$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
				$par_details = $this->users_model->special_fetch($cond);
				if($par_details[0]['student_id']!="")
				{
					$cond="SELECT GROUP_CONCAT(DISTINCT c.course_id) as course_id FROM course_attendants c,students_terms st WHERE st.id=c.student_term_id and st.student_id in(".$par_details[0]['student_id'].")";
					$cor_details = $this->users_model->special_fetch($cond);
					if($cor_details[0]['course_id']!="")
					{	
						$per_query = " and d.course_id in(".$cor_details[0]['course_id'].")";
						$filter_query=" and (d.personnel_id=".$id." or (local_share like '%view%'))";
					}
					else
						$per_query = " and d.course_id=''";
				}
				else
					$per_query = " and d.personnel_id=".$id;
			}
			else if (in_array(5, $group_arr))
			{
				$cond="SELECT GROUP_CONCAT(DISTINCT c.course_id) as course_id FROM course_attendants c,students_terms st WHERE st.id=c.student_term_id and st.student_id=".$id;
				$cor_details = $this->users_model->special_fetch($cond);
				if($cor_details[0]['course_id']!="")
				{
					$per_query = " and d.course_id in(".$cor_details[0]['course_id'].")";
					$filter_query=" and (d.personnel_id=".$id." or (local_share like '%view%'))";
				}
				else
					$per_query = " and d.course_id=''";
			}
			$totalRecord="";$totalRecordwithFilter="";$page_details=array();
			$flag=true;
			if($search_fld=="")
			{
				$cond="select d.*,c.name as cor_name from dossiers d,terms t,courses c where d.term_id=t.id and c.id=d.course_id".$delQuery.$per_query.$filter_query.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
				$page_details = $this->users_model->special_fetch($cond);
				$cond="select COUNT(d.id) as cnt from dossiers d,terms t,courses c where d.term_id=t.id and c.id=d.course_id".$delQuery.$per_query.$filter_query;
				$maps_count = $this->users_model->special_fetch($cond);
				$totalRecord = $maps_count[0]['cnt'];
				$totalRecordwithFilter = $totalRecord;
				if($searchQuery != ''||$delQuery != ''||$per_query != ''){
					$cond="select COUNT(d.id) as cnt from dossiers d,terms t,courses c where d.term_id=t.id and c.id=d.course_id".$delQuery.$per_query.$searchQuery.$filter_query;
					$maps_count = $this->users_model->special_fetch($cond);
					$totalRecordwithFilter = $maps_count[0]['cnt'];
				}
			}
			else
			{	
				$cond="select d.* from dossiers d,terms t where d.term_id=t.id".$delQuery.$per_query.$filter_query.$searchQuery." order by ".$columnName." ".$columnSortOrder;
				$dos_details = $this->users_model->special_fetch($cond);
				$totalRecord=count($dos_details);
				$j=0;
				foreach($dos_details as $dos)
				{	
					$dossier_id=$dos['id'];
					$cond="select dossier_file_id from dossiers_related_files where dossier_id=".$dossier_id;
					$dos_rel_details = $this->users_model->special_fetch($cond);
					if(count($dos_rel_details)>0)
					{	
						foreach($dos_rel_details as $dos_rel)
						{
							if($dos_rel['dossier_file_id']!="")
							{
								$search_fld=strtolower($search_fld);
								$cond="select id from document_text where document_id=".$dos_rel['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
								$doc_details = $this->users_model->special_fetch($cond);
								if(count($doc_details)>0)
								{
									$page_details[$j]=$dos;
									$j++;
									$flag=false;
									break;
								}
							}
						}
					}
					if($flag)
					{
						$cond="select dossier_file_id from dossiers_solutions where dossier_id=".$dossier_id;
						$dos_sol_details = $this->users_model->special_fetch($cond);
						if(count($dos_sol_details)>0)
						{
							foreach($dos_sol_details as $dos_sol)
							{
								if($dos_sol['dossier_file_id']!="")
								{
									$search_fld=strtolower($search_fld);
									$cond="select id from document_text where document_id=".$dos_sol['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
									$doc_details = $this->users_model->special_fetch($cond);
									if(count($doc_details)>0)
									{
										$page_details[$j]=$dos;
										$j++;
										$flag=false;
										break;
									}
								}
							}
						}
					}
					if($flag)
					{
						$cond="select dossier_file_id from dossiers_evaluations where dossier_id=".$dossier_id;
						$dos_eva_details = $this->users_model->special_fetch($cond);
						if(count($dos_eva_details)>0)
						{
							foreach($dos_eva_details as $dos_eva)
							{
								if($dos_eva['dossier_file_id']!="")
								{
									$search_fld=strtolower($search_fld);
									$cond="select id from document_text where document_id=".$dos_eva['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
									$doc_details = $this->users_model->special_fetch($cond);
									if(count($doc_details)>0)
									{
										$page_details[$j]=$dos;
										$j++;
										$flag=false;
										break;
									}
								}
							}
						}
					}
				}
				if($flag)
				{
					$page_deails=$dos_details;
				}
			}
			$i=0;
			foreach($page_details as $pages)
			{
				$cond="select * from school limit 1";
				$school_details = $this->users_model->special_fetch($cond);
				$page_details[$i]['school_details']=$school_details;
				if($pages['term_id']!="")
				{
					$cond="select name from terms where id=".$pages['term_id'];
					$comp_details = $this->users_model->special_fetch($cond);
					if(count($comp_details)>0)
						$page_details[$i]['term']=$comp_details[0]['name'];
					else
						$page_details[$i]['term']="";
				}
				else
					$page_details[$i]['term']="";
				$page_details[$i]['is_teacher_lesson']="Yes";
				if($pages['personnel_id']!="")
				{
					$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$pages['personnel_id'];
					$usr_details = $this->users_model->special_fetch($cond);
					if(count($usr_details)>0)
						$page_details[$i]['teacher']=$usr_details[0]['name'];
					else
						$page_details[$i]['teacher']="";
					if($group_id=="2")
					{
						$cond="SELECT personnel_id FROM courses WHERE id=".$pages['course_id'];
						$cor_details = $this->users_model->special_fetch($cond);
						if(count($cor_details)>0)
						{
							if($id!=$cor_details[0]['personnel_id'])
							{
								$page_details[$i]['is_teacher_lesson']="No";
							}
						}						
					}
				}
				else
					$page_details[$i]['teacher']="";
				$page_details[$i]['org_teacher']="";$page_details[$i]['course']="";$page_details[$i]['subject_id']="";
				if($pages['course_id']!="")
				{
					$cond="select name,subject_id,personnel_id from courses where id=".$pages['course_id'];
					$cor_details = $this->users_model->special_fetch($cond);
					if(count($cor_details)>0)
					{
						$page_details[$i]['course']=$cor_details[0]['name'];
						$page_details[$i]['subject_id']=$cor_details[0]['subject_id'];
						$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$cor_details[0]['personnel_id'];
						$cor_usr_details = $this->users_model->special_fetch($cond);
						if(count($cor_usr_details)>0)
							$page_details[$i]['org_teacher']=$cor_usr_details[0]['name'];
						else
							$page_details[$i]['org_teacher']="";
					}
				}
				if($pages['dossier_language_id']!="")
				{
					$cond="select name from dossier_languages where id=".$pages['dossier_language_id'];
					$cor_details = $this->users_model->special_fetch($cond);
					if(count($cor_details)>0)
						$page_details[$i]['language']=$cor_details[0]['name'];
					else
						$page_details[$i]['language']="";
				}
				else
					$page_details[$i]['language']="";
				$cond="select rating from dossiers_ratings where dossier_id=".$pages['id'];
				$rat_details = $this->users_model->special_fetch($cond);
				if(count($rat_details)>0)
					$page_details[$i]['rating']=$rat_details[0]['rating'];
				else
					$page_details[$i]['rating']="";
				$cond="select curriculum_id,subject_id,curriculum_item_cycle_id from curriculum_item where id=".$pages['curriculum_item_id'];
				$cur_details = $this->users_model->special_fetch($cond);
				if(count($cur_details)>0)
				{
					$page_details[$i]['curriculum_id']=$cur_details[0]['curriculum_id'];					
					$page_details[$i]['curriculum_cycle_id']=$cur_details[0]['curriculum_item_cycle_id'];
				}
				//preparation types
				$cond="select preparation_type_id from dossiers_preparation_types where dossier_id=".$pages['id'];
				$prep_details = $this->users_model->special_fetch($cond);
				$page_details[$i]['group_chk']="";
				$page_details[$i]['individual_chk']="";
				$page_details[$i]['remote_chk']="";
				foreach($prep_details as $prep)
				{
					if($prep['preparation_type_id']==5)
						$page_details[$i]['group_chk']=5;
					if($prep['preparation_type_id']==6)
						$page_details[$i]['individual_chk']=6;
					if($prep['preparation_type_id']==7)
						$page_details[$i]['remote_chk']=7;
				}
				$cond="select d.id,d.document_name,d.document_unique_name,d.file_size,df.ord from dossiers_related_files df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$pages['id']." order by df.ord asc";
				$doc_related_details = $this->users_model->special_fetch($cond);
				$page_details[$i]['document_files']=$doc_related_details;
				$cond="select d.id,d.document_name,d.document_unique_name,d.file_size from dossiers_solutions df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$pages['id'];
				$doc_solution_details = $this->users_model->special_fetch($cond);
				$page_details[$i]['solution_files']=$doc_solution_details;
				$cond="select df.mark_category_id,df.keywords,df.description,df.evaluation_date,d.id,d.document_name,d.document_unique_name,d.file_size from dossiers_evaluations df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$pages['id'];
				$doc_evaluation_details = $this->users_model->special_fetch($cond);
				$page_details[$i]['evaluation_files']=$doc_evaluation_details;
				if($id==$page_details[$i]['personnel_id'])
				{
					$page_details[$i]['duplicate_publish']=1;
					$page_details[$i]['duplicate_rating']=0;
				}
				else
				{
					if (strpos($page_details[$i]['local_share'], 'duplicate') !== false) 
						$page_details[$i]['duplicate_publish']=1;
					else
						$page_details[$i]['duplicate_rating']=1;
				}
				$page_details[$i]['domain_id']="";
				$i++;
			}
			
			if($flag)
			{
				if($totalRecord=="")
					$totalRecord=0;
				if($totalRecordwithFilter=="")
					$totalRecordwithFilter=0;
				if(count($page_details)<=0)
					$page_details=array();
				$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
				header('Content-Type:application/json');
				echo json_encode($out);
			}
			else
			{
				$totalRecordwithFilter=count($page_details);
				if(count($page_details)<=0)
				{
					$totalRecord=0;
					$totalRecordwithFilter=0;
					$page_details=array();
				}
				$output = array_slice($page_details, $start, $rowperpage); 
				$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
				header('Content-Type:application/json');
				echo json_encode($out); 
			}
		}
		else
		{
			$dossiers=array();
			if($columnName=="")
			{
				$columnName = "id";
				$columnSortOrder = "desc";
			}
			$host = $_SERVER['HTTP_HOST'];
			$host = str_replace("www.","",$host);
			//$this->load_database("proscola_school_live"); For PS Test Environment
			$this->load_database("");
			$cond="select * from admin where not FIND_IN_SET('".$host."', domain) and is_active=1";
			$adm_details = $this->users_model->special_fetch($cond);
			$i=0;
			$totalRecord=0;
			foreach($adm_details as $admin)
			{
				$this->load_database($admin['domain_id']);
				$cond="select * from school where id=".$admin['domain_id'];
				$school_details = $this->users_model->special_fetch($cond);
				$typeQuery="";
				if($type_fld != ''){
					$cond="select d.* from dossiers d,dossier_languages l where d.dossier_language_id=l.id and d.global_share<>'none' and d.is_deleted=0 and l.name='".$type_fld."'";		
				}
				else
				{
					$cond="select * from dossiers d where global_share<>'none' and is_deleted=0";
				}
				$dos_details = $this->users_model->special_fetch($cond);
				foreach($dos_details as $dos)
				{
					$flag=false;
					if($search_fld=="")
						$flag=true;
					else
					{
						$term_search_fld="";$name_search_fld="";$course_search_fld="";
						if($dos['term_id']!="")
						{
							$cond="select name from terms where id=".$dos['term_id'];
							$comp_details = $this->users_model->special_fetch($cond);
							if(count($comp_details)>0)
								$term_search_fld=$comp_details[0]['name'];
							else
								$term_search_fld="";
						}
						if($dos['personnel_id']!="")
						{
							$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$dos['personnel_id'];
							$usr_details = $this->users_model->special_fetch($cond);
							if(count($usr_details)>0)
								$name_search_fld=$usr_details[0]['name'];
							else
								$name_search_fld="";
						}
						if($dos['course_id']!="")
						{
							$cond="select name from courses where id=".$dos['course_id'];
							$cor_details = $this->users_model->special_fetch($cond);
							if(count($cor_details)>0)
								$course_search_fld=$cor_details[0]['name'];
							else
								$course_search_fld="";
						}
						$search_fld=strtolower($search_fld);
						if (str_contains(strtolower($dos['name']), $search_fld)||str_contains(strtolower($term_search_fld), $search_fld)||str_contains(strtolower($name_search_fld), $search_fld)||str_contains(strtolower($course_search_fld), $search_fld)||str_contains(strtolower($dos['goals']), $search_fld)||str_contains(strtolower($dos['useful_links']), $search_fld)||str_contains(strtolower($dos['files_description']), $search_fld)||str_contains(strtolower($dos['path_to_success']), $search_fld)||str_contains(strtolower($dos['task']), $search_fld)||str_contains(strtolower($dos['preparation_time']), $search_fld)||str_contains(strtolower($dos['keywords']), $search_fld)||str_contains(strtolower($dos['start_date']), $search_fld)||str_contains(strtolower($dos['end_date']), $search_fld)||str_contains(strtolower($dos['teaser_text']), $search_fld)) { 
							$flag=true;
						}
						else
						{
							$dossier_id=$dos['id'];
							$cond="select dossier_file_id from dossiers_related_files where dossier_id=".$dossier_id;
							$dos_rel_details = $this->users_model->special_fetch($cond);
							if(count($dos_rel_details)>0)
							{	
								foreach($dos_rel_details as $dos_rel)
								{
									if($dos_rel['dossier_file_id']!="")
									{
										$cond="select id from document_text where document_id=".$dos_rel['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
										$doc_details = $this->users_model->special_fetch($cond);
										if(count($doc_details)>0)
										{
											$flag=true;
											break;
										}
									}
								}
							}
							if(!$flag)
							{
								$cond="select dossier_file_id from dossiers_solutions where dossier_id=".$dossier_id;
								$dos_sol_details = $this->users_model->special_fetch($cond);
								if(count($dos_sol_details)>0)
								{
									foreach($dos_sol_details as $dos_sol)
									{
										if($dos_sol['dossier_file_id']!="")
										{
											$cond="select id from document_text where document_id=".$dos_sol['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
											$doc_details = $this->users_model->special_fetch($cond);
											if(count($doc_details)>0)
											{
												$flag=true;
												break;
											}
										}
									}
								}
							}
							if(!$flag)
							{
								$cond="select dossier_file_id from dossiers_evaluations where dossier_id=".$dossier_id;
								$dos_eva_details = $this->users_model->special_fetch($cond);
								if(count($dos_eva_details)>0)
								{
									foreach($dos_eva_details as $dos_eva)
									{
										if($dos_eva['dossier_file_id']!="")
										{
											$cond="select id from document_text where document_id=".$dos_eva['dossier_file_id']." and match(document_text) against ('".$search_fld."') limit 1";
											$doc_details = $this->users_model->special_fetch($cond);
											if(count($doc_details)>0)
											{
												$flag=true;
												break;
											}
										}
									}
								}
							}
						}
					}
					if($flag)
					{	
						$dossiers[]=array(
							"id"=>$dos['id'],
							"domain_id"=>$admin['domain_id'],
							"term_id"=>$dos['term_id'],
							"personnel_id"=>$dos['personnel_id'],
							"dossier_language_id"=>$dos['dossier_language_id'],
							"course_id"=>$dos['course_id'],
							"curriculum_item_id"=>$dos['curriculum_item_id'],
							"created_at"=>$dos['created_at'],
							"teaser_image"=>$dos['teaser_image'],
							"name"=>$dos['name'],
							"dossier_key"=>$dos['dossier_key'],
							"goals"=>$dos['goals'],
							"useful_links"=>$dos['useful_links'],
							"files_description"=>$dos['files_description'],
							"path_to_success"=>$dos['path_to_success'],
							"task"=>$dos['task'],
							"preparation_time"=>$dos['preparation_time'],
							"keywords"=>$dos['keywords'],
							"start_date"=>$dos['start_date'],
							"end_date"=>$dos['end_date'],
							"is_published"=>$dos['is_published'],
							"local_share"=>$dos['local_share'],
							"global_share"=>$dos['global_share'],
							"is_active"=>$dos['is_active'],
							"is_deleted"=>$dos['is_deleted'],
							"is_solutions_published"=>$dos['is_solutions_published'],
							"teaser_text"=>$dos['teaser_text'],
							"dossier_hash"=>$dos['dossier_hash'],
							"pdf_status"=>$dos['pdf_status'],
							"duplication_data"=>$dos['duplication_data'],
							"sent_tasks"=>$dos['sent_tasks'],
							"school_details"=>$school_details,
							"qr_code"=>$dos['qr_code']
						);
						if($dos['term_id']!="")
						{
							$cond="select name from terms where id=".$dos['term_id'];
							$comp_details = $this->users_model->special_fetch($cond);
							if(count($comp_details)>0)
								$dossiers[$i]['term']=$comp_details[0]['name'];
							else
								$dossiers[$i]['term']="";
						}
						else
							$dossiers[$i]['term']="";
						if($dos['personnel_id']!="")
						{
							$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$dos['personnel_id'];
							$usr_details = $this->users_model->special_fetch($cond);
							if(count($usr_details)>0)
								$dossiers[$i]['teacher']=$usr_details[0]['name'];
							else
								$dossiers[$i]['teacher']="";
						}
						else
							$dossiers[$i]['teacher']="";
						$dossiers[$i]['org_teacher']="";$dossiers[$i]['course']="";$dossiers[$i]['subject_id']="";
						if($dos['course_id']!="")
						{
							$cond="select name,subject_id,personnel_id from courses where id=".$dos['course_id'];
							$cor_details = $this->users_model->special_fetch($cond);
							if(count($cor_details)>0)
							{
								$dossiers[$i]['course']=$cor_details[0]['name'];
								$dossiers[$i]['subject_id']=$cor_details[0]['subject_id'];
								$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$cor_details[0]['personnel_id'];
								$usr_details = $this->users_model->special_fetch($cond);
								if(count($usr_details)>0)
									$dossiers[$i]['org_teacher']=$usr_details[0]['name'];
							}
						}
						if($dos['dossier_language_id']!="")
						{
							$cond="select name from dossier_languages where id=".$dos['dossier_language_id'];
							$cor_details = $this->users_model->special_fetch($cond);
							if(count($cor_details)>0)
								$dossiers[$i]['language']=$cor_details[0]['name'];
							else
								$dossiers[$i]['language']="";
						}
						else
							$dossiers[$i]['language']="";
						$cond="select rating from dossiers_ratings where dossier_id=".$dos['id'];
						$rat_details = $this->users_model->special_fetch($cond);
						if(count($rat_details)>0)
							$dossiers[$i]['rating']=$rat_details[0]['rating'];
						else
							$dossiers[$i]['rating']="";
						$cond="select curriculum_id,subject_id,curriculum_item_cycle_id from curriculum_item where id=".$dos['curriculum_item_id'];
						$cur_details = $this->users_model->special_fetch($cond);
						if(count($cur_details)>0)
						{
							$dossiers[$i]['curriculum_id']=$cur_details[0]['curriculum_id'];
							$dossiers[$i]['curriculum_cycle_id']=$cur_details[0]['curriculum_item_cycle_id'];
						}
						//preparation types
						$cond="select preparation_type_id from dossiers_preparation_types where dossier_id=".$dos['id'];
						$prep_details = $this->users_model->special_fetch($cond);
						$dossiers[$i]['group_chk']="";
						$dossiers[$i]['individual_chk']="";
						$dossiers[$i]['remote_chk']="";
						foreach($prep_details as $prep)
						{
							if($prep['preparation_type_id']==5)
								$dossiers[$i]['group_chk']=5;
							if($prep['preparation_type_id']==6)
								$dossiers[$i]['individual_chk']=6;
							if($prep['preparation_type_id']==7)
								$dossiers[$i]['remote_chk']=7;
						}
						$cond="select d.id,d.document_name,d.document_unique_name,d.file_size from dossiers_related_files df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dos['id'];
						$doc_related_details = $this->users_model->special_fetch($cond);
						$dossiers[$i]['document_files']=$doc_related_details;
						$cond="select d.id,d.document_name,d.document_unique_name,d.file_size from dossiers_solutions df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dos['id'];
						$doc_solution_details = $this->users_model->special_fetch($cond);
						$dossiers[$i]['solution_files']=$doc_solution_details;
						$cond="select df.mark_category_id,df.keywords,df.description,df.evaluation_date,d.id,d.document_name,d.document_unique_name,d.file_size from dossiers_evaluations df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dos['id'];
						$doc_evaluation_details = $this->users_model->special_fetch($cond);
						$dossiers[$i]['evaluation_files']=$doc_evaluation_details;
						if (strpos($dossiers[$i]['global_share'], 'duplicate') !== false) 
								$dossiers[$i]['duplicate_publish']=1;
							else
								$dossiers[$i]['duplicate_publish']=0;
						$i++;
					}
				}
			}
			$totalRecord=count($dossiers);
			$totalRecordwithFilter = $totalRecord;
			$search_count=0;
			$dossier_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($dossiers);$i++)
				{
					if(strpos(strtolower($dossiers[$i]['teacher']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['term']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['course']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['start_date']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['end_date']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['name']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['goals']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['useful_links']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['files_description']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['dossier_key']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['task']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['preparation_time']), $searchValue) !== false||strpos(strtolower($dossiers[$i]['keywords']), $searchValue) !== false)
					{
						$dossier_details[]=$dossiers[$i];
					}
				}
				$search_count=count($dossier_details);
			}
			else{
				$dossier_details=$dossiers;
			}
			if($search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($dossier_details)<=0)
			{
				$dossier_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($dossier_details as $key => $row)
				{
					$wek[$key]= $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $dossier_details);
			}
			$output = array_slice($dossier_details, $start, $rowperpage); 
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
			header('Content-Type:application/json');
			echo json_encode($out); 
		}
    }
	function convert_date($date)
    {
        $str_date=explode("/",$date);
        $new_date=$str_date[1]."/".$str_date[0]."/".$str_date[2];
        return strtotime($new_date);
    }
	
	function add_dossiers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$term_id = $data['term_id'];
		$personnel_id = $data['personnel_id'];
		$subject_id = $data['subject_id'];
		$dossier_language_id = $data['dossier_language_id'];
		$course_id = $data['course_id'];
		$curriculum_item_id = $data['curriculum_item_id'];
		$teaser_image = $data['teaser_image'];
		$teaser_text = $data['teaser_text'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$group_chk = $data['group_chk'];
		$individual_chk = $data['individual_chk'];
		$remote_chk = $data['remote_chk'];
		$published = $data['published'];
		$local_visible = $data['local_visible'];
		$local_duplication = $data['local_duplication'];
		$global_visible = $data['global_visible'];
		$global_duplication = $data['global_duplication'];
		$title = $data['title'];
		$estimated_time = $data['estimated_time'];
		$goals = $data['goals'];
		$path_to_success = $data['path_to_success'];
		$task = $data['task'];
		$keywords = $data['keywords'];
		$useful_links = $data['useful_links'];
		$description = $data['description'];
		$description = preg_replace("#([^>])&nbsp;#ui", "$1 ", $description);
		$solutions_published = $data['solutions_published'];
		$document_files = $data['document_files'];
		$files_order = $data['files_order'];
		$solution_files = $data['solution_files'];
		$evaluation_files = $data['evaluation_files'];
		$evaluation_details = $data['evaluation_details'];
		$dossier_key = $data['dossier_key'];
		$rating = $data['rating'];
		$qr_code = $data['qr_code'];
		$local_share="";
		$global_share="";
		if($published==0)
		{
			$local_share="none";
			$global_share="none";
		}
		else
		{
			if($local_visible==0&&$local_duplication==0)
				$local_share="none";
			else
			{
				if($local_visible==1)
					$local_share="view";
				if($local_duplication==1)
					$local_share=$local_share.",duplicate";
			}
			$local_share=trim($local_share,",");
			$global_share="";
			if($global_visible==0&&$global_duplication==0)
				$global_share="none";
			else
			{
				if($global_visible==1)
					$global_share="view";
				if($global_duplication==1)
					$global_share=$global_share.",duplicate";
			}
			$global_share=trim($global_share,",");
		}
		$global_share=trim($global_share,",");
		$input = array(
			'term_id'=>$term_id,
			'personnel_id'=>$personnel_id,
			'dossier_language_id'=>$dossier_language_id,
			'course_id '=>$course_id,
			'curriculum_item_id '=>$curriculum_item_id,
			'teaser_image'=>$teaser_image,
			'teaser_text'=>$teaser_text,
			'dossier_key'=>$dossier_key,
			'start_date'=>$start_date,
			'end_date'=>$end_date,
			'local_share'=>$local_share,
			'global_share'=>$global_share,
			'is_published'=>$published,
			'is_solutions_published'=>$solutions_published,
			'name'=>$title,
			'preparation_time'=>$estimated_time,
			'goals'=>$goals,
			'path_to_success'=>$path_to_success,
			'task'=>$task,
			'keywords'=>$keywords,
			'useful_links'=>$useful_links,
			'pdf_status'=>"in_progress",
			'qr_code'=>$qr_code,
			'files_description'=>$description,
			'created_at'=>time()
		);
		$dossier_id=$this->dossiers_model->add($input);
		$dossier_hash=md5($dossier_key);
		$input = array(
			'dossier_hash'=>$dossier_hash
		);
		$this->dossiers_model->edit($input,$dossier_id);
		if($group_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$group_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		if($individual_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$individual_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		if($remote_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$remote_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		$input = array(
			'dossier_id'=>$dossier_id,
			'rating'=>$rating
		);
		$this->dossiers_ratings_model->add($input);
		$lesson_folder_id=0;
		$permission=0;$global_permission=0;
		if($local_visible==0)
			$permission=1;
		if($global_visible==0)
			$global_permission=1;
		$lm_folder_id=0;
		if($document_files!=""||$solution_files!=""||$evaluation_files!="")
		{	
			$cond="select id from folders where folder='Lessons' and user_id=".$personnel_id;
			$fold_details = $this->users_model->special_fetch($cond);
			if(count($fold_details)>0)
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>$dossier_key,
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$fold_details[0]['id']
				);
				$lesson_folder_id=$this->folder_manager_model->add($input);
				if($permission==0)
				{
					$cond="select id from folders where folder='Public' and user_id=".$personnel_id;
					$fold_details = $this->users_model->special_fetch($cond);
					$input = array(
						'user_id'=>0,
						'folder'=>$dossier_key,
						'permission'=>$permission,
						'global_permission'=>$global_permission,
						'is_deleted'=>1,
						'parent_folder'=>$fold_details[0]['id']
					);
					$lm_folder_id=$this->folder_manager_model->add($input);
				}
			}
		}
		$document_files_arr=explode(",",$document_files);
		$files_order_arr=explode(",",$files_order);
		$solution_files_arr=explode(",",$solution_files);
		$evaluation_files_arr=explode(",",$evaluation_files);
		if($files_order!="")
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Learning Materials',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$lm_id=$this->folder_manager_model->add($input);
			$ord=0;
			foreach($files_order_arr as $fil)
			{
				$doc=$document_files_arr[$fil];
				$input = array(
					'dossier_id'=>$dossier_id,
					'dossier_file_id'=>$doc,
					'ord'=>$ord
				);
				$this->dossiers_related_files_model->add($input);
				$ord++;
				$cond="select * from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$lm_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
			}
		}
		else
		{
			$this->folder_manager_model->delete($lm_folder_id);
		}
		if($solution_files!="")
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Solutions',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$sl_id=$this->folder_manager_model->add($input);
			foreach($solution_files_arr as $doc)
			{
				$input = array(
					'dossier_id'=>$dossier_id,
					'dossier_file_id'=>$doc,
					'created_at'=>time()
				);
				$this->dossiers_solutions_model->add($input);
				$cond="select * from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$sl_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
			}
		}
		if($evaluation_files!="")
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Evaluations',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$ev_id=$this->folder_manager_model->add($input);
			$i=0;
			foreach($evaluation_files_arr as $doc)
			{
				$input = array(
					'dossier_id'=>$dossier_id,
					'dossier_file_id'=>$doc,
					'mark_category_id'=>$evaluation_details[$i]['mark_category_id'],
					'evaluation_date'=>$evaluation_details[$i]['evaluation_date'],
					'keywords'=>$evaluation_details[$i]['keywords'],
					'description'=>$evaluation_details[$i]['description'],
					'created_at'=>time()
				);
				$this->dossiers_evaluations_model->add($input);
				$cond="select * from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$ev_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[303]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function edit_dossiers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$term_id = $data['term_id'];
		$personnel_id = $data['personnel_id'];
		$subject_id = $data['subject_id'];
		$dossier_language_id = $data['dossier_language_id'];
		$course_id = $data['course_id'];
		$curriculum_item_id = $data['curriculum_item_id'];
		$teaser_image = $data['teaser_image'];
		$teaser_text = $data['teaser_text'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$group_chk = $data['group_chk'];
		$individual_chk = $data['individual_chk'];
		$remote_chk = $data['remote_chk'];
		$published = $data['published'];
		$local_visible = $data['local_visible'];
		$local_duplication = $data['local_duplication'];
		$global_visible = $data['global_visible'];
		$global_duplication = $data['global_duplication'];
		$title = $data['title'];
		$estimated_time = $data['estimated_time'];
		$goals = $data['goals'];
		$path_to_success = $data['path_to_success'];
		$task = $data['task'];
		$keywords = $data['keywords'];
		$useful_links = $data['useful_links'];
		$description = $data['description'];
		$description = preg_replace("#([^>])&nbsp;#ui", "$1 ", $description);
		$solutions_published = $data['solutions_published'];
		$document_files = $data['document_files'];
		$files_order = $data['files_order'];
		$solution_files = $data['solution_files'];
		$evaluation_details = $data['evaluation_details'];
		$rating = $data['rating'];
		$local_share="";
		$global_share="";
		if($published==0)
		{
			$local_share="none";
			$global_share="none";
		}
		else
		{
			if($local_visible==0&&$local_duplication==0)
				$local_share="none";
			else
			{
				if($local_visible==1)
					$local_share="view";
				if($local_duplication==1)
					$local_share=$local_share.",duplicate";
			}
			$local_share=trim($local_share,",");
			$global_share="";
			if($global_visible==0&&$global_duplication==0)
				$global_share="none";
			else
			{
				if($global_visible==1)
					$global_share="view";
				if($global_duplication==1)
					$global_share=$global_share.",duplicate";
			}
			$global_share=trim($global_share,",");
		}
		$input = array(
			'term_id'=>$term_id,
			'dossier_language_id'=>$dossier_language_id,
			'course_id '=>$course_id,
			'curriculum_item_id '=>$curriculum_item_id,
			'teaser_image'=>$teaser_image,
			'teaser_text'=>$teaser_text,
			'start_date'=>$start_date,
			'end_date'=>$end_date,
			'local_share'=>$local_share,
			'global_share'=>$global_share,
			'is_published'=>$published,
			'is_solutions_published'=>$solutions_published,
			'name'=>$title,
			'preparation_time'=>$estimated_time,
			'goals'=>$goals,
			'path_to_success'=>$path_to_success,
			'task'=>$task,
			'keywords'=>$keywords,
			'useful_links'=>$useful_links,
			'pdf_status'=>"in_progress",
			'files_description'=>$description,
			'updated_at'=>time()
		);
		$this->dossiers_model->edit($input,$id);
		$cond="select id from dossiers_ratings where dossier_id=".$id;
		$rat_details = $this->dossiers_model->special_fetch($cond);
		if(count($rat_details)>0){
			$input = array(
				'rating'=>(int)$rating
			);
			$this->dossiers_ratings_model->edit($input,$rat_details[0]['id']);
		}
		if($group_chk!=0)
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=".$group_chk." and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)<=0)
			{
				$input = array(
					'dossier_id'=>$id,
					'preparation_type_id'=>$group_chk
				);
				$this->dossiers_preparation_types_model->add($input);
			}
		}
		else
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=6 and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)>0)
			{
				$this->dossiers_preparation_types_model->delete($pre_details[0]['id']);
			}
		}
		if($individual_chk!=0)
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=".$individual_chk." and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)<=0)
			{
				$input = array(
					'dossier_id'=>$id,
					'preparation_type_id'=>$individual_chk
				);
				$this->dossiers_preparation_types_model->add($input);
			}
		}
		else
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=5 and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)>0)
			{
				$this->dossiers_preparation_types_model->delete($pre_details[0]['id']);
			}
		}
		if($remote_chk!=0)
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=".$remote_chk." and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)<=0)
			{
				$input = array(
					'dossier_id'=>$id,
					'preparation_type_id'=>$remote_chk
				);
				$this->dossiers_preparation_types_model->add($input);
			}
		}
		else
		{
			$cond="select id from dossiers_preparation_types where preparation_type_id=7 and dossier_id=".$id;
			$pre_details = $this->dossiers_model->special_fetch($cond);
			if(count($pre_details)>0)
			{
				$this->dossiers_preparation_types_model->delete($pre_details[0]['id']);
			}
		}
		$cond="select dossier_key from dossiers where id=".$id;
		$dossier_details = $this->dossiers_model->special_fetch($cond);
		$dossier_key=$dossier_details[0]['dossier_key'];
		$lesson_folder_id=0;
		$permission=0;$global_permission=0;
		if($local_visible==0)
			$permission=1;
		if($global_visible==0)
			$global_permission=1;
		$cond="select id from folders where folder='".$dossier_key."' and user_id<>0";
		$dos_fol_details = $this->dossiers_model->special_fetch($cond);
		if(count($dos_fol_details)<=0)
		{
			$cond="select id from folders where folder='Lessons' and user_id=".$personnel_id;
			$fold_details = $this->users_model->special_fetch($cond);
			if(count($fold_details)>0)
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>$dossier_key,
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$fold_details[0]['id']
				);
				$lesson_folder_id=$this->folder_manager_model->add($input);
			}
		}
		else
			$lesson_folder_id=$dos_fol_details[0]['id'];
		if($permission==0)
		{
			$cond="select id from folders where folder='".$dossier_key."' and user_id=0";
			$pub_details = $this->users_model->special_fetch($cond);
			if(count($pub_details)<=0)
			{
				$cond="select id from folders where folder='Public' and user_id=".$personnel_id;
				$fold_details = $this->users_model->special_fetch($cond);
				if(count($fold_details)>0)
				{
					$input = array(
						'user_id'=>0,
						'folder'=>$dossier_key,
						'permission'=>$permission,
						'global_permission'=>$global_permission,
						'is_deleted'=>1,
						'parent_folder'=>$fold_details[0]['id']
					);
					$this->folder_manager_model->add($input);
				}
			}
		}
		$new_document_files_arr=array();
		if($document_files!="")
		{
			$document_files_arr=explode(",",$document_files);
			if($files_order!="")
			{
				$files_order=explode(",",$files_order);
				foreach($files_order as $fil)
				{
					if($fil!="")
					{
						$doc_id=$document_files_arr[$fil];
						$new_document_files_arr[]=$doc_id;
					}
				}
			}
		}
		$cond="select group_concat(dossier_file_id) as dossier_file_id from dossiers_related_files where dossier_id=".$id;
		$old_doc_details = $this->dossiers_model->special_fetch($cond);
		$old_document_files_arr=explode(",",$old_doc_details[0]['dossier_file_id']);
		//$new_doc_files = array_diff($new_document_files_arr, $old_document_files_arr);
		$remove_doc_files = array_diff($old_document_files_arr, $new_document_files_arr);
		$cond="select id from folders where parent_folder=".$lesson_folder_id." and user_id=".$personnel_id." and folder='Learning Materials'";
		$lm_fol_details = $this->dossiers_model->special_fetch($cond);
		$lm_id=0;
		if(count($lm_fol_details)<=0)
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Learning Materials',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$lm_id=$this->folder_manager_model->add($input);
		}
		else
			$lm_id=$lm_fol_details[0]['id'];
		$i=0;
		foreach($new_document_files_arr as $doc)
		{
			$cond="select id from dossiers_related_files where dossier_id=".$id." and dossier_file_id=".$doc;
			$dos_rel_details = $this->dossiers_model->special_fetch($cond);
			if(count($dos_rel_details)<=0)
			{
				$input = array(
					'dossier_id'=>$id,
					'dossier_file_id'=>$doc,
					'ord'=>$i
				);
				$this->dossiers_related_files_model->add($input);
				$cond="select * from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$lm_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
				$i++;
			}
			else
			{
				$input = array(
					'ord'=>$i
				);
				$this->dossiers_related_files_model->edit($input,$dos_rel_details[0]['id']);
				$i++;
			}
		}
		foreach($remove_doc_files as $doc)
		{
			$input = array(
				'dossier_id'=>$id,
				'dossier_file_id'=>$doc
			);
			$this->dossiers_related_files_model->delete_files($input);
			if($doc!='')
			{
				$cond="select document_unique_name from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				if(count($doc_details)>0)
				{
					$input = array(
						'folder_id'=>$lm_id,
						'document_unique_name'=>$doc_details[0]['document_unique_name']
					);
					$this->file_manager_model->delete_files($input);
				}
			}
		}
		$lm_flag=false;
		$cond="select id from dossiers_related_files where dossier_id=".$id;
		$lm_doc_details = $this->dossiers_model->special_fetch($cond);
		if(count($lm_doc_details)<=0)
		{
			$this->folder_manager_model->delete($lm_id);
			$lm_flag=true;
		}
		//Solution Files
		if($solution_files!='')
			$new_document_files_arr=explode(",",$solution_files);
		else
			$new_document_files_arr=array();
		$cond="select group_concat(dossier_file_id) as dossier_file_id from dossiers_solutions where dossier_id=".$id;
		$old_doc_details = $this->dossiers_model->special_fetch($cond);
		$old_document_files_arr=explode(",",$old_doc_details[0]['dossier_file_id']);
		$new_doc_files = array_diff($new_document_files_arr, $old_document_files_arr);
		$remove_doc_files = array_diff($old_document_files_arr, $new_document_files_arr);
		$cond="select id from folders where parent_folder=".$lesson_folder_id." and user_id=".$personnel_id." and folder='Solutions'";
		$lm_fol_details = $this->dossiers_model->special_fetch($cond);
		$lm_id=0;
		if(count($lm_fol_details)<=0)
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Solutions',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$lm_id=$this->folder_manager_model->add($input);
		}
		else
			$lm_id=$lm_fol_details[0]['id'];
		foreach($new_doc_files as $doc)
		{
			$input = array(
				'dossier_id'=>$id,
				'dossier_file_id'=>$doc
			);
			$this->dossiers_solutions_model->add($input);
			$cond="select * from documents where id=".$doc;
			$doc_details = $this->users_model->special_fetch($cond);
			$input = array(
				'folder_id'=>$lm_id,
				'document_name'=>$doc_details[0]['document_name'],
				'document_unique_name'=>$doc_details[0]['document_unique_name'],
				'file_size'=>$doc_details[0]['file_size'],
				'file_permissions'=>$permission,
				'created_at'=>time()
			);
			$this->file_manager_model->add($input);
		}
		foreach($remove_doc_files as $doc)
		{
			$input = array(
				'dossier_id'=>$id,
				'dossier_file_id'=>$doc
			);
			$this->dossiers_solutions_model->delete_files($input);
			if($doc!='')
			{
				$cond="select document_unique_name from documents where id=".$doc;
				$doc_details = $this->users_model->special_fetch($cond);
				if(count($doc_details)>0)
				{
					$input = array(
						'folder_id'=>$lm_id,
						'document_unique_name'=>$doc_details[0]['document_unique_name']
					);
					$this->file_manager_model->delete_files($input);
				}
			}
		}
		$sol_flag=false;
		$cond="select id from dossiers_solutions where dossier_id=".$id;
		$lm_doc_details = $this->dossiers_model->special_fetch($cond);
		if(count($lm_doc_details)<=0)
		{
			$this->folder_manager_model->delete($lm_id);
			$sol_flag=true;
		}
		//Evaluation Files
		$cond="select group_concat(dossier_file_id) as dossier_file_id from dossiers_evaluations where dossier_id=".$id;
		$old_doc_details = $this->dossiers_model->special_fetch($cond);
		$old_document_files_arr=explode(",",$old_doc_details[0]['dossier_file_id']);
		$cond="select id from folders where parent_folder=".$lesson_folder_id." and user_id=".$personnel_id." and folder='Evaluations'";
		$lm_fol_details = $this->dossiers_model->special_fetch($cond);
		$lm_id=0;
		if(count($lm_fol_details)<=0)
		{
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>'Evaluations',
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$lesson_folder_id
			);
			$lm_id=$this->folder_manager_model->add($input);
		}
		else
			$lm_id=$lm_fol_details[0]['id'];
		foreach($evaluation_details as $eval)
		{
			if (in_array($eval['dossier_file_id'], $old_document_files_arr))
			{
				$input = array(
					'dossier_id'=>$id,
					'dossier_file_id'=>$eval['dossier_file_id'],
					'mark_category_id'=>$eval['mark_category_id'],
					'evaluation_date'=>$eval['evaluation_date'],
					'keywords'=>$eval['keywords'],
					'description'=>$eval['description']
				);
				$this->dossiers_evaluations_model->edit_files($input);
				$pos = array_search($eval['dossier_file_id'], $old_document_files_arr);
				unset($old_document_files_arr[$pos]);
			}
			else
			{
				$input = array(
					'dossier_id'=>$id,
					'dossier_file_id'=>$eval['dossier_file_id'],
					'mark_category_id'=>$eval['mark_category_id'],
					'evaluation_date'=>$eval['evaluation_date'],
					'keywords'=>$eval['keywords'],
					'description'=>$eval['description']
				);
				$this->dossiers_evaluations_model->add($input);
				$cond="select * from documents where id=".$eval['dossier_file_id'];
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$lm_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
			}
		}
		foreach($old_document_files_arr as $dossier_file_id)
		{
			$input = array(
				'dossier_id'=>$id,
				'dossier_file_id'=>$dossier_file_id
			);
			$this->dossiers_evaluations_model->delete_files($input);
			if($dossier_file_id!='')
			{
				$cond="select document_unique_name from documents where id=".$dossier_file_id;
				$doc_details = $this->users_model->special_fetch($cond);
				if(count($doc_details)>0)
				{
					$input = array(
						'folder_id'=>$lm_id,
						'document_unique_name'=>$doc_details[0]['document_unique_name']
					);
					$this->file_manager_model->delete_files($input);
				}
			}
		}
		$eva_flag=false;
		$cond="select id from dossiers_evaluations where dossier_id=".$id;
		$lm_doc_details = $this->dossiers_model->special_fetch($cond);
		if(count($lm_doc_details)<=0)
		{
			$this->folder_manager_model->delete($lm_id);
			$eva_flag=true;
		}
		if($lm_flag&&$sol_flag&&$eva_flag)
		{
			$this->folder_manager_model->delete($lesson_folder_id);
		}
		if($lm_flag||$published==0)
		{
			$cond="select id from folders where folder='".$dossier_key."' and user_id=0";
			$dos_fol_details = $this->dossiers_model->special_fetch($cond);
			if(count($dos_fol_details)>0)
				$this->folder_manager_model->delete($dos_fol_details[0]['id']);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[315]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    function duplicate_dossiers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$term_id = $data['term_id'];
		$personnel_id = $data['personnel_id'];
		$subject_id = $data['subject_id'];
		$dossier_language_id = $data['dossier_language_id'];
		$course_id = $data['course_id'];
		$curriculum_item_id = $data['curriculum_item_id'];
		$teaser_image = $data['teaser_image'];
		$teaser_text = $data['teaser_text'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$group_chk = $data['group_chk'];
		$individual_chk = $data['individual_chk'];
		$remote_chk = $data['remote_chk'];
		$published = $data['published'];
		$local_visible = $data['local_visible'];
		$local_duplication = $data['local_duplication'];
		$global_visible = $data['global_visible'];
		$global_duplication = $data['global_duplication'];
		$title = $data['title'];
		$estimated_time = $data['estimated_time'];
		$goals = $data['goals'];
		$path_to_success = $data['path_to_success'];
		$task = $data['task'];
		$local = $data['local'];
		$keywords = $data['keywords'];
		$useful_links = $data['useful_links'];
		$description = $data['description'];
		$description = preg_replace("#([^>])&nbsp;#ui", "$1 ", $description);
		$solutions_published = $data['solutions_published'];
		$document_files = $data['document_files'];
		$files_order = $data['files_order'];
		$solution_files = $data['solution_files'];
		$evaluation_details = $data['evaluation_details'];
		$dossier_key = $data['dossier_key'];
		$rating = $data['rating'];
		$qr_code = $data['qr_code'];
		$local_share="";
		$global_share="";
		if($published==0)
		{
			$local_share="none";
			$global_share="none";
		}
		else
		{
			if($local_visible==0&&$local_duplication==0)
				$local_share="none";
			else
			{
				if($local_visible==1)
					$local_share="view";
				if($local_duplication==1)
					$local_share=$local_share.",duplicate";
			}
			$local_share=trim($local_share,",");
			$global_share="";
			if($global_visible==0&&$global_duplication==0)
				$global_share="none";
			else
			{
				if($global_visible==1)
					$global_share="view";
				if($global_duplication==1)
					$global_share=$global_share.",duplicate";
			}
			$global_share=trim($global_share,",");
		}
		$global_share=trim($global_share,",");
		$input = array(
			'term_id'=>$term_id,
			'personnel_id'=>$personnel_id,
			'dossier_language_id'=>$dossier_language_id,
			'course_id '=>$course_id,
			'curriculum_item_id '=>$curriculum_item_id,
			'teaser_image'=>$teaser_image,
			'teaser_text'=>$teaser_text,
			'start_date'=>$start_date,
			'end_date'=>$end_date,
			'local_share'=>$local_share,
			'global_share'=>$global_share,
			'is_published'=>$published,
			'is_solutions_published'=>$solutions_published,
			'name'=>$title,
			'preparation_time'=>$estimated_time,
			'goals'=>$goals,
			'path_to_success'=>$path_to_success,
			'task'=>$task,
			'keywords'=>$keywords,
			'useful_links'=>$useful_links,
			'pdf_status'=>"in_progress",
			'files_description'=>$description,
			'dossier_key'=>$dossier_key,
			'qr_code'=>$qr_code,
			'created_at'=>time()
		);
		$dossier_id=$this->dossiers_model->add($input);
		$dossier_hash=md5($dossier_key);
		$input = array(
			'dossier_hash'=>$dossier_hash
		);
		$this->dossiers_model->edit($input,$dossier_id);
		$input = array(
			'dossier_id'=>$dossier_id,
			'rating'=>$rating
		);
		$this->dossiers_ratings_model->add($input);
		if($group_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$group_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		if($individual_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$individual_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		if($remote_chk!=0)
		{
			$input = array(
				'dossier_id'=>$dossier_id,
				'preparation_type_id'=>$remote_chk
			);
			$this->dossiers_preparation_types_model->add($input);
		}
		$dup_folder_id=0;
		$permission=0;$global_permission=0;
		if($local_visible==0)
			$permission=1;
		if($global_visible==0)
			$global_permission=1;
		if($document_files!=""||$solution_files!=""||count($evaluation_details)>0)
		{
			$cond="select id from folders where folder='Duplicate' and user_id=".$personnel_id;
			$fold_details = $this->users_model->special_fetch($cond);
			$input = array(
				'user_id'=>$personnel_id,
				'folder'=>$dossier_key,
				'permission'=>$permission,
				'global_permission'=>$global_permission,
				'is_deleted'=>1,
				'parent_folder'=>$fold_details[0]['id']
			);
			$dup_folder_id=$this->folder_manager_model->add($input);
			if($permission==0)
			{
				$cond="select id from folders where folder='Public' and user_id=".$personnel_id;
				$fold_details = $this->users_model->special_fetch($cond);
				$input = array(
					'user_id'=>0,
					'folder'=>$dossier_key,
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$fold_details[0]['id']
				);
				$this->folder_manager_model->add($input);
			}
		}
		if($local==1)
		{	
			$document_files_arr=explode(",",$document_files);
			$files_order_arr=explode(",",$files_order);
			$solution_files_arr=explode(",",$solution_files);
			if($files_order!="")
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Learning Materials',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				$ord=0;
				foreach($files_order_arr as $fil)
				{
					$doc=$document_files_arr[$fil];
					$input = array(
						'dossier_id'=>$dossier_id,
						'dossier_file_id'=>$doc,
						'ord'=>$ord
					);
					$this->dossiers_related_files_model->add($input);
					$ord++;
					if($doc!="")
					{
						$cond="select * from documents where id=".$doc;
						$doc_details = $this->users_model->special_fetch($cond);
						$input = array(
							'folder_id'=>$lm_id,
							'document_name'=>$doc_details[0]['document_name'],
							'document_unique_name'=>$doc_details[0]['document_unique_name'],
							'file_size'=>$doc_details[0]['file_size'],
							'file_permissions'=>$permission,
							'created_at'=>time()
						);
						$this->file_manager_model->add($input);
					}
				}
			}
			if($solution_files!="")
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Solutions',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				foreach($solution_files_arr as $doc)
				{
					$input = array(
						'dossier_id'=>$dossier_id,
						'dossier_file_id'=>$doc,
						'created_at'=>time()
					);
					$this->dossiers_solutions_model->add($input);
					$cond="select * from documents where id=".$doc;
						$doc_details = $this->users_model->special_fetch($cond);
						$input = array(
							'folder_id'=>$lm_id,
							'document_name'=>$doc_details[0]['document_name'],
							'document_unique_name'=>$doc_details[0]['document_unique_name'],
							'file_size'=>$doc_details[0]['file_size'],
							'file_permissions'=>$permission,
							'created_at'=>time()
						);
					$this->file_manager_model->add($input);
				}
			}
			for($i=0;$i<count($evaluation_details);$i++)
			{
				$input = array(
					'dossier_id'=>$evaluation_details[$i]['dossier_id'],
					'dossier_file_id'=>$evaluation_details[$i]['dossier_file_id'],
					'mark_category_id'=>$evaluation_details[$i]['mark_category_id'],
					'evaluation_date'=>$evaluation_details[$i]['evaluation_date'],
					'keywords'=>$evaluation_details[$i]['keywords'],
					'description'=>$evaluation_details[$i]['description'],
					'created_at'=>time()
				);
				$this->dossiers_evaluations_model->add($input);
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Evaluations',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				$cond="select * from documents where id=".$evaluation_details[$i]['dossier_file_id'];
				$doc_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder_id'=>$lm_id,
					'document_name'=>$doc_details[0]['document_name'],
					'document_unique_name'=>$doc_details[0]['document_unique_name'],
					'file_size'=>$doc_details[0]['file_size'],
					'file_permissions'=>$permission,
					'created_at'=>time()
				);
				$this->file_manager_model->add($input);
			}
		}
		else
		{
			$document_files_arr=explode(",",$document_files);
			$files_order_arr=explode(",",$files_order);
			$solution_files_arr=explode(",",$solution_files);
			if($files_order!="")
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Learning Materials',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				$ord=0;
				foreach($files_order_arr as $fil)
				{
					if($fil!="")
					{
						$doc=$document_files_arr[$fil];
						if (strpos($doc, "d*o*m") !== false) 
						{
							if($doc!="")
							{
								$doc_items=explode('d*o*m',$doc);
								$input = array(
									'folder_id'=>$lm_id,
									'document_name'=>$doc_items[1],
									'document_unique_name'=>$doc_items[2],
									'file_size'=>$doc_items[3],
									'file_permissions'=>$permission,
									'created_at'=>time()
								);
								$doc_id=$this->file_manager_model->add($input);
								$input = array(
									'dossier_id'=>$dossier_id,
									'dossier_file_id'=>$doc_id,
									'ord'=>$ord
								);
								$this->dossiers_related_files_model->add($input);
							}
						}
						else
						{
							$input = array(
								'dossier_id'=>$dossier_id,
								'dossier_file_id'=>$doc,
								'ord'=>$ord
							);
							$this->dossiers_related_files_model->add($input);
							$ord++;
							if($doc!="")
							{
								$cond="select * from documents where id=".$doc;
								$doc_details = $this->users_model->special_fetch($cond);
								$input = array(
									'folder_id'=>$lm_id,
									'document_name'=>$doc_details[0]['document_name'],
									'document_unique_name'=>$doc_details[0]['document_unique_name'],
									'file_size'=>$doc_details[0]['file_size'],
									'file_permissions'=>$permission,
									'created_at'=>time()
								);
								$this->file_manager_model->add($input);
							}
						}
					}
				}
			}
			if($solution_files!="")
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Solutions',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				foreach($solution_files_arr as $doc)
				{
					if (strpos($doc, "d*o*m") !== false) 
					{
						if($doc!="")
						{
							$doc_items=explode('d*o*m',$doc);
							$input = array(
								'folder_id'=>$lm_id,
								'document_name'=>$doc_items[1],
								'document_unique_name'=>$doc_items[2],
								'file_size'=>$doc_items[3],
								'file_permissions'=>$permission,
								'created_at'=>time()
							);
							$doc_id=$this->file_manager_model->add($input);
							$input = array(
								'dossier_id'=>$dossier_id,
								'dossier_file_id'=>$doc_id,
								'created_at'=>time()
							);
							$this->dossiers_solutions_model->add($input);
						}
					}
					else
					{
						$input = array(
							'dossier_id'=>$dossier_id,
							'dossier_file_id'=>$doc,
							'created_at'=>time()
						);
						$this->dossiers_solutions_model->add($input);
						$cond="select * from documents where id=".$doc;
						$doc_details = $this->users_model->special_fetch($cond);
						$input = array(
							'folder_id'=>$lm_id,
							'document_name'=>$doc_details[0]['document_name'],
							'document_unique_name'=>$doc_details[0]['document_unique_name'],
							'file_size'=>$doc_details[0]['file_size'],
							'file_permissions'=>$permission,
							'created_at'=>time()
						);
						$this->file_manager_model->add($input);
					}
				}
			}
			for($i=0;$i<count($evaluation_details);$i++)
			{
				$input = array(
					'user_id'=>$personnel_id,
					'folder'=>'Evaluations',
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1,
					'parent_folder'=>$dup_folder_id
				);
				$lm_id=$this->folder_manager_model->add($input);
				if (strpos($evaluation_details[$i]['dossier_file_id'], "d*o*m") !== false) 
				{
					$doc_items=explode('d*o*m',$evaluation_details[$i]['dossier_file_id']);
					$input = array(
						'folder_id'=>$lm_id,
						'document_name'=>$doc_items[1],
						'document_unique_name'=>$doc_items[2],
						'file_size'=>$doc_items[3],
						'file_permissions'=>$permission,
						'created_at'=>time()
					);
					$doc_id=$this->file_manager_model->add($input);
					$input = array(
						'dossier_id'=>$dossier_id,
						'dossier_file_id'=>$doc_id,
						'mark_category_id'=>$evaluation_details[$i]['mark_category_id'],
						'evaluation_date'=>$evaluation_details[$i]['evaluation_date'],
						'keywords'=>$evaluation_details[$i]['keywords'],
						'description'=>$evaluation_details[$i]['description'],
						'created_at'=>time()
					);
					$this->dossiers_evaluations_model->add($input);
				}
				else
				{
					$input = array(
						'dossier_id'=>$dossier_id,
						'dossier_file_id'=>$evaluation_details[$i]['dossier_file_id'],
						'mark_category_id'=>$evaluation_details[$i]['mark_category_id'],
						'evaluation_date'=>$evaluation_details[$i]['evaluation_date'],
						'keywords'=>$evaluation_details[$i]['keywords'],
						'description'=>$evaluation_details[$i]['description'],
						'created_at'=>time()
					);
					$this->dossiers_evaluations_model->add($input);
					$cond="select * from documents where id=".$evaluation_details[$i]['dossier_file_id'];
					$doc_details = $this->users_model->special_fetch($cond);
					$input = array(
						'folder_id'=>$lm_id,
						'document_name'=>$doc_details[0]['document_name'],
						'document_unique_name'=>$doc_details[0]['document_unique_name'],
						'file_size'=>$doc_details[0]['file_size'],
						'file_permissions'=>$permission,
						'created_at'=>time()
					);
					$this->file_manager_model->add($input);
				}
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[304]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    } 	    
    function delete_dossiers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id']; 
		$label_details = $this->get_labels_page($lang_id);
		$user_id = $data['user_id']; 
		$group_id = $data['group_id'];
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select name,personnel_id from dossiers where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			if($user_id!=$p_details[0]['personnel_id']&&$group_id=="2")
			{	
				$in_use_name=$in_use_name.",".$name;
			}
			else
			{
				$cond="select id from course_attendants_marks where dossier_id=".$id;
				$ab_details = $this->subject_types_model->special_fetch($cond);
				if(count($ab_details)<=0)
				{
					$input = array(
						'is_deleted'=>1,
						'deleted_at'=>time()
					);
					$this->dossiers_model->edit($input,$id);
					$cond="select dossier_key from dossiers where id=".$id;
					$dos_details = $this->users_model->special_fetch($cond);
					if(count($dos_details)>0)
					{
						$input = array(
							'is_active'=>1,
							'dossier_key'=>$dos_details[0]['dossier_key']
						);
						$this->folder_manager_model->update_folder_status($input);
					}	
					$not_in_use_name=$not_in_use_name.",".$name;
				}
				else
				{
					$in_use_name=$in_use_name.",".$name;
				}
			}			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[305]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[364]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);               
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function restore_dossiers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->dossiers_model->edit($input,$id);
			$cond="select dossier_key from dossiers where id=".$id;
			$dos_details = $this->users_model->special_fetch($cond);
			if(count($dos_details)>0)
			{
				$input = array(
					'is_active'=>0,
					'dossier_key'=>$dos_details[0]['dossier_key']
				);
				$this->folder_manager_model->update_folder_status($input);
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[306]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function send_task_dossiers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id']; 
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$user_id = $data['user_id']; 
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$msg='';$link='';
			$cond="select * from dossiers where id=".$id;
			$dos_details = $this->users_model->special_fetch($cond);
			if(count($dos_details)>0)
			{
				if (str_contains($dos_details[0]['local_share'], 'view')) 
				{ 
					$due_datetime = $dos_details[0]['end_date'];
					$due_date_timestamp=strtotime($due_datetime);
					$created_at_timestamp=time();
					$created_at=date('F j, Y h:i', $created_at_timestamp);
					$msg=$dos_details[0]['preparation_time'];
					$link.='<button type="button" class="modal-popup dossier_class" id="'.$dos_details[0]['id'].'"><h6 class="text-align-right font-green"><b>'.$dos_details[0]['name'].'</b></h6></button><br />';
					$link.='<button type="button" id="'.$dos_details[0]['dossier_key'].'" class="btn btn-link text-succes dow_doc">Download File</a>';
					$input = array(
						'sender_id'=>$user_id,
						'type'=>'task',
						'subject'=>$dos_details[0]['name'],
						'message'=>$msg,
						'links'=>$link,
						'attachment'=>'',
						'due_datetime'=>$due_datetime,
						'due_date_timestamp'=>$due_date_timestamp,
						'is_reply_enabled'=>0,
						'ord'=>1,
						'created_at'=>$created_at,
						'created_at_timestamp'=>$created_at_timestamp
					);
					$n_id = $this->notifications_model->add($input);
					$course_id=$dos_details[0]['course_id'];
					$cond="SELECT name FROM courses WHERE id=".$course_id;
					$cor_details = $this->users_model->special_fetch($cond);
					$course_name='';
					if(count($cor_details)>0)
						$course_name=$cor_details[0]['name'];
					$course=array(
						$course_id=>$course_name
					);
					$cond="SELECT DISTINCT(st.student_id) as id FROM students_terms st,course_attendants c,users u WHERE st.id=c.student_term_id and u.id=st.student_id and u.is_active=1 and c.course_id=".$course_id;
					$student_details = $this->users_model->special_fetch($cond);
					foreach($student_details as $stu)
					{
						$input = array(
							'notification_id'=>$n_id,
							'recipient_id'=>$stu['id']
						);
						$this->notifications_recipients_model->add($input);
					}
					$recipients[]=array(
						"student_courses"=>$course
					);
					$recipient_info=json_encode($recipients);
					$input = array(
						'recipients_info'=>$recipient_info,
						'path'=>$n_id
					);
					$this->notifications_model->edit($input,$n_id);
					$sent_tasks=$dos_details[0]['sent_tasks']+1;
					$input = array(
						'sent_tasks'=>$sent_tasks
					);
					$this->dossiers_model->edit($input,$dos_details[0]['id']);
				}
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[374]['name']);               
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function update_dossiers_pdf_status(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$dossier_key = $data['dossier_key'];
		$cond="select id from dossiers where dossier_key='".$dossier_key."'";
		$dos_details = $this->dossiers_model->special_fetch($cond);
		$id=$dos_details[0]['id'];
		$input = array(
			'pdf_status'=>'completed'
		);
		$this->dossiers_model->edit($input,$id);
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function excuse_dossiers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_excusable,is_excused from dossiers where id=".$id;
			$absence_details = $this->dossiers_model->special_fetch($cond);
			if($absence_details[0]['is_excusable']==1)
			{
				if($absence_details[0]['is_excused']==1)
					$excused=0;
				else
					$excused=1;
				$input = array(
					'is_excused'=>$excused
				);
				$this->dossiers_model->edit($input,$id);
			}	
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[307]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_dossiers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['student_name']==""||$page['reported_by']==""||$page['absence_category']==""||$page['start_date']==""||$page['end_date']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['reported_by'];
				$corrupt_arr[] =$page['absence_category'];
				$corrupt_arr[] =$page['start_date'];
				$corrupt_arr[] =$page['end_date'];
				$corrupt_arr[] =$page['justification'];
				$corrupt_arr[] =$page['excusable'];
				$corrupt_arr[] =$page['excused'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[308]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[309]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['reported_by_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[310]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['absence_category_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[311]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['start_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[312]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if(!$this->validateDate($page['end_date']))
				{
					$error_arr=array();
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['reported_by'];
					$error_arr[] =$page['absence_category'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['justification'];
					$error_arr[] =$page['excusable'];
					$error_arr[] =$page['excused'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[313]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$cond="select id from terms where is_active=1";
					$term_details = $this->dossiers_model->special_fetch($cond);
					$term_id=$term_details[0]['id'];
					$cond="select id from students_terms where student_id=".$page['student_id']." and term_id=".$term_id;
					$student_term_details = $this->dossiers_model->special_fetch($cond);
					$student_term_id=$student_term_details[0]['id'];
					$start_timestamp=strtotime($page['start_date']);
					$end_timestamp=strtotime($page['end_date']);
					$input = array(
						'student_term_id'=>$student_term_id,
						'absence_category_id'=>$page['absence_category_id'],
						'personnel_id'=>$page['student_id'],
						'datetime_from'=>$page['start_date'],
						'datetime_to'=>$page['end_date'],
						'startdate_timestamp'=>$start_timestamp,
						'enddate_timestamp'=>$end_timestamp,
						'justification'=>$page['justification'],
						'is_excusable'=>$page['excusable'],
						'is_excused'=>$page['excused'],
						'is_active'=>$page['status']
					);	
					$this->dossiers_model->add($input);
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[314]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function validateDate($date, $format = 'd/m/Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
	function get_dossiers_type(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from dossier_languages where is_deleted=0 and is_active=1 order by name asc";
		$dossier_language_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','dossier_language_details'=>$dossier_language_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_dossiers_type_global(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$host = $_SERVER['HTTP_HOST'];
		$host = str_replace("www.","",$host);
		$this->load_database("");
		$cond="select * from admin where not FIND_IN_SET('".$host."', domain) and is_active=1";
		$adm_details = $this->users_model->special_fetch($cond);
		
		$dos_lang=array();
		foreach($adm_details as $admin)
		{
			$this->load_database($admin['domain_id']);
			$cond="select id,name from dossier_languages where is_deleted=0 and is_active=1";
			$dossier_language_details = $this->users_model->special_fetch($cond);
			foreach($dossier_language_details as $dos)
			$dos_lang[] = array(
				'id'=>$dos['id'],
				'name'=>$dos['name']
			);
		}
		$dos_lang=$this->duplicate_arr($dos_lang,"name");
		foreach ($dos_lang as $key => $row)
		{
			$wek[$key]= $row['name'];
		}  
		$sort=SORT_ASC;
		array_multisort($wek, $sort, $dos_lang);
		$out = array('statuscode'=>'200','dossier_language_details'=>$dos_lang);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function duplicate_arr($array,$column_name)
    {   
        $duplicateFields = [$column_name => array()];
        foreach ($array as $index => $value) {
                if(in_array($value[$column_name], $duplicateFields[$column_name])){
                        unset($array[$index]);
                }else{
                        array_push($duplicateFields[$column_name], $value[$column_name]);
                }
        }
        return $array;
    }
	function get_curriculum_items(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,title,curriculum_id,subject_id,curriculum_item_cycle_id from curriculum_item where is_deleted=0 and is_active=1 order by title asc";
		$curriculum_item_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','curriculum_item_details'=>$curriculum_item_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }	
	function get_dossier_preview_by_id(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$host = $_SERVER['HTTP_HOST'];
        $host = str_replace("www.","",$host);
        $cond="select * from school where domain like'%".$host."%'";
		$school_details = $this->course_attendants_marks_model->special_fetch($cond);
		$cond="SELECT * FROM dossiers where id=".$id;
		$dossier_details = $this->course_attendants_marks_model->special_fetch($cond);
		if($dossier_details[0]['term_id']!="")
		{
			$cond="select name from terms where id=".$dossier_details[0]['term_id'];
			$comp_details = $this->users_model->special_fetch($cond);
			if(count($comp_details)>0)
				$dossier_details[0]['term']=$comp_details[0]['name'];
			else
				$dossier_details[0]['term']="";
		}
		else
			$dossier_details[0]['term']="";
		if($dossier_details[0]['personnel_id']!="")
		{
			$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$dossier_details[0]['personnel_id'];
			$usr_details = $this->users_model->special_fetch($cond);
			if(count($usr_details)>0)
				$dossier_details[0]['teacher']=$usr_details[0]['name'];
			else
				$dossier_details[0]['teacher']="";
		}
		else
			$dossier_details[0]['teacher']="";
		if($dossier_details[0]['course_id']!="")
		{
			$cond="select name from courses where id=".$dossier_details[0]['course_id'];
			$cor_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)>0)
				$dossier_details[0]['course']=$cor_details[0]['name'];
			else
				$dossier_details[0]['course']="";
		}
		else
			$dossier_details[0]['course']="";
		if($dossier_details[0]['dossier_language_id']!="")
		{
			$cond="select name from dossier_languages where id=".$dossier_details[0]['dossier_language_id'];
			$cor_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)>0)
				$dossier_details[0]['language']=$cor_details[0]['name'];
			else
				$dossier_details[0]['language']="";
		}
		else
			$dossier_details[0]['language']="";
		$cond="select d.id,d.document_name,d.document_unique_name from dossiers_related_files df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_related_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['document_files']=$doc_related_details;
		$cond="select d.id,d.document_name,d.document_unique_name from dossiers_solutions df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_solution_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['solution_files']=$doc_solution_details;
		$cond="select df.mark_category_id,df.keywords,df.description,df.evaluation_date,d.id,d.document_name,d.document_unique_name from dossiers_evaluations df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_solution_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['evaluation_files']=$doc_solution_details;
		$out = array('statuscode'=>'200','dossier_details'=>$dossier_details,'school_details'=>$school_details);             
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
}
