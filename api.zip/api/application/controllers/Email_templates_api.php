<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Email_templates_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=50 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//Personnel Functions
	function view_email_templates(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(e.template_key) like '%".$searchValue."%' or lower(ei.subject) like '%".$searchValue."%' or lower(ei.from) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		if($columnName=="from")
		{
			$columnName = "ei.from";
		}
		$cond="select l.id from languages l,system_settings s where l.locale=s.value and s.key='current-ui-language'";
		$lang_details = $this->users_model->special_fetch($cond);
		$lang_id=$lang_details[0]['id'];
		$cond="select e.template_key,e.keywords,e.is_active,ei.* from email_templates e,email_templates_i18n ei where e.id=ei.email_template_id and e.is_active=1 and ei.language_id=".$lang_id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(e.id) as cnt from email_templates e,email_templates_i18n ei where e.id=ei.email_template_id and e.is_active=1 and ei.language_id=".$lang_id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(e.id) as cnt from email_templates e,email_templates_i18n ei where e.id=ei.email_template_id and e.is_active=1 and ei.language_id=".$lang_id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
    
    function edit_email_templates(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$language_id = $data['language_id'];
		$from_email = $data['from_email'];
		$subject = $data['subject'];
		$content = $data['content'];
		$text_content = $data['text_content'];
		$status = $data['status'];
		$is_translate = $data['is_translate'];
		$id = $data['id'];
		$input = array(
			'is_active'=>$status
		);
		$this->email_templates_model->edit($input,$id);
		if($is_translate=="1")
		{
			$input = array(
				'from'=>$from_email,
				'subject'=>$subject,
				'html_content'=>$content,
				'text_content'=>$text_content
			);
			$this->email_templates_i18n_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[40]['name']);
		header('Content-Type:application/json');
		echo json_encode($out);
    }
	    
   
	function get_languages(){
		$cond="select l.id from languages l,system_settings s where l.locale=s.value and s.key='current-ui-language'";
		$lang_details = $this->users_model->special_fetch($cond);
		$lang_id=$lang_details[0]['id'];
		$cond="select id,name from languages where is_active=1 and is_deleted=0 order by name asc";
		$language_details = $this->users_model->special_fetch($cond);
		$email_details=array();
		foreach($language_details as $lang)
		{
			if($lang_id==$lang['id'])
				$default=1;
			else
				$default=0;
			$email_details[] = array(
				'id'=>$lang['id'],
				'name'=>$lang['name'],
				'default'=>$default
			  );
		}
		$out = array('statuscode'=>'200','language_details'=>$email_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_email_template_by_id(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$email_template_id = $data['email_template_id'];
		$language_id = $data['language_id'];
		$cond="select * from email_templates_i18n where email_template_id=".$email_template_id." and language_id=".$language_id;
		$lang_details = $this->users_model->special_fetch($cond);
		$email_details=array();
		if(count($lang_details)>0)
		{
			$email_details = array(
				'is_translate'=>1,
				'from_email'=>$lang_details[0]['from'],
				'subject'=>$lang_details[0]['subject'],
				'content'=>$lang_details[0]['html_content'],
				'text_content'=>$lang_details[0]['text_content']
			  );
		}
		else
		{
			$email_details = array(
				'is_translate'=>0,
				'from_email'=>"",
				'subject'=>"",
				'content'=>"",
				'text_content'=>""
			);
		}
		$out = array('statuscode'=>'200','email_details'=>$email_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function email_settings(){
		
		$cond="select * from system_settings where id>=3 and id<=9 order by id asc";
		$system_details = $this->users_model->special_fetch($cond);
		$email_settings_details=array();
		if(count($system_details)>0)
		{
			$email_settings_details = array(
				'smtp_settings'=>$system_details[0]['value'],
				'host_name'=>$system_details[1]['value'],
				'username'=>$system_details[2]['value'],
				'password'=>$system_details[3]['value'],
				'port'=>$system_details[4]['value'],
				'encryption'=>$system_details[5]['value'],
				'auth_mode'=>$system_details[6]['value']
			  );
		}
		$out = array('statuscode'=>'200','email_settings_details'=>$email_settings_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function update_email_settings(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$smtp_settings = $data['smtp_settings'];
		$host_name = $data['host_name'];
		$username = $data['username'];
		$password = $data['password'];
		$port = $data['port'];
		$encryption = $data['encryption'];
		$auth_mode = $data['auth_mode'];
		$input = array(
			'value'=>$smtp_settings
		);
		$this->system_settings_model->edit($input,3);
		$input = array(
			'value'=>$host_name
		);
		$this->system_settings_model->edit($input,4);
		$input = array(
			'value'=>$username
		);
		$this->system_settings_model->edit($input,5);
		$input = array(
			'value'=>$password
		);
		$this->system_settings_model->edit($input,6);
		$input = array(
			'value'=>$port
		);
		$this->system_settings_model->edit($input,7);
		$input = array(
			'value'=>$encryption
		);
		$this->system_settings_model->edit($input,8);
		$input = array(
			'value'=>$auth_mode
		);
		$this->system_settings_model->edit($input,9);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[41]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
}
