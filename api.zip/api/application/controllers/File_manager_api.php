<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class File_manager_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=60 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	function view_files(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$folder_id = $data['folder_id'];
		$user_id = $data['user_id'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(document_name) like '%".$searchValue."%' or lower(file_size) like '%".$searchValue."%' or lower(created_at) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		if($folder_id=="")
		{
			$cond="select id from folders where user_id=".$user_id." and default_type=1";
        	$fol_details = $this->users_model->special_fetch($cond);
			$folder_id=$fol_details[0]['id'];
		}
		$cond="select folder,parent_folder,user_id from folders where id=".$folder_id;
		$user_fol_details = $this->users_model->special_fetch($cond);
		if($user_fol_details[0]['user_id']==0)
		{
			$cond="select id,user_id from folders where folder='".$user_fol_details[0]['folder']."' and user_id!=0";
			$par_fol_details = $this->users_model->special_fetch($cond);
			$cond="select id from folders where parent_folder=".$par_fol_details[0]['id']." and user_id=".$par_fol_details[0]['user_id']." and folder='Learning Materials'";
			$final_fol_details = $this->users_model->special_fetch($cond);
			$folder_id=$final_fol_details[0]['id'];
		}
		$cond="select * from documents where folder_id=".$folder_id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from documents where folder_id=".$folder_id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(id) as cnt from documents where folder_id=".$folder_id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_folders(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$folder_id = $data['folder_id'];
		$user_id = $data['user_id'];
		$searchQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(folder) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "id";
			$columnSortOrder = "desc";
		}
		if($folder_id=="")
		{
			$cond="select id from folders where user_id=".$user_id." and default_type=1";
        	$fol_details = $this->users_model->special_fetch($cond);
			$folder_id=$fol_details[0]['id'];
		}
		$cond="select folder,user_id from folders where id=".$folder_id;
		$pub_fol_details = $this->users_model->special_fetch($cond);
		$fol_user_id="";
		$folder_name="";$page_details=array();
		if(count($pub_fol_details)>0)
		{
			$folder_name=$pub_fol_details[0]['folder'];
			$fol_user_id=$pub_fol_details[0]['user_id'];
		}
		$totalRecord=0;$totalRecordwithFilter=0;
		if($folder_name!="Public")
		{
			if($folder_id==2)
				$cond="select * from folders where parent_folder=".$folder_id." and (user_id=".$user_id." or folder='Shared') and folder<>'Public' and folder<>'Duplicate' and folder<>'Lessons'".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
			else
			{
				if($fol_user_id==-1)
					$cond="select * from folders where parent_folder=".$folder_id." and user_id=-1".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
				else
					$cond="select * from folders where parent_folder=".$folder_id." and (user_id=".$user_id." or folder='Shared')".$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
			}
			$page_details = $this->users_model->special_fetch($cond);
			$cond="select COUNT(id) as cnt from folders where parent_folder=".$folder_id." and user_id=".$user_id;
			$maps_count = $this->users_model->special_fetch($cond);
			$totalRecord = $maps_count[0]['cnt'];
			$totalRecordwithFilter = $totalRecord;
			if($searchQuery != ''){
				$cond="select COUNT(id) as cnt from folders where parent_folder=".$folder_id." and user_id=".$user_id.$searchQuery;
				$maps_count = $this->users_model->special_fetch($cond);
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			}
		}
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function add_new_folder(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$folder_id = $data['folder_id'];
		$folder_name = $data['folder_name'];
		$old_folder_name = $data['old_folder_name'];
		$user_id = $data['user_id'];
		$fl_name=strtolower($folder_name);
		$cond="select concat(first_name,' ',last_name) as name from users where id=".$user_id;
		$usr_details = $this->users_model->special_fetch($cond);
		$user_folder_name=strtolower($usr_details[0]['name']);
		if($old_folder_name!="")
		{
			if($folder_id=="#")
			{
				$out = array('statuscode'=>'201');
			}
			else
			{

				if($fl_name==$user_folder_name||$fl_name=='common'||$fl_name=='documents'||$fl_name=='shared')
				{
					$err_msg=$folder_name." is Reserved Folder Name - Cannot Rename Folder";
					$out = array('statuscode'=>'201','statusdescription'=>$err_msg);
				}
				else
				{
					$cond="select user_id from folders where id=".$folder_id;
					$par_folder_details = $this->users_model->special_fetch($cond);
					if(count($par_folder_details)>0)
					{
						if($par_folder_details[0]['user_id']==-1)
							$cond="select id from folders where parent_folder=".$folder_id." and folder='".$old_folder_name."' and user_id=-1";
						else
							$cond="select id from folders where parent_folder=".$folder_id." and folder='".$old_folder_name."' and user_id=".$user_id;
						$old_fol_details = $this->users_model->special_fetch($cond);
						if(count($old_fol_details)>0)
						{
							$old_id=$old_fol_details[0]['id'];
							$input = array(
								'folder'=>$folder_name
							);
							$mid = $this->folder_manager_model->edit($input,$old_id);
						}
						$out = array('statuscode'=>'200');
					}
					else
					{
						$out = array('statuscode'=>'201','statusdescription'=>"Unable To Find Parent Folder - Cannot Create Folder");
					}
				}
			}
		}
		else
		{
			
			if($fl_name==$user_folder_name||$fl_name=='common'||$fl_name=='documents'||$fl_name=='shared')
			{
				$err_msg=$folder_name." is Reserved Folder Name - Permission Denied To Create New Folder";
				$out = array('statuscode'=>'201','statusdescription'=>$err_msg);
			}
			else
			{
				$cond="select folder,user_id from folders where id=".$folder_id;
				$par_folder_details = $this->users_model->special_fetch($cond);
				if(count($par_folder_details)>0)
				{
					if($par_folder_details[0]['user_id']==-1)
						$cond="select id from folders where parent_folder=".$folder_id." and folder='".$folder_name."' and user_id=-1";
					else
						$cond="select id from folders where parent_folder=".$folder_id." and folder='".$folder_name."' and user_id=".$user_id;
					$fol_details = $this->users_model->special_fetch($cond);
					if(count($fol_details)<=0)
					{
						if($par_folder_details[0]['user_id']==-1)
						{
							$input = array(
								'folder'=>$folder_name,
								'parent_folder'=>$folder_id,
								'user_id'=>-1
							);
						}
						else
						{
							$input = array(
								'folder'=>$folder_name,
								'parent_folder'=>$folder_id,
								'user_id'=>$user_id
							);
						}
						$mid = $this->folder_manager_model->add($input);
						if($mid){				
							$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[75]['name']);
						}
						else{
							$out = array('statuscode'=>'201','statusdescription'=>" ".$label_details[76]['name']);
						}
					}  
					else
					{
						$out = array('statuscode'=>'201','statusdescription'=>" ".$label_details[77]['name']);
					}
				}
				else
					$out = array('statuscode'=>'201','statusdescription'=>"Unable To Find Parent Folder - Cannot Create Folder");
			}
		}    
		header('Content-Type:application/json');
		echo json_encode($out);    
    }
	function delete_folder(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$folder_arr=explode(",",$ids);
		$flag=false;
		foreach($folder_arr as $folder_id)
		{
			$cond="select is_deleted from folders where id=".$folder_id;
			$fol_details = $this->users_model->special_fetch($cond);
			$is_deleted=$fol_details[0]['is_deleted'];
			if($is_deleted==0)
			{
				$this->folder_manager_model->delete($folder_id);				
				$flag=true;
			}
		}
		if($flag)
		{
			$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[78]['name']);
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>" ".$label_details[79]['name']);
		}
		header('Content-Type:application/json');
		echo json_encode($out);
    }
	function move_to_folder(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$user_id = $data['user_id'];
		$parent = $data['parent'];
		$folder_arr=explode(",",$ids);
		$flag=false;$move_flag=false;
		foreach($folder_arr as $folder_id)
		{
			$cond="select is_deleted,folder,user_id from folders where id=".$folder_id;
			$fol_details = $this->users_model->special_fetch($cond);
			$is_deleted=$fol_details[0]['is_deleted'];
			if($is_deleted==0)
			{
				$cond="select id from folders where parent_folder=".$parent." and folder='".$fol_details[0]['folder']."'";
				$old_fol_details = $this->users_model->special_fetch($cond);
				if(count($old_fol_details)<=0)
				{
					$cond="select user_id from folders where id=".$parent;
					$pr_fol_details = $this->users_model->special_fetch($cond);
					if($fol_details[0]['user_id']==-1)
					{	
						if($pr_fol_details[0]['user_id']==-1)
						{
							$input = array(
								'parent_folder'=>$parent
							);
						}
						else
						{
							$input = array(
								'parent_folder'=>$parent,
								'user_id'=>$user_id
							);
						}
					}
					else
					{
						if($pr_fol_details[0]['user_id']==-1)
						{
							$input = array(
								'parent_folder'=>$parent,
								'user_id'=>-1
							);
						}
						else
						{
							$input = array(
								'parent_folder'=>$parent
							);
						}
					}
					$this->folder_manager_model->edit($input,$folder_id);
					$move_flag=true;
				}
				$flag=true;
			}
		}
		if($flag)
		{
			if($move_flag)
				$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[80]['name']);
			else
				$out = array('statuscode'=>'201','statusdescription'=>" Unable To Move - Folder Already Exists");
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>" ".$label_details[81]['name']);
		}
		header('Content-Type:application/json');
		echo json_encode($out);
    }
	function copy_to_folder(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$parent = $data['parent'];
		$user_id = $data['user_id'];
		$folder_arr=explode(",",$ids);
		$flag=false;$move_flag=false;
		foreach($folder_arr as $folder_id)
		{
			$cond="select folder,is_deleted from folders where id=".$folder_id;
			$file_details = $this->users_model->special_fetch($cond);
			if(count($file_details)>0)
			{
				if($file_details[0]['is_deleted']==0)
				{
					$cond="select id from folders where parent_folder=".$parent." and folder='".$file_details[0]['folder']."'";
					$old_fol_details = $this->users_model->special_fetch($cond);
					if(count($old_fol_details)<=0)
					{
						$cond="select user_id from folders where id=".$parent;
						$par_details = $this->users_model->special_fetch($cond);
						if($par_details[0]['user_id']==-1)
						{
							$input = array(
								'folder'=>$file_details[0]['folder'],
								'parent_folder'=>$parent,
								'user_id'=>-1
							);
						}
						else
						{
							$input = array(
								'folder'=>$file_details[0]['folder'],
								'parent_folder'=>$parent,
								'user_id'=>$user_id
							);
						}
						$id=$this->folder_manager_model->add($input);
						$cond="select * from documents where folder_id=".$folder_id;
						$file_details = $this->users_model->special_fetch($cond);
						foreach($file_details as $file)
						{
							$input = array(
								'folder_id'=>$id,
								'document_name'=>$file['document_name'],
								'document_unique_name'=>$file['document_unique_name'],
								'file_size'=>$file['file_size'],
								'file_permissions'=>$file['file_permissions'],
								'created_at'=>time()
							);
							$this->file_manager_model->add($input);
						}
						$move_flag=true;
					}
				}
				else
					$flag=true;
			}
		}
		if($flag)
		{
			$out = array('statuscode'=>'201','statusdescription'=>" Permission To Copy Folders Denied");
		}
		else
		{
			if($move_flag)
				$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[82]['name']);
			else
				$out = array('statuscode'=>'201','statusdescription'=>" Unable To Copy - Folder Already Exists");
		}
		header('Content-Type:application/json');
		echo json_encode($out);
    }
	function rename_folder(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$user_id = $data['user_id'];
		$folder_name = $data['folder_name'];
		$cond="select is_deleted,user_id,parent_folder from folders where id=".$id;
		$fol_details = $this->users_model->special_fetch($cond);
		$is_deleted=$fol_details[0]['is_deleted'];
		$fol_user_id=$fol_details[0]['user_id'];
		if($is_deleted==0)
		{
			$cond="select concat(first_name,' ',last_name) as name from users where id=".$user_id;
			$usr_details = $this->users_model->special_fetch($cond);
			$user_folder_name=strtolower($usr_details[0]['name']);
			$fl_name=strtolower($folder_name);
			if($fl_name==$user_folder_name||$fl_name=='common'||$fl_name=='documents'||$fl_name=='shared')
			{
				$err_msg=$folder_name." is Reserved Folder Name - Cannot Rename Folder";
				$out = array('statuscode'=>'201','statusdescription'=>$err_msg);
			}
			else
			{
				$cond="select id from folders where parent_folder=".$fol_details[0]['parent_folder']." and folder='".$folder_name."' and id<>".$id;
				$old_fol_details = $this->users_model->special_fetch($cond);
				if(count($old_fol_details)<=0)
				{	
					$input = array(
						'folder'=>$folder_name
					);
					$this->folder_manager_model->edit($input,$id);
					$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[83]['name']);  
				}
				else
					$out = array('statuscode'=>'201','statusdescription'=>" Folder Already Exists");
			}
		}
		else
			$out = array('statuscode'=>'201','statusdescription'=>" ".$label_details[49]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function move_or_copy_folder(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$parent = $data['parent'];
		$mode = $data['mode'];
		$user_id = $data['user_id'];
		$folder_id = $data['folder_id'];
		$folder_name = $data['folder_name'];
		$cond="select is_deleted from folders where id=".$folder_id;
		$fol_details = $this->users_model->special_fetch($cond);
		$is_deleted=$fol_details[0]['is_deleted'];
		if($is_deleted==0)
		{
			if($mode=="move_node")
			{	
				$input = array(
					'parent_folder'=>$parent
				);
				$this->folder_manager_model->edit($input,$folder_id);
			}
			else if($mode=="copy_node")
			{	
				$input = array(
					'folder'=>$folder_name,
					'parent_folder'=>$parent,
					'user_id'=>$user_id
				);
				$id=$this->folder_manager_model->add($input);
				$cond="select * from documents where folder_id=".$folder_id;
				$file_details = $this->users_model->special_fetch($cond);
				foreach($file_details as $file)
				{
					$input = array(
						'folder_id'=>$id,
						'document_name'=>$file['document_name'],
						'document_unique_name'=>$file['document_unique_name'],
						'file_size'=>$file['file_size'],
						'file_permissions'=>$file['file_permissions'],
						'created_at'=>time()
					);
					$this->file_manager_model->add($input);
				}
			}  
			$out = array('statuscode'=>'200');  
		}
		else
		{
			$out = array('statuscode'=>'201'); 
		}
		header('Content-Type:application/json');
		echo json_encode($out);    
    }
	function get_file_size()
	{
		$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/user_files/1642702760038_1641651184202.JPEG";
		//$file_path = __DIR__ . '\assets\uploads\1642702760038_1641651184202.JPEG';
    	echo $size=filesize($file_path);
	}
	function add_files(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$folder_id = $data['folder_id'];
		$material_original_name=explode(",",$data['material_original_name']);
		$material_unique_name=explode(",",$data['material_unique_name']);
		for($i=0;$i<count($material_original_name);$i++)
		{
			$file = 'assets/uploads/user_files/'.$material_unique_name[$i];
			$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/user_files/".$material_unique_name[$i];
			$file_size=filesize($file_path);
			$file_size_text=$this->formatSizeUnits($file_size);
			$arr2 = array(
							'folder_id' => $folder_id,			
							'document_name' => $material_original_name[$i],
							'document_unique_name' => $material_unique_name[$i],
                            'file_size' => $file_size_text,
							'created_at' => time()
							 );		
			$this->file_manager_model->add($arr2);
		}
		$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[84]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}
	function delete_files(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select document_unique_name from documents where id=".$id;
        	$file_details = $this->users_model->special_fetch($cond);
			$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/user_files/".$file_details[0]['document_unique_name'];
			$this->file_manager_model->delete($id);
			if(file_exists($file_path)) 
			{
				unlink($file_path);
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[85]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function move_to_folder_files(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$selected_folder_id = $data['selected_folder_id'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'folder_id'=>$selected_folder_id,
				'created_at'=>time()
			);
			$this->file_manager_model->edit($input,$id);	
		}
		$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[86]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function rename_files(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$file_name = $data['file_name'];
		$cond="select document_name from documents where id=".$id;
		$file_details = $this->users_model->special_fetch($cond);
		$org_file_name=$file_details[0]['document_name'];
		$extension = pathinfo($org_file_name, PATHINFO_EXTENSION);
		$file_name=$file_name.".".$extension;
		$input = array(
			'document_name'=>$file_name,
			'created_at'=>time()
		);
		$this->file_manager_model->edit($input,$id);
		$out = array('statuscode'=>'200','statusdescription'=>" ".$label_details[87]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
