<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Labels_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	 
	//Career Goals
	function view_labels(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$page_fld = $data['page_fld'];
		$section_fld = $data['section_fld'];
		$lang_fld = $data['lang_fld'];				
		$searchQuery = "";
		if($page_fld==''||$section_fld==''||$lang_fld=='')
		{
			$page_details=array();$totalRecord=0;$totalRecordwithFilter=0;
		}
		else
		{
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				$searchQuery = " and (lower(l.name) like '%".$searchValue."%' or lower(l.type) like '%".$searchValue."%' or lower(l.order_no) like '%".$searchValue."%' or lower(i.page_name) like '%".$searchValue."%' or lower(s.section) like '%".$searchValue."%')";
			}
			$cond="select l.*,i.page_name,s.section from labels l,inner_pages i,sections s where l.page_id=i.id and l.section_id=s.id and page_id=".$page_fld." and section_id=".$section_fld." and lang_id=".$lang_fld.$searchQuery." order by order_no asc limit ".$start.",".$rowperpage;
			$page_details = $this->users_model->special_fetch($cond);
			$cond="select COUNT(id) as cnt from labels where page_id=".$page_fld." and section_id=".$section_fld." and lang_id=".$lang_fld;
			$maps_count = $this->users_model->special_fetch($cond);
			$totalRecord = $maps_count[0]['cnt'];
			$totalRecordwithFilter = $totalRecord;
			if($searchQuery != ''){
				$cond="select COUNT(l.id) as cnt from labels l,inner_pages i,sections s where l.page_id=i.id and l.section_id=s.id and page_id=".$page_fld." and section_id=".$section_fld." and lang_id=".$lang_fld.$searchQuery;
				$maps_count = $this->users_model->special_fetch($cond);
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			}
			$cond="select group_concat(id) as id from labels where page_id=".$page_fld." and lang_id=".$lang_fld;
			$pg_details = $this->users_model->special_fetch($cond);
			$id_arr=explode(",",$pg_details[0]['id']);
			$i=0;
			foreach($page_details as $page)
			{
				$index = array_search($page['id'], $id_arr);
				$page_details[$i]['index']=$index;
				$i++;
			}
			if($totalRecord=="")
				$totalRecord=0;
			if($totalRecordwithFilter=="")
				$totalRecordwithFilter=0;
			if(count($page_details)<=0)
				$page_details=array();
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_labels(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$name = $data['name'];
		$type = $data['type'];
		$order_no = $data['order_no'];
		$page_id = $data['page_id'];
		$section_id = $data['section_id'];
		$cond="select count(id) as label_id from labels where page_id=".$page_id." and lang_id=1";
        $lbl_details = $this->users_model->special_fetch($cond);
		$label_id=$lbl_details[0]['label_id'];
		$input = array(
			'name'=>$name,
			'type'=>$type,
			'order_no'=>$order_no,
			'page_id'=>$page_id,
			'label_id'=>$label_id,
			'lang_id'=>1,
			'status'=>0,
			'section_id'=>$section_id
		);
		$this->labels_model->add($input);
		$cond="select id,code from languages where id<>1 and is_deleted=0";
        $lang_details = $this->users_model->special_fetch($cond);
		foreach($lang_details as $lang)
		{
			$lang_type='';
			$name=$this->translate_lang($lang['code'],$name);
			if($type!='')
				$lang_type=$this->translate_lang($lang['code'],$type);
			$input = array(
				'page_id'=>$page_id,
				'label_id'=>$label_id,
				'section_id'=>$section_id,
				'name'=>$name,
				'type'=>$lang_type,
				'order_no'=>$order_no,
				'status'=>0,
				'lang_id'=>$lang['id']
			);
			$this->labels_model->add($input);
		} 
		$out = array('statuscode'=>'200','statusdescription'=>' Label Added Successfully');
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function convert_lang()
	{
		$cond="select * from labels where lang_id=1";
        $lang_details = $this->users_model->special_fetch($cond);
		foreach($lang_details as $lang)
		{
			$lang_type='';
			$name=$this->translate_lang('tl',$lang['name']);
			if($lang['type']!='')
				$lang_type=$this->translate_lang('tl',$lang['type']);
			$input = array(
				'page_id'=>$lang['page_id'],
				'section_id'=>$lang['section_id'],
				'name'=>$name,
				'type'=>$lang_type,
				'order_no'=>$lang['order_no'],
				'status'=>$lang['status'],
				'lang_id'=>3
			);
			$this->labels_model->add($input);
		} 
	}
    function edit_labels(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$name = $data['name'];
		$type = $data['type'];
		$order_no = $data['order_no'];
		$page_id = $data['page_id'];
		$section_id = $data['section_id'];
		$id = $data['id'];
		$input = array(
			'name'=>$name,
			'type'=>$type,
			'order_no'=>$order_no,
			'section_id'=>$section_id
		);
		$this->labels_model->edit($input,$id);
		$out = array('statuscode'=>'200','statusdescription'=>' Label Updated Successfully');
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function set_status_labels(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select status from labels where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['status']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'status'=>$status
			);
			$this->labels_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>'Label Status Changed Successfully');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_pages(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,page_name as name from inner_pages";
		$page_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','page_details'=>$page_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_sections(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,section as name from sections";
		$section_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','section_details'=>$section_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_labels_language(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from languages where is_deleted=0";
		$language_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','language_details'=>$language_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_host()
	{
		$host = $_SERVER['HTTP_HOST'];
		echo $host = str_replace("www.","",$host);
	}
	function get_trans(){
		echo $this->tran("de","Hello");
		
	}
	function tran($code,$text)
	{
		$url = 'https://www.googleapis.com/language/translate/v2?key='. APIKEY.'&q='.rawurlencode($text).'&source=en&target='.$code;
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($handle); 
		$responseDecoded = json_decode($response, true);
		curl_close($handle);
        if (array_key_exists("error",$responseDecoded))
        {
            echo "Language Code Error!";
        }
        else
        {
		    $res_text=$responseDecoded['data']['translations'][0]['translatedText'];
		    return $res_text;
        }
	}
    function convert_labels()
    {
        $page_id = $this->input->post('page_id');
        $lang_id = $this->input->post('lang_id');
		$cond="select * from labels where page_id=".$page_id." and lang_id=1";
        $pg_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($pg_details);$i++)
        {
            $label_id=$i;
			$label_name=$pg_details[$i]['name'];
			$label_type=$pg_details[$i]['type'];
			$input = array(
				'label_id'=>$label_id
			);
			$this->labels_model->edit($input,$pg_details[$i]['id']);
            $lbl_trans_name=$this->tran("de",$label_name);
			$lbl_trans_type=$this->tran("de",$label_type);
			$input = array(
				'page_id'=>$pg_details[$i]['page_id'],
				'section_id'=>$pg_details[$i]['section_id'],
				'name'=>$lbl_trans_name,
				'type'=>$lbl_trans_type,
				'order_no'=>$pg_details[$i]['order_no'],
				'status'=>$pg_details[$i]['status'],
				'lang_id'=>$lang_id,
				'label_id'=>$label_id
			);
			$this->labels_model->add($input);
        }
		echo "Done";
    }  
	function convert_task_labels()
    {
        $cond="select * from labels where id>=220091";
        $pg_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($pg_details);$i++)
        {
            $label_id=$pg_details[$i]['label_id'];
			$label_name=$pg_details[$i]['name'];
			$label_type=$pg_details[$i]['type'];
			$lbl_trans_name=$this->tran("de",$label_name);
			$lbl_trans_type=$this->tran("de",$label_type);
			$input = array(
				'page_id'=>$pg_details[$i]['page_id'],
				'section_id'=>$pg_details[$i]['section_id'],
				'name'=>$lbl_trans_name,
				'type'=>$lbl_trans_type,
				'order_no'=>$pg_details[$i]['order_no'],
				'status'=>$pg_details[$i]['status'],
				'lang_id'=>2,
				'label_id'=>$label_id
			);
			$this->labels_model->add($input);
        }
		echo "Done";
    } 
	function convert_only_labels()
    {
        $page_id = $this->input->post('page_id');
        $cond="select * from labels where page_id=".$page_id." and lang_id=1";
        $pg_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($pg_details);$i++)
        {
            $label_id=$i;
			$input = array(
				'label_id'=>$label_id
			);
			$this->labels_model->edit($input,$pg_details[$i]['id']);           
        }
		echo "Done";
    } 
	function update_date()
    {
        $cond="select created_at,start_date,id from dossiers";
        $pg_details = $this->users_model->special_fetch($cond);	
		for($i=0;$i<count($pg_details);$i++)
        {
            if($pg_details[$i]['created_at']=='')
			{
				$timestamp = strtotime($pg_details[$i]['start_date']);
				$input = array(
					'created_at'=>$timestamp
				);
				$this->dossiers_model->edit($input,$pg_details[$i]['id']); 
			}
        }
		echo "Done";
    } 
	function update_roles()
	{
		$j=1;
		for($i=344;$i<=686;$i++)
		{
			$input = array(
				'label_id'=>$j
			);
			$this->roles_model->edit($input,$i);
			$j++;
		}
		echo "Done";
	}

}
