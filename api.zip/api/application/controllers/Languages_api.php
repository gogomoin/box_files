<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Languages_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=52 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//Career Goals
	function view_languages(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and lower(name) like '%".$searchValue."%'";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from languages where 1".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from languages where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from languages where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_languages(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$code = $data['code'];
		$locale = $data['locale'];
		$status = $data['status'];
		$cond="select id from languages";
		$lang_count = $this->users_model->special_fetch($cond);
		if(count($lang_count)<2)
		{
			$data_arr=array(
					'name'=>$name,
					'is_deleted'=>0
				);
			$languages_details = $this->languages_model->get_records($data_arr);
			$mid="";
			if(count($languages_details)<=0)
			{
				$valid=$this->translate_lang($code,'Hello');
				if($valid!='')
				{
					$input = array(
						'name'=>$name,
						'code'=>$code,
						'locale'=>$locale,
						'is_active'=>$status,
						'created_at'=>time()
					);
					$mid = $this->languages_model->add($input);
					if($mid)
					{
						$out = array('statuscode'=>'200','statusdescription'=>$label_details[55]['name']);
					}
					else{
						$mid="";
						$out = array('statuscode'=>'201','statusdescription'=>$label_details[56]['name']);
					}
				}
				else
				{
					$mid="";
					$out = array('statuscode'=>'201','statusdescription'=>'Invalid Language Code');
				}
			}  
			else
			{
				$mid="";
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[57]['name']);
			}
			header('Content-Type:application/json');
			set_time_limit(0);
			ob_end_clean();
			header("Connection: close");
			ob_start();
			echo json_encode($out);
			$size = ob_get_length();
			header("Content-Length: $size");
			ob_end_flush(); // Strange behaviour, will not work
			flush();            // Unless both are called !
			session_write_close();  
			//if($mid!="") 
				//$this->upload_labels($code,$mid); 
		}
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>'Maximum 2 Languages Allowed - Please Contact Administrator For More Lanaguages');
			header('Content-Type:application/json');
        	echo json_encode($out);
		}
		  
    }
	function upload_labels()
	{
		$cond="select * from labels where lang_id=1 and page_id=46 and section_id<>27 order by id asc";
        $lang_details = $this->users_model->special_fetch($cond);
		foreach($lang_details as $lang)
		{
			$type="";
			if($lang['name']!="")
			{
				$name=$this->translate_lang("tl",$lang['name']);
				if($lang['type']!='')
					$type=$this->translate_lang("tl",$lang['type']);
				$input = array(
					'page_id'=>$lang['page_id'],
					'section_id'=>$lang['section_id'],
					'name'=>$name,
					'type'=>$type,
					'order_no'=>$lang['order_no'],
					'status'=>0,
					'lang_id'=>2
				);
				$this->labels_model->add($input);
			}
			usleep( 5 * 1000 );
		} 
		echo "Done";
	}
	function upload_roles()
	{
		$cond="select * from roles where lang_id=1 order by id asc";
        $lang_details = $this->users_model->special_fetch($cond);
		$name="";
		foreach($lang_details as $lang)
		{
			if($lang['role']!="")
			{
				$name=$this->translate_lang("tl",$lang['role']);
				$input = array(
					'page_id'=>$lang['page_id'],
					'role'=>$name,
					'lang_id'=>2
				);
				$this->db->insert('roles',$input);
			}
			usleep( 5 * 1000 );
		} 
		echo "Done";
	}
	function upload_modules()
	{
		$cond="select * from modules where lang_id=1 order by page_id asc";
        $mod_details = $this->users_model->special_fetch($cond);
		foreach($mod_details as $mod)
		{
			if($mod['module']!="")
			{
				$module=$this->translate_lang("tl",$mod['module']);
				$input = array(
					'page_id'=>$mod['page_id'],
					'module'=>$module,
					'lang_id'=>2
				);
				$this->db->insert('modules',$input);
			}
			usleep( 5 * 1000 );
		} 
		echo "Done";
	}
	function upload_language()
	{
		$cond="select * from paginate_numbers where lang_id=1 order by id asc";
        $mod_details = $this->users_model->special_fetch($cond);
		foreach($mod_details as $mod)
		{
			if($mod['number']!="")
			{
				$module=$this->translate_lang("tl",$mod['number']);
				$input = array(
					'page_id'=>1,
					'number'=>$module,
					'lang_id'=>2
				);
				$this->db->insert('paginate_numbers',$input);
			}
			usleep( 5 * 1000 );
		} 
		echo "Done";
	}
    
    function edit_languages(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$name = $data['name'];
		$code = $data['code'];
		$locale = $data['locale'];
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from languages where name='".$name."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'code'=>$code,
				'locale'=>$locale,
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$mid = $this->languages_model->edit($input,$id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[58]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[59]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[60]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_languages(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select name from languages where id=".$id;
			$lang_details = $this->languages_model->special_fetch($cond);
			$name=$lang_details[0]['name'];
			$cond="select id from email_templates_i18n where language_id=".$id;
			$et_details = $this->languages_model->special_fetch($cond);
			$cond="select translation_id from translations_i18n where language_id=".$id;
			$tr_details = $this->languages_model->special_fetch($cond);
			if(count($et_details)<=0&&count($tr_details)<=0)
			{	
				$input = array(
					'is_deleted'=>1
				);
				$this->languages_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[61]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[62]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_languages(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->languages_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[63]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_languages(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from languages where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->languages_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[64]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
