<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Lesson_numbers_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=17 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    } 
	//Career Goals
	function view_lesson_numbers(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(lesson_number) like '%".$searchValue."%' or lower(time_from) like '%".$searchValue."%' or lower(time_to) like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from lesson_numbers where 1".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from lesson_numbers where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from lesson_numbers where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_lesson_numbers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$lesson_number = $data['lesson_number'];
		$time_from = $data['time_from'];
		$time_to = $data['time_to'];
		$status = $data['status'];
		$cond="select id from lesson_numbers where lesson_number=".$lesson_number." and is_deleted=0";
		$lesson_numbers_details = $this->users_model->special_fetch($cond);
		if(count($lesson_numbers_details)<=0)
		{
			$cond="select * from lesson_numbers where is_deleted=0";
			$lesson_num_details = $this->users_model->special_fetch($cond);
			$flag=true;
			foreach($lesson_num_details as $les)
			{
				if($this->compare_time($time_from,$time_to,$les['time_from'],$les['time_to']))
				{
					$flag=false;
					break;
				}
			}
			if($flag)
			{
	
				$input = array(
					'lesson_number'=>$lesson_number,
					'time_from'=>$time_from,
					'time_to'=>$time_to,
					'is_active'=>$status,
					'created_at'=>time()
				);
				$mid = $this->lesson_numbers_model->add($input);
				if($mid){				
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[103]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[104]['name']);
				}
			}
			else
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[129]['name']);
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[105]['name']);
		}
		
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_lesson_numbers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$lesson_number = $data['lesson_number'];
		$time_from = $data['time_from'];
		$time_to = $data['time_to'];
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from lesson_numbers where lesson_number='".$lesson_number."' and is_deleted=0 and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$cond="select * from lesson_numbers where is_deleted=0 and id<>".$id;
			$lesson_num_details = $this->users_model->special_fetch($cond);
			$flag=true;
			foreach($lesson_num_details as $les)
			{
				if($this->compare_time($time_from,$time_to,$les['time_from'],$les['time_to']))
				{
					$flag=false;
					break;
				}
			}
			if($flag)
			{
				$input = array(
					'lesson_number'=>$lesson_number,
					'time_from'=>$time_from,
					'time_to'=>$time_to,
					'is_active'=>$status,
					'updated_at'=>time()
				);
				$mid = $this->lesson_numbers_model->edit($input,$id);
				if($mid){
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[106]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[107]['name']);
				} 
			}
			else
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[139]['name']);
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[140]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_lesson_numbers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{	
			$cond="select lesson_number from lesson_numbers where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['lesson_number'];
			$cond="select id from timetable	where lesson_number_id=".$id;
			$ab_details = $this->subject_types_model->special_fetch($cond);
			if(count($ab_details)<=0)
			{
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->lesson_numbers_model->edit($input,$id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[109]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[59]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_lesson_numbers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->lesson_numbers_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[110]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_lesson_numbers(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from lesson_numbers where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->lesson_numbers_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[111]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
    function import_lesson_numbers(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['lesson_number']==""||$page['time_from']==""||$page['time_to']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['lesson_number'];
				$corrupt_arr[] =$page['time_from'];
				$corrupt_arr[] =$page['time_to'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[112]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if (ctype_digit($page['lesson_number'])) 
				{
					$cond="select id from lesson_numbers where lesson_number=".$page['lesson_number'];
					$pg_details = $this->users_model->special_fetch($cond);
					if(count($pg_details)>0)
					{
						$error_arr=array();
						$error_arr[] =$page['lesson_number'];
						$error_arr[] =$page['time_from'];
						$error_arr[] =$page['time_to'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[113]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						
							$input = array(
								'lesson_number'=>$page['lesson_number'],
								'time_from'=>$page['time_from'],
								'time_to'=>$page['time_to'],
								'is_active'=>$page['status_val'],
								'created_at'=>time()
							);
							$this->lesson_numbers_model->add($input);
							$flag=true;
					}
				}
				else
				{
					$error_arr=array();
					$error_arr[] =$page['lesson_number'];
					$error_arr[] =$page['time_from'];
					$error_arr[] =$page['time_to'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[141]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[114]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function compare_time($current_start_time,$current_end_time,$start_time,$end_time)
    {
        $date = date('d-m-Y');
		$cur_start_date=$date.' '.$current_start_time;
		$current_start_time=strtotime($cur_start_date);
		$cur_end_date=$date.' '.$current_end_time;
		$current_end_time=strtotime($cur_end_date);
		$start_date=$date.' '.$start_time;
		$start_time=strtotime($start_date);
		$end_date=$date.' '.$end_time;
		$end_time=strtotime($end_date);
        if (($current_start_time < $start_time && $current_end_time <= $start_time)||($current_start_time >= $end_time && $current_end_time > $end_time))
            return false;
        else
            return true;
    }
	function compare_test_time()
    {
		$current_start_time='14:00';$current_end_time='14:20';$start_time='13:00';$end_time='14:00';
		$date = date('d-m-Y');
		$cur_start_date=$date.' '.$current_start_time;
		$current_start_time=strtotime($cur_start_date);
		$cur_end_date=$date.' '.$current_end_time;
		$current_end_time=strtotime($cur_end_date);
		$start_date=$date.' '.$start_time;
		$start_time=strtotime($start_date);
		$end_date=$date.' '.$end_time;
		$end_time=strtotime($end_date);
		//echo $current_start_time;
		if (($current_start_time < $start_time && $current_end_time <= $start_time)||($current_start_time >= $end_time && $current_end_time > $end_time))
            echo 'false';
        else
			echo 'true';
    }
}
