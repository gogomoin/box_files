<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Mark_categories_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=19 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    } 
	//Mark Categories
	function view_mark_categories(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$default_fld = $data['default_fld'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and lower(name) like '%".$searchValue."%'";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($default_fld != ''&&$default_fld != 'all'){
			$searchQuery .= " and is_default=".$default_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from mark_categories where 1".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from mark_categories where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from mark_categories where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_mark_categories(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$factor = $data['factor'];
		$status = $data['status'];
		$default = $data['default'];
		$data_arr=array(
				'name'=>$name
			);
        $mark_categories_details = $this->mark_categories_model->get_records($data_arr);
		if(count($mark_categories_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'factor'=>$factor,
				'is_active'=>$status,
				'is_default'=>$default,
				'created_at'=>time()
			);
			$mid = $this->mark_categories_model->add($input);
			if($mid){				
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[109]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[110]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[111]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_mark_categories(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$factor = $data['factor'];
		$status = $data['status'];
		$default = $data['default'];
		$id = $data['id'];
		$cond="select id from mark_categories where name='".$name."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'factor'=>$factor,
				'is_active'=>$status,
				'is_default'=>$default,
				'updated_at'=>time()
			);
			$mid = $this->mark_categories_model->edit($input,$id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[112]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[113]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[114]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_mark_categories(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select name from mark_categories where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from course_attendants_marks where mark_category_id=".$id;
			$ab_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from dossiers_evaluations where mark_category_id=".$id;
			$dos_details = $this->subject_types_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($dos_details)<=0)
			{
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->marks_model->edit($input,$id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->mark_categories_model->edit($input,$id);			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[115]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[59]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);             
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_mark_categories(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{	
			$input = array(
				'is_deleted'=>0
			);
			$this->mark_categories_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[116]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_mark_categories(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from mark_categories where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->mark_categories_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[117]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_default_mark_categories(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_default from mark_categories where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_default']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_default'=>$status,
				'updated_at'=>time()
			);
			$this->mark_categories_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[118]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function import_mark_categories(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']==""||$page['factor']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['factor'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$page['default'];
				$corrupt_arr[] =$label_details[119]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from mark_categories where name='".$page['name']."'";
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['name'];
					$error_arr[] =$page['factor'];
					$error_arr[] =$page['status'];
					$error_arr[] =$page['default'];
					$error_arr[] =$label_details[120]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$numberRegex = '/^-?\d+(\.\d+)?$/';
					if (!preg_match($numberRegex, $page['factor'])) 
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['factor'];
						$error_arr[] =$page['status'];
						$error_arr[] =$page['default'];
						$error_arr[] =$label_details[148]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						$input = array(
							'name'=>$page['name'],
							'factor'=>$page['factor'],
							'is_active'=>$page['status_val'],
							'is_default'=>$page['default_val'],
							'created_at'=>time()
						);
						$this->mark_categories_model->add($input);
						$flag=true;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[121]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
}
