<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Notifications_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=49 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }  
	function created_date_fld($created_at_fld)
	{
		$searchQuery ="";
		if(strpos($created_at_fld, "to") !== false){
			$date_arr=explode(" ",$created_at_fld);
			$start_timestamp=strtotime($date_arr[0]);
			$end_timestamp=strtotime($date_arr[2]);
			$end_timestamp = strtotime("tomorrow", $end_timestamp) - 1;
			$searchQuery = " and (n.created_at_timestamp>=".$start_timestamp." and n.created_at_timestamp<=".$end_timestamp.")";
		} 
		else
		{
			$start_timestamp=strtotime($created_at_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			$searchQuery = " and (n.created_at_timestamp>=".$start_timestamp." and n.created_at_timestamp<=".$end_timestamp.")";
		}
		return $searchQuery;
	}
	//Career Goals
	function view_inbox_messages(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  lower(n.created_at) like '%".$searchValue."%' or  lower(CONCAT(u.first_name, ' ', u.last_name)) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,CONCAT(u.first_name, ' ', u.last_name) as created_by_name,nr.is_seen from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='note' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='note' and n.is_deleted=0 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='note' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_messages(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  lower(n.created_at) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='note' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='note' and n.is_deleted=0 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='note' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_inbox_task(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$due_date_fld = $data['due_date_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  lower(n.created_at) like '%".$searchValue."%' or  lower(n.due_datetime) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($due_date_fld != ''){
			$start_timestamp=strtotime($due_date_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			$searchQuery = " and (n.due_date_timestamp>=".$start_timestamp." and n.due_date_timestamp<=".$end_timestamp.")";
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,nr.is_seen from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_task(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$due_date_fld = $data['due_date_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($due_date_fld != ''){
			$start_timestamp=strtotime($due_date_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			$searchQuery = " and (n.due_date_timestamp>=".$start_timestamp." and n.due_date_timestamp<=".$end_timestamp.")";
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
		else
		{
			$i=0;
			foreach($page_details as $not)
			{
				$attachment_name="";
				if($not['attachment']!="")
				{
					$not_arr=explode(",",$not['attachment']);
					foreach($not_arr as $doc)
					{
						$cond="select document_unique_name from documents where id=".$doc;
						$doc_details = $this->users_model->special_fetch($cond);
						if(count($doc_details)>0)
						{
							if($attachment_name=='')
								$attachment_name=$doc_details[0]['document_unique_name'];
							else
								$attachment_name=$attachment_name.",".$doc_details[0]['document_unique_name'];
						}
					}
					$page_details[$i]['attachment_name']=$attachment_name;
				}
				else
					$page_details[$i]['attachment_name']="";
				$i++;
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	//Meetings
	function view_inbox_meetings(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$due_date_fld = $data['due_date_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($due_date_fld != ''){
			$start_timestamp=strtotime($due_date_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			$searchQuery = " and (n.due_date_timestamp>=".$start_timestamp." and n.due_date_timestamp<=".$end_timestamp.")";
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,nr.is_seen from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_meetings(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$due_date_fld = $data['due_date_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($due_date_fld != ''){
			$start_timestamp=strtotime($due_date_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			$searchQuery = " and (n.due_date_timestamp>=".$start_timestamp." and n.due_date_timestamp<=".$end_timestamp.")";
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	//Feedback
	function view_inbox_feedback(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$feedback_fld = $data['feedback_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  lower(n.feedback_answer) like '%".$searchValue."%' or  lower(CONCAT(u.first_name, ' ', u.last_name)) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($feedback_fld != ''&&$feedback_fld != 'all'){
			$searchQuery .= " and has_feedback_message=".$feedback_fld;			
	    }
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,CONCAT(u.first_name, ' ', u.last_name) as created_by_name,nr.is_seen from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='feedback' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='feedback' and n.is_deleted=0 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='feedback' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		$i=0;
		foreach($page_details as $page)
		{
			$path_arr=explode(",",$page['path']);
			$lvl=count($path_arr);
			if($lvl==1)
				$page_details[$i]['has_feedback_message']=2;
			else if($lvl>1)
			{
				$page_details[$i]['parent_sender']='No';
				$cnt=$lvl-1;
				$parent_id=$path_arr[$cnt];
				$cond="select sender_id from notifications where id=".$parent_id;
            	$par_details = $this->users_model->special_fetch($cond);
				if(count($par_details)>0)
				{
					if($par_details[0]['sender_id']==$id)
					{
						$page_details[$i]['has_feedback_message']=$page['has_feedback_message'];
						$page_details[$i]['parent_sender']='Yes';
					}
					else
						$page_details[$i]['has_feedback_message']=2;
				}
			}
			$attachment_name="";
			if($page['attachment']!="")
			{
				$not_arr=explode(",",$page['attachment']);
				foreach($not_arr as $doc)
				{
					$cond="select document_unique_name from documents where id=".$doc;
					$doc_details = $this->users_model->special_fetch($cond);
					if(count($doc_details)>0)
					{
						if($attachment_name=='')
							$attachment_name=$doc_details[0]['document_unique_name'];
						else
							$attachment_name=$attachment_name.",".$doc_details[0]['document_unique_name'];
					}
				}
				$page_details[$i]['attachment_name']=$attachment_name;
			}
			else
				$page_details[$i]['attachment_name']="";
			$i++;
		}
		
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_feedback(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$feedback_fld = $data['feedback_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($feedback_fld != ''&&$feedback_fld != 'all'){
			$searchQuery .= " and has_feedback_message=".$feedback_fld;			
	    }
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='feedback' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='feedback' and n.is_deleted=0 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='feedback' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		$i=0;
		foreach($page_details as $page)
		{
			$path_arr=explode(",",$page['path']);
			$lvl=count($path_arr);
			if($lvl==1)
				$page_details[$i]['has_feedback_message']=2;
			else if($lvl>1)
			{
				$cnt=$lvl-1;
				$parent_id=$path_arr[$cnt];
				$cond="select sender_id from notifications where id=".$parent_id;
            	$par_details = $this->users_model->special_fetch($cond);
				if(count($par_details)>0)
				{
					if($par_details[0]['sender_id']!=$id)
						$page_details[$i]['has_feedback_message']=$page['has_feedback_message'];
					else
						$page_details[$i]['has_feedback_message']=2;
				}
			}
			$i++;
		}
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	//Document
	function view_inbox_document(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,nr.is_seen from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='document' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='document' and n.is_deleted=0 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and type='document' and n.is_deleted=0 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_document(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  n.due_datetime like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='document' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='document' and n.is_deleted=0 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='document' and n.is_deleted=0 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		
		if(count($page_details)<=0)
			$page_details=array();
		else
		{
			$i=0;
			
			foreach($page_details as $not)
			{
				$attachment_name="";
				if($not['attachment']!="")
				{
					$not_arr=explode(",",$not['attachment']);
					foreach($not_arr as $doc)
					{
						$cond="select document_unique_name from documents where id=".$doc;
						$doc_details = $this->users_model->special_fetch($cond);
						if(count($doc_details)>0)
						{
							if($attachment_name=='')
								$attachment_name=$doc_details[0]['document_unique_name'];
							else
								$attachment_name=$attachment_name.",".$doc_details[0]['document_unique_name'];
						}
					}
					$page_details[$i]['attachment_name']=$attachment_name;
				}
				else
					$page_details[$i]['attachment_name']="";
				$i++;
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	//Archive
	function view_inbox_archive(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  lower(CONCAT(u.first_name, ' ', u.last_name)) like '%".$searchValue."%' or  lower(n.type) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,CONCAT(u.first_name, ' ', u.last_name) as created_by_name from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and n.is_deleted=1 and nr.recipient_id=".$id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and n.is_deleted=1 and nr.recipient_id=".$id;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select COUNT(n.id) as cnt from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and n.is_deleted=1 and nr.recipient_id=".$id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_outbox_archive(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$subject_fld = $data['subject_fld'];
		$created_at_fld = $data['created_at_fld'];
		$id = $data['id'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(n.subject) like '%".$searchValue."%' or  n.created_at like '%".$searchValue."%' or  lower(n.type) like '%".$searchValue."%')";
	   	}
		if($subject_fld != ''){
			$searchQuery = " and n.id=".$subject_fld;
	   	}
		if($created_at_fld != ''){
			$searchQuery = $this->created_date_fld($created_at_fld);
	   	}
		if($columnName==""||$columnName=="created_at")
		{
			$columnName = "n.created_at_timestamp";
			$columnSortOrder = "desc";
		}
		$cond="select n.*,count(nr.notification_id) as no_of_recipients from notifications n,notifications_recipients nr where n.id=nr.notification_id and n.is_deleted=1 and n.sender_id=".$id.$searchQuery." group by nr.notification_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and n.is_deleted=1 and n.sender_id=".$id." group by nr.notification_id";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = count($maps_count);
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''){
            $cond="select n.id from notifications n,notifications_recipients nr where n.id=nr.notification_id and n.is_deleted=1 and n.sender_id=".$id.$searchQuery." group by nr.notification_id";
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = count($maps_count);
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function add_notifications(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$message_type = $data['message_type'];
		$student_rbtn = $data['student_rbtn'];
		$personnel_rbtn = $data['personnel_rbtn'];
		$parent_rbtn = $data['parent_rbtn'];
		$personnel_id = $data['personnel_id'];
		$student_course_id = $data['student_course_id'];
		$student_id = $data['student_id'];
		$parent_course_id = $data['parent_course_id'];
		$parent_id = $data['parent_id'];
		$subject = $data['subject'];
		$message = $data['message'];
		$link = $data['link'];
		$document_files = $data['document_files'];
		date_default_timezone_set('Etc/UTC');
		$due_date = $data['due_date'];
		$due_date_timestamp=strtotime($due_date);
		$due_datetime = $data['due_datetime'];
		$due_datetime_timestamp=strtotime($due_datetime);
		$reply_enabled = $data['reply_enabled'];
		$text_message_enabled = $data['text_message_enabled'];
		$created_at_timestamp=time();
		$created_at=date('F j, Y h:i', $created_at_timestamp);
		if($message_type=="note")
		{
			$input = array(
				'sender_id'=>$id,
				'type'=>'note',
				'subject'=>$subject,
				'message'=>$message,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$n_id
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[338]['name'],'message_type'=>$message_type);
		}  
		else if($message_type=="task")
		{
			$input = array(
				'sender_id'=>$id,
				'type'=>'task',
				'subject'=>$subject,
				'message'=>$message,
				'links'=>$link,
				'attachment'=>$document_files,
				'due_datetime'=>$due_date,
				'due_date_timestamp'=>$due_date_timestamp,
				'is_reply_enabled'=>$reply_enabled,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$n_id
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[339]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="appointment")
		{
			$input = array(
				'sender_id'=>$id,
				'type'=>'appointment',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_datetime_timestamp,
				'is_reply_enabled'=>$reply_enabled,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$n_id
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[340]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="feedback")
		{
			$reply_enabled=0;
			if($text_message_enabled==1)
				$reply_enabled=1;
			$input = array(
				'sender_id'=>$id,
				'type'=>'feedback',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_datetime_timestamp,
				'has_feedback_message'=>$text_message_enabled,
				'is_reply_enabled'=>$reply_enabled,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$n_id
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[341]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="document")
		{
			$input = array(
				'sender_id'=>$id,
				'type'=>'document',
				'subject'=>$subject,
				'message'=>$message,
				'links'=>$link,
				'attachment'=>$document_files,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_datetime_timestamp,
				'is_reply_enabled'=>$reply_enabled,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$n_id
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[342]['name'],'message_type'=>$message_type);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_recipients($n_id,$message_type,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id)
	{
		$recipients=array();
		if($message_type!="task")
		{
			if($personnel_rbtn=="all")
			{
				$recipients[]=array(
					"personnel"=>"all"
				);
				$cond="select distinct(u.id) from users u,user_groups ug,personnel p where u.id=ug.user_id and u.id=p.id and ug.group_id in(1,2,3) and p.is_deleted=0 and u.is_active=1";
				$personnel_details = $this->users_model->special_fetch($cond);
				foreach($personnel_details as $per)
				{
					$input = array(
						'notification_id'=>$n_id,
						'recipient_id'=>$per['id']
					);
					$this->notifications_recipients_model->add($input);
				}
			}
			else if($personnel_rbtn=="list")
			{
				$personnel=array();
				if(count($personnel_id)>0)
				{
					foreach($personnel_id as $per)
					{
						$per_arr=explode("-",$per);
						$id=trim($per_arr[0]);
						$name=trim($per_arr[1]);
						$personnel[]=array(
							$id=>$name
						);
						$input = array(
							'notification_id'=>$n_id,
							'recipient_id'=>$id
						);
						$this->notifications_recipients_model->add($input);
					}
				}
				$recipients[]=array(
					"personnel_list"=>$personnel
				);
			}
		}
		if($student_rbtn=="all")
		{
			$recipients[]=array(
				"students"=>"all"
			);
			$cond="select s.id from students s,users u where u.id=s.id and s.is_deleted=0 and u.is_active=1";
			$student_details = $this->users_model->special_fetch($cond);
			foreach($student_details as $per)
			{
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$per['id']
				);
				$this->notifications_recipients_model->add($input);
			}
		}
		else if($student_rbtn=="list")
		{
			$student=array();
			if(count($student_id)>0)
			{
				foreach($student_id as $per)
				{
					$per_arr=explode("-",$per);
					$id=trim($per_arr[0]);
					$name=trim($per_arr[1]);
					$student[]=array(
						$id=>$name
					);
					$input = array(
						'notification_id'=>$n_id,
						'recipient_id'=>$id
					);
					$this->notifications_recipients_model->add($input);
				}
			}
			$recipients[]=array(
				"students_list"=>$student
			);
		}
		else if($student_rbtn=="course")
		{
			$course=array();
			if(count($student_course_id)>0)
			{
				foreach($student_course_id as $stu_course_id)
				{
					$per_arr=explode("-",$stu_course_id);
					$id=trim($per_arr[0]);
					$name=trim($per_arr[1]);
					$course[]=array(
						$id=>$name
					);
					$cond="SELECT DISTINCT(st.student_id) as id FROM students_terms st,course_attendants c,users u WHERE st.id=c.student_term_id and u.id=st.student_id and c.course_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					foreach($student_details as $stu)
					{
						$input = array(
							'notification_id'=>$n_id,
							'recipient_id'=>$stu['id']
						);
						$this->notifications_recipients_model->add($input);
					}
				}
			}
			$recipients[]=array(
				"student_courses"=>$course
			);
		}
		if($message_type!="task")
		{
			if($parent_rbtn=="course")
			{
				$course=array();
				if(count($parent_course_id)>0)
				{
					foreach($parent_course_id as $par_course_id)
					{
						$per_arr=explode("-",$par_course_id);
						$id=trim($per_arr[0]);
						$name=trim($per_arr[1]);
						$course[]=array(
							$id=>$name
						);
						$cond="SELECT DISTINCT(sp.parent_id) as id FROM students_terms st,course_attendants c,students_parents sp WHERE st.id=c.student_term_id and sp.student_id=st.student_id and c.course_id=".$id;
						$parent_details = $this->users_model->special_fetch($cond);
						foreach($parent_details as $stu)
						{
							$input = array(
								'notification_id'=>$n_id,
								'recipient_id'=>$stu['id']
							);
							$this->notifications_recipients_model->add($input);
						}
					}
				}
				$recipients[]=array(
					"parent_courses"=>$course
				);
			}
			else if($parent_rbtn=="list")
			{
				$parent=array();
				if(count($parent_id)>0)
				{
					foreach($parent_id as $per)
					{
						$per_arr=explode("-",$per);
						$id=trim($per_arr[0]);
						$name=trim($per_arr[1]);
						$parent[]=array(
							$id=>$name
						);
						$input = array(
							'notification_id'=>$n_id,
							'recipient_id'=>$id
						);
						$this->notifications_recipients_model->add($input);
					}
				}
				$recipients[]=array(
					"parent_list"=>$parent
				);
			}
		}
		$recipient_info=json_encode($recipients);
		return $recipient_info;
	}
    
    function preview_notifications(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$id = $data['id'];
		$user_id = $data['user_id'];
		$cond="select type,path,lvl,subject,due_datetime from notifications where id=".$id;
        $not_details = $this->users_model->special_fetch($cond);
		$message_type=$not_details[0]['type'];
		$subject=$not_details[0]['subject'];
		$due_datetime=$not_details[0]['due_datetime'];
		$path_route=explode(",",$not_details[0]['path']);
		$path_route = array_reverse($path_route);
		$message_details=array();
		foreach($path_route as $route)
		{
			$cond="select * from notifications where id=".$route;
			$notification_details = $this->users_model->special_fetch($cond);
			if($user_id==$notification_details[0]['sender_id'])
				$sender="from";
			else
				$sender="to";
			$cond="SELECT is_read FROM notifications_recipients WHERE notification_id=".$route." and recipient_id=".$user_id;
			$not_rep_details = $this->users_model->special_fetch($cond);
			$is_read="";
			if(count($not_rep_details)>0)
				$is_read=$not_rep_details[0]['is_read'];
			if($message_type=="note"||$message_type=="appointment")
			{	
				$cond="SELECT CONCAT(first_name, ' ', last_name) as name,avatar FROM users WHERE id=".$notification_details[0]['sender_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				$message_details[]=array(
					"id"=>$notification_details[0]['id'],
					"sender"=>$sender,
					"type"=>$message_type,
					"message"=>$notification_details[0]['message'],
					"has_feedback_answer"=>$notification_details[0]['has_feedback_message'],
					"sender_name"=>$usr_details[0]['name'],
					"is_read"=>$is_read,
					"avatar"=>$usr_details[0]['avatar'],
					"created_at"=>$notification_details[0]['created_at'],
					"created_at_timestamp"=>$notification_details[0]['created_at_timestamp']
				);
			}
			else if($message_type=="feedback")
			{
				$cond="SELECT CONCAT(first_name, ' ', last_name) as name,avatar FROM users WHERE id=".$notification_details[0]['sender_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				$path_arr=explode(",",$notification_details[0]['path']);
				$parent_sender="";$feedback_message="";
				$lvl=count($path_arr);
				if($lvl==1)
					$feedback_message=2;
				else if($lvl>1)
				{
					$parent_sender='Yes';
					$cnt=$lvl-1;
					$parent_id=$path_arr[$cnt];
					$cond="select sender_id from notifications where id=".$parent_id;
					$par_details = $this->users_model->special_fetch($cond);
					if(count($par_details)>0)
					{
						if($par_details[0]['sender_id']!=$notification_details[0]['sender_id'])
						{
							$feedback_message=$notification_details[0]['has_feedback_message'];
							$parent_sender='No';
						}
						else
						{
							$feedback_message=2;
							$parent_sender='Yes';
						}
					}
				}	
				$message_details[]=array(
					"id"=>$notification_details[0]['id'],
					"sender"=>$sender,
					"type"=>$message_type,
					"message"=>$notification_details[0]['message'],
					"has_feedback_message"=>$feedback_message,
					"parent_sender"=>$parent_sender,
					"sender_name"=>$usr_details[0]['name'],
					"is_read"=>$is_read,
					"lvl"=>$lvl,
					"avatar"=>$usr_details[0]['avatar'],
					"created_at"=>$notification_details[0]['created_at'],
					"created_at_timestamp"=>$notification_details[0]['created_at_timestamp']
				);
			}
			else if($message_type=="task"||$message_type=="document")
			{	
				$cond="SELECT CONCAT(first_name, ' ', last_name) as name,avatar FROM users WHERE id=".$notification_details[0]['sender_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				$attachment_names="";
				if($notification_details[0]['attachment']!="")
				{
					$cond="SELECT group_concat(document_unique_name) as document_unique_name FROM documents WHERE id in(".$notification_details[0]['attachment'].")";
					$doc_details = $this->users_model->special_fetch($cond);
					$attachment_names=$doc_details[0]['document_unique_name'];
				}
				$message_details[]=array(
					"id"=>$notification_details[0]['id'],
					"sender"=>$sender,
					"type"=>$message_type,
					"message"=>$notification_details[0]['message'],
					"links"=>$notification_details[0]['links'],
					"attachment"=>$notification_details[0]['attachment'],
					"attachment_names"=>$attachment_names,
					"is_read"=>$is_read,
					"sender_name"=>$usr_details[0]['name'],
					"avatar"=>$usr_details[0]['avatar'],
					"created_at"=>$notification_details[0]['created_at'],
					"created_at_timestamp"=>$notification_details[0]['created_at_timestamp']
				);
			}
		}
		$out = array('statuscode'=>'200','subject'=>$subject,'due_datetime'=>$due_datetime,'message_details'=>$message_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }

	function reply_notifications(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$id = $data['id'];
		$sender_id = $data['sender_id'];
		$message = $data['message'];
		$link = $data['link'];
		$document_files = $data['document_files'];
		$feedback_option = $data['feedback_option'];
		$created_at_timestamp=time();
		$created_at=date('F j, Y h:i', $created_at_timestamp);
		$cond="select type,path,subject,sender_id,due_datetime,due_date_timestamp from notifications where id=".$id;
        $not_details = $this->users_model->special_fetch($cond);
		$message_type=$not_details[0]['type'];
		$subject=$not_details[0]['subject'];
		$due_datetime=$not_details[0]['due_datetime'];
		$due_date_timestamp=$not_details[0]['due_date_timestamp'];
		$path=$not_details[0]['path'];
		$parent_id=$not_details[0]['sender_id'];
		if($message_type=="task")
		{
			$input = array(
				'sender_id'=>$sender_id,
				'parent_id'=>$parent_id,
				'type'=>'task',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_date_timestamp,
				'links'=>$link,
				'attachment'=>$document_files,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_reply_recipients($n_id,$parent_id);
			$path=$n_id.",".$path;
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$path
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[343]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="appointment")
		{
			$input = array(
				'sender_id'=>$sender_id,
				'parent_id'=>$parent_id,
				'type'=>'appointment',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_date_timestamp,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_reply_recipients($n_id,$parent_id);
			$path=$n_id.",".$path;
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$path
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[344]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="feedback")
		{
			$input = array(
				'sender_id'=>$sender_id,
				'parent_id'=>$parent_id,
				'type'=>'feedback',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_date_timestamp,
				'has_feedback_message'=>$feedback_option,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_reply_recipients($n_id,$parent_id);
			$path=$n_id.",".$path;
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$path
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[345]['name'],'message_type'=>$message_type);
		}
		else if($message_type=="document")
		{
			$input = array(
				'sender_id'=>$sender_id,
				'parent_id'=>$parent_id,
				'type'=>'document',
				'subject'=>$subject,
				'message'=>$message,
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_date_timestamp,
				'links'=>$link,
				'attachment'=>$document_files,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$recipient_info=$this->get_reply_recipients($n_id,$parent_id);
			$path=$n_id.",".$path;
			$input = array(
				'recipients_info'=>$recipient_info,
				'path'=>$path
			);
			$this->notifications_model->edit($input,$n_id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[346]['name'],'message_type'=>$message_type);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_reply_recipients($n_id,$parent_id)
	{
		$recipients=array();
		$cond="select concat(first_name,' ',last_name) as name,entity_class from users where id=".$parent_id;
		$user_details = $this->users_model->special_fetch($cond);
		$receivers_name=$user_details[0]['name'];
		if($user_details[0]['entity_class']=="personnelentity")
		{
			$cond="select u.id from users u,user_groups ug where u.id=ug.user_id and ug.group_id in(1,2,3) and u.id=".$parent_id;
			$per_details = $this->users_model->special_fetch($cond);
			if(count($per_details)>0)
			{
				$personnel=array();
				$personnel[]=array(
					$parent_id=>$receivers_name
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$parent_id
				);
				$this->notifications_recipients_model->add($input);
				$recipients[]=array(
					"personnel_list"=>$personnel
				);
			}
			else
			{
				$parent=array();
				$parent[]=array(
					$parent_id=>$receivers_name
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$parent_id
				);
				$this->notifications_recipients_model->add($input);
				$recipients[]=array(
					"parent_list"=>$parent
				);
			}
		}
		else if($user_details[0]['entity_class']=="studententity")
		{
			$student=array();
			$student[]=array(
				$parent_id=>$receivers_name
			);
			$input = array(
				'notification_id'=>$n_id,
				'recipient_id'=>$parent_id
			);
			$this->notifications_recipients_model->add($input);
			$recipients[]=array(
				"students_list"=>$student
			);
		}
		$recipient_info=json_encode($recipients);
		return $recipient_info;
	}   
	function mark_as_read_notifications(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$user_id = $data['user_id'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_read'=>1,
				'notification_id'=>$id,
				'recipient_id'=>$user_id
			);
			$this->notifications_recipients_model->edit_as_read($input);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[207]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function mark_as_unread_notifications(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$user_id = $data['user_id'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_read'=>0,
				'notification_id'=>$id,
				'recipient_id'=>$user_id
			);
			$this->notifications_recipients_model->edit_as_read($input);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[208]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    } 
	function mark_as_read_or_unread_notifications(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$nid = $data['nid'];
		$read_type = $data['read_type'];
		$user_id = $data['user_id'];
		if($read_type==0)
			$read_type=1;
		else
			$read_type=0;
		$input = array(
			'is_read'=>$read_type,
			'notification_id'=>$nid,
			'recipient_id'=>$user_id
		);
		$this->notifications_recipients_model->edit_as_read($input);			
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function update_is_seen(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$user_id = $data['user_id'];
		$input = array(
			'is_seen'=>1,
			'notification_id'=>$id,
			'recipient_id'=>$user_id
		);
		$this->notifications_recipients_model->edit_is_seen($input);
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function archive_notifications(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->notifications_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[209]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_notifications(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->notifications_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[210]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
	function get_student_by_course(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$course_id = $data['course_id'];
		if($course_id!="")
		{
			$cond="SELECT DISTINCT(st.student_id) as id,CONCAT(u.first_name, ' ', u.last_name) as name FROM students_terms st,course_attendants c,users u WHERE st.id=c.student_term_id and u.id=st.student_id and c.course_id in(".$course_id.") order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
		}	
		else
			$student_details=array(); 	
		$out = array('statuscode'=>'200','student_course_details'=>$student_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_parent_by_course(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$course_id = $data['course_id'];
		$cond="SELECT DISTINCT(st.student_id) as id,CONCAT(u.first_name, ' ', u.last_name) as name FROM students_terms st,course_attendants c,users u WHERE st.id=c.student_term_id and u.id=st.student_id and c.course_id in(".$course_id.")";
		$student_details = $this->users_model->special_fetch($cond);
		$parent_info=array();
		foreach($student_details as $stu)
		{
			$cond="select parent_id from students_parents where student_id=".$stu['id'];
			$st_details = $this->users_model->special_fetch($cond);
			foreach($st_details as $par)
			{
				$cond="select id,CONCAT(first_name, ' ', last_name) as name from users where id=".$par['parent_id'];
				$parent_details = $this->users_model->special_fetch($cond);
				$parent_info[]=array(
					"id"=>$parent_details[0]['id'],
					"name"=>$parent_details[0]['name'],
					"student_name"=>$stu['name']
				);
			}
		}
		$tmp = array();
		foreach($parent_info as $arg)
		{
			$tmp[$arg['id']][] = $arg['name'].",".$arg['student_name'];
		}
		$output = array();
		foreach($tmp as $type => $labels)
		{
			$par_name="";$student_names="";
			foreach($labels as $lbl)
			{
				$labels_arr=explode(",",$lbl);
				$par_name=$labels_arr[0];
				if($student_names=="")
					$student_names=$labels_arr[1];
				else
					$student_names=$student_names.",".$labels_arr[1];
			}
			$output[] = array(
				'id' => $type,
				'name' => $par_name,
				'student_names' => $student_names
			);
		}
		foreach ($output as $key => $row)
		{
			$wek[$key]  = $row['name'];
		}  
		$sort=SORT_ASC;
		array_multisort($wek, $sort, $output);
		$out = array('statuscode'=>'200','parent_info'=>$output);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_inbox_count(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="select count(is_seen) as msg_count from notifications n,notifications_recipients nr where nr.notification_id=n.id and type='note' and is_seen=0 and nr.recipient_id=".$id;
		$msg_details = $this->users_model->special_fetch($cond);
		$messages_count=$msg_details[0]['msg_count'];
		$cond="select count(is_seen) as task_count from notifications n,notifications_recipients nr where nr.notification_id=n.id and type='task' and is_seen=0 and nr.recipient_id=".$id;
		$msg_details = $this->users_model->special_fetch($cond);
		$task_count=$msg_details[0]['task_count'];
		$cond="select count(is_seen) as meetings_count from notifications n,notifications_recipients nr where nr.notification_id=n.id and type='appointment' and is_seen=0 and nr.recipient_id=".$id;
		$msg_details = $this->users_model->special_fetch($cond);
		$meetings_count=$msg_details[0]['meetings_count'];
		$cond="select count(is_seen) as feedback_count from notifications n,notifications_recipients nr where nr.notification_id=n.id and type='feedback' and is_seen=0 and nr.recipient_id=".$id;
		$msg_details = $this->users_model->special_fetch($cond);
		$feedback_count=$msg_details[0]['feedback_count'];
		$cond="select count(is_seen) as document_count from notifications n,notifications_recipients nr where nr.notification_id=n.id and type='document' and is_seen=0 and nr.recipient_id=".$id;
		$msg_details = $this->users_model->special_fetch($cond);
		$document_count=$msg_details[0]['document_count'];
		$out = array('statuscode'=>'200','messages_count'=>$messages_count,'task_count'=>$task_count,'meetings_count'=>$meetings_count,'feedback_count'=>$feedback_count,'document_count'=>$document_count);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_subjects_for_search(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$type = $data['type'];
		$user_id = $data['user_id'];
		$notification_details=array();
		if($type=="inbox_messages")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='note' and n.is_deleted=0 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="inbox_task")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="inbox_meetings")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="inbox_feedback")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='feedback' and n.is_deleted=0 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="inbox_document")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='document' and n.is_deleted=0 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_messages")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='note' and n.is_deleted=0 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_task")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='task' and n.is_deleted=0 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_meetings")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='appointment' and n.is_deleted=0 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_feedback")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='feedback' and n.is_deleted=0 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_document")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and type='document' and n.is_deleted=0 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="inbox_archive")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and n.is_deleted=1 and nr.recipient_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		else if($type=="outbox_archive")
		{
			$cond="select n.id,n.subject from notifications n,notifications_recipients nr where n.id=nr.notification_id and n.is_deleted=1 and n.sender_id=".$user_id;
			$notification_details = $this->users_model->special_fetch($cond);
		}
		$item_details=array();	
		foreach($notification_details as $not)
		{
			if(strpos(strtolower($not['subject']), $search_term)!==false)
			{
				$item_details[]=array("id"=>$not['id'],"name"=>$not['subject']);
			}
		}
		$total_count=count($item_details);
		$out = array('total_count'=>$total_count,'items'=>$item_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function time_elapsed_string($datetime, $full,$time) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
        if($diff->d<=7)
        {
            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

        
            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v) {
                if ($diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            }
        
            if (!$full) $string = array_slice($string, 0, 1);
            return $string ? implode(', ', $string) . ' ago' : 'just now';
        }
        else
        {
            return date('M d', $time);
        }
    }
	function get_un_seen_messages()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
        $cond="SELECT n.id,n.subject,n.message,n.created_at_timestamp,n.sender_id,n.type,n.is_reply_enabled FROM notifications n, notifications_recipients nr WHERE n.id=nr.notification_id and is_seen=0 and nr.recipient_id=".$id." order by created_at_timestamp desc";
        $not_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($not_details);$i++)
        {
            $time=$not_details[$i]['created_at_timestamp'];
            $timestamp="@".$time;
            $not_details[$i]['created_at_timestamp']=$this->time_elapsed_string($timestamp,false,$time);
            $cond="select concat(first_name,' ',last_name) as name,first_name, last_name,avatar from users where id=".$not_details[$i]['sender_id'];
            $user_details = $this->users_model->special_fetch($cond);
            if($user_details[0]['avatar']=="")
                $not_details[$i]['avatar']="";
            else
                $not_details[$i]['avatar']=$user_details[0]['avatar'];
            $first_name=$user_details[0]['first_name'];
            $last_name=$user_details[0]['last_name'];
            $not_details[$i]['short_name']=strtoupper($first_name[0].$last_name[0]);
            $not_details[$i]['name']=$user_details[0]['name'];
        }
		$out = array('statuscode'=>'200','notification_details'=>$not_details);              
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function get_msg_count()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="SELECT count(id) as cnt FROM notifications_recipients WHERE is_seen=0 and recipient_id=".$id;
        $not_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','count'=>$not_details[0]['cnt']);              
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function update_is_seen_all(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$input = array(
			'recipient_id'=>$id
		);
		$this->notifications_recipients_model->edit_is_seen_all($input);
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}

