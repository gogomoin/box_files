<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */
//use Mailgun\Mailgun;
class Parents_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
		$this->load->library('mails');
    }    
    
	function index() 
	{		
		
	} 
	
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=34 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
    function search_all()
	{
		$group_id="1,2";
		$user_groups="3,2,1";
		$groups=explode(",",$group_id);
		$parents=explode(",",$user_groups);
		$containsAllValues = !array_diff($groups, $parents);
		echo $containsAllValues;
		$all = array
		(
			0 => 307,
			1 => 157,
			2 => 234,
			3 => 201,
			4 => 322,
			5 => 324
		);
		$search_this = array
		(
			0 => 200,
			1 => 234
		);	
		//$containsAllValues = !array_diff($search_this, $all);
		//echo $containsAllValues;
	}
	//parents
	function view_parents(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$searchQuery = "";
		$searchGroup = "";
		$delQuery = "";
		$parents = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(u.last_name) like '%".$searchValue."%' or lower(u.first_name) like '%".$searchValue."%' or lower(p.mobile_phone) like '%".$searchValue."%' or lower(u.email) like '%".$searchValue."%' or lower(p.city) like '%".$searchValue."%' or lower(c.name) like '%".$searchValue."%' or lower(p.zip) like '%".$searchValue."%' or lower(p.address) like '%".$searchValue."%' or lower(p.address2) like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and u.is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and p.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and p.is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "u.created_at";
			$columnSortOrder = "desc";
		}
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		$cond="select u.id,u.username,u.email,u.first_name,u.last_name,u.is_active,c.name as country_name,p.country,p.gender_id,g.name as gender,p.city,p.address,p.address2,p.zip,p.mobile_phone,p.fixed_phone,p.birth_date,p.admission,p.emission,p.diploma,p.is_deleted,p.personnel_function_id from users u,countries c,personnel p,user_groups ug,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and u.id=ug.user_id and ug.group_id=4".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->parents_model->special_fetch($cond);
		$cond="select COUNT(u.id) as cnt from users u,countries c,personnel p,user_groups ug,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and u.id=ug.user_id and ug.group_id=4".$searchGroup.$delQuery;
		$maps_count = $this->parents_model->special_fetch($cond);
		$totalRecord = $maps_count[0]['cnt'];
		$totalRecordwithFilter = $totalRecord;
		if($searchQuery != ''||$delQuery != ''){
			$cond="select COUNT(u.id) as cnt from users u,countries c,personnel p,user_groups ug,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and u.id=ug.user_id and ug.group_id=4".$searchGroup.$delQuery.$searchQuery;
			$maps_count = $this->parents_model->special_fetch($cond);
			$totalRecordwithFilter = $maps_count[0]['cnt'];
		}
		$i=0;
		foreach($page_details as $user)
		{
			$page_details[$i]['is_parent']="0";
			$i++;
		}
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
		{
			$page_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function randomPassword($num) {
        $alphabet = '1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < $num; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
	function add_parents(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$salt = $data['salt'];
		$password = $data['password'];
		$personnel_function_id = $data['personnel_function_id'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$diploma = $data['diploma'];
		$no_email = $data['no_email'];
		$status = $data['status'];
		$data_arr=array(
				'username'=>$email
			);
        $parents_details = $this->parents_model->get_records($data_arr);
		if($id=="")
		{
			if(count($parents_details)<=0)
			{
				if($no_email==1)
				{
					$num=$this->randomPassword(5);
					$username="NR".$num;
					$salt=$username;
        			$password=md5($salt);
					$email="";
				}
				else
				{
					$username=$email;
				}
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'salt'=>$salt,
					'password'=>$password,
					'is_active'=>$status,
					'entity_class'=>'personnelentity',
					'created_at'=>time()
				);
				$id = $this->parents_model->add($input);
				$input = array(
					'user_id'=>$id,
					'group_id'=>4
				);
				$this->user_groups_model->add($input);
				$input = array(
					'id'=>$id,
					'gender_id'=>$gender_id,
					'personnel_function_id'=>$personnel_function_id,
					'city'=>$city,
					'country'=>$country,
					'zip'=>$zip,
					'address'=>$address,
					'address2'=>$address2,
					'mobile_phone'=>$mobile_phone,
					'fixed_phone'=>$fixed_phone,
					'diploma'=>$diploma
				);
				$this->personnel_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Public",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$public_id=$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"PTSFRRP",
					'parent_folder'=>$public_id,
					'is_deleted'=>1
				);
				$public_id=$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Lessons",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Duplicate",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$this->folder_manager_model->add($input);
				if($no_email==0)
					$this->send_registration_mail($id,$first_name,$last_name,$email,$salt);
				$out = array('statuscode'=>'200','id'=>$id,'statusdescription'=>$label_details[173]['name']);			
			}  
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[174]['name']);
			}
		}
		else
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{	
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$mid = $this->parents_model->edit($input,$id);
			$input = array(
				'personnel_function_id'=>$personnel_function_id,
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'diploma'=>$diploma
			);
			$mid = $this->personnel_model->edit($input,$id);
			$out = array('statuscode'=>'200','id'=>$id,'statusdescription'=>$label_details[175]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_parents(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$personnel_function_id = $data['personnel_function_id'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$diploma = $data['diploma'];
		$status = $data['status'];
		$no_email = $data['no_email'];
		$id = $data['id'];
		$cond="select id from users where username='".$email."' and id<>".$id;
        $career_details = $this->parents_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{	
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$mid = $this->parents_model->edit($input,$id);
			$input = array(
				'personnel_function_id'=>$personnel_function_id,
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'diploma'=>$diploma
			);
			$mid = $this->personnel_model->edit($input,$id);	
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[175]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[176]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[177]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function send_registration_mail($id,$first_name,$last_name,$email,$password) 
	{
		$cond="select s.key,s.value from system_settings s";
		$settings = $this->users_model->special_fetch($cond);
		$login_link='';
		foreach($settings as $set)
		{
			if($set['key']=='login-link')
				$login_link=$set['value'];
		}
		$html_content='';
		$cond="select * from email_templates_i18n where email_template_id=1 and language_id=1";
		$email_setting_details = $this->users_model->special_fetch($cond);
		if(count($email_setting_details)>0){
			$html_content=$email_setting_details[0]['html_content'];
			$html_content=str_replace("{FIRST_NAME}",$first_name,$html_content);
			$html_content=str_replace("{LAST_NAME}",$last_name,$html_content);
			$html_content=str_replace("{LOGIN_PAGE}",$login_link,$html_content);
			$html_content=str_replace("{USERNAME}",$email,$html_content);
			$html_content=str_replace("{PASSWORD}",$password,$html_content);
		}
		$formname = 'Proscola Admin';
		$formaddrs = $formname." <".$email_setting_details[0]['from'].">";
		$subject=$email_setting_details[0]['subject'];
		$to=$email;
		$this->send_mail($formaddrs,$to,$subject,$html_content);
    }
	function send_mail($formaddrs,$to,$subject,$html_content)
	{
		$params = array(
			'from'	=> $formaddrs,
			'to'	=> $to,
			'subject' => $subject,
			'html'	=> $html_content
		);
		$result=$this->mails->send_message($params);
		return $result;
	}  
    function delete_parents(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name=""; 
		foreach($id_arr as $id)
		{
			$cond="select concat(first_name,' ',last_name) as name from users where id=".$id;
			$p_details = $this->parents_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from students_parents where parent_id=".$id." limit 1";
			$stp_details = $this->career_goals_model->special_fetch($cond);
			if(count($stp_details)<=0)
			{	
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->personnel_model->edit($input,$id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[114]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[118]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);       
    }
	function restore_parents(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->personnel_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[179]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_parents(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from users where id=".$id;
			$st_details = $this->parents_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->parents_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[180]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
    function get_personnel_functions(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from personnel_functions where is_deleted=0 and is_active=1";
		$function_details = $this->parents_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','function_details'=>$function_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_gender(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from genders where is_deleted=0 and is_active=1";
		$gender_details = $this->parents_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','gender_details'=>$gender_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_parents(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']==""||$page['first_name']==""||$page['email']==""||$page['gender']==""||$page['country']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['first_name'];
				$corrupt_arr[] =$page['email'];
				$corrupt_arr[] =$page['gender'];
				$corrupt_arr[] =$page['country'];
				$corrupt_arr[] =$page['diploma'];
				$corrupt_arr[] =$page['city'];
				$corrupt_arr[] =$page['address'];
				$corrupt_arr[] =$page['zip'];
				$corrupt_arr[] =$page['address2'];
				$corrupt_arr[] =$page['mobile_phone'];
				$corrupt_arr[] =$page['fixed_phone'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[279]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from users where email='".$page['email']."'";
				$pg_details = $this->parents_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['name'];
					$error_arr[] =$page['first_name'];
					$error_arr[] =$page['email'];
					$error_arr[] =$page['gender'];
					$error_arr[] =$page['country'];
					$error_arr[] =$page['diploma'];
					$error_arr[] =$page['city'];
					$error_arr[] =$page['address'];
					$error_arr[] =$page['zip'];
					$error_arr[] =$page['address2'];
					$error_arr[] =$page['mobile_phone'];
					$error_arr[] =$page['fixed_phone'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[281]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					if($page['gender_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['first_name'];
						$error_arr[] =$page['email'];
						$error_arr[] =$page['gender'];
						$error_arr[] =$page['country'];
						$error_arr[] =$page['diploma'];
						$error_arr[] =$page['city'];
						$error_arr[] =$page['address'];
						$error_arr[] =$page['zip'];
						$error_arr[] =$page['address2'];
						$error_arr[] =$page['mobile_phone'];
						$error_arr[] =$page['fixed_phone'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[184]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}					
					else if($page['country_id']=="")
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['first_name'];
						$error_arr[] =$page['email'];
						$error_arr[] =$page['gender'];
						$error_arr[] =$page['country'];
						$error_arr[] =$page['diploma'];
						$error_arr[] =$page['city'];
						$error_arr[] =$page['address'];
						$error_arr[] =$page['zip'];
						$error_arr[] =$page['address2'];
						$error_arr[] =$page['mobile_phone'];
						$error_arr[] =$page['fixed_phone'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[185]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						$input = array(
							'last_name'=>$page['name'],
							'first_name'=>$page['first_name'],
							'email'=>$page['email'],
							'username'=>$page['email'],
							'salt'=>$page['salt'],
							'password'=>$page['password'],
							'is_active'=>$page['status_val'],
							'created_at'=>time()
						);
						$id = $this->parents_model->add($input);
						$input = array(
							'user_id'=>$id,
							'group_id'=>4
						);
						$this->user_groups_model->add($input);
						$input = array(
							'id'=>$id,
							'personnel_function_id'=>NULL,
							'gender_id'=>$page['gender_id'],
							'city'=>$page['city'],
							'country'=>$page['country_id'],
							'zip'=>$page['zip'],
							'address'=>$page['address'],
							'address2'=>$page['address2'],
							'mobile_phone'=>$page['mobile_phone'],
							'fixed_phone'=>$page['fixed_phone'],
							'diploma'=>$page['diploma']
						);
						$this->personnel_model->add($input);
						$flag=true;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[186]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
}
