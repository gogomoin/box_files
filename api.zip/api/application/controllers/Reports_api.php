<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Reports_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=46 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    } 
	function save_report(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$id = $data['id'];
		$label_details = $this->get_labels_page($lang_id);
		$report_fld = $data['report_fld'];
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$student_fld = $data['student_fld'];
		$excusable_fld = $data['excusable_fld'];
		$evaluation_date_fld = $data['evaluation_date_fld'];
		$columns_order = $data['columns_order'];
		$report_name = $data['report_name'];
		if($report_fld==1)
			$grid_id='report.absence';
		else if($report_fld==2)
			$grid_id='report.disciplinary';
		else if($report_fld==3)
			$grid_id='report.coaching';
		else if($report_fld==4)
			$grid_id='report.course_attendants';
		else if($report_fld==5)
			$grid_id='report.course_marks';
		else if($report_fld==6)
			$grid_id='report.student_marks';
		$cond="select gp.id from grid_presets g,grid_presets_i18n gp where g.id=gp.grid_preset_id and g.user_id=".$id." and gp.language_id=".$lang_id." and gp.name='".$report_name."' and g.grid_id='".$grid_id."'";
		$rep_details = $this->users_model->special_fetch($cond);
		$preset_details=array();
		if(count($rep_details)<=0)
		{
			$filters=array();
			if($report_fld==1)
			{
				$filters[]=array("term"=>$term_fld);
				if($student_fld!="")
				{
					$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_fld;
					$stu_details = $this->users_model->special_fetch($cond);
					$student_data=$student_fld."-".$stu_details[0]['name'];
					$filters[]=array("student"=>$student_data);
				}	
				if($excusable_fld!="")
					$filters[]=array("excusable"=>$excusable_fld);
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.absence',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			else if($report_fld==2)
			{
				$filters[]=array("term"=>$term_fld);
				if($student_fld!="")
				{
					$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_fld;
					$stu_details = $this->users_model->special_fetch($cond);
					$student_data=$student_fld."-".$stu_details[0]['name'];
					$filters[]=array("student"=>$student_data);
				}	
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.disciplinary',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			else if($report_fld==3)
			{
				$filters[]=array("term"=>$term_fld);
				if($student_fld!="")
				{
					$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_fld;
					$stu_details = $this->users_model->special_fetch($cond);
					$student_data=$student_fld."-".$stu_details[0]['name'];
					$filters[]=array("student"=>$student_data);
				}	
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.coaching',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			else if($report_fld==4)
			{
				$filters[]=array("term"=>$term_fld);
				$filters[]=array("course"=>$course_fld);
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.course_attendants',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			else if($report_fld==5)
			{
				$filters[]=array("term"=>$term_fld);
				if($course_fld!="")
				{
					$filters[]=array("course"=>$course_fld);
				}
				if($evaluation_date_fld!="")
				{
					$filters[]=array("eval_date"=>$evaluation_date_fld);
				}
				if($student_fld!="")
				{
					$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_fld;
					$stu_details = $this->users_model->special_fetch($cond);
					$student_data=$student_fld."-".$stu_details[0]['name'];
					$filters[]=array("student"=>$student_data);
				}
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.course_marks',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			else if($report_fld==6)
			{
				$filters[]=array("term"=>$term_fld);
				$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_fld;
				$stu_details = $this->users_model->special_fetch($cond);
				$student_data=$student_fld."-".$stu_details[0]['name'];
				$filters[]=array("student"=>$student_data);
				$filters[]=array("grid_columns"=>$columns_order);
				$filters_info=json_encode($filters);
				$input = array(
					'user_id'=>$id,
					'grid_id'=>'report.student_marks',
					'filters'=>$filters_info,
					'created_at'=>time()
				);
				$report_id = $this->reports_model->add($input);
				$input = array(
					'grid_preset_id'=>$report_id,
					'language_id'=>$lang_id,
					'name'=>$report_name
				);
				$this->reports_name_model->add($input);
			}
			$cond="select g.*,gp.name from grid_presets g,grid_presets_i18n gp where g.id=gp.grid_preset_id and g.user_id=".$id." and gp.language_id=".$lang_id." and g.grid_id='".$grid_id."'";
			$preset_details = $this->users_model->special_fetch($cond);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[39]['name'],'preset_details'=>$preset_details);
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[38]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }  
	function filter_report(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$label_details = $this->get_labels_page($lang_id);
		$report_fld = $data['report_fld'];
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$student_fld = $data['student_fld'];
		$excusable_fld = $data['excusable_fld'];
		$evaluation_date_fld = $data['evaluation_date_fld'];
		$columns_order = $data['columns_order'];
		$cols_arr=explode(",",$columns_order);
		$column_details=array();$row_details=array();
		$searchQuery='';
		if($report_fld==1)
		{
			$column_headers=array("<b>".$label_details[40]['name']."</b>", "<b>".$label_details[41]['name']."</b>","<b>".$label_details[42]['name']."</b>","<b>".$label_details[43]['name']."</b>","<b>".$label_details[44]['name']."</b>","<b>".$label_details[76]['name']."</b>","<b>".$label_details[86]['name']."</b>");
			$column_names=array("student_name", "absence_category","start_date","end_date","reported_by","justification","is_excused");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			if($student_fld != ''){
				$searchQuery .= " and st.student_id=".$student_fld;			
			}
			else
			{
				if($group_id==4)
				{
					$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					if($student_details[0]['id']!="")
					{
						$searchQuery .= " and st.student_id in(".$student_details[0]['id'].")";
					}
				}
				else if($group_id==5)
				{
					$searchQuery .= " and st.student_id=".$id;	
				}
			}
			if($excusable_fld != ''&&$excusable_fld != 'all'){
				$searchQuery .= " and a.is_excused=".$excusable_fld;			
			}
			$cond="select a.student_term_id,a.absence_category_id,a.startdate_timestamp,a.enddate_timestamp,a.personnel_id,a.justification,a.is_excused from absences a,students_terms st where a.student_term_id=st.id and a.is_deleted=0 and a.is_active=1 and st.term_id=".$term_fld.$searchQuery;
			$absence_details = $this->users_model->special_fetch($cond);
			foreach($absence_details as $abs)	
			{
				$col_values=array();
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						$student_term_id=$abs['student_term_id'];
						$cond="select concat(u.first_name,' ',u.last_name) as name from students_terms st,users u where st.student_id=u.id and st.id=".$student_term_id;
						$stu_details = $this->users_model->special_fetch($cond);
						if(count($stu_details)>0)
							$col_values['student_name']=$stu_details[0]['name'];
						else
							$col_values['student_name']='';
					}
					if($cols==1)
					{
						$cond="select name from absence_categories where id=".$abs['absence_category_id'];
						$abs_details = $this->users_model->special_fetch($cond);
						if(count($abs_details)>0)
							$col_values['absence_category']=$abs_details[0]['name'];
						else
							$col_values['absence_category']='';
					}
					if($cols==2)
						$col_values['start_date']=date('F j, Y H:i', $abs['startdate_timestamp']);
					if($cols==3)
						$col_values['end_date']=date('F j, Y H:i', $abs['enddate_timestamp']);
					if($cols==4)
					{
						$cond="select concat(first_name,' ',last_name) as name from users where id=".$abs['personnel_id'];
						$per_details = $this->users_model->special_fetch($cond);
						if(count($per_details)>0)
							$col_values['reported_by']=$per_details[0]['name'];
						else
							$col_values['reported_by']='';
					}
					if($cols==5)
						$col_values['justification']=$abs['justification'];
					if($cols==6)
					{
						$str='<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_excused']==0)
							$str='<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$col_values['is_excused']=$str;
					}
				}
				$row_details[]=$col_values;
			}
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details);
		}
		else if($report_fld==2)
		{
			$column_headers=array("<b>".$label_details[40]['name']."</b>", "<b>".$label_details[47]['name']."</b>","<b>".$label_details[48]['name']."</b>","<b>".$label_details[49]['name']."</b>","<b>".$label_details[50]['name']."</b>","<b>".$label_details[51]['name']."</b>","<b>".$label_details[52]['name']."</b>","<b>".$label_details[53]['name']."</b>");
			$column_names=array("student_name", "category","points","remark_date","reported_by","remark","is_parent_check_needed","is_checked_by_parent");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			if($student_fld != ''){
				$searchQuery .= " and st.student_id=".$student_fld;			
			}
			else
			{
				if($group_id==4)
				{
					$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					if($student_details[0]['id']!="")
					{
						$searchQuery .= " and st.student_id in(".$student_details[0]['id'].")";
					}
				}
				else if($group_id==5)
				{
					$searchQuery .= " and st.student_id=".$id;	
				}
			}
			$cond="select a.student_term_id,a.disciplinary_category_id,a.points_value,a.remarkdate_timestamp,a.personnel_id,a.description,a.is_parent_check_needed,a.is_checked_by_parent from disciplinary_protocols a,students_terms st where a.student_term_id=st.id and a.is_deleted=0 and a.is_active=1 and st.term_id=".$term_fld.$searchQuery;
			$disciplinary_details = $this->users_model->special_fetch($cond);
			foreach($disciplinary_details as $abs)	
			{
				$col_values=array();
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						$student_term_id=$abs['student_term_id'];
						$cond="select concat(u.first_name,' ',u.last_name) as name from students_terms st,users u where st.student_id=u.id and st.id=".$student_term_id;
						$stu_details = $this->users_model->special_fetch($cond);
						if(count($stu_details)>0)
							$col_values['student_name']=$stu_details[0]['name'];
						else
							$col_values['student_name']='';

					}
					if($cols==1)
					{
						$cond="select name from disciplinary_categories where id=".$abs['disciplinary_category_id'];
						$abs_details = $this->users_model->special_fetch($cond);
						if(count($abs_details)>0)
							$col_values['category']=$abs_details[0]['name'];
						else
							$col_values['category']='';
					}
					if($cols==2)
						$col_values['points']=$abs['points_value'];
					if($cols==3)
						$col_values['remark_date']=date('F j, Y H:i', $abs['remarkdate_timestamp']);
					if($cols==4)
					{
						$cond="select concat(first_name,' ',last_name) as name from users where id=".$abs['personnel_id'];
						$per_details = $this->users_model->special_fetch($cond);
						if(count($per_details)>0)
							$col_values['reported_by']=$per_details[0]['name'];
						else
							$col_values['reported_by']='';
					}
					if($cols==5)
						$col_values['remark']=$abs['description'];
					if($cols==6)
					{
						$str='<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_parent_check_needed']==0)
							$str='<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$col_values['is_parent_check_needed']=$str;
					}
					if($cols==7)
					{
						$str='<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_checked_by_parent']==0)
							$str='<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$col_values['is_checked_by_parent']=$str;
					}
				}
				$row_details[]=$col_values;
			}
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details);
		}
		else if($report_fld==3)
		{
			$column_headers=array("<b>".$label_details[40]['name']."</b>", "<b>".$label_details[54]['name']."</b>","<b>".$label_details[55]['name']."</b>","<b>".$label_details[56]['name']."</b>","<b>".$label_details[57]['name']."</b>","<b>".$label_details[58]['name']."</b>","<b>".$label_details[59]['name']."</b>","<b>".$label_details[60]['name']."</b>");
			$column_names=array("student_name", "coaching_date","deadline_date","student_agenda","personnel_agenda","protocol","arrangement","is_fulfilled");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			if($student_fld != ''){
				$searchQuery .= " and st.student_id=".$student_fld;			
			}
			else
			{
				if($group_id==4)
				{
					$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					if($student_details[0]['id']!="")
					{
						$searchQuery .= " and st.student_id in(".$student_details[0]['id'].")";
					}
				}
				else if($group_id==5)
				{
					$searchQuery .= " and st.student_id=".$id;	
				}
			}
			$cond="select a.student_term_id,a.coaching_date,a.deadline_date,a.student_agenda,a.personnel_agenda,a.protocol,a.arrangement,a.is_fulfilled from coaching_protocols a,students_terms st where a.student_term_id=st.id and a.is_deleted=0 and a.is_active=1 and st.term_id=".$term_fld.$searchQuery;
			$coaching_details = $this->users_model->special_fetch($cond);
			foreach($coaching_details as $abs)	
			{
				$col_values=array();
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						$student_term_id=$abs['student_term_id'];
						$cond="select concat(u.first_name,' ',u.last_name) as name from students_terms st,users u where st.student_id=u.id and st.id=".$student_term_id;
						$stu_details = $this->users_model->special_fetch($cond);
						if(count($stu_details)>0)
							$col_values['student_name']=$stu_details[0]['name'];
						else
							$col_values['student_name']='';

					}
					if($cols==1)
						$col_values['coaching_date']=$abs['coaching_date'];
					if($cols==2)
						$col_values['deadline_date']=$abs['deadline_date'];
					if($cols==3)
						$col_values['student_agenda']=$abs['student_agenda'];
					if($cols==4)
						$col_values['personnel_agenda']=$abs['personnel_agenda'];
					if($cols==5)
						$col_values['protocol']=$abs['protocol'];
					if($cols==6)
						$col_values['arrangement']=$abs['arrangement'];
					if($cols==7)
					{
						$str='<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_fulfilled']==0)
							$str='<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$col_values['is_fulfilled']=$str;
					}
				}
				$row_details[]=$col_values;
			}
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details);
		}
		else if($report_fld==4)
		{
			$column_headers=array("<b>".$label_details[40]['name']."</b>", "<b>".$label_details[61]['name']."</b>", "<b>".$label_details[62]['name']."</b>", "<b>".$label_details[63]['name']."</b>", "<b>".$label_details[64]['name']."</b>","<b>".$label_details[65]['name']."</b>");
			$column_names=array("student_name","course","grade","study_level","tutor","status");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			if($group_id==4)
			{
				$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
				$student_details = $this->users_model->special_fetch($cond);
				if($student_details[0]['id']!="")
				{
					$searchQuery .= " and st.student_id in(".$student_details[0]['id'].")";
				}
			}
			else if($group_id==5)
			{
				$searchQuery .= " and st.student_id=".$id;	
			}
			$cond="select a.student_term_id,a.course_id,a.student_course_status_id from course_attendants a,students_terms st where a.student_term_id=st.id and st.is_active=1 and st.term_id=".$term_fld." and a.course_id=".$course_fld.$searchQuery;
			$course_details = $this->users_model->special_fetch($cond);
			foreach($course_details as $abs)	
			{
				$col_values=array();
				$cond="select * from students_terms where id=".$abs['student_term_id'];
				$student_term_details = $this->users_model->special_fetch($cond);
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						if(count($student_term_details)>0)
						{
							$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_term_details[0]['student_id'];
							$stu_details = $this->users_model->special_fetch($cond);
							if(count($stu_details)>0)
								$col_values['student_name']=$stu_details[0]['name'];
							else
								$col_values['student_name']='';
						}
						else
							$col_values['student_name']='';

					}
					if($cols==1)
					{
						$cond="select name from courses where id=".$abs['course_id'];
						$cor_details = $this->users_model->special_fetch($cond);
						if(count($cor_details)>0)
							$col_values['course']=$cor_details[0]['name'];
						else
							$col_values['course']='';
					}
					if($cols==2)
					{
						if(count($student_term_details)>0)
						{
							$cond="select name from classes where id=".$student_term_details[0]['class_id'];
							$stu_details = $this->users_model->special_fetch($cond);
							if(count($stu_details)>0)
								$col_values['grade']=$stu_details[0]['name'];
							else
								$col_values['grade']='';
						}
						else
							$col_values['grade']='';

					}
					if($cols==3)
					{
						if(count($student_term_details)>0)
						{
							if($student_term_details[0]['main_level_id']!=''||$student_term_details[0]['main_level_id']!=0)
							{
								$cond="select name from main_levels where id=".$student_term_details[0]['main_level_id'];
								$stu_details = $this->users_model->special_fetch($cond);
								if(count($stu_details)>0)
									$col_values['study_level']=$stu_details[0]['name'];
								else
									$col_values['study_level']='';
							}
							else
								$col_values['study_level']='';
						}
						else
							$col_values['study_level']='';

					}
					if($cols==4)
					{
						if(count($student_term_details)>0)
						{
							$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_term_details[0]['coach_id'];
							$stu_details = $this->users_model->special_fetch($cond);
							if(count($stu_details)>0)
								$col_values['tutor']=$stu_details[0]['name'];
							else
								$col_values['tutor']='';
						}
						else
							$col_values['tutor']='';

					}
					if($cols==5)
					{
						$cond="select name from student_course_statuses where id=".$abs['student_course_status_id'];
						$cor_details = $this->users_model->special_fetch($cond);
						if(count($cor_details)>0)
							$col_values['status']=$cor_details[0]['name'];
						else
							$col_values['status']='';
					}	
				}
				$row_details[]=$col_values;
			}
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details);
		}
		else if($report_fld==5)
		{
			$column_headers=array("<b>".$label_details[61]['name']."</b>","<b>".$label_details[40]['name']."</b>", "<b>".$label_details[66]['name']."</b>","<b>".$label_details[67]['name']."</b>","<b>".$label_details[68]['name']."</b>","<b>".$label_details[69]['name']."</b>","<b>".$label_details[70]['name']."</b>");
			$column_names=array("course","student_name", "mark_category","factor","mark","is_counted","evaluation_date");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			if($student_fld != ''){
				$searchQuery .= " and st.student_id=".$student_fld;			
			}
			else
			{
				if($group_id==4)
				{
					$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					if($student_details[0]['id']!="")
					{
						$searchQuery .= " and st.student_id in(".$student_details[0]['id'].")";
					}
				}
				else if($group_id==5)
				{
					$searchQuery .= " and st.student_id=".$id;	
				}
			}
			if($course_fld != ''){
				$searchQuery .= " and ca.course_id=".$course_fld;			
			}
			if($evaluation_date_fld != ''){
				$searchQuery .= " and a.evaluation_date=".$evaluation_date_fld;			
			}
			$total_avg=0;
			$student_all_details=array();
			$cond="select ca.course_id,st.student_id,a.mark_category_id,a.mark_id,a.is_counted,a.evaluation_date from course_attendants_marks a,course_attendants ca,students_terms st where a.course_attendant_id=ca.id and ca.student_term_id=st.id and a.is_deleted=0 and a.is_active=1 and st.term_id=".$term_fld.$searchQuery;
			$mark_details = $this->users_model->special_fetch($cond);
			foreach($mark_details as $abs)	
			{
				$col_values=array();
				$cond="select name,factor from mark_categories where id=".$abs['mark_category_id'];
				$mrk_details = $this->users_model->special_fetch($cond);
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						$cond="select name from courses where id=".$abs['course_id'];
						$cor_details = $this->users_model->special_fetch($cond);
						if(count($cor_details)>0)
							$col_values['course']=$cor_details[0]['name'];
						else
							$col_values['course']='';
					}
					if($cols==1)
					{
						$cond="select concat(first_name,' ',last_name) as name from users where id=".$abs['student_id'];
						$stu_details = $this->users_model->special_fetch($cond);
						if(count($stu_details)>0)
							$col_values['student_name']=$stu_details[0]['name'];
						else
							$col_values['student_name']='';
					}
					if($cols==2)
					{
						if(count($mrk_details)>0)
							$col_values['mark_category']=$mrk_details[0]['name'];
						else
							$col_values['mark_category']='';
					}
					$factor="";$mark=0;
					if($cols==3)
					{
						if(count($mrk_details)>0)
						{
							$col_values['factor']=$mrk_details[0]['factor'];
							$factor=$col_values['factor'];
						}
						else
							$col_values['factor']='';
					}
					if($cols==4)
					{
						$cond="select number_value from marks where id=".$abs['mark_id'];
						$mark_details = $this->users_model->special_fetch($cond);
						if(count($mark_details)>0)
						{
							$col_values['mark']=$mark_details[0]['number_value'];
							$mark=$col_values['mark'];
						}
						else
							$col_values['mark']='';
					}
					if($cols==5)
					{
						$str='<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_counted']==0)
							$str='<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$col_values['is_counted']=$str;
					}
					if($cols==6)
						$col_values['evaluation_date']=$abs['evaluation_date'];					
				}
				$row_details[]=$col_values;	
			}
			$total_avg=0;$mrk_avg=0;$wt_avg=0;
			foreach($row_details as $rows)
			{
				$wt1=0;
				if($rows['factor']!="")
					$wt1=$rows['factor'];
				$cond="select assessment_value from subject_types st,subjects s,courses c where c.subject_id=s.id and st.id=s.subject_type_id and c.name='".$rows['course']."'";
				$mrk_sub_details = $this->students_terms_model->special_fetch($cond);
				$wt2=0;
				if(count($mrk_sub_details)>0)
					$wt2=$mrk_sub_details[0]['assessment_value'];
				if($rows['mark']>0)
				{
					$mrk_avg=$mrk_avg+($rows['mark']*$wt1*$wt2);
					$wt_avg=$wt_avg+($wt1*$wt2);
				}
			}
			if($wt_avg!=0)
				$total_avg=round(($mrk_avg/$wt_avg),2);
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details,'total_avg'=>$total_avg);
		}
		else if($report_fld==6)
		{
			$column_headers=array("<b>".$label_details[61]['name']."</b>", "<b>".$label_details[71]['name']."</b>","<b>".$label_details[72]['name']."</b>");
			$column_names=array("course", "avg_mark","detail_view");
			foreach($cols_arr as $cols)
			{
				$column_details[]=array("title"=>$column_headers[$cols],"data"=>$column_names[$cols]);
			}
			
			$cond="select distinct(ca.course_id) as course_id from course_attendants ca,students_terms st where ca.student_term_id=st.id and st.is_active=1 and st.term_id=".$term_fld." and st.student_id=".$student_fld;
			$course_details = $this->users_model->special_fetch($cond);
			foreach($course_details as $course)
			{
				$cond="select a.mark_category_id,a.mark_id,a.is_counted,a.evaluation_date from course_attendants_marks a,course_attendants ca,students_terms st where a.course_attendant_id=ca.id and ca.student_term_id=st.id and ca.course_id=".$course['course_id']." and st.student_id=".$student_fld;
				$mark_details = $this->users_model->special_fetch($cond);
				$avg_mark=0;
				$optns='';
				if(count($mark_details)>0)
				{
					$optns .='<ul data-dtr-index="1" class="mark_data_count">';
					$optns .='<li data-dtr-index="4" data-dt-row="1" data-dt-column="4">';
					$optns .='<span class="dtr-data">';
					$optns .='<div class="container student-marks-table">';
					$optns .='<div class="container">';
					$optns .='<div class="row">';
					$optns .='<div class="col-lg-2 br1 det_css"><b>'.$label_details[68]['name'].'</b></div>';
					$optns .='<div class="col-lg-3 br1 det_css"><b>'.$label_details[73]['name'].'</b></div>';
					$optns .='<div class="col-lg-2 br1 det_css"><b>'.$label_details[67]['name'].'</b></div>';
					$optns .='<div class="col-lg-3 br1 det_css"><b>'.$label_details[66]['name'].'</b></div>';
					$optns .='<div class="col-lg-2 br1 det_css"><b>'.$label_details[74]['name'].'</b></div>';
					$optns .='</div>';
					$optns .='</div>';
					$total_marks=0;
					$mrk_total=0;$wt1=0;
					foreach($mark_details as $abs)	
					{
						$cond="select number_value,name from marks where id=".$abs['mark_id'];
						$mark_details = $this->users_model->special_fetch($cond);
						$cond="select name,factor from mark_categories where id=".$abs['mark_category_id'];
						$mrk_details = $this->users_model->special_fetch($cond);
						$optns .='<div class="container">';
						$optns .='<div class="row">';
						$optns .='<div class="col col-lg-2 br1 det_css">'.$mark_details[0]['name'].'</div>';
						$optns .='<div class="col col-lg-3 br1 det_css">'.$abs['evaluation_date'].'</div>';
						$optns .='<div class="col col-lg-2 br1 det_css">'.$mrk_details[0]['factor'].'</div>';
						$optns .='<div class="col col-lg-3 br1 det_css">'.$mrk_details[0]['name'].'</div>';
						$str = '<span class="badge badge-light-success fs-7 td-center">'.$label_details[45]['name'].'</span>';
						if($abs['is_counted']==0)
							$str = '<span class="badge badge-light-danger fs-7 td-center">'.$label_details[46]['name'].'</span>';
						$optns .='<div class="col-lg-2 br1 det_css">'.$str.'</div>';
						$optns .='</div>';
						$optns .='</div>';
						$mrk_total=$mrk_total+($mark_details[0]['number_value']*$mrk_details[0]['factor']);
						$wt1=$wt1+$mrk_details[0]['factor'];
					}
					if($wt1!=0)
						$avg_mark=round(($mrk_total/$wt1),2);
					$optns.='</div></span></li></ul>';
				}
				foreach($cols_arr as $cols)
				{
					if($cols==0)
					{
						$cond="select name from courses where id=".$course['course_id'];
						$cor_details = $this->users_model->special_fetch($cond);
						if(count($cor_details)>0)
							$col_values['course']=$cor_details[0]['name'];
						else
							$col_values['course']='';
					}
					if($cols==1)
					{
						$col_values['avg_mark']=$avg_mark;
					}
					if($cols==2)
					{
						$col_values['detail_view']=$optns;
					}
				}
				$row_details[]=$col_values;
			}
			$total_mrk=0;$total_sub_wt=0;
			foreach($row_details as $rows)
			{
				$cond="select assessment_value from subject_types st,subjects s,courses c where c.subject_id=s.id and st.id=s.subject_type_id and c.name='".$rows['course']."'";
				$mrk_sub_details = $this->students_terms_model->special_fetch($cond);
				if(count($mrk_sub_details)>0)
				{
					if($rows['avg_mark']!=0)
					{
						$sub_wt=$mrk_sub_details[0]['assessment_value'];
						$total_mrk=$total_mrk+($rows['avg_mark']*$sub_wt);
						$total_sub_wt=$total_sub_wt+$sub_wt;
					}
				}
			}
			if($total_sub_wt>0)
				$total_avg=round(($total_mrk/$total_sub_wt),2);
			$out = array('statuscode'=>'200','column_details'=>$column_details,'row_details'=>$row_details,'total_avg'=>$total_avg);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }  
	
	function get_presets(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$id = $data['id'];
		$cond="select g.*,gp.name from grid_presets g,grid_presets_i18n gp where g.id=gp.grid_preset_id and g.user_id=".$id." and gp.language_id=".$lang_id." order by gp.name asc";
		$preset_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','preset_details'=>$preset_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function open_preset_report(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$preset_fld = $data['preset_fld'];
		$cond="select g.*,gp.name from grid_presets g,grid_presets_i18n gp where g.id=gp.grid_preset_id and g.id=".$preset_fld;
		$preset_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','preset_details'=>$preset_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function delete_reports(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$preset_fld = $data['preset_fld']; 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$cond="select id from grid_presets_i18n where grid_preset_id=".$preset_fld;
		$pre_details = $this->users_model->special_fetch($cond);
		$this->reports_model->delete($preset_fld);
		$this->reports_name_model->delete($pre_details[0]['id']);
		$cond="select g.*,gp.name from grid_presets g,grid_presets_i18n gp where g.id=gp.grid_preset_id and g.user_id=".$id." and gp.language_id=".$lang_id;	
		$preset_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[75]['name'],'preset_details'=>$preset_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
}
