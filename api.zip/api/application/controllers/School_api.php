<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class School_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=25 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    } 
	//Schools
	function view_school(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];				
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(s.name) like '%".$searchValue."%' or lower(s.gen_email) like '%".$searchValue."%' or lower(s.specific_email) like '%".$searchValue."%' or lower(s.phone_no) like '%".$searchValue."%' or lower(s.city) like '%".$searchValue."%' or lower(s.country) like '%".$searchValue."%' or lower(s.zip_code) like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and s.is_active=".$status_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and s.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and s.is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "s.created_at";
			$columnSortOrder = "desc";
		}
		$cond="select s.*,c.name as country_name from school s,countries c where c.id=s.country".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(s.id) as cnt from school s,countries c where c.id=s.country".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(s.id) as cnt from school s,countries c where c.id=s.country".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_school(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$name = $data['name'];
		$logo = $data['logo'];
		$gen_email = $data['gen_email'];
		$specific_email = $data['specific_email'];
		$phone_no = $data['phone_no'];
		$address1 = $data['address1'];
		$address2 = $data['address2'];
		$city = $data['city'];
		$country = $data['country'];
		$zip_code = $data['zip_code'];
		$domain = $data['domain'];
		$db_name = $data['db_name'];
		$status = $data['status'];
		$data_arr=array(
				'name'=>$name
			);
        $school_details = $this->school_model->get_records($data_arr);
		if(count($school_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'logo'=>$logo,
				'gen_email'=>$gen_email,
				'specific_email'=>$specific_email,
				'phone_no'=>$phone_no,
				'address1'=>$address1,
				'address2'=>$address2,
				'city'=>$city,
				'country'=>$country,
				'zip_code'=>$zip_code,
				'domain'=>$domain,
				'db_name'=>$db_name,
				'is_active'=>$status,
				'created_at'=>time()
			);
			$mid = $this->school_model->add($input);
			if($mid){				
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[119]['name'],'id'=>$mid);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[120]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[120]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_school(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$logo = $data['logo'];
		$gen_email = $data['gen_email'];
		$specific_email = $data['specific_email'];
		$phone_no = $data['phone_no'];
		$address1 = $data['address1'];
		$address2 = $data['address2'];
		$city = $data['city'];
		$country = $data['country'];
		$zip_code = $data['zip_code'];
		$domain = $data['domain'];
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from school where name='".$name."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		$cond="select domain from school where id=".$id;
        $sch_details = $this->users_model->special_fetch($cond);
		if($domain=="")
		{
			$domain=$sch_details[0]['domain'];
		}
		if(count($career_details)<=0)
		{
			$input = array(
				'name'=>$name,
				'logo'=>$logo,
				'gen_email'=>$gen_email,
				'specific_email'=>$specific_email,
				'phone_no'=>$phone_no,
				'address1'=>$address1,
				'address2'=>$address2,
				'city'=>$city,
				'country'=>$country,
				'zip_code'=>$zip_code,
				'domain'=>$domain,
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$mid = $this->school_model->edit($input,$id);
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[122]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[123]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[124]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_school(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->school_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[125]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_school(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->school_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[126]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_school(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from school where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->school_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[127]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
    function get_countries(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from countries where is_deleted=0 and is_active=1 order by name asc";
		$country_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','country_details'=>$country_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_school_data(){
				
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from school limit 1";
		$school_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','school_details'=>$school_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
