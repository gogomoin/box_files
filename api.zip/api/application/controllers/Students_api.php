<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Students_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
		$this->load->library('mails');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=45 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//students
	function view_students(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$resigned_fld = $data['resigned_fld'];	
		$teacher_fld = $data['teacher_fld'];
		$grade_fld = $data['grade_fld'];
		$study_level_fld = $data['study_level_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$searchGroup = "";
		$delQuery = "";
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and u.is_active=".$status_fld;			
	    }
		if($resigned_fld != ''&&$resigned_fld != 'all'){
			$searchQuery .= " and s.is_finished_school=".$resigned_fld;
	    }		
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and s.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and s.is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "u.created_at";
			$columnSortOrder = "desc";
		}
		$per_query='';
		$flag=true;
		$term_id="";
		$cond="select * from terms where is_deleted=0 and is_active=1";
		$term_details = $this->users_model->special_fetch($cond);
		if(count($term_details)>0)
			$term_id=$term_details[0]['id'];
		else
			$flag=false;
		/* $cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
			}
		}
		if($term_id=="")
		{
			$cond="select id from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
				$term_id=$term_details[0]['id'];
			else
				$flag=false;
		} */
		$group_arr=explode(",",$group_id);
		if (in_array(1, $group_arr)||in_array(3, $group_arr))
		{
			$per_query='';
		}
		else if ($group_id=="2")
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT id) as course_id FROM courses WHERE personnel_id=".$id;
			$per_details = $this->users_model->special_fetch($cond);
			if($per_details[0]['course_id']!='')
			{
				$cond="SELECT GROUP_CONCAT(DISTINCT st.student_id) as student_id FROM course_attendants c,students_terms st WHERE st.id=c.student_term_id and c.course_id in (".$per_details[0]['course_id'].")";
				$stu_details = $this->users_model->special_fetch($cond);
				if($stu_details[0]['student_id']!='')
					$per_query = " and s.id in(".$stu_details[0]['student_id'].")";
				else
					$flag=false;
			}
			else
				$flag=false;
		}
		else if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!='')
				$per_query = " and s.id in(".$par_details[0]['student_id'].")";
			else
				$flag=false;
		}
		else if (in_array(5, $group_arr))
		{
			$per_query = " and u.id=".$id;
		}
		if($flag)
		{
			$totalRecord="";$totalRecordwithFilter="";$page_details=array();
			$cond="SELECT s.*,CONCAT(u.first_name, ' ', u.last_name) as name,u.username,u.first_name,u.last_name,u.email,u.avatar,u.is_active FROM users u,students s where s.id=u.id".$delQuery.$searchQuery.$per_query;
			$page_details = $this->students_model->special_fetch($cond);
			$totalRecord = count($page_details);
			$student_all_details=array();
			foreach($page_details as $student)
			{
				$class_id="";$coach_id="";$main_level_id="";$grade="";$study_level="";$tutor="";
				$cond="select * from students_terms where student_id=".$student['id']." and term_id=".$term_id;
				$st_term_details = $this->students_model->special_fetch($cond);
				if(count($st_term_details)>0)
				{
					foreach($st_term_details as $st_terms)
					{
						if($st_terms['class_id']!="")
						{
							$cond="select name from classes where id=".$st_terms['class_id'];
							$class_details = $this->students_model->special_fetch($cond);
							if(count($class_details)>0)
							{
								if($grade=="")
								{
									$grade=$class_details[0]['name'];
									$class_id=$st_terms['class_id'];
								}
								else
								{
									$grade=$grade.",".$class_details[0]['name'];
									$class_id=$class_id.",".$st_terms['class_id'];
								}
							}
						}
						if($st_terms['main_level_id']!="0"&&$st_terms['main_level_id']!="")
						{
							$cond="select name from main_levels where id=".$st_terms['main_level_id'];
							$study_level_details = $this->students_model->special_fetch($cond);
							if(count($study_level_details)>0)
							{
								if($study_level=="")
								{
									$study_level=$study_level_details[0]['name'];
									$main_level_id=$st_terms['main_level_id'];
								}
								else
								{
									$study_level=$study_level.",".$study_level_details[0]['name'];
									$main_level_id=$main_level_id.",".$st_terms['main_level_id'];
								}
							}
						}
						if($st_terms['coach_id']!="")
						{
							$cond="select first_name,last_name from users where id=".$st_terms['coach_id'];
							$tutor_details = $this->students_model->special_fetch($cond);
							if(count($tutor_details)>0)
							{
								if($tutor=="")
								{
									$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
									$coach_id=$st_terms['coach_id'];
								}
								else
								{
									$tutor=$tutor.",".$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
									$coach_id=$coach_id.",".$st_terms['coach_id'];
								}
							}	
						}
					}
				}
				$cond="select group_concat(s.post_school_career_goal_id) as career_goal_ids,group_concat(p.name) as career_goal_names from students_post_school_career_goals s,post_school_career_goals p where s.post_school_career_goal_id=p.id and  s.student_id=".$student['id'];
				$career_goals_details = $this->students_model->special_fetch($cond);
				$career_goal_ids=$career_goals_details[0]['career_goal_ids'];
				$career_goal_names=$career_goals_details[0]['career_goal_names'];
				$cond="select group_concat(s.intended_profession_id) as profession_ids,group_concat(i.name) as profession_names from students_intended_professions s,intended_professions i where s.intended_profession_id=i.id and s.student_id=".$student['id'];
				$profession_details = $this->students_model->special_fetch($cond);
				$profession_ids=$profession_details[0]['profession_ids'];
				$profession_names=$profession_details[0]['profession_names'];
				$cond="select group_concat(parent_id) as parent_ids,group_concat(relation) as relation_ids,group_concat(id) as student_parent_ids from students_parents where student_id=".$student['id'];
				$parent_details = $this->students_model->special_fetch($cond);
				$parent_ids=$parent_details[0]['parent_ids'];
				$relation_ids=$parent_details[0]['relation_ids'];
				$student_parent_ids=$parent_details[0]['student_parent_ids'];
				$parent_names="";
				if($parent_ids!="")
				{
					$parent_id_arr=explode(",",$parent_ids);
					foreach($parent_id_arr as $par)
					{
						$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$par;
						$par_details = $this->students_model->special_fetch($cond);
						if(count($par_details)>0)
							$parent_names=$parent_names.",".$par_details[0]['name'];					
					}
					$parent_names=trim($parent_names,",");
				}
				
				if($student['gender_id']!="")
				{
					$cond="select name from genders where id=".$student['gender_id'];
					$gender_details = $this->students_model->special_fetch($cond);
					$gender=$gender_details[0]['name'];
				}
				else
					$gender="";
				if($student['country']!="")
				{
					$cond="select name from countries where id=".$student['country'];
					$country_details = $this->students_model->special_fetch($cond);
					$country_name=$country_details[0]['name'];
				}
				else
					$country_name="";
				$cond="select d.id,d.document_unique_name from students_documents s,documents d where s.document_id=d.id and s.student_id=".$student['id'];
				$doc_details = $this->students_model->special_fetch($cond);
				$student_name=$student['first_name']." ".$student['last_name'];
				$student_all_details[]=array(
					"id"=>$student['id'],
					"profile_image"=>$student['avatar'],
					"name"=>$student_name,
					"username"=>$student['username'],
					"last_name"=>$student['last_name'],
					"first_name"=>$student['first_name'],
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"mobile_phone"=>$student['mobile_phone'],
					"email"=>$student['email'],
					"is_active"=>$student['is_active'],
					"is_finished_school"=>$student['is_finished_school'],
					"special_needs"=>$student['special_needs'],
					"gender_id"=>$student['gender_id'],
					"gender"=>$gender,
					"document_details"=>$doc_details,
					"country"=>$student['country'],
					"country_name"=>$country_name,
					"city"=>$student['city'],
					"address"=>$student['address'],
					"address2"=>$student['address2'],
					"zip"=>$student['zip'],
					"fixed_phone"=>$student['fixed_phone'],
					"birth_date"=>$student['birth_date'],
					"remarks"=>$student['remarks'],
					"detailed_career_goals"=>$student['detailed_career_goals'],
					"personal_weaknesses"=>$student['personal_weaknesses'],
					"personal_strengths"=>$student['personal_strengths'],
					"has_smoking_permission"=>$student['has_smoking_permission'],
					"has_outgoing_permission"=>$student['has_outgoing_permission'],
					"other_permissions"=>$student['other_permissions'],
					"admission"=>$student['admission'],
					"emission"=>$student['emission'],
					"is_deleted"=>$student['is_deleted'],
					"career_goal_ids"=>$career_goal_ids,
					"profession_ids"=>$profession_ids,
					"career_goal_names"=>$career_goal_names,
					"profession_names"=>$profession_names,
					"parent_ids"=>$parent_ids,
					"student_parent_ids"=>$student_parent_ids,
					"parent_names"=>$parent_names,
					"relation_ids"=>$relation_ids,
					"term_id"=>$term_id,
					"class_id"=>$class_id,
					"main_level_id"=>$main_level_id,
					"coach_id"=>$coach_id
				);
			}
			
			$totalRecordwithFilter = $totalRecord;
			$student_filter_details=array();
			$filter_count=0;
			if($grade_fld!=""||$teacher_fld!=""||$study_level_fld!="")
			{
				for($i=0;$i<count($student_all_details);$i++)
				{
					$grade_flag=true;$teacher_flag=true;$study_level_flag=true;
					if($grade_fld!="")
					{
						$grade_arr=explode(',',$student_all_details[$i]['class_id']);
						if (!in_array($grade_fld, $grade_arr)) 
							$grade_flag=false;
					}
					if($teacher_fld!="")
					{
						$teacher_arr=explode(',',$student_all_details[$i]['coach_id']);
						if (!in_array($teacher_fld, $teacher_arr)) 
							$teacher_flag=false;
					}
					if($study_level_fld!="")
					{
						$study_level_arr=explode(',',$student_all_details[$i]['main_level_id']);
						if (!in_array($study_level_fld, $study_level_arr)) 
							$study_level_flag=false;
					}
					if($grade_flag&&$teacher_flag&&$study_level_flag)
					{
						$student_filter_details[]=$student_all_details[$i];
					}
				}
				$filter_count=count($student_filter_details);
			}
			else
			{
				$student_filter_details=$student_all_details;
			}
			$search_count=0;
			$students_details=array();
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				for($i=0;$i<count($student_filter_details);$i++)
				{
					if(strpos(strtolower($student_filter_details[$i]['name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['mobile_phone']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['email']), $searchValue) !== false)
					{
						$students_details[]=$student_filter_details[$i];
					}
				}
				$search_count=count($students_details);
			}
			else{
				$students_details=$student_filter_details;
			}
			if($filter_count==0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			else if($filter_count!=0&&$search_count==0)
				$totalRecordwithFilter=$filter_count;
			else if($filter_count!=0&&$search_count!=0)
				$totalRecordwithFilter=$search_count;
			if($totalRecord=="")
				$totalRecord=0;
			if(count($students_details)<=0)
			{
				$students_details=array();
				$totalRecord=0;
				$totalRecordwithFilter=0;
			}
			else
			{
				foreach ($students_details as $key => $row)
				{
					$wek[$key]  = $row[$columnName];
				}  
				if($columnSortOrder=='asc')
					$sort=SORT_ASC;
				else
					$sort=SORT_DESC;
				array_multisort($wek, $sort, $students_details);
			}
			$output = array_slice($students_details, $start, $rowperpage);
			$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
		}
		else
		{
			$output=array();
			$out = array('statuscode'=>'200','totalRecord'=>0,'totalRecordwithFilter'=>0,'page_details'=>$output);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_student_assignments(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$student_id = $data['student_id'];
		$term_details=array();
		if($student_id!="")
		{
			$cond="select * from students_terms where student_id=".$student_id." and is_active=1";
			$page_details = $this->users_model->special_fetch($cond);
			foreach($page_details as $page)
			{
				if($page['term_id']!="")
				{
					$cond="select name from terms where id=".$page['term_id'];
					$class_details = $this->students_model->special_fetch($cond);
					if(count($class_details)>0)
						$term=$class_details[0]['name'];
					else
						$term="";
				}
				else
					$term="";
				if($page['class_id']!="")
				{
					$cond="select name from classes where id=".$page['class_id'];
					$class_details = $this->students_model->special_fetch($cond);
					if(count($class_details)>0)
						$grade=$class_details[0]['name'];
					else
						$grade="";
				}
				else
					$grade="";
				if($page['main_level_id']!="")
				{
					$cond="select name from main_levels where id=".$page['main_level_id'];
					$study_level_details = $this->students_model->special_fetch($cond);
					if(count($study_level_details)>0)
						$study_level=$study_level_details[0]['name'];
					else
						$study_level="";
				}
				else
					$study_level="";
				if($page['coach_id']!="")
				{
					$cond="select first_name,last_name from users where id=".$page['coach_id'];
					$tutor_details = $this->students_model->special_fetch($cond);
					if(count($tutor_details)>0)
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					else
						$tutor="";
				}
				else
					$tutor="";
				$term_details[]=array(
					"term"=>$term,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor
				);
			}
		}
		$totalRecord=0;
		$totalRecordwithFilter=0;
		if(count($term_details)<=0)
			$term_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$term_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function randomPassword($num) {
        $alphabet = '1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < $num; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
	function add_students(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);  
		$id = $data['id'];
		$avatar = $data['avatar'];
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$salt = $data['salt'];
		$password = $data['password'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$birth_date = $data['birth_date'];
		$admission = $data['admission'];
		$emission = $data['emission'];
		$parent_info = $data['parent_info'];
		$profession_id = $data['profession_id'];
		$post_school_career_goals_id = $data['post_school_career_goals_id'];
		$remarks = $data['remarks'];
		$detailed_career_goals = $data['detailed_career_goals'];
		$personal_weaknesses = $data['personal_weaknesses'];
		$personal_strengths = $data['personal_strengths'];
		$has_smoking_permission = $data['has_smoking_permission'];
		$has_outgoing_permission = $data['has_outgoing_permission'];
		$other_permissions = $data['other_permissions'];
		$new_assignment = $data['new_assignment'];
		$term_id = $data['term_id'];
		$grade_id = $data['grade_id'];
		$teacher_id = $data['teacher_id'];
		$study_level_id = $data['study_level_id'];
		if($study_level_id=='')
			$study_level_id=0;
		$document_ids = $data['document_ids'];
		$resigned = $data['resigned'];
		$special_needs = $data['special_needs'];
		$status = $data['status'];
		$no_email = $data['no_email'];
		$data_arr=array(
				'username'=>$email
			);
        $students_details = $this->users_model->get_records($data_arr);
		if($id=="")
		{
			if(count($students_details)<=0)
			{
				if($no_email==1)
				{
					$num=$this->randomPassword(5);
					$username="NR".$num;
					$salt=$username;
        			$password=md5($salt);
					$email="";
				}
				else
				{
					$username=$email;
				}
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'salt'=>$salt,
					'password'=>$password,
					'is_active'=>$status,
					'entity_class'=>'studententity',
					'created_at'=>time()
				);
				$id = $this->users_model->add($input);								
				$input = array(
					'id'=>$id,
					'gender_id'=>$gender_id,
					'city'=>$city,
					'country'=>$country,
					'zip'=>$zip,
					'address'=>$address,
					'address2'=>$address2,
					'mobile_phone'=>$mobile_phone,
					'fixed_phone'=>$fixed_phone,
					'birth_date'=>$birth_date,
					'admission'=>$admission,
					'emission'=>$emission,
					'remarks'=>$remarks,
					'detailed_career_goals'=>$detailed_career_goals,
					'personal_weaknesses'=>$personal_weaknesses,
					'personal_strengths'=>$personal_strengths,
					'has_smoking_permission'=>$has_smoking_permission,
					'has_outgoing_permission'=>$has_outgoing_permission,
					'other_permissions'=>$other_permissions,
					'special_needs'=>$special_needs,
					'is_finished_school'=>$resigned
				);
				$this->students_model->add($input);
				$profession_id_arr=explode(",",$profession_id);
				foreach($profession_id_arr as $profession)
				{
					if($profession!="")
					{
						$input = array(
							'student_id'=>$id,
							'intended_profession_id'=>$profession
						);
						$this->students_in_profession_model->add($input);
					}
				}
				$post_school_career_goals_id_arr=explode(",",$post_school_career_goals_id);
				foreach($post_school_career_goals_id_arr as $career_goal)
				{
					if($career_goal!="")
					{
						$input = array(
							'student_id'=>$id,
							'post_school_career_goal_id'=>$career_goal
						);
						$this->students_post_career_goals_model->add($input);
					}
				}
				foreach($parent_info as $parent)
				{
					if($parent['parent_name']!=""&&$parent['relation']!="")
					{
						$input = array(
							'student_id'=>$id,
							'parent_id'=>$parent['parent_name'],
							'relation'=>$parent['relation']
						);
						$this->students_parents_model->add($input);
					}
				}
				if($new_assignment==1)
				{
					$input = array(
						'student_id'=>$id,
						'term_id'=>$term_id,
						'class_id'=>$grade_id,
						'main_level_id'=>$study_level_id,
						'coach_id  '=>$teacher_id,
						'created_at'=>time()
					);
					$this->students_terms_model->add($input);
				}
				$input = array(
					'user_id'=>$id,
					'group_id'=>5
				);
				$this->user_groups_model->add($input);
				if($no_email==0)
					$this->send_registration_mail($id,$first_name,$last_name,$email,$salt);
				$out = array('statuscode'=>'200','id'=>$id,'statusdescription'=>$label_details[286]['name']);
			}  
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[430]['name']);
			}
		}
		else
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$this->users_model->edit($input,$id);
			$input = array(
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'birth_date'=>$birth_date,
				'admission'=>$admission,
				'emission'=>$emission,
				'remarks'=>$remarks,
				'detailed_career_goals'=>$detailed_career_goals,
				'personal_weaknesses'=>$personal_weaknesses,
				'personal_strengths'=>$personal_strengths,
				'has_smoking_permission'=>$has_smoking_permission,
				'has_outgoing_permission'=>$has_outgoing_permission,
				'other_permissions'=>$other_permissions,
				'special_needs'=>$special_needs,
				'is_finished_school'=>$resigned
			);
			$this->students_model->edit($input,$id);
			//Intended Professions Update
			$new_profession_id_arr=explode(",",$profession_id);
			$cond="select group_concat(intended_profession_id) as profession_id from students_intended_professions where student_id=".$id;
			$prof_details = $this->students_model->special_fetch($cond);
			$old_profession_id_arr=explode(",",$prof_details[0]['profession_id']);
			$new_arr=array_diff($new_profession_id_arr,$old_profession_id_arr);
			$old_arr=array_diff($old_profession_id_arr,$new_profession_id_arr);
			foreach($new_arr as $profession_id)
			{
				if($profession_id!="")
				{
					$input = array(
						'student_id'=>$id,
						'intended_profession_id'=>$profession_id
					);
					$this->students_in_profession_model->add($input);
				}
			}
			foreach($old_arr as $profession_id)
			{
				if($profession_id!="")
				{
					$cond="select id from students_intended_professions where student_id=".$id." and intended_profession_id=".$profession_id;
					$prof_details = $this->students_model->special_fetch($cond);
					$this->students_in_profession_model->delete($prof_details[0]['id']);
				}
			}
			//Career Goals Update
			$new_career_goals_id_arr=explode(",",$post_school_career_goals_id);
			$cond="select group_concat(post_school_career_goal_id) as career_goal_id from students_post_school_career_goals where student_id=".$id;
			$prof_details = $this->students_model->special_fetch($cond);
			$old_career_goals_id_arr=explode(",",$prof_details[0]['career_goal_id']);
			$new_arr=array_diff($new_career_goals_id_arr,$old_career_goals_id_arr);
			$old_arr=array_diff($old_career_goals_id_arr,$new_career_goals_id_arr);
			foreach($new_arr as $career_goal_id)
			{
				if($career_goal_id!="")
				{
					$input = array(
						'student_id'=>$id,
						'post_school_career_goal_id'=>$career_goal_id
					);
					$this->students_post_career_goals_model->add($input);
				}
			}
			foreach($old_arr as $career_goal_id)
			{
				if($career_goal_id!="")
				{
					$cond="select id from students_post_school_career_goals where student_id=".$id." and post_school_career_goal_id=".$career_goal_id;
					$prof_details = $this->students_model->special_fetch($cond);
					$this->students_post_career_goals_model->delete($prof_details[0]['id']);
				}
			}
			//Parents Update
			$this->students_parents_model->delete($id);
			foreach($parent_info as $parent)
			{
				if($parent['parent_name']!=""&&$parent['relation']!="")
				{
					$input = array(
						'student_id'=>$id,
						'parent_id'=>$parent['parent_name'],
						'relation'=>$parent['relation']
					);
					$this->students_parents_model->add($input);
				}
			}
			if($new_assignment==1)
			{
				$cond="select id from students_terms where student_id=".$id." and term_id=".$term_id;
				$prof_details = $this->students_model->special_fetch($cond);
				if(count($prof_details)>0)
				{
					$input = array(
						'student_id'=>$id,
						'term_id'=>$term_id,
						'class_id'=>$grade_id,
						'main_level_id'=>$study_level_id,
						'coach_id'=>$teacher_id
					);
					$this->students_terms_model->edit_student($input);
				}
				else
				{
					$input = array(
						'student_id'=>$id,
						'term_id'=>$term_id,
						'class_id'=>$grade_id,
						'main_level_id'=>$study_level_id,
						'coach_id'=>$teacher_id,
						'created_at'=>time()
					);
					$this->students_terms_model->add($input);
				}				
			}
			$doc_arr=explode(",",$document_ids);
			foreach($doc_arr as $doc)
			{
				if($doc!="")
				{
					$cond="select id from students_documents where student_id=".$id." and document_id=".$doc;
					$doc_details = $this->students_model->special_fetch($cond);
					if(count($doc_details)<=0)
					{
						$input = array(
							'student_id'=>$id,
							'document_id'=>$doc
						);
						$this->students_documents_model->add($input);
					}
				}
			}
			$out = array('statuscode'=>'200','id'=>$id);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_students(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$id = $data['id'];
		$avatar = $data['avatar'];
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$salt = $data['salt'];
		$password = $data['password'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$birth_date = $data['birth_date'];
		$admission = $data['admission'];
		$emission = $data['emission'];
		$parent_info = $data['parent_info'];
		$profession_id = $data['profession_id'];
		$post_school_career_goals_id = $data['post_school_career_goals_id'];
		$remarks = $data['remarks'];
		$detailed_career_goals = $data['detailed_career_goals'];
		$personal_weaknesses = $data['personal_weaknesses'];
		$personal_strengths = $data['personal_strengths'];
		$has_smoking_permission = $data['has_smoking_permission'];
		$has_outgoing_permission = $data['has_outgoing_permission'];
		$other_permissions = $data['other_permissions'];
		$new_assignment = $data['new_assignment'];
		$term_id = $data['term_id'];
		$grade_id = $data['grade_id'];
		$teacher_id = $data['teacher_id'];
		$study_level_id = $data['study_level_id'];
		$document_ids = $data['document_ids'];
		$resigned = $data['resigned'];
		$special_needs = $data['special_needs'];
		$no_email = $data['no_email'];
		$status = $data['status'];
		$cond="select id from users where username='".$email."' and id<>".$id;
        $career_details = $this->students_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'avatar'=>$avatar,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$mid = $this->users_model->edit($input,$id);
			$input = array(
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'birth_date'=>$birth_date,
				'admission'=>$admission,
				'emission'=>$emission,
				'remarks'=>$remarks,
				'detailed_career_goals'=>$detailed_career_goals,
				'personal_weaknesses'=>$personal_weaknesses,
				'personal_strengths'=>$personal_strengths,
				'has_smoking_permission'=>$has_smoking_permission,
				'has_outgoing_permission'=>$has_outgoing_permission,
				'other_permissions'=>$other_permissions,
				'special_needs'=>$special_needs,
				'is_finished_school'=>$resigned
			);
			$this->students_model->edit($input,$id);
			//Intended Professions Update
			$new_profession_id_arr=explode(",",$profession_id);
			$cond="select group_concat(intended_profession_id) as profession_id from students_intended_professions where student_id=".$id;
			$prof_details = $this->students_model->special_fetch($cond);
			$old_profession_id_arr=explode(",",$prof_details[0]['profession_id']);
			$new_arr=array_diff($new_profession_id_arr,$old_profession_id_arr);
			$old_arr=array_diff($old_profession_id_arr,$new_profession_id_arr);
			foreach($new_arr as $profession_id)
			{
				if($profession_id!="")
				{
					$input = array(
						'student_id'=>$id,
						'intended_profession_id'=>$profession_id
					);
					$this->students_in_profession_model->add($input);
				}
			}
			foreach($old_arr as $profession_id)
			{
				if($profession_id!="")
				{
					$cond="select id from students_intended_professions where student_id=".$id." and intended_profession_id=".$profession_id;
					$prof_details = $this->students_model->special_fetch($cond);
					$this->students_in_profession_model->delete($prof_details[0]['id']);
				}
			}
			//Career Goals Update
			$new_career_goals_id_arr=explode(",",$post_school_career_goals_id);
			$cond="select group_concat(post_school_career_goal_id) as career_goal_id from students_post_school_career_goals where student_id=".$id;
			$prof_details = $this->students_model->special_fetch($cond);
			$old_career_goals_id_arr=explode(",",$prof_details[0]['career_goal_id']);
			$new_arr=array_diff($new_career_goals_id_arr,$old_career_goals_id_arr);
			$old_arr=array_diff($old_career_goals_id_arr,$new_career_goals_id_arr);
			foreach($new_arr as $career_goal_id)
			{
				if($career_goal_id!="")
				{
					$input = array(
						'student_id'=>$id,
						'post_school_career_goal_id'=>$career_goal_id
					);
					$this->students_post_career_goals_model->add($input);
				}
			}
			foreach($old_arr as $career_goal_id)
			{
				if($career_goal_id!="")
				{
					$cond="select id from students_post_school_career_goals where student_id=".$id." and post_school_career_goal_id=".$career_goal_id;
					$prof_details = $this->students_model->special_fetch($cond);
					$this->students_post_career_goals_model->delete($prof_details[0]['id']);
				}
			}
			//Parents Update
			$new_parent_id_arr=array();
			$new_id_arr=array();
			foreach($parent_info as $parent)
			{
				$new_parent_id_arr[]=$parent['parent_name'];
				if($parent['student_parent']!="")
					$new_id_arr[]=$parent['student_parent'];
			}
			$cond="select group_concat(distinct parent_id) as parent_id from students_parents where student_id=".$id;
			$prof_details = $this->students_model->special_fetch($cond);
			$old_parent_id_arr=explode(",",$prof_details[0]['parent_id']);
			$new_arr=array_diff($new_parent_id_arr,$old_parent_id_arr);
			$old_arr=array_diff($old_parent_id_arr,$new_parent_id_arr);
			$common_arr=array_intersect($new_parent_id_arr,$old_parent_id_arr);
			foreach($new_arr as $parent_id)
			{
				foreach($parent_info as $parent)
				{
					if($parent['parent_name']==$parent_id)
					{
						$input = array(
							'student_id'=>$id,
							'parent_id'=>$parent['parent_name'],
							'relation'=>$parent['relation']
						);
						$this->students_parents_model->add($input);
					}
				}				
			}
			foreach($new_id_arr as $parent_id)
			{
				foreach($parent_info as $parent)
				{
					if($parent['student_parent']==$parent_id)
					{
						$input = array(
							'parent_id'=>$parent['parent_name'],
							'relation'=>$parent['relation']
						);
						$this->students_parents_model->edit($input,$parent['student_parent']);
					}
				}
			}
			foreach($old_arr as $parent_id)
			{
				if($parent_id!="")
				{
					$cond="select id from students_parents where student_id=".$id." and parent_id=".$parent_id;
					$prof_details = $this->students_model->special_fetch($cond);
					if(count($prof_details)>0)
					{
						$this->students_parents_model->delete($prof_details[0]['id']);
					}
				}
			}
			if($new_assignment==1)
			{
				if($study_level_id=="")
					$study_level_id=0;
				$cond="select id from students_terms where student_id=".$id." and term_id=".$term_id." and class_id=".$grade_id;
				$student_term_details = $this->students_terms_model->special_fetch($cond);
				if(count($student_term_details)<=0)
				{
					$input = array(
						'student_id'=>$id,
						'term_id'=>$term_id,
						'class_id'=>$grade_id,
						'coach_id'=>$teacher_id,
						'main_level_id'=>$study_level_id
					);
					$this->students_terms_model->add($input);
				}			
			}
			$doc_arr=explode(",",$document_ids);
			foreach($doc_arr as $doc)
			{
				if($doc!="")
				{
					$cond="select id from students_documents where student_id=".$id." and document_id=".$doc;
					$doc_details = $this->students_model->special_fetch($cond);
					if(count($doc_details)<=0)
					{
						$input = array(
							'student_id'=>$id,
							'document_id'=>$doc
						);
						$this->students_documents_model->add($input);
					}
				}
			}
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[431]['name']);			
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[432]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_students(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id']; 
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select concat(first_name,' ',last_name) as name from users where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from meeting_items_responsible_students where student_id=".$id;
			$ab_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from students_intended_professions	where student_id=".$id;
			$inp_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from students_parents where student_id=".$id;
			$par_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from students_post_school_career_goals	where student_id=".$id;
			$pos_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from students_terms where student_id=".$id;
			$ter_details = $this->subject_types_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($inp_details)<=0&&count($par_details)<=0&&count($pos_details)<=0&&count($ter_details)<=0)
			{
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->students_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[289]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[352]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);               
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_students(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->students_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[290]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_students(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from users where id=".$id;
			$stat_details = $this->students_model->special_fetch($cond);
			if($stat_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->users_model->edit($input,$id);	
			$cond="select is_finished_school from students where id=".$id;
			$st_details = $this->students_model->special_fetch($cond);
			if($stat_details[0]['is_active']==0)
			{
				if($st_details[0]['is_finished_school']==1)
				{
					$input = array(
						'is_finished_school'=>0
					);
					$this->students_model->edit($input,$id);
				}
			}		
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[291]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function set_resigned_students(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id']; 
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_finished_school from students where id=".$id;
			$stat_details = $this->students_model->special_fetch($cond);
			if($stat_details[0]['is_finished_school']==0)
			{
				$status=1;
			}
			else
			{
				$status=0;
			}
			$input = array(
				'is_finished_school'=>$status
			);
			$this->students_model->edit($input,$id);
			if($stat_details[0]['is_finished_school']==0)
			{
				$cond="select is_active from users where id=".$id;
				$st_details = $this->students_model->special_fetch($cond);
				if($st_details[0]['is_active']==1)
				{
					$input = array(
						'is_active'=>0
					);
					$this->users_model->edit($input,$id);
				}
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[292]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_parent_info(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$par_id = $data['par_id'];
		$cond="select u.last_name,u.first_name,u.email,p.city,p.zip,p.address,p.mobile_phone from users u,personnel p where u.id=p.id and u.id=".$par_id;
		$user_details = $this->students_model->special_fetch($cond);
		$out = array('statuscode'=>'200','user_details'=>$user_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_students(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']==""||$page['first_name']==""||$page['birth_date']==""||$page['gender']==""||$page['country']==""||$page['admission']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['first_name'];
				$corrupt_arr[] =$page['email'];
				$corrupt_arr[] =$page['gender'];
				$corrupt_arr[] =$page['birth_date'];
				$corrupt_arr[] =$page['admission'];
				$corrupt_arr[] =$page['parent'];
				$corrupt_arr[] =$page['relation'];
				$corrupt_arr[] =$page['country'];
				$corrupt_arr[] =$page['emission'];
				$corrupt_arr[] =$page['city'];
				$corrupt_arr[] =$page['address'];
				$corrupt_arr[] =$page['zip'];
				$corrupt_arr[] =$page['address2'];
				$corrupt_arr[] =$page['mobile_phone'];
				$corrupt_arr[] =$page['fixed_phone'];
				$corrupt_arr[] =$page['profession'];
				$corrupt_arr[] =$page['career_goal'];
				$corrupt_arr[] =$page['remarks'];
				$corrupt_arr[] =$page['detailed_career_goals'];
				$corrupt_arr[] =$page['personal_weaknesses'];
				$corrupt_arr[] =$page['personal_strengths'];
				$corrupt_arr[] =$page['has_smoking_permission'];
				$corrupt_arr[] =$page['has_outgoing_permission'];
				$corrupt_arr[] =$page['other_permissions'];
				$corrupt_arr[] =$page['new_assignment'];
				$corrupt_arr[] =$page['term'];
				$corrupt_arr[] =$page['grade'];
				$corrupt_arr[] =$page['tutor'];
				$corrupt_arr[] =$page['study_level'];
				$corrupt_arr[] =$page['resigned'];
				$corrupt_arr[] =$page['special_needs'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[303]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['new_assignment']=="1"&&($page['term']==""||$page['grade']==""||$page['tutor']==""||$page['study_level']==""))
				{
					$corrupt_arr=array();
					$corrupt_arr[] =$page['name'];
					$corrupt_arr[] =$page['first_name'];
					$corrupt_arr[] =$page['email'];
					$corrupt_arr[] =$page['gender'];
					$corrupt_arr[] =$page['birth_date'];
					$corrupt_arr[] =$page['admission'];
					$corrupt_arr[] =$page['parent'];
					$corrupt_arr[] =$page['relation'];
					$corrupt_arr[] =$page['country'];
					$corrupt_arr[] =$page['emission'];
					$corrupt_arr[] =$page['city'];
					$corrupt_arr[] =$page['address'];
					$corrupt_arr[] =$page['zip'];
					$corrupt_arr[] =$page['address2'];
					$corrupt_arr[] =$page['mobile_phone'];
					$corrupt_arr[] =$page['fixed_phone'];
					$corrupt_arr[] =$page['profession'];
					$corrupt_arr[] =$page['career_goal'];
					$corrupt_arr[] =$page['remarks'];
					$corrupt_arr[] =$page['detailed_career_goals'];
					$corrupt_arr[] =$page['personal_weaknesses'];
					$corrupt_arr[] =$page['personal_strengths'];
					$corrupt_arr[] =$page['has_smoking_permission'];
					$corrupt_arr[] =$page['has_outgoing_permission'];
					$corrupt_arr[] =$page['other_permissions'];
					$corrupt_arr[] =$page['new_assignment'];
					$corrupt_arr[] =$page['term'];
					$corrupt_arr[] =$page['grade'];
					$corrupt_arr[] =$page['tutor'];
					$corrupt_arr[] =$page['study_level'];
					$corrupt_arr[] =$page['resigned'];
					$corrupt_arr[] =$page['special_needs'];
					$corrupt_arr[] =$page['status'];
					$corrupt_arr[] =$label_details[303]['name'];
					$corrupt[$r]=$corrupt_arr;
					$r++;
				}
				else
				{
					if($page['email']=="")
					{
						$pg_details=array();
					}
					else
					{
						$cond="select id from users where email='".$page['email']."'";
						$pg_details = $this->students_model->special_fetch($cond);
					}
					if(count($pg_details)>0)
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['first_name'];
						$error_arr[] =$page['email'];
						$error_arr[] =$page['gender'];
						$error_arr[] =$page['birth_date'];
						$error_arr[] =$page['admission'];
						$error_arr[] =$page['parent'];
						$error_arr[] =$page['relation'];
						$error_arr[] =$page['country'];
						$error_arr[] =$page['emission'];
						$error_arr[] =$page['city'];
						$error_arr[] =$page['address'];
						$error_arr[] =$page['zip'];
						$error_arr[] =$page['address2'];
						$error_arr[] =$page['mobile_phone'];
						$error_arr[] =$page['fixed_phone'];
						$error_arr[] =$page['profession'];
						$error_arr[] =$page['career_goal'];
						$error_arr[] =$page['remarks'];
						$error_arr[] =$page['detailed_career_goals'];
						$error_arr[] =$page['personal_weaknesses'];
						$error_arr[] =$page['personal_strengths'];
						$error_arr[] =$page['has_smoking_permission'];
						$error_arr[] =$page['has_outgoing_permission'];
						$error_arr[] =$page['other_permissions'];
						$error_arr[] =$page['new_assignment'];
						$error_arr[] =$page['term'];
						$error_arr[] =$page['grade'];
						$error_arr[] =$page['tutor'];
						$error_arr[] =$page['study_level'];
						$error_arr[] =$page['resigned'];
						$error_arr[] =$page['special_needs'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[433]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						$admission_date=false;$birth_date=false;
						if($page['admission']!='')
						{
							$date = DateTime::createFromFormat('d-m-Y', $page['admission']);
							if (!$date) {
								$date = DateTime::createFromFormat('d/m/Y',  $page['admission']);
							}
							if (!$date) {
								$admission_date=true;
							} 
						}
						if($page['birth_date']!='')
						{
							$date = DateTime::createFromFormat('d-m-Y', $page['birth_date']);
							if (!$date) {
								$date = DateTime::createFromFormat('d/m/Y',  $page['birth_date']);
							}
							if (!$date) {
								$birth_date=true;
							} 
						}
						if($page['profession_id']==""&&$page['profession']!="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[293]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['gender_id']=="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[294]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}					
						else if($page['country_id']=="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[295]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['career_goal_id']==""&&$page['career_goal']!="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[296]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($admission_date)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[448]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($birth_date)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[449]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['term_id']==""&&$page['new_assignment_val']==1)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[298]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['grade_id']==""&&$page['new_assignment_val']==1)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[299]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['tutor_id']==""&&$page['new_assignment_val']==1)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[300]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['study_level_id']==""&&$page['new_assignment_val']==1)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['parent'];
							$error_arr[] =$page['relation'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['profession'];
							$error_arr[] =$page['career_goal'];
							$error_arr[] =$page['remarks'];
							$error_arr[] =$page['detailed_career_goals'];
							$error_arr[] =$page['personal_weaknesses'];
							$error_arr[] =$page['personal_strengths'];
							$error_arr[] =$page['has_smoking_permission'];
							$error_arr[] =$page['has_outgoing_permission'];
							$error_arr[] =$page['other_permissions'];
							$error_arr[] =$page['new_assignment'];
							$error_arr[] =$page['term'];
							$error_arr[] =$page['grade'];
							$error_arr[] =$page['tutor'];
							$error_arr[] =$page['study_level'];
							$error_arr[] =$page['resigned'];
							$error_arr[] =$page['special_needs'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[301]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else
						{
							if($page['email']=="")
							{
								$num=$this->randomPassword(5);
								$username="NR".$num;
								$page['salt']=$username;
								$page['password']=md5($page['salt']);
							}
							else
							{
								$username=$page['email'];
							}
							$input = array(
								'last_name'=>$page['name'],
								'first_name'=>$page['first_name'],
								'email'=>$page['email'],
								'username'=>$username,
								'salt'=>$page['salt'],
								'password'=>$page['password'],
								'is_active'=>$page['status_val'],
								'entity_class'=>'studententity',
								'created_at'=>time()
							);
							$id = $this->users_model->add($input);								
							$input = array(
								'id'=>$id,
								'gender_id'=>$page['gender_id'],
								'city'=>$page['city'],
								'country'=>$page['country_id'],
								'zip'=>$page['zip'],
								'address'=>$page['address'],
								'address2'=>$page['address2'],
								'mobile_phone'=>$page['mobile_phone'],
								'fixed_phone'=>$page['fixed_phone'],
								'birth_date'=>$page['birth_date'],
								'admission'=>$page['admission'],
								'emission'=>$page['emission'],
								'remarks'=>$page['remarks'],
								'detailed_career_goals'=>$page['detailed_career_goals'],
								'personal_weaknesses'=>$page['personal_weaknesses'],
								'personal_strengths'=>$page['personal_strengths'],
								'has_smoking_permission'=>$page['has_smoking_permission_val'],
								'has_outgoing_permission'=>$page['has_outgoing_permission_val'],
								'other_permissions'=>$page['other_permissions'],
								'special_needs'=>$page['special_needs_val'],
								'is_finished_school'=>$page['resigned_val']
							);
							$this->students_model->add($input);
							$profession_id_arr=explode(",",$page['profession_id']);
							foreach($profession_id_arr as $profession)
							{
								if($profession!="")
								{
									$input = array(
										'student_id'=>$id,
										'intended_profession_id'=>$profession
									);
									$this->students_in_profession_model->add($input);
								}
							}
							$post_school_career_goals_id_arr=explode(",",$page['career_goal_id']);
							foreach($post_school_career_goals_id_arr as $career_goal)
							{
								if($career_goal!="")
								{
									$input = array(
										'student_id'=>$id,
										'post_school_career_goal_id'=>$career_goal
									);
									$this->students_post_career_goals_model->add($input);
								}
							}
							$parent_arr=explode(",",$page['parent_ids']);
							$relation_arr=explode(",",$page['relation']);
							for($i=0;$i<count($parent_arr);$i++)
							{
								if($parent_arr[$i]!="")
								{
									$input = array(
										'student_id'=>$id,
										'parent_id'=>$parent_arr[$i],
										'relation'=>$relation_arr[$i]
									);
									$this->students_parents_model->add($input);
								}
							}
							if($page['new_assignment_val']==1)
							{
								$input = array(
									'student_id'=>$id,
									'term_id'=>$page['term_id'],
									'class_id'=>$page['grade_id'],
									'main_level_id'=>$page['study_level_id'],
									'coach_id'=>$page['tutor_id'],
									'created_at'=>time()
								);
								$this->students_terms_model->add($input);
							}
							$input = array(
								'user_id'=>$id,
								'group_id'=>5
							);
							$this->user_groups_model->add($input);
							if($page['email']!="")
								$this->send_registration_mail($id,$page['first_name'],$page['name'],$page['email'],$page['salt']);
							$flag=true;
						}
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[302]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function get_grades(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from classes where is_deleted=0 and is_active=1 ORDER BY LPAD(lower(name), 6,0) asc";
		$grade_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','grade_details'=>$grade_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_study_level(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from main_levels where is_deleted=0 and is_active=1 order by name asc";
		$study_level_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','study_level_details'=>$study_level_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_parents(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$cond="select u.id,CONCAT(u.first_name, ' ', u.last_name) as name from users u,personnel p,user_groups ug where u.id=p.id and ug.user_id=u.id and ug.group_id=4 and p.is_deleted=0 and u.is_active=1 order by name asc";
		$parent_details = $this->users_model->special_fetch($cond);
		$parent_info=array();
		
		foreach($parent_details as $parent)
		{
			if(strpos(strtolower($parent['name']), $search_term)!==false)
			{
				$parent_info[]=array(
					"id"=>$parent['id'],
					"name"=>$parent['name']
				);
			}
		}
		$total_count=count($parent_info);
		$out = array('total_count'=>$total_count,'items'=>$parent_info);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_professions(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from intended_professions where is_deleted=0 and is_active=1 order by name asc";
		$profession_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','profession_details'=>$profession_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_career_goals(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from post_school_career_goals where is_deleted=0 and is_active=1 order by name asc";
		$career_goal_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','career_goal_details'=>$career_goal_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_terms(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);	
		$out = array('statuscode'=>'200','term_details'=>$term_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function send_registration_mail($id,$first_name,$last_name,$email,$password) 
	{
		$cond="select s.key,s.value from system_settings s";
		$settings = $this->users_model->special_fetch($cond);
		$login_link='';
		foreach($settings as $set)
		{
			if($set['key']=='login-link')
				$login_link=$set['value'];
		}
		$html_content='';
		$cond="select * from email_templates_i18n where email_template_id=4 and language_id=1";
		$email_setting_details = $this->users_model->special_fetch($cond);
		if(count($email_setting_details)>0){
			$html_content=$email_setting_details[0]['html_content'];
			$html_content=str_replace("{FIRST_NAME}",$first_name,$html_content);
			$html_content=str_replace("{LAST_NAME}",$last_name,$html_content);
			$html_content=str_replace("{LOGIN_PAGE}",$login_link,$html_content);
			$html_content=str_replace("{USERNAME}",$email,$html_content);
			$html_content=str_replace("{PASSWORD}",$password,$html_content);
		}
		$formname = 'Proscola Admin';
		$formaddrs = $formname." <".$email_setting_details[0]['from'].">";
		$subject=$email_setting_details[0]['subject'];
		$to=$email;
		$this->send_mail($formaddrs,$to,$subject,$html_content);
    }
	function send_mail($formaddrs,$to,$subject,$html_content)
	{
		$params = array(
			'from'	=> $formaddrs,
			'to'	=> $to,
			'subject' => $subject,
			'html'	=> $html_content
		);
		$result=$this->mails->send_message($params);
		return $result;
	}
}
