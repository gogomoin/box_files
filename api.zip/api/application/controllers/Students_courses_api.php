<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Students_courses_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=36 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//students_courses
	function view_students_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$course_fld = $data['course_fld'];
		$student_fld = $data['student_fld'];
		$teacher_fld = $data['teacher_fld'];
		$grade_fld = $data['grade_fld'];
		$study_level_fld = $data['study_level_fld'];
		$searchQuery = "";
		$searchGroup = "";
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		if($term_fld=="")
		{
			$cond="select * from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
				$term_fld=$term_details[0]['id'];
			else
				$term_fld="";
		}
		/* if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		} */
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		$cond="SELECT * FROM course_attendants where is_active=1";
		$page_details = $this->students_courses_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$cond="select * from students_terms where id=".$student['student_term_id'];
			$student_term_details = $this->students_courses_model->special_fetch($cond);
			if(count($student_term_details)>0)
			{
				$term_id=$student_term_details[0]['term_id'];
				$student_id=$student_term_details[0]['student_id'];
				$class_id=$student_term_details[0]['class_id'];
				$main_level_id=$student_term_details[0]['main_level_id'];
				$coach_id=$student_term_details[0]['coach_id'];
				$cond="select name from courses where id=".$student['course_id'];
				$course_details = $this->students_courses_model->special_fetch($cond);
				$course=$course_details[0]['name'];
				$cond="select first_name,last_name from users where id=".$student_id;
				$stu_details = $this->students_courses_model->special_fetch($cond);
				$student_name=$stu_details[0]['first_name']." ".$stu_details[0]['last_name'];
				if($term_id!="")
				{
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_courses_model->special_fetch($cond);
					$term=$term_details[0]['name'];
				}
				else
					$term="";
				if($class_id!="")
				{
					$cond="select name from classes where id=".$class_id;
					$class_details = $this->students_courses_model->special_fetch($cond);
					$grade=$class_details[0]['name'];
				}
				else
					$grade="";
				if($main_level_id!="0"&&$main_level_id!="")
				{
					$cond="select name from main_levels where id=".$main_level_id;
					$study_level_details = $this->students_courses_model->special_fetch($cond);
					$study_level=$study_level_details[0]['name'];
				}
				else
					$study_level="";
				if($coach_id!="")
				{
					$cond="select first_name,last_name from users where id=".$coach_id;
					$tutor_details = $this->students_courses_model->special_fetch($cond);
					if(count($tutor_details)>0)
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					else
						$tutor="";
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"course"=>$course,
					"course_status_id"=>$student['student_course_status_id'],
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"course_id"=>$student['course_id'],
					"student_id"=>$student_id,
					"class_id"=>$class_id,
					"main_level_id"=>$main_level_id,
					"coach_id"=>$coach_id
				);
			}
		}
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($term_fld == ''){
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{
				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
		}
		if($grade_fld!=""||$teacher_fld!=""||$study_level_fld!=""||$term_fld!=""||$student_fld!=""||$course_fld!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;$course_flag=true;
				if($term_fld!="")
				{
					if($term_fld!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}				
				if($course_fld!="")
				{
					if($course_fld!=$student_all_details[$i]['course_id'])
						$course_flag=false;
				}
				if($student_fld!="")
				{
					if($student_fld!=$student_all_details[$i]['student_id'])
						$student_flag=false;
				}
				if($grade_fld!="")
				{
					if($grade_fld!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld!="")
				{
					if($teacher_fld!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld!="")
				{
					if($study_level_fld!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag&&$course_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		$search_count=0;
		$students_courses_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['course']), $searchValue) !== false)
				{
					$students_courses_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_courses_details);
		}
		else{
			$students_courses_details=$student_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_courses_details)<=0)
		{
			$students_courses_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($students_courses_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_courses_details);
		}
		$output = array_slice($students_courses_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_all_students_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld_list = $data['term_fld_list'];
		$student_fld_list = $data['student_fld_list'];
		$teacher_fld_list = $data['teacher_fld_list'];
		$grade_fld_list = $data['grade_fld_list'];
		$study_level_fld_list = $data['study_level_fld_list'];
		$selected_students_list = $data['selected_students_list'];
		if($selected_students_list!="")
			$student_terms_arr=explode(",",$selected_students_list);
		else
			$student_terms_arr=array();
		$cond="SELECT id,student_id,term_id,class_id,coach_id,main_level_id FROM students_terms";
		$student_term_details = $this->students_courses_model->special_fetch($cond);
		$student_all_details=array();
		foreach($student_term_details as $student_term)
		{
			if(!in_array($student_term['id'], $student_terms_arr))
			{ 	
				$cond="SELECT first_name,last_name FROM users where id=".$student_term['student_id'];
				$student_details = $this->students_courses_model->special_fetch($cond);
				$student_name=$student_details[0]['first_name']." ".$student_details[0]['last_name'];
				$term_id=$student_term['term_id'];
				$grade_id=$student_term['class_id'];
				$study_level_id=$student_term['main_level_id'];
				$tutor_id=$student_term['coach_id'];
				$cond="select name from terms where id=".$term_id;
				$term_details = $this->students_courses_model->special_fetch($cond);
				$term=$term_details[0]['name'];	
				if($term_id!="")
				{
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_courses_model->special_fetch($cond);
					$term=$term_details[0]['name'];
				}
				else
					$term="";			
				if($grade_id!="")
				{
					$cond="select name from classes where id=".$grade_id;
					$class_details = $this->students_courses_model->special_fetch($cond);
					$grade=$class_details[0]['name'];
				}
				else
					$grade="";
				if($study_level_id!="0"&&$study_level_id!="")
				{
					$cond="select name from main_levels where id=".$study_level_id;
					$study_level_details = $this->students_courses_model->special_fetch($cond);
					$study_level=$study_level_details[0]['name'];
				}
				else
					$study_level="";
				if($tutor_id!="")
				{
					$cond="select first_name,last_name from users where id=".$tutor_id;
					$tutor_details = $this->students_courses_model->special_fetch($cond);
					if(count($tutor_details)>0)
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					else
						$tutor="";
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student_term['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"student_id"=>$student_term['student_id'],
					"class_id"=>$grade_id,
					"main_level_id"=>$study_level_id,
					"coach_id"=>$tutor_id
				);
			}
		}
		
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		$totalRecord=count($student_all_details);
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($grade_fld_list!=""||$teacher_fld_list!=""||$study_level_fld_list!=""||$term_fld_list!=""||$student_fld_list!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;
				if($term_fld_list!="")
				{
					if($term_fld_list!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($student_fld_list!="")
				{
					if($student_fld_list!=$student_all_details[$i]['student_id'])
						$student_flag=false;
				}
				if($grade_fld_list!="")
				{
					if($grade_fld_list!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld_list!="")
				{
					if($teacher_fld_list!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld_list!="")
				{
					if($study_level_fld_list!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		$search_count=0;
		$students_courses_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_courses_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_courses_details);
		}
		else{
			$students_courses_details=$student_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_courses_details)<=0)
		{
			$students_courses_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($students_courses_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_courses_details);
		}
		$output = array_slice($students_courses_details, $limit, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_selected_students_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$selected_students_list = $data['selected_students_list'];
		$student_terms_arr=explode(",",$selected_students_list);
		$cond="SELECT id,student_id,term_id,class_id,coach_id,main_level_id FROM students_terms";
		$student_term_details = $this->students_courses_model->special_fetch($cond);
		$student_all_details=array();
		foreach($student_term_details as $student_term)
		{
			if(in_array($student_term['id'], $student_terms_arr))
			{ 	
				$cond="SELECT first_name,last_name FROM users where id=".$student_term['student_id'];
				$student_details = $this->students_courses_model->special_fetch($cond);
				$student_name=$student_details[0]['first_name']." ".$student_details[0]['last_name'];
				$term_id=$student_term['term_id'];
				$grade_id=$student_term['class_id'];
				$study_level_id=$student_term['main_level_id'];
				$tutor_id=$student_term['coach_id'];
				$cond="select name from terms where id=".$term_id;
				$term_details = $this->students_courses_model->special_fetch($cond);
				$term=$term_details[0]['name'];	
				if($term_id!="")
				{
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_courses_model->special_fetch($cond);
					$term=$term_details[0]['name'];
				}
				else
					$term="";			
				if($grade_id!="")
				{
					$cond="select name from classes where id=".$grade_id;
					$class_details = $this->students_courses_model->special_fetch($cond);
					$grade=$class_details[0]['name'];
				}
				else
					$grade="";
				if($study_level_id!="0"&&$study_level_id!="")
				{
					$cond="select name from main_levels where id=".$study_level_id;
					$study_level_details = $this->students_courses_model->special_fetch($cond);
					$study_level=$study_level_details[0]['name'];
				}
				else
					$study_level="";
				if($tutor_id!="")
				{
					$cond="select first_name,last_name from users where id=".$tutor_id;
					$tutor_details = $this->students_courses_model->special_fetch($cond);
					$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
				}
				else
					$tutor="";
				$student_all_details[]=array(
					"id"=>$student_term['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor
				);
			}
		}
		$totalRecord=count($student_all_details);
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($student_all_details)<=0)
		{
			$student_all_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($student_all_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $student_all_details);
		}
		$output = array_slice($student_all_details, $limit, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function search_revisions($dataArray, $search_value, $key_to_search, $other_matching_value = null, $other_matching_key = null) {
		// This function will search the revisions for a certain value
		// related to the associative key you are looking for.
		$keys = array();
		foreach ($dataArray as $key => $cur_value) {
			if ($cur_value[$key_to_search] == $search_value) {
				if (isset($other_matching_key) && isset($other_matching_value)) {
					if ($cur_value[$other_matching_key] == $other_matching_value) {
						$keys[] = $key;
					}
				} else {
					// I must keep in mind that some searches may have multiple
					// matches and others would not, so leave it open with no continues.
					$keys[] = $key;
				}
			}
		}
		return $keys;
	}
	function test()
	{
		$data = array(
			array(
				'cust_group' => 6,
				'price' => 13.21,
				'price_qty' => 5
			),
			array(
				'cust_group' => 8,
				'price' => 15.25,
				'price_qty' => 4
			),
			array(
				'cust_group' => 8,
				'price' => 12.75,
				'price_qty' => 10
			)
		);
		
		$findKey = $this->search_revisions($data,'8', 'cust_group', '10', 'price_qty');
		$index=$findKey[0];
		if(count($findKey)>0)
			print_r($data[$index]['cust_group']);
	}
	function view_all_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$individual_fld = $data['individual_fld'];
		$del_fld = $data['del_fld'];
		$personnel_fld = $data['personnel_fld'];
		$subject_fld = $data['subject_fld'];
		$competence_level_fld = $data['competence_level_fld'];
		$selected_courses_list = $data['selected_courses_list'];				
		$searchQuery = "";
		$delQuery = "";
		/* if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(c.name) like '%".$searchValue."%' or lower(s.name) like '%".$searchValue."%' or lower(u.first_name) like '%".$searchValue."%' or lower(u.last_name) like '%".$searchValue."%' or lower(s.name) like '%".$searchValue."%' or lower(cl.name) like '%".$searchValue."%')";
	   	} */
		if($individual_fld != ''&&$individual_fld != 'all'){
			$searchQuery .= " and is_individual=".$individual_fld;			
	    }
		if($personnel_fld != ''){
			$searchQuery .= " and personnel_id=".$personnel_fld;			
	    }
		if($subject_fld != ''){
			$searchQuery .= " and subject_id=".$subject_fld;			
	    }
		if($competence_level_fld != ''){
			$searchQuery .= " and competence_level_id=".$competence_level_fld;			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($selected_courses_list != ''){
			$searchQuery .= " and id not in(".$selected_courses_list.")";			
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cond="select * from courses where 1".$delQuery.$searchQuery;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from courses";
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from courses where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		$i=0;
		//var_dump($page_details);die();
		foreach($page_details as $course)
		{
			if($course['subject_id']!="")
			{
				$cond="select name from subjects where id=".$course['subject_id'];
				$subject_details = $this->students_model->special_fetch($cond);
				if(count($subject_details)>0)
					$page_details[$i]['subject']=$subject_details[0]['name'];
				else 
					$page_details[$i]['subject']="";
			}
			else
				$page_details[$i]['subject']="";
			if($course['competence_level_id']!="0"&&$course['competence_level_id']!="")
			{
				$cond="select name from competence_levels where id=".$course['competence_level_id'];
				$study_level_details = $this->students_model->special_fetch($cond);
				if(count($study_level_details)>0)
					$page_details[$i]['competence_level']=$study_level_details[0]['name'];
				else
					$page_details[$i]['competence_level']="";
			}
			else
				$page_details[$i]['competence_level']="";
			if($course['personnel_id']!="")
			{
				$cond="select concat(first_name,' ',last_name) as name from users where id=".$course['personnel_id'];
				$personnel_details = $this->students_model->special_fetch($cond);
				if(count($personnel_details)>0)
					$page_details[$i]['personnel']=$personnel_details[0]['name'];
				else
					$page_details[$i]['personnel']="";
			}
			else
				$page_details[$i]['personnel']="";
			$i++;
		}
		$search_count=0;
		$students_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($page_details);$i++)
			{
				if(strtolower($page_details[$i]['is_individual'])==0)
					$ind="no";
				else
					$ind="yes";
				if(strpos(strtolower($page_details[$i]['name']), $searchValue) !== false||strpos(strtolower($page_details[$i]['subject']), $searchValue) !== false||strpos(strtolower($page_details[$i]['personnel']), $searchValue) !== false||strpos(strtolower($page_details[$i]['competence_level']), $searchValue) !== false||$ind==$searchValue)
				{
					$students_details[]=$page_details[$i];
				}
			}
			$search_count=count($students_details);
		}
		else{
			$students_details=$page_details;
		}
		if($search_count>0)
			$totalRecordwithFilter=$search_count;
		if(count($students_details)<=0)
		{
			$students_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($students_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_details);
		}
		$output = array_slice($students_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_all_selected_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$selected_courses_list = $data['selected_courses_list'];
		$searchQuery = "";
		$delQuery = "";
		if($selected_courses_list!="")
		{
			if($searchValue != ''){
				$searchValue=strtolower($searchValue);
				$searchQuery = " and (lower(c.name) like '%".$searchValue."%' or lower(s.name) like '%".$searchValue."%' or lower(u.first_name) like '%".$searchValue."%' or lower(u.last_name) like '%".$searchValue."%')";
			}
			$searchQuery .= " and c.id in(".$selected_courses_list.")";	
			if($columnName=="")
			{
				$columnName = "c.created_at";
				$columnSortOrder = "desc";
			}
			$cond="select c.*,CONCAT(u.first_name, ' ', u.last_name) as personnel,s.name as subject from courses c,users u,subjects s where c.personnel_id=u.id and c.subject_id=s.id".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
			$page_details = $this->users_model->special_fetch($cond);
			$cond="select COUNT(c.id) as cnt from courses c where 1".$delQuery;
			$maps_count = $this->users_model->special_fetch($cond);
			$totalRecord = $maps_count[0]['cnt'];
			$totalRecordwithFilter = $totalRecord;
			if($searchQuery != ''||$delQuery != ''){
				$cond="select COUNT(c.id) as cnt from courses c,users u,subjects s where c.personnel_id=u.id and c.subject_id=s.id".$delQuery.$searchQuery;
				$maps_count = $this->users_model->special_fetch($cond);
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			}
			$i=0;
			foreach($page_details as $pages)
			{
				if($pages['competence_level_id']!="")
				{
					$cond="select name from competence_levels where id=".$pages['competence_level_id'];
					$comp_details = $this->users_model->special_fetch($cond);
					if(count($comp_details)>0)
						$page_details[$i]['competence_level']=$comp_details[0]['name'];
					else
						$page_details[$i]['competence_level']="";
				}
				else
					$page_details[$i]['competence_level']="";
				$i++;
			}
			if($totalRecord=="")
				$totalRecord=0;
			if($totalRecordwithFilter=="")
				$totalRecordwithFilter=0;
			if(count($page_details)<=0)
				$page_details=array();
		}
		else
		{
			$totalRecord=0;
			$totalRecordwithFilter=0;
			$page_details=array();
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_final_students_courses(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$limit = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$student_course_status_fld = $data['student_course_status_fld'];
		$selected_student_courses_list = $data['selected_student_courses_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		$student_all_details=array();
		if($student_course_status_fld!="")
		{
			$student_courses=explode(",",$selected_student_courses_list);
			foreach($student_courses as $student)
			{
				$student_courses_arr=explode("-",$student);	
				$student_term_id=$student_courses_arr[0];
				$course_id=$student_courses_arr[1];		
				$has_assignment=1;$same_term="no";$same_grade="no";$same_course="no";
				$cond="SELECT student_id,term_id,class_id FROM students_terms where id=".$student_term_id;
				$student_term_details = $this->students_courses_model->special_fetch($cond);
				$cond="SELECT first_name,last_name FROM users where id=".$student_term_details[0]['student_id'];
				$student_details = $this->students_courses_model->special_fetch($cond);
				$student_name=$student_details[0]['first_name']." ".$student_details[0]['last_name'];
				$cond="select name from terms where id=".$student_term_details[0]['term_id'];
				$term_details = $this->students_courses_model->special_fetch($cond);
				$term=$term_details[0]['name'];
				$cond="select name from classes where id=".$student_term_details[0]['class_id'];
				$class_details = $this->students_courses_model->special_fetch($cond);
				$grade=$class_details[0]['name'];
				$cond="select name from student_course_statuses where id=".$student_course_status_fld;
				$course_status_details = $this->students_courses_model->special_fetch($cond);
				$course_status=$course_status_details[0]['name'];
				$cond="select name from courses where id=".$course_id;
				$course_details = $this->students_courses_model->special_fetch($cond);
				$course=$course_details[0]['name'];
				$cond="select st.id from students_terms st,course_attendants c where st.id=c.student_term_id and st.student_id=".$student_term_details[0]['student_id']." and st.term_id=".$student_term_details[0]['term_id'];
				$st_term_details = $this->students_courses_model->special_fetch($cond);
				if(count($st_term_details)>0)
					$same_term="yes";
				$cond="select st.id from students_terms st,course_attendants c where st.id=c.student_term_id and st.student_id=".$student_term_details[0]['student_id']." and st.class_id=".$student_term_details[0]['class_id'];
				$st_class_details = $this->students_courses_model->special_fetch($cond);
				if(count($st_class_details)>0)
					$same_grade="yes";
				$cond="select st.id from students_terms st,course_attendants c where st.id=c.student_term_id and c.course_id=".$course_id." and st.student_id=".$student_term_details[0]['student_id'];
				$st_cor_details = $this->students_courses_model->special_fetch($cond);
				if(count($st_cor_details)>0)
					$same_course="yes";
				$cond="select id from course_attendants where student_term_id=".$student_term_id." and course_id=".$course_id;
				$course_attendant_details = $this->students_courses_model->special_fetch($cond);
				if(count($course_attendant_details)>0)
					$has_assignment=0;
				$student_all_details[]=array(
					"id"=>$student,
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"course"=>$course,
					"same_term"=>$same_term,
					"same_grade"=>$same_grade,
					"same_course"=>$same_course,
					"course_status"=>$course_status,
					"has_assignment"=>$has_assignment
				);
			}
		}
		$totalRecord=count($student_all_details);
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($student_all_details)<=0)
			$student_all_details=array();
		else
		{
			foreach ($student_all_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $student_all_details);
		}
		$output = array_slice($student_all_details, $limit, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function add_students_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$selected_student_courses_list = $data['selected_student_courses_list'];
		$student_course_status_fld = $data['student_course_status_fld'];
		$selected_student_courses_list=implode(',', array_keys(array_flip(explode(',', $selected_student_courses_list))));
		$selected_student_courses_list_arr=explode(",",$selected_student_courses_list);
		$added_students=""; $existing_students="";
		foreach($selected_student_courses_list_arr as $student)
		{
			$student_courses_arr=explode("-",$student);
			$student_term_id=$student_courses_arr[0];
			$course_id=$student_courses_arr[1];
			$cond="SELECT concat(u.first_name,' ',u.last_name) as name FROM users u,students_terms s where u.id=s.student_id and s.id=".$student_term_id;
			$stu_details = $this->students_terms_model->special_fetch($cond);
			$cond="select name from courses where id=".$course_id;
			$course_details = $this->students_courses_model->special_fetch($cond);
			$cond="select id from course_attendants where student_term_id=".$student_term_id." and course_id=".$course_id;
			$course_attendant_details = $this->students_courses_model->special_fetch($cond);
			if(count($course_attendant_details)<=0)
			{
				$input = array(
					'student_term_id'=>$student_term_id,
					'course_id'=>$course_id,
					'student_course_status_id '=>$student_course_status_fld,
					'created_at'=>time()
				);
				$this->students_courses_model->add($input);
			}	
		}	
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[158]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    function edit_students_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$id = $data['id'];
		$course_id = $data['course_id'];
		$course_status_id = $data['course_status_id'];
		$cond="select student_term_id from course_attendants where id=".$id;
		$course_attendant_details = $this->students_courses_model->special_fetch($cond);
		if(count($course_attendant_details)>0)
			$student_term_id=$course_attendant_details[0]['student_term_id'];
		else
			$student_term_id=0;
		$cond="select id from course_attendants where student_term_id=".$student_term_id." and course_id=".$course_id;
		$cor_attendant_details = $this->students_courses_model->special_fetch($cond);
		if(count($cor_attendant_details)>0)
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[215]['name']);	
		else
		{
			$input = array(
				'course_id'=>$course_id,
				'student_course_status_id'=>$course_status_id
			);
			$this->students_courses_model->edit($input,$id);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[159]['name']);	
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }	    
    function delete_students_courses(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select course_id from course_attendants where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$course_id=$p_details[0]['course_id'];
			$cond="select name from courses where id=".$course_id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from course_attendants_marks where course_attendant_id=".$id;
			$ab_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from course_upload_students where course_attendant_id=".$id;
			$cor_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from course_uploads where course_attendant_id=".$id;
			$cup_details = $this->subject_types_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($cor_details)<=0&&count($cup_details)<=0)
			{
				$this->students_courses_model->delete($id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}		
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[101]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[252]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);
		header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function import_students_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['term']==""||$page['student_name']==""||$page['course']==""||$page['course_status']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['term'];
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['course'];
				$corrupt_arr[] =$page['course_status'];
				$corrupt_arr[] =$label_details[253]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['term_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['course'];
					$error_arr[] =$page['course_status'];
					$error_arr[] =$label_details[163]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['course'];
					$error_arr[] =$page['course_status'];
					$error_arr[] =$label_details[164]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['course_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['course'];
					$error_arr[] =$page['course_status'];
					$error_arr[] =$label_details[165]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['course_status_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['course'];
					$error_arr[] =$page['course_status'];
					$error_arr[] =$label_details[166]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$cond="select id from students_terms where term_id=".$page['term_id']." and student_id=".$page['student_id'];
					$stu_term_details = $this->students_courses_model->special_fetch($cond);
					if(count($stu_term_details)>0)
					{
						$student_term_id=$stu_term_details[0]['id'];
						$cond="select id from course_attendants where student_term_id=".$student_term_id." and course_id=".$page['course_id'];
						$course_att_details = $this->students_courses_model->special_fetch($cond);	
						if(count($course_att_details)>0)
						{
							$input = array(
								'student_course_status_id'=>$page['course_status_id'],
								'updated_at'=>time()
							);
							$this->students_courses_model->edit($input,$course_att_details[0]['id']);
							$flag=true;
						}
						else
						{
							$input = array(
								'student_term_id'=>$student_term_id,
								'course_id'=>$page['course_id'],
								'student_course_status_id'=>$page['course_status_id'],
								'created_at'=>time()
							);
							$this->students_courses_model->add($input);
							$flag=true;
						}
					}
					else
					{
						$error_arr=array();
						$error_arr[] =$page['term'];
						$error_arr[] =$page['student_name'];
						$error_arr[] =$page['course'];
						$error_arr[] =$page['course_status'];
						$error_arr[] =$label_details[229]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[167]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function get_courses(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$group_id = $data['group_id'];
		$id = $data['id'];
		$course_details=array();
		if($group_id==4)
		{
			$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
			$student_details = $this->users_model->special_fetch($cond);
			if($student_details[0]['id']!="")
			{
				$cond="select c.* from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id in(".$student_details[0]['id'].") group by c.name  order by c.name asc";
				$course_details = $this->users_model->special_fetch($cond);
			}
		}
		else if($group_id==5)
		{
			$cond="select c.* from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id=".$id." group by c.name  order by c.name asc";
			$course_details = $this->users_model->special_fetch($cond);
		}
		else if($group_id==2)
		{
			$cond="select * from courses where is_deleted=0 and is_active=1 and personnel_id=".$id." order by name asc";
			$course_details = $this->users_model->special_fetch($cond);
		}
		else
		{
			$cond="select * from courses where is_deleted=0 and is_active=1 order by name asc";
			$course_details = $this->users_model->special_fetch($cond);
		}
		$out = array('statuscode'=>'200','course_details'=>$course_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_student_course_status(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from student_course_statuses where is_deleted=0 and is_active=1 order by name asc";
		$course_status_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','course_status_details'=>$course_status_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function duplicate_student_courses(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$source_term_id = $data['source_term_id'];
		$destination_term_id = $data['destination_term_id'];
		$cond="select c.id from course_attendants c,students_terms st where st.id=c.student_term_id and term_id=".$destination_term_id;
		$term_details = $this->users_model->special_fetch($cond);
		if(count($term_details)>0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[232]['name']); 			
		}
		else
		{
			$cond="select *,st.id as st_term_id from course_attendants c,students_terms st where st.id=c.student_term_id and  term_id=".$source_term_id." and c.is_active=1 and st.is_active=1";
			$source_term_details = $this->users_model->special_fetch($cond);
			foreach($source_term_details as $source)
			{
				$cond="select id from students_terms where term_id=".$destination_term_id." and student_id=".$source['student_id']." and class_id=".$source['class_id']." and main_level_id=".$source['main_level_id']." and coach_id=".$source['coach_id'];
				$st_term_details = $this->users_model->special_fetch($cond);
				if(count($st_term_details)>0)
				{
					$student_term_id=$st_term_details[0]['id'];
				}
				else
				{
					$input = array(
						'term_id'=>$destination_term_id,
						'student_id'=>$source['student_id'],
						'class_id'=>$source['class_id'],
						'main_level_id'=>$source['main_level_id'],
						'coach_id'=>$source['coach_id'],
						'created_at'=>time()
					);
					$student_term_id=$this->students_terms_model->add($input);
				}
				$input = array(
					'student_term_id'=>$student_term_id,
					'course_id'=>$source['course_id'],
					'student_course_status_id'=>$source['student_course_status_id'],
					'created_at'=>time()
				);
				$this->students_courses_model->add($input);
			}
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[233]['name']);  
		}    
		header('Content-Type:application/json');
        echo json_encode($out);
    }
}
