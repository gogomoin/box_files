<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Students_terms_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=35 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }	
	//students_terms
	function view_students_terms(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld = $data['term_fld'];
		$student_fld = $data['student_fld'];
		$teacher_fld = $data['teacher_fld'];
		$grade_fld = $data['grade_fld'];
		$study_level_fld = $data['study_level_fld'];
		$searchQuery = "";
		$searchGroup = "";
		if($columnName=="")
		{
			$columnName = "st.created_at";
			$columnSortOrder = "desc";
		}
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		$cond="SELECT * FROM students_terms where is_active=1";
		$page_details = $this->students_terms_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$cond="select name from terms where id=".$student['term_id'];
			$term_details = $this->students_terms_model->special_fetch($cond);
			$term=$term_details[0]['name'];
			$cond="select first_name,last_name from users where id=".$student['student_id'];
			$stu_details = $this->students_terms_model->special_fetch($cond);
			$student_name=$stu_details[0]['first_name']." ".$stu_details[0]['last_name'];
			if($student['class_id']!="")
			{
				$cond="select name from classes where id=".$student['class_id'];
				$class_details = $this->students_terms_model->special_fetch($cond);
				$grade=$class_details[0]['name'];
			}
			else
				$grade="";
			if($student['main_level_id']!="0"&&$student['main_level_id']!="")
			{
				$cond="select name from main_levels where id=".$student['main_level_id'];
				$study_level_details = $this->students_terms_model->special_fetch($cond);
				$study_level=$study_level_details[0]['name'];
			}
			else
				$study_level="";
			if($student['coach_id']!="")
			{
				$cond="select first_name,last_name from users where id=".$student['coach_id'];
				$tutor_details = $this->students_terms_model->special_fetch($cond);
				if(count($tutor_details)>0)
					$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
				else
					$tutor="";
			}
			else
				$tutor="";
			$student_all_details[]=array(
				"id"=>$student['id'],
				"term"=>$term,
				"student_name"=>$student_name,
				"grade"=>$grade,
				"study_level"=>$study_level,
				"tutor"=>$tutor,
				"term_id"=>$student['term_id'],
				"student_id"=>$student['student_id'],
				"class_id"=>$student['class_id'],
				"main_level_id"=>$student['main_level_id'],
				"coach_id"=>$student['coach_id']
			);
		}
		$totalRecordwithFilter = $totalRecord;
		$student_filter_details=array();
		$filter_count=0;
		if($grade_fld!=""||$teacher_fld!=""||$study_level_fld!=""||$term_fld!=""||$student_fld!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;
				if($term_fld!="")
				{
					if($term_fld!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($student_fld!="")
				{
					if($student_fld!=$student_all_details[$i]['student_id'])
						$student_flag=false;
				}
				if($grade_fld!="")
				{
					if($grade_fld!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld!="")
				{
					if($teacher_fld!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld!="")
				{
					if($study_level_fld!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		$search_count=0;
		$students_terms_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_terms_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_terms_details);
		}
		else{
			$students_terms_details=$student_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_terms_details)<=0)
		{
			$students_terms_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			/* foreach ($students_terms_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_terms_details); */

			$columnValues = array_column($students_terms_details, $columnName);
			// Sort the values while preserving the original array keys
			if ($columnSortOrder == 'asc') {
				array_multisort($columnValues, SORT_ASC, SORT_REGULAR, $students_terms_details);
			} else {
				array_multisort($columnValues, SORT_DESC, SORT_REGULAR, $students_terms_details);
			}
		}
		$output = array_slice($students_terms_details, $start, $rowperpage); 
		$out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_all_students_terms(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_fld_list = $data['term_fld_list'];
		$teacher_fld_list = $data['teacher_fld_list'];
		$grade_fld_list = $data['grade_fld_list'];
		$study_level_fld_list = $data['study_level_fld_list'];
		$assigned_fld_list = $data['assigned_fld_list'];
		$status_fld_list = $data['status_fld_list'];
		$selected_students_list = $data['selected_students_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($status_fld_list != ''&&$status_fld_list != 'all'){
			$searchQuery .= " and u.is_active=".$status_fld_list;			
	    }
		if($selected_students_list != ''){
			$searchQuery .= " and s.id not in(".$selected_students_list.")";			
	    }
		if($term_fld_list!="")
		{
			$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s,students_terms st where st.student_id=s.id and u.id=s.id and s.is_deleted=0 and st.term_id=".$term_fld_list.$searchQuery;
		}
		else
		{
			$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id and s.is_deleted=0".$searchQuery;
		}
		$page_details = $this->students_terms_model->special_fetch($cond);
		
		$student_all_details=array();
		foreach($page_details as $student)
		{
			$student_name=$student['first_name']." ".$student['last_name'];
			$grade="";$grade_id="";$study_level="";$study_level_id="";$tutor="";$tutor_id="";$term="";$term_id="";
			if($term_fld_list!="")
			{
				$cond="select * from students_terms where student_id=".$student['id']." and term_id=".$term_fld_list;
			}
			else
			{
				$cond="select * from students_terms where student_id=".$student['id'];
			}
			$student_term_details = $this->students_terms_model->special_fetch($cond);
			if($assigned_fld_list != ''&&$assigned_fld_list == 'all')
			{
				if(count($student_term_details)>0)
				{
					$term_id=$student_term_details[0]['term_id'];
					$grade_id=$student_term_details[0]['class_id'];
					$study_level_id=$student_term_details[0]['main_level_id'];
					$tutor_id=$student_term_details[0]['coach_id'];
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_terms_model->special_fetch($cond);
					$term=$term_details[0]['name'];				
					if($grade_id!="")
					{
						$cond="select name from classes where id=".$grade_id;
						$class_details = $this->students_terms_model->special_fetch($cond);
						$grade=$class_details[0]['name'];
					}
					else
						$grade="";
					if($study_level_id!="0"&&$study_level_id!="")
					{
						$cond="select name from main_levels where id=".$study_level_id;
						$study_level_details = $this->students_terms_model->special_fetch($cond);
						$study_level=$study_level_details[0]['name'];
					}
					else
						$study_level="";
					if($tutor_id!="")
					{
						$cond="select first_name,last_name from users where id=".$tutor_id;
						$tutor_details = $this->students_terms_model->special_fetch($cond);
						if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
					}
					else
						$tutor="";
				}
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor,
					"term_id"=>$term_id,
					"student_id"=>$student['id'],
					"class_id"=>$grade_id,
					"main_level_id"=>$study_level_id,
					"coach_id"=>$tutor_id
				);
			}
			else if($assigned_fld_list != ''&&$assigned_fld_list == 1)
			{
				if(count($student_term_details)>0)
				{
					$term_id=$student_term_details[0]['term_id'];
					$grade_id=$student_term_details[0]['class_id'];
					$study_level_id=$student_term_details[0]['main_level_id'];
					$tutor_id=$student_term_details[0]['coach_id'];
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_terms_model->special_fetch($cond);
					$term=$term_details[0]['name'];				
					if($grade_id!="")
					{
						$cond="select name from classes where id=".$grade_id;
						$class_details = $this->students_terms_model->special_fetch($cond);
						$grade=$class_details[0]['name'];
					}
					else
						$grade="";
					if($study_level_id!="0"&&$study_level_id!="")
					{
						$cond="select name from main_levels where id=".$study_level_id;
						$study_level_details = $this->students_terms_model->special_fetch($cond);
						$study_level=$study_level_details[0]['name'];
					}
					else
						$study_level="";
					if($tutor_id!="")
					{
						$cond="select first_name,last_name from users where id=".$tutor_id;
						$tutor_details = $this->students_terms_model->special_fetch($cond);
						if(count($tutor_details)>0)
							$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
						else
							$tutor="";
					}
					else
						$tutor="";
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"grade"=>$grade,
						"study_level"=>$study_level,
						"tutor"=>$tutor,
						"term_id"=>$term_id,
						"student_id"=>$student['id'],
						"class_id"=>$grade_id,
						"main_level_id"=>$study_level_id,
						"coach_id"=>$tutor_id
					);
				}			
			}
			else if($assigned_fld_list != ''&&$assigned_fld_list == 0)
			{
				if(count($student_term_details)<=0)
				{	
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"grade"=>$grade,
						"study_level"=>$study_level,
						"tutor"=>$tutor,
						"term_id"=>$term_id,
						"student_id"=>$student['id'],
						"class_id"=>$grade_id,
						"main_level_id"=>$study_level_id,
						"coach_id"=>$tutor_id
					);
				}
			}			
		}
		
		$student_filter_details=array();
		$filter_count=0;
		if($grade_fld_list!=""||$teacher_fld_list!=""||$study_level_fld_list!=""||$term_fld_list!="")
		{
			for($i=0;$i<count($student_all_details);$i++)
			{
				$grade_flag=true;$teacher_flag=true;$study_level_flag=true;$term_flag=true;$student_flag=true;
				if($term_fld_list!="")
				{
					if($term_fld_list!=$student_all_details[$i]['term_id'])
						$term_flag=false;
				}
				if($grade_fld_list!="")
				{
					if($grade_fld_list!=$student_all_details[$i]['class_id'])
						$grade_flag=false;
				}
				if($teacher_fld_list!="")
				{
					if($teacher_fld_list!=$student_all_details[$i]['coach_id'])
						$teacher_flag=false;
				}
				if($study_level_fld_list!="")
				{
					if($study_level_fld_list!=$student_all_details[$i]['main_level_id'])
						$study_level_flag=false;
				}
				if($grade_flag&&$teacher_flag&&$study_level_flag&&$term_flag&&$student_flag)
				{
					$student_filter_details[]=$student_all_details[$i];
				}
			}
			$filter_count=count($student_filter_details);
		}
		else
		{
			$student_filter_details=$student_all_details;
		}
		
		$search_count=0;
		$students_terms_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($student_filter_details);$i++)
			{
				if(strpos(strtolower($student_filter_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['term']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['study_level']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['tutor']), $searchValue) !== false||strpos(strtolower($student_filter_details[$i]['grade']), $searchValue) !== false)
				{
					$students_terms_details[]=$student_filter_details[$i];
				}
			}
			$search_count=count($students_terms_details);
		}
		else{
			$students_terms_details=$student_filter_details;
		}		
		$totalRecord = count($students_terms_details);
		$totalRecordwithFilter = $totalRecord;
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($students_terms_details)<=0)
		{
			$students_terms_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($students_terms_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $students_terms_details);
		}
		$output = array_slice($students_terms_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_selected_students_terms(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$selected_students_list = $data['selected_students_list'];
		$searchQuery = "";
		$totalRecord=0;$totalRecordwithFilter=0;$page_details=array();
		$student_all_details=array();
		if($selected_students_list!="")
		{
			$searchQuery .= " and s.id in(".$selected_students_list.")";
			$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id".$searchQuery;
			$page_details = $this->students_terms_model->special_fetch($cond);
			$totalRecord = count($page_details);
			foreach($page_details as $student)
			{
				$student_name=$student['first_name']." ".$student['last_name'];
				$grade="";$grade_id="";$study_level="";$study_level_id="";$tutor="";$tutor_id="";$term="";$term_id="";
				$cond="select * from students_terms where student_id=".$student['id'];
				$student_term_details = $this->students_terms_model->special_fetch($cond);
				if(count($student_term_details)>0)
				{
					$term_id=$student_term_details[0]['term_id'];
					$grade_id=$student_term_details[0]['class_id'];
					$study_level_id=$student_term_details[0]['main_level_id'];
					$tutor_id=$student_term_details[0]['coach_id'];
					$cond="select name from terms where id=".$term_id;
					$term_details = $this->students_terms_model->special_fetch($cond);
					$term=$term_details[0]['name'];				
					if($grade_id!="")
					{
						$cond="select name from classes where id=".$grade_id;
						$class_details = $this->students_terms_model->special_fetch($cond);
						$grade=$class_details[0]['name'];
					}
					else
						$grade="";
					if($study_level_id!="0"&&$study_level_id!="")
					{
						$cond="select name from main_levels where id=".$study_level_id;
						$study_level_details = $this->students_terms_model->special_fetch($cond);
						$study_level=$study_level_details[0]['name'];
					}
					else
						$study_level="";
					if($tutor_id!="")
					{
						$cond="select first_name,last_name from users where id=".$tutor_id;
						$tutor_details = $this->students_terms_model->special_fetch($cond);
						$tutor=$tutor_details[0]['first_name']." ".$tutor_details[0]['last_name'];
					}
					else
						$tutor="";
				}
				$student_all_details[]=array(
					"id"=>$student['id'],
					"term"=>$term,
					"student_name"=>$student_name,
					"grade"=>$grade,
					"study_level"=>$study_level,
					"tutor"=>$tutor
				);
			}
		}
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($student_all_details)<=0)
		{
			$student_all_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($student_all_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $student_all_details);
		}
		$output = array_slice($student_all_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_final_students_terms(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$term_id = $data['term_id'];
		$teacher_id = $data['teacher_id'];
		$grade_id = $data['grade_id'];
		$study_level_id = $data['study_level_id'];
		$term = $data['term'];
		$teacher = $data['teacher'];
		$grade = $data['grade'];
		$study_level = $data['study_level'];
		$selected_students_list = $data['selected_students_list'];
		$searchQuery = "";
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($selected_students_list != ''){
			$searchQuery .= " and s.id in(".$selected_students_list.")";			
	    }
		$cond="SELECT u.id,u.first_name,u.last_name FROM users u,students s where u.id=s.id and s.is_deleted=0".$searchQuery;
		$page_details = $this->students_terms_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$student_all_details=array();
		if($term_id!="")
		{
			foreach($page_details as $student)
			{			
				$has_assignment=0;$same_grade='';$same_term='';
				$student_name=$student['first_name']." ".$student['last_name'];
				$old_grade="";$old_study_level="";$old_tutor="";$old_term="";
				$cond="select * from students_terms where student_id=".$student['id'];
				$student_term_details = $this->students_terms_model->special_fetch($cond);
				if(count($student_term_details)>0)
				{
					foreach($student_term_details as $st_terms)
					{
						$same_grade='yes';$same_term='yes';
						if($grade_id!="")
						{
							$cond="select name from classes where id=".$st_terms['class_id'];
							$class_details = $this->students_terms_model->special_fetch($cond);
							$old_grade=$class_details[0]['name'];
							if($old_grade!=$grade)
								$same_grade="no";
						}
						if($term_id!="")
						{
							$cond="select name from terms where id=".$st_terms['term_id'];
							$term_details = $this->students_terms_model->special_fetch($cond);
							$old_term=$term_details[0]['name'];
							if($old_term!=$term)
								$same_term="no";
						}
						if($same_grade=="yes"&&$same_term=="yes")
						{
							$has_assignment=1;
							break;
						}
					}
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"grade"=>$grade,
						"same_grade"=>$same_grade,
						"same_term"=>$same_term,
						"old_grade"=>$old_grade,
						"study_level"=>$study_level,
						"old_study_level"=>$old_study_level,
						"tutor"=>$teacher,
						"old_tutor"=>$old_tutor,
						"has_assignment"=>$has_assignment,
						"term_id"=>$term_id,
						"student_id"=>$student['id'],
						"class_id"=>$grade_id,
						"main_level_id"=>$study_level_id,
						"coach_id"=>$teacher_id
					);
				}
				else
				{
					$student_all_details[]=array(
						"id"=>$student['id'],
						"term"=>$term,
						"student_name"=>$student_name,
						"grade"=>$grade,
						"same_grade"=>$same_grade,
						"same_term"=>$same_term,
						"old_grade"=>"",
						"study_level"=>$study_level,
						"old_study_level"=>"",
						"tutor"=>$teacher,
						"old_tutor"=>"",
						"has_assignment"=>"0",
						"term_id"=>$term_id,
						"student_id"=>$student['id'],
						"class_id"=>$grade_id,
						"main_level_id"=>$study_level_id,
						"coach_id"=>$teacher_id
					);
				}
			}
		}
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($student_all_details)<=0)
		{
			$student_all_details=array();
			$totalRecordwithFilter = $totalRecord=0;
		}	
		else
		{
			foreach ($student_all_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $student_all_details);
		}
		$output = array_slice($student_all_details, $start, $rowperpage); 
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function add_students_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$selected_students_list = $data['selected_students_list'];
		$term_id = $data['term_id'];
		$grade_id = $data['grade_id'];
		$teacher_id = $data['teacher_id'];
		$study_level_id = $data['study_level_id'];
		$students_list=explode(",",$selected_students_list);
		if($study_level_id=="")
			$study_level_id=0;
		$added_students=""; $existing_students="";
		foreach($students_list as $student)
		{
			$cond="SELECT concat(u.first_name,' ',u.last_name) as name FROM users u,students s where u.id=s.id and s.id=".$student;
			$stu_details = $this->students_terms_model->special_fetch($cond);
			$cond="select * from students_terms where student_id=".$student." and term_id=".$term_id." and class_id=".$grade_id;
			$student_term_details = $this->students_terms_model->special_fetch($cond);
			if(count($student_term_details)<=0)
			{
				$input = array(
					'student_id'=>$student,
					'term_id'=>$term_id,
					'class_id'=>$grade_id,
					'coach_id'=>$teacher_id,
					'main_level_id'=>$study_level_id
				);
				$this->students_terms_model->add($input);
			}
		}	
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[161]['name']);			
	    header('Content-Type:application/json');
        echo json_encode($out);        
    }    
    function edit_students_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$id = $data['id'];
		$class_id = $data['class_id'];
		$coach_id = $data['coach_id'];
		$main_level_id = $data['main_level_id'];
		if($main_level_id=="")
			$main_level_id=0;
		$cond="select * from students_terms where id=".$id;
		$st_details = $this->students_terms_model->special_fetch($cond);
		$cond="select * from students_terms where student_id=".$st_details[0]['student_id']." and term_id=".$st_details[0]['term_id']." and class_id=".$class_id." and id<>".$id;
		$student_term_details = $this->students_terms_model->special_fetch($cond);
		if(count($student_term_details)>0)
		{
			$statusdescription=$label_details[226]['name'];
		}
		else
		{
			$input = array(
				'class_id'=>$class_id,
				'main_level_id'=>$main_level_id,
				'coach_id  '=>$coach_id
			);
			$this->students_terms_model->edit($input,$id);
			$statusdescription=$label_details[162]['name'];
		}
		$out = array('statuscode'=>'200','statusdescription'=>$statusdescription);	
        header('Content-Type:application/json');
        echo json_encode($out);
    }	    
    function delete_students_terms(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name=""; 
		foreach($id_arr as $id)
		{
			$cond="select student_id from students_terms where id=".$id;
			$stu_details = $this->users_model->special_fetch($cond);
			$student_id=$stu_details[0]['student_id'];
			$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from absences where student_term_id=".$id." limit 1";
			$ab_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from coaching_protocols where student_term_id=".$id." limit 1";
			$cor_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from course_attendants	where student_term_id=".$id." limit 1";
			$cur_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from disciplinary_protocols where student_term_id=".$id." limit 1";
			$dis_details = $this->career_goals_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($cor_details)<=0&&count($cur_details)<=0&&count($dis_details)<=0)
			{	
				$this->students_terms_model->delete($id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[99]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[103]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);               
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
	function import_students_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['term']==""||$page['student_name']==""||$page['grade']==""||$page['tutor']=="")
			{				
				$corrupt_arr=array();
				$corrupt_arr[] =$page['term'];
				$corrupt_arr[] =$page['student_name'];
				$corrupt_arr[] =$page['grade'];
				$corrupt_arr[] =$page['tutor'];
				$corrupt_arr[] =$page['study_level'];
				$corrupt_arr[] =$label_details[246]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['term_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['grade'];
					$error_arr[] =$page['tutor'];
					$error_arr[] =$page['study_level'];
					$error_arr[] =$label_details[165]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['student_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['grade'];
					$error_arr[] =$page['tutor'];
					$error_arr[] =$page['study_level'];
					$error_arr[] =$label_details[166]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['grade_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['grade'];
					$error_arr[] =$page['tutor'];
					$error_arr[] =$page['study_level'];
					$error_arr[] =$label_details[167]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else if($page['tutor_id']=="")
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['student_name'];
					$error_arr[] =$page['grade'];
					$error_arr[] =$page['tutor'];
					$error_arr[] =$page['study_level'];
					$error_arr[] =$label_details[168]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$cond="select * from students_terms where term_id=".$page['term_id']." and student_id=".$page['student_id'];
					$stu_term_details = $this->students_terms_model->special_fetch($cond);	
					if($page['study_level_id']=="")
						$page['study_level_id']=0;
					if(count($stu_term_details)>0)
					{
						$input = array(
							'class_id'=>$page['grade_id'],
							'main_level_id'=>$page['study_level_id'],
							'coach_id  '=>$page['tutor_id']
						);
						$this->students_terms_model->edit($input,$stu_term_details[0]['id']);
						$flag=true;
					}
					else
					{
						$input = array(
							'student_id'=>$page['student_id'],
							'term_id'=>$page['term_id'],
							'class_id'=>$page['grade_id'],
							'main_level_id'=>$page['study_level_id'],
							'coach_id  '=>$page['tutor_id'],
							'created_at'=>time()
						);
						$this->students_terms_model->add($input);
						$flag=true;
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[170]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	
	function get_students(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select u.id,CONCAT(u.first_name, ' ', u.last_name) as name from users u,students s where u.id=s.id and s.is_deleted=0 and u.is_active=1 order by name asc";
		$student_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','student_details'=>$student_details);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function get_active_terms(){		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from terms where is_deleted=0 order by is_active desc";
		$term_details = $this->users_model->special_fetch($cond);
		$active_terms=array();
		$active_terms[]=array("id"=>$term_details[0]['id'],"name"=>$term_details[0]['name']);
		$active_terms[]=array("id"=>"","name"=>"------");
		for($i=1;$i<count($term_details);$i++)
		{
			$active_terms[]=array("id"=>$term_details[$i]['id'],"name"=>$term_details[$i]['name']);
		}
		$out = array('statuscode'=>'200','term_details'=>$active_terms);              
        header('Content-Type:application/json');
        echo json_encode($out);      
    }
	function duplicate_student_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$source_term_id = $data['source_term_id'];
		$destination_term_id = $data['destination_term_id'];
		$cond="select id from students_terms where term_id=".$source_term_id;
		$source_term_details = $this->users_model->special_fetch($cond);
		if(count($source_term_details)<=0)
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[239]['name']); 
			
		}
		else
		{
			$cond="select id from students_terms where term_id=".$destination_term_id;
			$term_details = $this->users_model->special_fetch($cond);
			if(count($term_details)>0)
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[240]['name']); 
				
			}
			else
			{
				$cond="select * from students_terms where term_id=".$source_term_id." and is_active=1";
				$source_term_details = $this->users_model->special_fetch($cond);
				foreach($source_term_details as $source)
				{
					$input = array(
						'term_id'=>$destination_term_id,
						'student_id'=>$source['student_id'],
						'class_id'=>$source['class_id'],
						'main_level_id'=>$source['main_level_id'],
						'coach_id'=>$source['coach_id'],
						'created_at'=>time()
					);
					$student_term_id=$this->students_terms_model->add($input);
				}
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[241]['name']);  
			}    
		}
		header('Content-Type:application/json');
        echo json_encode($out);
    }
}
