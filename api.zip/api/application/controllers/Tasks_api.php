<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Tasks_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}  
	
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=40 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	
	//Career Goals
	function view_tasks(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$dossier_id = $data['dossier_id'];
		$group_id = $data['group_id'];
		$user_id = $data['user_id'];
		$task_category_fld = $data['task_category_fld'];
		$from_date_fld = $data['from_date_fld'];
		$to_date_fld = $data['to_date_fld'];
		$is_published_fld = $data['is_published_fld'];
		$is_locked_fld = $data['is_locked_fld'];
		$current_date = $data['current_date'];
		$is_del_fld = $data['is_del_fld'];
		$searchQuery = "";
		$dateQuery = "";
		$delQuery = "";
		$cond="SELECT id FROM tasks WHERE is_published=1 and is_checked=0 and to_date < '".$current_date."'";
		$all_tsk_details = $this->users_model->special_fetch($cond);
		foreach($all_tsk_details as $tsk_ids)
		{
			$cond="SELECT id FROM `student_tasks` WHERE is_submit=0 and is_reopened=0 and task_id=".$tsk_ids['id'];
			$stu_tsk_details = $this->users_model->special_fetch($cond);
			foreach($stu_tsk_details as $stu_tsk_ids)
			{
				$input = array(
					'is_lock'=>1,
					'is_submit'=>1,
					'is_force_submit'=>1
				);
				$this->student_tasks_model->edit($input,$stu_tsk_ids['id']);
			}
			$input = array(
				'is_checked'=>1
			);
			$this->tasks_model->edit($input,$tsk_ids['id']);
		}
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(t.title) like '%".$searchValue."%' or lower(t.from_date) like '%".$searchValue."%' or lower(t.to_date) like '%".$searchValue."%' or lower(t.description) like '%".$searchValue."%' or lower(tc.name) like '%".$searchValue."%')";
	   	}
		if($is_published_fld != ''&&$is_published_fld != 'all'){
			$searchQuery .= " and t.is_published=".$is_published_fld;			
	    }
		if($is_locked_fld != ''&&$is_locked_fld != 'all'){
			$searchQuery .= " and t.is_locked=".$is_locked_fld;			
	    }
		if($is_del_fld != ''){
			if($is_del_fld != 'all')
				$delQuery = " and t.is_deleted=".$is_del_fld;
	    }
		else
		{
			$delQuery = " and t.is_deleted=0";	
		}
		if($from_date_fld!="")
		{
			$searchQuery .= " and DATE(STR_TO_DATE('".$from_date_fld."','%d-%m-%Y')) BETWEEN DATE(t.from_date) AND DATE(t.to_date)";
		}
		if($task_category_fld != ''){
			$searchQuery .= " and t.task_category_id=".$task_category_fld;			
	    }
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$per_query='';
		$filter_query='';
		$group_arr=explode(",",$group_id);
		if (in_array(2, $group_arr))
		{
			$cond="SELECT course_id FROM dossiers WHERE id=".$dossier_id;
			$ls_details = $this->users_model->special_fetch($cond);
			if(count($ls_details)>0)
			{
				$cond="SELECT personnel_id FROM courses WHERE id=".$ls_details[0]['course_id'];
				$cor_details = $this->users_model->special_fetch($cond);
				if(count($cor_details)>0)
				{
					if($cor_details[0]['personnel_id']==$user_id)
						$per_query="";
					else
						$per_query = " and t.created_by=".$user_id;
				}
			}
			else
				$per_query = " and t.created_by=".$user_id;
			
		}
		else if (in_array(4, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT student_id) as student_id FROM students_parents WHERE parent_id=".$user_id;
			$par_details = $this->users_model->special_fetch($cond);
			if($par_details[0]['student_id']!="")
			{
				$cond="SELECT GROUP_CONCAT(DISTINCT st.task_id) as task_ids FROM `student_tasks` st,tasks t WHERE t.id=st.task_id and t.is_published=1 and st.student_id in(".$par_details[0]['student_id'].")";
				$tsk_details = $this->users_model->special_fetch($cond);
				if($tsk_details[0]['task_ids']!="")
				{	
					$per_query = " and t.id in(".$tsk_details[0]['task_ids'].")";
				}
				else
					$per_query = " and t.created_by=".$user_id;
			}
			else
				$per_query = " and t.created_by=".$user_id;
			//$dateQuery=' and NOW() BETWEEN from_date AND to_date';
			$dateQuery .= " and t.from_date <= '".$current_date."'";			
		}
		else if (in_array(5, $group_arr))
		{
			$cond="SELECT GROUP_CONCAT(DISTINCT st.task_id) as task_ids FROM `student_tasks` st,tasks t WHERE t.id=st.task_id and t.is_published=1 and st.student_id=".$user_id;
			$tsk_details = $this->users_model->special_fetch($cond);
			if($tsk_details[0]['task_ids']!="")
			{	
				$per_query = " and t.id in(".$tsk_details[0]['task_ids'].")";
			}
			else
				$per_query = " and t.created_by=".$user_id;
				//$dateQuery .= " and DATE(STR_TO_DATE('".$current_date."','%d-%m-%Y')) BETWEEN DATE(t.from_date) AND DATE(t.to_date)";
				$dateQuery .= " and t.from_date <= '".$current_date."'";
		}
		$cond="select t.*,tc.name as task_category from tasks t,task_categories tc where tc.id=t.task_category_id and t.dossier_id=".$dossier_id.$per_query.$dateQuery.$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(t.id) as cnt from tasks t,task_categories tc where tc.id=t.task_category_id and t.dossier_id=".$dossier_id.$per_query.$dateQuery.$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(t.id) as cnt from tasks t,task_categories tc where tc.id=t.task_category_id and t.dossier_id=".$dossier_id.$per_query.$dateQuery.$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
		else
		{
			$lesson_name="";$course="";
			$cond="select name,course_id from dossiers where id=".$dossier_id;
			$dos_details = $this->users_model->special_fetch($cond);
			if(count($dos_details)>0)
			{
				$cond="select name from courses where id=".$dos_details[0]['course_id'];
				$cor_details = $this->users_model->special_fetch($cond);
				$lesson_name=$dos_details[0]['name'];
				if(count($cor_details)>0)
					$course=$cor_details[0]['name'];			
			}
			for($i=0;$i<count($page_details);$i++)
			{
				$document_details=array();
				if($page_details[$i]['task_document']!="")
				{
					$cond="select * from documents where id in(".$page_details[$i]['task_document'].")";
					$document_details = $this->users_model->special_fetch($cond);
				}
				$page_details[$i]['document_details']=$document_details;
				$page_details[$i]['lesson_name']=$lesson_name;
				$page_details[$i]['course']=$course;
				if (in_array(5, $group_arr))
				{
					$cond="select comments,rating,is_submit,is_lock from student_tasks where task_id=".$page_details[$i]['id']." and student_id=".$user_id;
					$comment_details = $this->users_model->special_fetch($cond);
					if(count($comment_details)>0)
					{
						$page_details[$i]['comments']=$comment_details[0]['comments'];
						$page_details[$i]['rating']=$comment_details[0]['rating'];
						$page_details[$i]['is_submit']=$comment_details[0]['is_submit'];
						$page_details[$i]['is_lock']=$comment_details[0]['is_lock'];
					}
					else
					{
						$page_details[$i]['comments']="";
						$page_details[$i]['rating']="";
						$page_details[$i]['is_submit']="";
						$page_details[$i]['is_lock']="";
					}
				}
				else
				{
					$page_details[$i]['comments']="";
					$page_details[$i]['rating']="";
					$page_details[$i]['is_submit']="";
					$page_details[$i]['is_lock']="";
				}
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_students_task(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$task_id = $data['task_id'];
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(u.first_name) like '%".$searchValue."%' or lower(u.last_name) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "id";
			$columnSortOrder = "desc";
		}
		$cond="select st.*,u.first_name,u.last_name,CONCAT(u.first_name,' ',u.last_name) as student from student_tasks st,users u where st.student_id=u.id and st.task_id=".$task_id.$searchQuery." group by st.student_id order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(st.id) as cnt from student_tasks st,users u where st.student_id=u.id and st.task_id=".$task_id." group by st.student_id";
        $maps_count = $this->users_model->special_fetch($cond);
		if (!empty($maps_count)) {
			$totalRecord = $maps_count[0]['cnt'];
		} else {
			$totalRecord = 0; // or whatever default value you want
		}
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(st.id) as cnt from student_tasks st,users u where st.student_id=u.id and st.task_id=".$task_id.$searchQuery." group by st.student_id";
            $maps_count = $this->users_model->special_fetch($cond);
			if (!empty($maps_count)) {
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			} else {
				$totalRecordwithFilter = 0; // or whatever default value you want
			}
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
		else
		{
			for($i=0;$i<count($page_details);$i++)
			{
				$page_details[$i]['task_document_key']="";
				$cond="select task_document_key from tasks where id=".$page_details[$i]['task_id'];
            	$document_details = $this->users_model->special_fetch($cond);
				if(count($document_details)>0){
					$page_details[$i]['task_document_key']=$document_details[0]['task_document_key'];
				}
			}
		}
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }	
	function view_task_logs(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$task_id = $data['task_id'];
		$lang_id = $data['lang_id'];
		$searchQuery = "";
		$delQuery = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(u.first_name) like '%".$searchValue."%' or lower(u.last_name) like '%".$searchValue."%' or lower(st.logged_for) like '%".$searchValue."%' or lower(st.log_type) like '%".$searchValue."%' or lower(st.created_at) like '%".$searchValue."%')";
	   	}
		if($columnName=="")
		{
			$columnName = "st.id";
			$columnSortOrder = "desc";
		}
		$cond="select st.*,u.first_name,u.last_name,CONCAT(u.first_name,' ',u.last_name) as logged_user from tasks_log st,users u where st.logged_by=u.id and st.task_id=".$task_id.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(st.id) as cnt from tasks_log st,users u where st.logged_by=u.id and st.task_id=".$task_id;
        $maps_count = $this->users_model->special_fetch($cond);
		if (!empty($maps_count)) {
			$totalRecord = $maps_count[0]['cnt'];
		} else {
			$totalRecord = 0; // or whatever default value you want
		}
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(st.id) as cnt from tasks_log st,users u where st.logged_by=u.id and st.task_id=".$task_id.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
			if (!empty($maps_count)) {
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			} else {
				$totalRecordwithFilter = 0; // or whatever default value you want
			}
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();	
		else
		{
			$cond="select name,label_id from labels where label_id>=582 and label_id<=593 and lang_id=".$lang_id;
            $lbl_details = $this->users_model->special_fetch($cond);
			for($i=0;$i<count($page_details);$i++)
			{
				$value=$page_details[$i]['log_type'];
				$result = "";
				foreach ($lbl_details as $item) {
					if ($item["label_id"] === $value) {
						$result = $item["name"];
						break;
					}
				}
				$page_details[$i]['log_type']=$result;
				$result = "";
				$value=$page_details[$i]['logged_for'];
				foreach ($lbl_details as $item) {
					if ($item["label_id"] === $value) {
						$result = $item["name"];
						break;
					}
				}
				if($result!="")
					$page_details[$i]['logged_for']=$result;
			}
		}		
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function test_log()
	{
		$lang_id=1;
		$cond="select name,label_id from labels where label_id>=582 and label_id<=591 and lang_id=".$lang_id;
		$lbl_details = $this->users_model->special_fetch($cond);
		//if(==1)
		die(); // Outputs: "Submitted"
		var_dump($lbl_details);die();
		
	}
	function add_tasks(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$title = $data['title'];
		$task_category_id = $data['task_category_id'];
		$from_date = $data['from_date'];
		$to_date = $data['to_date'];
		$description = $data['description'];
		$document_files = $data['document_files'];
		$task_document = $data['task_document'];
		$dossier_id = $data['dossier_id'];
		$task_dup = $data['task_dup'];
		$is_published = $data['is_published'];
		$user_id = $data['user_id'];
		if($from_date!="")
		{
			$from_date_obj = DateTime::createFromFormat('d-m-Y h:i A', $from_date);
			$from_date = $from_date_obj->format('Y-m-d H:i:s');
		}
		else
			$from_date ='0000-00-00 00:00:00';
		if($to_date!="")
		{
			$to_date_obj = DateTime::createFromFormat('d-m-Y h:i A', $to_date);
			$to_date = $to_date_obj->format('Y-m-d H:i:s');
		}
		else
			$to_date ='2099-01-01 12:00:00';
		$timestamp = time(); 
		$created_at = date('Y-m-d H:i:s', $timestamp);
		if($task_dup=='0')
		{
			if($id=="")
			{
				$data_arr=array(
					'title'=>$title,
					'is_deleted'=>0,
					'dossier_id'=>$dossier_id
				);
				$tasks_details = $this->tasks_model->get_records($data_arr);
				if(count($tasks_details)<=0)
				{
					if($document_files!="")
						$pdf_status=0;
					else
						$pdf_status=1;
					$input = array(
						'title'=>$title,
						'task_category_id'=>$task_category_id,
						'from_date'=>$from_date,
						'to_date'=>$to_date,
						'description'=>$description,
						'task_document'=>$document_files,
						'task_document_key'=>$task_document,
						'dossier_id'=>$dossier_id,
						'is_published'=>$is_published,
						'pdf_status'=>$pdf_status,
						'created_by'=>$user_id,
						'created_at'=>$created_at
					);
					$mid = $this->tasks_model->add($input);
					if($mid){	
						$term_query="";
						$cond="SELECT id FROM terms WHERE is_active=1";
						$term_details = $this->users_model->special_fetch($cond);
						if(count($term_details)>0)
							$term_query=" and st.term_id=".$term_details[0]['id'];					
						$cond="SELECT DISTINCT st.student_id as student_ids FROM dossiers d,course_attendants c,students_terms st WHERE d.course_id=c.course_id and st.id=c.student_term_id and d.id=".$dossier_id.$term_query;
						$stu_details = $this->users_model->special_fetch($cond);
						if(count($stu_details)>0)
						{
							foreach($stu_details as $student_id)
							{
								$input = array(
									'task_id'=>$mid,
									'student_id'=>$student_id['student_ids']
								);
								$this->student_tasks_model->add($input);
							}
						}		
						$out = array('statuscode'=>'200','statusdescription'=>$label_details[469]['name']);
					}
					else{
						$out = array('statuscode'=>'201','statusdescription'=>$label_details[470]['name']);
					}
				}  
				else
				{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[471]['name']);
				}
			}
			else
			{
				$cond="select id from tasks where title='".$title."' and id<>".$id." and dossier_id=".$dossier_id." and is_deleted=0";
				$task_details = $this->users_model->special_fetch($cond);
				if(count($task_details)<=0)
				{
					if($document_files!="")
						$pdf_status=0;
					else
					{
						$pdf_status=1;
						$task_document="";
					}
					$cond="select id from annotations where task_id=".$id." limit 1";
					$anot_details = $this->users_model->special_fetch($cond);
					if(count($anot_details)>0)
					{
						$input = array(
							'title'=>$title,
							'task_category_id'=>$task_category_id,
							'from_date'=>$from_date,
							'to_date'=>$to_date,
							'description'=>$description,
							'updated_at'=>$created_at
						);
					}
					else
					{
						$input = array(
							'title'=>$title,
							'task_category_id'=>$task_category_id,
							'from_date'=>$from_date,
							'to_date'=>$to_date,
							'description'=>$description,
							'task_document'=>$document_files,
							'task_document_key'=>$task_document,
							'pdf_status'=>$pdf_status,
							'updated_at'=>$created_at
						);
					}
					$mid = $this->tasks_model->edit($input,$id);
					if($mid){				
						$out = array('statuscode'=>'200','statusdescription'=>$label_details[472]['name']);
					}
					else{
						$out = array('statuscode'=>'201','statusdescription'=>$label_details[473]['name']);
					}
				}  
				else
				{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[474]['name']);
				}
			}
		}
		else
		{
			$data_arr=array(
				'title'=>$title,
				'dossier_id'=>$dossier_id
			);
			$tasks_details = $this->tasks_model->get_records($data_arr);
			if(count($tasks_details)<=0)
			{
				if($document_files!="")
					$pdf_status=0;
				else
					$pdf_status=1;
				$input = array(
					'title'=>$title,
					'task_category_id'=>$task_category_id,
					'from_date'=>$from_date,
					'to_date'=>$to_date,
					'description'=>$description,
					'task_document'=>$document_files,
					'task_document_key'=>$task_document,
					'dossier_id'=>$dossier_id,
					'is_published'=>$is_published,
					'pdf_status'=>$pdf_status,
					'created_by'=>$user_id,
					'created_at'=>$created_at
				);
				$mid = $this->tasks_model->add($input);
				if($mid){	
					$cond="SELECT DISTINCT st.student_id as student_id FROM dossiers d,course_attendants c,students_terms st WHERE d.course_id=c.course_id and st.id=c.student_term_id and d.id=".$dossier_id;
					$stu_details = $this->users_model->special_fetch($cond);
					if(count($stu_details)>0)
					{
						foreach($stu_details as $student_id)
						{
							$input = array(
								'task_id'=>$mid,
								'student_id'=>$student_id['student_id']
							);
							$this->student_tasks_model->add($input);
						}
					}			
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[475]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[476]['name']);
				}
			}  
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[477]['name']);
			}
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function update_task_pdf_status(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$task_document_key = $data['task_document'];
		$cond="select id from tasks where task_document_key='".$task_document_key."'";
		$dos_details = $this->dossiers_model->special_fetch($cond);
		$id=$dos_details[0]['id'];
		$input = array(
			'pdf_status'=>1
		);
		$this->tasks_model->edit($input,$id);
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    function change_tasks_status(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$user_id = $data['user_id'];
		$status_type = $data['status_type'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		$not_in_use_msg="";$in_use_msg="";
		foreach($id_arr as $id)
		{
			if($status_type=="pub")
			{
				$cond="select title,is_published from tasks where id=".$id;
				$p_details = $this->users_model->special_fetch($cond);
				if(count($p_details)>0)
				{
					$name=$p_details[0]['title'];
					$is_published=$p_details[0]['is_published'];
				}
				else
				{
					$name="";
					$is_published="";
				}
				$log_type="";
				if($is_published!="")
				{
					if($is_published==0)
					{
						$input = array(
							'is_published'=>1
						);
						$this->tasks_model->edit($input,$id);
						$not_in_use_name=$not_in_use_name.",".$name;
						$log_type="582";//Published
					}
					else
					{
						$cond="select id from student_tasks where task_id=".$id." and is_private=1";
						$ab_details = $this->tasks_model->special_fetch($cond);
						if(count($ab_details)<=0)
						{	
							$input = array(
								'is_published'=>0
							);
							$this->tasks_model->edit($input,$id);							
							$not_in_use_name=$not_in_use_name.",".$name;
							$log_type="583";//Un-published
						}
						else
						{
							$in_use_name=$in_use_name.",".$name;
						}						
					}
					if($log_type!="")
					{
						$timestamp = time(); 
						$created_at = date('Y-m-d H:i:s', $timestamp);
						$input = array(
							'task_id'=>$id,
							'logged_by'=>$user_id,
							'logged_for'=>"584",//All Students
							'log_type'=>$log_type,
							'created_at'=>$created_at
						);
						$this->tasks_log_model->add($input);
					}
				}
			}
			else if($status_type=="loc")
			{
				$cond="select is_locked from tasks where id=".$id;
				$p_details = $this->users_model->special_fetch($cond);
				if(count($p_details)>0)
				{
					$is_locked=$p_details[0]['is_locked'];
					if($is_locked==0)
					{
						$is_locked=1;
						$log_type="585";//Locked
					}
					else
					{
						$is_locked=0;
						$log_type="586";//Un-locked
					}
					$input = array(
						'is_locked'=>$is_locked
					);
					$this->tasks_model->edit($input,$id);
					$cond="select * from student_tasks where task_id=".$id;
					$student_details = $this->users_model->special_fetch($cond);
					foreach($student_details as $student)
					{
						if($is_locked==1)
						{
							//Lock the task
							if($student['is_submit']==0)
							{
								$input = array(
									'is_lock'=>1,
									'is_submit'=>1,
									'is_force_submit'=>1
								);
								$this->student_tasks_model->edit($input,$student['id']);
							}
							else
							{
								$input = array(
									'is_lock'=>1
								);
								$this->student_tasks_model->edit($input,$student['id']);
							}							
						}
						else
						{
							$log_type="587";//Un-locked And Reopened
							//UnLock the task
							$input = array(
								'is_lock'=>0,
								'is_submit'=>0,
								'is_reopened'=>1,
								'is_force_submit'=>0
							);
							$this->student_tasks_model->edit($input,$student['id']);
						}						
					}					
					$timestamp = time(); 
					$created_at = date('Y-m-d H:i:s', $timestamp);
					$input = array(
						'task_id'=>$id,
						'logged_by'=>$user_id,
						'logged_for'=>"584",//All Students
						'log_type'=>$log_type,
						'created_at'=>$created_at
					);
					$this->tasks_log_model->add($input);
				}				
			}
			else if($status_type=="stu_loc")
			{
				$cond="select * from student_tasks where id=".$id;
				$student_details = $this->users_model->special_fetch($cond);
				if(count($student_details)>0)
				{
					$student_name="";
					$cond="select concat(first_name,' ',last_name) as name from users where id=".$student_details[0]['student_id'];
					$stu_details = $this->users_model->special_fetch($cond);
					if(count($stu_details)>0)
						$student_name=$stu_details[0]['name'];
					if($student_details[0]['is_lock']==0)
					{	
						//Lock the task
						if($student_details[0]['is_submit']==0)
						{
							$log_type="588";//Locked and Force Submitted
							$input = array(
								'is_lock'=>1,
								'is_submit'=>1,
								'is_force_submit'=>1
							);
							$this->student_tasks_model->edit($input,$student_details[0]['id']);
						}
						else
						{
							$log_type="585";//Locked
							$input = array(
								'is_lock'=>1
							);
							$this->student_tasks_model->edit($input,$student_details[0]['id']);
						}							
					}
					else
					{
						//UnLock the task
						$log_type="587";//Un-locked and Reopened
						$input = array(
							'is_lock'=>0,
							'is_submit'=>0,
							'is_reopened'=>1,
							'is_force_submit'=>0
						);
						$this->student_tasks_model->edit($input,$student_details[0]['id']);
					}					
					$timestamp = time(); 
					$created_at = date('Y-m-d H:i:s', $timestamp);
					$input = array(
						'task_id'=>$student_details[0]['task_id'],
						'logged_by'=>$user_id,
						'logged_for'=>$student_name,
						'log_type'=>$log_type,
						'created_at'=>$created_at
					);
					$this->tasks_log_model->add($input);
				}				
			}
			else if($status_type=="del")
			{
				$cond="select title,is_deleted from tasks where id=".$id;
				$p_details = $this->users_model->special_fetch($cond);
				$name=$p_details[0]['title'];
				$cond="select id from student_tasks where task_id=".$id." and is_private=1";
				$ab_details = $this->tasks_model->special_fetch($cond);
				if(count($ab_details)<=0)
				{	
					$input = array(
						'is_deleted'=>1
					);
					$this->tasks_model->edit($input,$id);	
					$timestamp = time(); 
					$created_at = date('Y-m-d H:i:s', $timestamp);
					$input = array(
						'task_id'=>$id,
						'logged_by'=>$user_id,
						'log_type'=>"589",//Deleted
						'created_at'=>$created_at
					);
					$this->tasks_log_model->add($input);						
					$not_in_use_name=$not_in_use_name.",".$name;
				}
				else
				{
					$in_use_name=$in_use_name.",".$name;
				}
			}
			else if($status_type=="res")
			{
				$cond="select title,is_deleted from tasks where id=".$id;
				$p_details = $this->users_model->special_fetch($cond);
				$name=$p_details[0]['title'];
				$input = array(
					'is_deleted'=>0
				);
				$this->tasks_model->edit($input,$id);	
				$timestamp = time(); 
				$created_at = date('Y-m-d H:i:s', $timestamp);
				$input = array(
					'task_id'=>$id,
					'logged_by'=>$user_id,
					'log_type'=>"590",//Restored
					'created_at'=>$created_at
				);
				$this->tasks_log_model->add($input);						
				$not_in_use_name=$not_in_use_name.",".$name;				
			}
			else if($status_type=="sub")
			{
				$input = array(
					'task_id'=>$id,
					'student_id'=>$user_id,
					'is_submit'=>1,
					'is_lock'=>1
				);
				$this->student_tasks_model->edit_submit($input);	
				$timestamp = time(); 
				$created_at = date('Y-m-d H:i:s', $timestamp);
				$input = array(
					'task_id'=>$id,
					'logged_by'=>$user_id,
					'log_type'=>"591",//Submitted
					'created_at'=>$created_at
				);
				$this->tasks_log_model->add($input);				
			} 
			else if($status_type=="preview_sub")
			{
				$input = array(
					'task_id'=>$id,
					'student_id'=>$user_id,
					'is_submit'=>1,
					'is_lock'=>1
				);
				$this->student_tasks_model->edit_submit($input);	
				$timestamp = time(); 
				$created_at = date('Y-m-d H:i:s', $timestamp);
				$input = array(
					'task_id'=>$id,
					'logged_by'=>$user_id,
					'log_type'=>"591",//Submitted
					'created_at'=>$created_at
				);
				$this->tasks_log_model->add($input);				
			} 
		}
		if($status_type=="pub")
		{
			if($not_in_use_name!="")
				$not_in_use_msg=" ".trim($not_in_use_name,", ").$label_details[478]['name'];
			if($in_use_name!="")
				$in_use_msg=" ".trim($in_use_name,",").$label_details[479]['name'];	
		}
		else if($status_type=="loc")
		{
			$not_in_use_msg=$label_details[480]['name'];
		}
		else if($status_type=="stu_loc")
		{
			$not_in_use_msg=$label_details[480]['name'];
		}
		else if($status_type=="del")
		{
			if($not_in_use_name!="")
				$not_in_use_msg=" ".trim($not_in_use_name,", ").$label_details[481]['name'];
			if($in_use_name!="")
				$in_use_msg=" ".trim($in_use_name,",").$label_details[482]['name'];	
		}
		else if($status_type=="res")
		{
			if($not_in_use_name!="")
				$not_in_use_msg=" ".trim($not_in_use_name,", ").$label_details[483]['name'];
		}
		else if($status_type=="sub")
		{
			$not_in_use_msg=$label_details[484]['name'];
		}
		else if($status_type=="preview_sub")
		{
			$not_in_use_msg=$label_details[484]['name'];
		}
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_task_categories()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from task_categories where is_deleted=0 and is_active=1 order by name asc";
		$task_category_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','task_category_details'=>$task_category_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function check_task_user()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$user_id = $data['user_id'];
		$cond="select entity_class from users where id=".$user_id;
		$user_details = $this->users_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			if($user_details[0]['entity_class']=='studententity')
				$out = array('statuscode'=>'200');
			else
			{
				$cond="select group_concat(group_id) as group_ids from user_groups where user_id=".$user_id;
				$user_group_details = $this->users_model->special_fetch($cond);
				$group_ids = $user_group_details[0]['group_ids'];
				if($group_ids!="")
				{
					if($group_ids=="2")
					{
						$cond="select course_id,personnel_id from dossiers where id=".$id;
						$dos_details = $this->users_model->special_fetch($cond);	
						if(count($dos_details)>0)
						{
							$cond="select personnel_id from courses where id=".$dos_details[0]['course_id'];
							$cor_details = $this->users_model->special_fetch($cond);	
							if(count($cor_details)>0)
							{
								if($cor_details[0]['personnel_id']==$user_id||$dos_details[0]['personnel_id']==$user_id)
									$out = array('statuscode'=>'200'); 
								else
									$out = array('statuscode'=>'201');
							}
							else
								$out = array('statuscode'=>'201');
						}							
					}
					else
					{
						$out = array('statuscode'=>'200'); 
					}
				}
				else
					$out = array('statuscode'=>'201');
			}
		}
		else 
			$out = array('statuscode'=>'201');
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_task_rating()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$rating = $data['rating'];
		$st_id = $data['st_id'];
		$cond="select rating from student_tasks where id=".$st_id;
		$task_details = $this->users_model->special_fetch($cond);
		if(count($task_details)>0)
		{
			if($task_details[0]['rating']==1&&$rating==1)
				$rating=0;
			$input = array(
				'rating'=>$rating
			);
			$this->student_tasks_model->edit($input,$st_id);
		}
		$out = array('statuscode'=>'200','rating'=>$rating); 	
		header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_task_comment()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$comments = $data['comments'];
		$st_task_id = $data['st_task_id'];
		$input = array(
			'comments'=>$comments
		);
		$this->student_tasks_model->edit($input,$st_task_id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[485]['name']); 	
		header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function check_task_dates()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$cond="select from_date,to_date,is_published from tasks where id=".$id;
		$task_details = $this->users_model->special_fetch($cond);
		if(count($task_details)>0)
			$out = array('statuscode'=>'200','from_date'=>$task_details[0]['from_date'],'to_date'=>$task_details[0]['to_date'],'publish'=>$task_details[0]['is_published']); 
		else
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[486]['name']);
		header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
	function set_annotations()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$task_type = $data['task_type'];
		$annotation_xml = $data['annotation_xml'];
		$task_id = $data['task_id'];
		$student_id = $data['student_id'];
		$user_id = $data['user_id'];
		$annotation_id=$this->filter_id($annotation_xml);
		if($annotation_id!="")
		{
			$timestamp = time(); 
			$created_at = date('Y-m-d H:i:s', $timestamp);
			$cond="select id from annotations where annotation_id='".$annotation_id."'";
			$annotation_details = $this->users_model->special_fetch($cond);
			if(count($annotation_details)<=0)
			{
				if($task_type=="teach")
				{
					$input = array(
						'task_id'=>$task_id,
						'teacher_id'=>$user_id,
						'annotation_id'=>$annotation_id,
						'annotation_xml'=>$annotation_xml,
						'task_type'=>$task_type,
						'created_at'=>$created_at
					);
					$this->annotations_model->add($input);
				}
				else if($task_type=="do")
				{
					$input = array(
						'task_id'=>$task_id,
						'student_id'=>$user_id,
						'annotation_id'=>$annotation_id,
						'annotation_xml'=>$annotation_xml,
						'task_type'=>$task_type,
						'created_at'=>$created_at
					);
					$this->annotations_model->add($input);
					$cond="select id,is_private from student_tasks where task_id=".$task_id." and student_id=".$user_id;
					$student_details = $this->users_model->special_fetch($cond);
					if(count($student_details)>0)
					{
						if($student_details[0]['is_private']==0)
						{
							$input = array(
								'is_private'=>1
							);
							$this->student_tasks_model->edit($input,$student_details[0]['id']);
							$timestamp = time(); 
							$created_at = date('Y-m-d H:i:s', $timestamp);
							$input = array(
								'task_id'=>$task_id,
								'logged_by'=>$user_id,
								'log_type'=>"592",//Privatized
								'created_at'=>$created_at
							);
							$this->tasks_log_model->add($input);
						}
					}
				}
				else if($task_type=="markup")
				{
					$input = array(
						'task_id'=>$task_id,
						'teacher_id'=>$user_id,
						'student_id'=>$student_id,
						'annotation_id'=>$annotation_id,
						'annotation_xml'=>$annotation_xml,
						'task_type'=>$task_type,
						'created_at'=>$created_at
					);
					$this->annotations_model->add($input);
					$cond="select id,is_revise from student_tasks where task_id=".$task_id." and student_id=".$student_id;
					$student_details = $this->users_model->special_fetch($cond);
					if(count($student_details)>0)
					{
						if($student_details[0]['is_revise']==0)
						{
							$student_name="";
							$input = array(
								'is_revise'=>1
							);
							$this->student_tasks_model->edit($input,$student_details[0]['id']);
							$timestamp = time(); 
							$created_at = date('Y-m-d H:i:s', $timestamp);
							$cond="select concat(first_name,' ',last_name) as student_name from users where id=".$student_id;
							$usr_details = $this->users_model->special_fetch($cond);
							if(count($usr_details)>0)
								$student_name=$usr_details[0]['student_name'];
							$input = array(
								'task_id'=>$task_id,
								'logged_by'=>$user_id,
								'logged_for'=>$student_name,
								'log_type'=>"593",//Revised
								'created_at'=>$created_at
							);
							$this->tasks_log_model->add($input);
						}
					}
				}
				else if($task_type=="teach_lesson")
				{
					$input = array(
						'task_id'=>$task_id,
						'teacher_id'=>$user_id,
						'annotation_id'=>$annotation_id,
						'annotation_xml'=>$annotation_xml,
						'task_type'=>$task_type,
						'created_at'=>$created_at
					);
					$this->annotations_model->add($input);
				}
			}
			else
			{
				$input = array(
					'annotation_xml'=>$annotation_xml,
					'updated_at'=>$created_at
				);
				$this->annotations_model->edit($input,$annotation_details[0]['id']);
			}			 
		}
    }
	function get_annotations()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$task_type = $data['task_type'];
		$task_id = $data['task_id'];
		$student_id = $data['student_id'];
		$user_id = $data['user_id'];
		$annotation_details=array();
		if($task_type=="teach")
		{
			$cond="select annotation_xml from annotations where task_id=".$task_id." and teacher_id=".$user_id." and task_type='".$task_type."'";
			$annotation_details = $this->users_model->special_fetch($cond);
		} 
		else if($task_type=="do")
		{			
			$name="Teacher Name";
			$cond="select annotation_xml from annotations where task_id=".$task_id." and student_id=".$user_id." and task_type='do'";
			$student_annotation_details = $this->users_model->special_fetch($cond);
			$cond="select annotation_xml,teacher_id from annotations where task_id=".$task_id." and student_id=".$user_id." and task_type='markup'";
			$tecaher_annotation_details = $this->users_model->special_fetch($cond);
			foreach($student_annotation_details as $annot_xml)
			{
				$annotation_details[]=array(
					"annotation_xml"=>$annot_xml['annotation_xml']
				);
			}
			foreach($tecaher_annotation_details as $annot_xml)
			{
				$cond="select concat(first_name,' ',last_name) as teacher_name from users where id=".$annot_xml['teacher_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				if(count($usr_details)>0)
					$name=$usr_details[0]['teacher_name'];
				else
					$name="Teacher";
				$annotation_xml=$this->change_title($annot_xml['annotation_xml'],$name);
				$annotation_details[]=array(
					"annotation_xml"=>$annotation_xml
				);
			}
		} 
		else if($task_type=="markup")
		{			
			$name="Student Name";
			$cond="select annotation_xml from annotations where task_id=".$task_id." and student_id=".$student_id." and teacher_id=".$user_id." and task_type='markup'";
			$teacher_annotation_details = $this->users_model->special_fetch($cond);
			$cond="select annotation_xml from annotations where task_id=".$task_id." and student_id=".$student_id." and task_type='do'";
			$student_annotation_details = $this->users_model->special_fetch($cond);
			foreach($teacher_annotation_details as $annot_xml)
			{
				$annotation_details[]=array(
					"annotation_xml"=>$annot_xml['annotation_xml']
				);
			}
			foreach($student_annotation_details as $annot_xml)
			{
				$cond="select concat(first_name,' ',last_name) as student_name from users where id=".$student_id;
				$usr_details = $this->users_model->special_fetch($cond);
				if(count($usr_details)>0)
					$name=$usr_details[0]['student_name'];
				else
					$name="Student";
				$annotation_xml=$this->change_title($annot_xml['annotation_xml'],$name);
				$annotation_details[]=array(
					"annotation_xml"=>$annotation_xml
				);
			}
		} 
		else if($task_type=="teach_lesson")
		{
			$cond="select annotation_xml from annotations where task_id=".$task_id." and teacher_id=".$user_id." and task_type='".$task_type."'";
			$annotation_details = $this->users_model->special_fetch($cond);
		}
		$out = array('statuscode'=>'200','annotation_details'=>$annotation_details); 	
		header('Content-Type:application/json');
		echo json_encode($out); 
    }
	
	function get_view_annotations()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$task_type = $data['task_type'];
		$task_id = $data['task_id'];
		$user_id = $data['user_id'];
		$annotation_details=array();
		$name="Unknown";
		$cond="select annotation_xml,teacher_id from annotations where task_id=".$task_id." and student_id=".$user_id." and (task_type='do' or task_type='markup')";
		$student_annotation_details = $this->users_model->special_fetch($cond);
		foreach($student_annotation_details as $annot_xml)
		{
			if($annot_xml['teacher_id']!="")
			{
				$cond="select concat(first_name,' ',last_name) as teacher_name from users where id=".$annot_xml['teacher_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				if(count($usr_details)>0)
					$name=$usr_details[0]['teacher_name'];
				else
					$name="Teacher";
			}
			else
			{
				$cond="select concat(first_name,' ',last_name) as student_name from users where id=".$user_id;
				$usr_details = $this->users_model->special_fetch($cond);
				if(count($usr_details)>0)
					$name=$usr_details[0]['student_name'];
				else
					$name="Student";
			}
			$annotation_xml=$this->change_title($annot_xml['annotation_xml'],$name);
			$annotation_details[]=array(
				"annotation_xml"=>$annotation_xml
			);
		}		 
		$out = array('statuscode'=>'200','annotation_details'=>$annotation_details); 	
		header('Content-Type:application/json');
		echo json_encode($out); 
    }
	function check_annotation()
	{	
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$task_id = $data['task_id'];
		$cond="select id from annotations where task_id=".$task_id." limit 1";
		$annotation_details = $this->users_model->special_fetch($cond);
		if(count($annotation_details)<=0)
			$out = array('statuscode'=>'200'); 
		else
			$out = array('statuscode'=>'201'); 
		header('Content-Type:application/json');
		echo json_encode($out); 
    }
	function filter_id($annotation_xml)
    {
		$doc = new DOMDocument();
		$doc->loadXML($annotation_xml);
		if ($doc->getElementsByTagName('add')->item(0)->hasChildNodes()) {
			$xmlObj = new SimpleXMLElement($annotation_xml);
			$name = (string) $xmlObj->xpath('//@name')[0];
			return $name;
		}
		else if ($doc->getElementsByTagName('modify')->item(0)->hasChildNodes()) {
			$xmlObj = new SimpleXMLElement($annotation_xml);
			$name = (string) $xmlObj->xpath('//@name')[0];
			return $name;
		}
		else if ($doc->getElementsByTagName('delete')->item(0)->hasChildNodes()) {
			$xml = new SimpleXMLElement($annotation_xml);
			$id_value = (string) $xml->delete->id;
			return $id_value;
		}
        return "";
    }
	function change_title($annotation_xml,$name)
	{
		$doc = new DOMDocument();
		$doc->loadXML($annotation_xml);
		$xpath = new DOMXPath($doc);
		$elements = $xpath->query("//*[@title='Guest']");
		foreach ($elements as $element) {
			$element->setAttribute('title', $name);
		}
		$new_annotation_xml = $doc->saveXML();
		return $new_annotation_xml;
	}
	function filter_name()
	{
		$xml = '<xfdf xmlns="http://ns.adobe.com/xfdf/" xml:space="preserve">
		<fields />
		<add />
		<modify><freetext page="2" rect="189.750,370.194,542.574,415.530" flags="print" name="4cac72e2-c7fe-9254-f302-d5bf898d0934" title="Guest" subject="Free Text" date="D:20230427185945+05\'30\'" width="0" creationdate="D:20230427185454+05\'30\'" TextColor="#E44234" FontSize="12"><trn-custom-data bytes="{&quot;trn-auto-size-type&quot;:&quot;auto&quot;,&quot;trn-wrapped-text-lines&quot;:&quot;[\&quot;Hi I am your jogging tent and again modifyiing the content to the  \&quot;,\&quot;tomorrow it can be something else \&quot;,\&quot;Thank you \&quot;]&quot;}"/><contents>Hi I am your jogging tent and again modifyiing the content to the 
		tomorrow it can be something else
		Thank you</contents><contents-richtext><body><p><span>Hi I am your jogging tent and again modifyiing the content to the 
		tomorrow it can be something else
		Thank you</span></p></body></contents-richtext><defaultappearance>0 0 0 rg /Helvetica 12 Tf</defaultappearance><defaultstyle>font: Helvetica 12pt; text-align: left; text-vertical-align: top; color: #E44234</defaultstyle></freetext></modify>
		<delete />
		</xfdf>';
		$doc = new DOMDocument();
		$doc->loadXML($xml);
		if ($doc->getElementsByTagName('add')->item(0)->hasChildNodes()) {
			echo 'Add element is not empty';
		} else {
			echo 'Add element is empty';
		}
		if ($doc->getElementsByTagName('modify')->item(0)->hasChildNodes()) {
			echo 'Modify element is not empty';
		} else {
			echo 'Modify element is empty';
		}
		if ($doc->getElementsByTagName('delete')->item(0)->hasChildNodes()) {
			echo 'Delete element is not empty';
		} else {
			echo 'Delete element is empty';
		}
	}
}
