<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Team_meetings_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=48 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//team_meetings
	function view_team_meetings(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$created_by_fld = $data['created_by_fld'];	
		$personnel_fld = $data['personnel_fld'];
		$student_fld = $data['student_fld'];
		$groups_fld = $data['groups_fld'];
		$date_created_fld = $data['date_created_fld'];	
		$deadline_fld = $data['deadline_fld'];
		$meeting_status_fld = $data['meeting_status_fld'];
		$id = $data['id'];
		$group_id = $data['group_id'];
		$searchQuery = "";
		$searchGroup = "";
		$delQuery = "";
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($meeting_status_fld != ''&&$meeting_status_fld != 'all'){
			$searchQuery .= " and status='".$meeting_status_fld."'";			
	    }	
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$per_query='';
		$flag=true;
		$group_arr=explode(",",$group_id);
		if (in_array(1, $group_arr)||in_array(3, $group_arr))
		{
			$per_query='';
		}
		else if (in_array(2, $group_arr))
		{
			$per_query = " and created_by=".$id;
		}
		$totalRecord="";$totalRecordwithFilter="";
		$page_details=array();
		$cond="SELECT * FROM meeting_items where 1".$delQuery.$searchQuery.$per_query;
		$page_details = $this->meeting_items_model->special_fetch($cond);
		$totalRecord = count($page_details);
		$meeting_details=array();
		$i=0;
		foreach($page_details as $meet)
		{
			$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$meet['created_by'];
			$usr_details = $this->meeting_items_model->special_fetch($cond);
			if(count($usr_details)>0)
				$created_by=$usr_details[0]['name'];
			else
				$created_by="";
			$page_details[$i]['created_by_name']=$created_by;
			$cond="select group_concat(personnel_function_id) as groups from meeting_items_responsible_groups where meeting_item_id=".$meet['id'];
			$group_details = $this->meeting_items_model->special_fetch($cond);
			if(count($group_details)>0)
				$groups=$group_details[0]['groups'];
			else
				$groups="";
			$page_details[$i]['groups']=$groups;
			$cond="select group_concat(personnel_id) as personnel from meeting_items_responsible_personnel where meeting_item_id=".$meet['id'];
			$personnel_details = $this->meeting_items_model->special_fetch($cond);
			if(count($personnel_details)>0)
				$personnel=$personnel_details[0]['personnel'];
			else
				$personnel="";
			$page_details[$i]['personnel']=$personnel;
			$cond="select m.student_id as id,CONCAT(u.first_name, ' ', u.last_name) as name from meeting_items_responsible_students m,users u where u.id=m.student_id and m.meeting_item_id=".$meet['id'];
			$student_details = $this->meeting_items_model->special_fetch($cond);
			$page_details[$i]['student_details']=$student_details;
			$i++;
		}
		$totalRecordwithFilter = $totalRecord;
		$page_filter_details=array();
		$filter_count=0;
		if($created_by_fld!=""||$personnel_fld!=""||$student_fld!=""||$groups_fld!=""||$date_created_fld!=""||$deadline_fld!="")
		{
			for($i=0;$i<count($page_details);$i++)
			{
				$created_by_flag=true;$personnel_flag=true;$student_flag=true;$groups_flag=true;$date_created_flag=true;$deadline_flag=true;
				if($created_by_fld!="")
				{
					if($created_by_fld!=$page_details[$i]['created_by'])
						$created_by_flag=false;
				}
				if($personnel_fld!="")
				{
					$per_arr=explode(",",$page_details[$i]['personnel']);
					if(!in_array($personnel_fld, $per_arr))
						$personnel_flag=false;
				}
				if($student_fld!="")
				{
					$per_arr=array();
					$students=$page_details[$i]['student_details'];
					foreach($students as $stu)
					{
						$per_arr[]=$stu['id'];
					}
					if(!in_array($student_fld, $per_arr))
						$student_flag=false;
				}
				if($groups_fld!="")
				{
					$per_arr=explode(",",$page_details[$i]['groups']);
					if(!in_array($groups_fld, $per_arr))
						$groups_flag=false;
				}
				if($date_created_fld!="")
				{	
					$date_created_flag=$this->created_date_fld($date_created_fld,$page_details[$i]['created_at']);
				}
				if($deadline_fld!="")
				{	
					$deadline_flag=$this->created_date_fld($deadline_fld,$page_details[$i]['deadline_date']);
				}
				if($created_by_flag&&$personnel_flag&&$student_flag&&$groups_flag&&$date_created_flag&&$deadline_flag)
				{
					$page_filter_details[]=$page_details[$i];
				}
			}
			$filter_count=count($page_filter_details);
		}
		else
		{
			$page_filter_details=$page_details;
		}
		$search_count=0;
		$team_meetings_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($page_filter_details);$i++)
			{	
				if(strpos(strtolower($page_filter_details[$i]['title']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['priority']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['status']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['created_by_name']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['deadline_date']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['opened_date']), $searchValue) !== false||strpos(strtolower($page_filter_details[$i]['finished_date']), $searchValue) !== false)
				{
					$team_meetings_details[]=$page_filter_details[$i];
				}
			}
			$search_count=count($team_meetings_details);
		}
		else{
			$team_meetings_details=$page_filter_details;
		}
		if($filter_count==0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		else if($filter_count!=0&&$search_count==0)
			$totalRecordwithFilter=$filter_count;
		else if($filter_count!=0&&$search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
			$totalRecord=0;
		if(count($team_meetings_details)<=0)
		{
			$team_meetings_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		else
		{
			foreach ($team_meetings_details as $key => $row)
			{
				$wek[$key]  = $row[$columnName];
			}  
			if($columnSortOrder=='asc')
				$sort=SORT_ASC;
			else
				$sort=SORT_DESC;
			array_multisort($wek, $sort, $team_meetings_details);
		}
		$output = array_slice($team_meetings_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function created_date_fld($date_created_fld,$cur_st)
	{
		if(strpos($date_created_fld, "to") !== false){
			$date_arr=explode(" ",$date_created_fld);
			$start_timestamp=strtotime($date_arr[0]);
			$end_timestamp=strtotime($date_arr[2]);
			$end_timestamp = strtotime("tomorrow", $end_timestamp) - 1;
			if(!(($cur_st>=$start_timestamp&&$cur_st<=$end_timestamp)))
			{
				 return false;
			}
		} 
		else
		{
			$start_timestamp=strtotime($date_created_fld);
			$end_timestamp = strtotime("tomorrow", $start_timestamp) - 1;
			if(!(($cur_st>=$start_timestamp&&$cur_st<=$end_timestamp)))
			{
				return false;
			}
		}
		return true;
	}
	function send_team_notifications($n_id,$group,$personnel,$students)
	{
		$recipients=array();
		$per_info='';
		foreach($group as $group_id)
		{
			if($group_id!="")
			{
				$cond="select distinct(u.id) as id from users u,personnel_functions pf,personnel p where u.id=p.id and pf.id=p.personnel_function_id and pf.id=".$group_id." and p.is_deleted=0 and u.is_active=1";
				$personnel_details = $this->users_model->special_fetch($cond);
				foreach($personnel_details as $per)
				{
					$input = array(
						'notification_id'=>$n_id,
						'recipient_id'=>$per['id']
					);
					$this->notifications_recipients_model->add($input);
				}
				$cond="select name from personnel_functions where id=".$group_id;
				$func_details = $this->users_model->special_fetch($cond);
				if(count($func_details)>0)
				{
					if($per_info=="")
						$per_info=$func_details[0]['name']." - All";
					else
						$per_info=$per_info.",".$func_details[0]['name']." - All";
				}
			}
		}
		if($per_info!="")
		{
			$recipients[]=array(
				"personnel"=>$per_info
			);
		}
		$personnel_arr=array();
		foreach($personnel as $per)
		{
			if($per!="")
			{
				$cond="select concat(first_name,' ',last_name) as name from users where id=".$per;
				$per_details = $this->users_model->special_fetch($cond);
				$personnel_arr[]=array(
					$per=>$per_details[0]['name']
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$per
				);
				$this->notifications_recipients_model->add($input);
			}
		}
		if(count($personnel_arr)>0)
		{
			$recipients[]=array(
				"personnel_list"=>$personnel_arr
			);
		}
		$student=array();
		foreach($students as $stud_id)
		{
			if($stud_id!="")
			{
				$cond="select concat(first_name,' ',last_name) as name from users where id=".$stud_id;
				$student_details = $this->users_model->special_fetch($cond);
				$student[]=array(
					$stud_id=>$student_details[0]['name']
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$stud_id
				);
				$this->notifications_recipients_model->add($input);
			}
		}
		if(count($student)>0)
		{
			$recipients[]=array(
				"students_list"=>$student
			);
		}
		$recipient_info=json_encode($recipients);
		$input = array(
			'recipients_info'=>$recipient_info,
			'path'=>$n_id
		);
		$this->notifications_model->edit($input,$n_id);
	}
	function add_team_meetings(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$user_id = $data['user_id'];
		$title = $data['title'];
		$category_id = $data['category_id'];
		$created_by = $data['created_by'];
		$deadline_date = $data['deadline_date'];
		$group_id = $data['group_id'];
		$student_id = $data['student_id'];
		$personnel_id = $data['personnel_id'];
		$opinion = $data['opinion'];
		$decision = $data['decision'];
		$priority = $data['priority'];
		$meeting_status = $data['meeting_status'];
		$fail = $data['fail'];
		$status = $data['status'];
		$mid = $data['mid'];
		if($id=="")
		{
			$input = array(
				'title'=>$title,
				'meeting_item_category_id'=>$category_id,
				'created_by'=>$created_by,
				'deadline_date'=>$deadline_date,
				'opinions'=>$opinion,
				'decisions'=>$decision,
				'priority'=>$priority,
				'status'=>$meeting_status,
				'fail'=>$fail,
				'is_active'=>$status,
				'created_at'=>time()
			);
			$meeting_item_id = $this->meeting_items_model->add($input);	
			$cond="select name from meeting_item_categories where id=".$category_id;
			$cat_details = $this->meeting_items_model->special_fetch($cond);
			if(count($cat_details)>0)
				$meet_cat=$cat_details[0]['name'];
			else
				$meet_cat='';
			if($meet_cat=='')
				$sub=$title;
			else
				$sub=$title." - ".$meet_cat;
			$due_date_timestamp=strtotime($deadline_date);
			$created_at=time();
			$created_at_timestamp=strtotime($created_at);
			$input = array(
				'sender_id'=>$user_id,
				'type'=>'appointment',
				'subject'=>$sub,
				'message'=>'',
				'due_datetime'=>$deadline_date,
				'due_date_timestamp'=>$due_date_timestamp,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			$group_id_arr=explode(",",$group_id);
			foreach($group_id_arr as $group)
			{
				if($group!="")
				{
					$input = array(
						'meeting_item_id'=>$meeting_item_id,
						'personnel_function_id'=>$group
					);
					$this->meeting_items_responsible_groups_model->add($input);
				}
			}
			$personnel_id_arr=explode(",",$personnel_id);
			foreach($personnel_id_arr as $personnel)
			{
				if($personnel!="")
				{
					$input = array(
						'meeting_item_id'=>$meeting_item_id,
						'personnel_id'=>$personnel
					);
					$this->meeting_items_responsible_personnel_model->add($input);
				}
			}
			$student_id_arr=explode(",",$student_id);
			foreach($student_id_arr as $student)
			{
				if($student!="")
				{
					$input = array(
						'meeting_item_id'=>$meeting_item_id,
						'student_id'=>$student
					);
					$this->meeting_items_responsible_students_model->add($input);
				}
			}
			if($mid==1)
				$this->send_team_notifications($n_id,$group_id_arr,$personnel_id_arr,$student_id_arr);
			$out = array('statuscode'=>'200','id'=>$meeting_item_id,'meeting_item_id'=>$meeting_item_id,'statusdescription'=>$label_details[121]['name']);
		}
		else
		{
			$group_id_arr=array();$personnel_id_arr=array();$student_id_arr=array();
			$input = array(
				'title'=>$title,
				'meeting_item_category_id'=>$category_id,
				'created_by'=>$created_by,
				'deadline_date'=>$deadline_date,
				'opinions'=>$opinion,
				'decisions'=>$decision,
				'priority'=>$priority,
				'status'=>$meeting_status,
				'fail'=>$fail,
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->meeting_items_model->edit($input,$id);
			$cond="select name from meeting_item_categories where id=".$category_id;
			$cat_details = $this->meeting_items_model->special_fetch($cond);
			if(count($cat_details)>0)
				$meet_cat=$cat_details[0]['name'];
			else
				$meet_cat='';
			if($meet_cat=='')
				$sub=$title;
			else
				$sub=$title." - ".$meet_cat;
			$due_date_timestamp=strtotime($deadline_date);
			$created_at=time();
			$created_at_timestamp=strtotime($created_at);
			$input = array(
				'sender_id'=>$user_id,
				'type'=>'appointment',
				'subject'=>$sub,
				'message'=>'',
				'due_datetime'=>$deadline_date,
				'due_date_timestamp'=>$due_date_timestamp,
				'created_at'=>$created_at,
				'created_at_timestamp'=>$created_at_timestamp
			);
			$n_id = $this->notifications_model->add($input);
			//Groups Update
			$new_group_id_arr=explode(",",$group_id);
			$cond="select group_concat(personnel_function_id) as group_id from meeting_items_responsible_groups where meeting_item_id=".$id;
			$grp_details = $this->meeting_items_model->special_fetch($cond);
			$old_group_id_arr=explode(",",$grp_details[0]['group_id']);
			$new_arr=array_diff($new_group_id_arr,$old_group_id_arr);
			$common_group_id_arr=array_intersect($new_group_id_arr, $old_group_id_arr);
			$group_id_arr=array_merge($new_arr,$common_group_id_arr);
			$old_arr=array_diff($old_group_id_arr,$new_group_id_arr);
			foreach($new_arr as $group)
			{
				if($group!="")
				{
					$input = array(
						'meeting_item_id'=>$id,
						'personnel_function_id'=>$group
					);
					$this->meeting_items_responsible_groups_model->add($input);
				}
			}
			foreach($old_arr as $group)
			{
				if($group!="")
				{
					$cond="select id from meeting_items_responsible_groups where meeting_item_id=".$id." and personnel_function_id=".$group;
					$prof_details = $this->meeting_items_model->special_fetch($cond);
					$this->meeting_items_responsible_groups_model->delete($prof_details[0]['id']);
				}
			}
			//Personnel Update
			$new_personnel_id_arr=explode(",",$personnel_id);
			$cond="select group_concat(personnel_id) as personnel_id from meeting_items_responsible_personnel where meeting_item_id=".$id;
			$grp_details = $this->meeting_items_model->special_fetch($cond);
			$old_personnel_id_arr=explode(",",$grp_details[0]['personnel_id']);
			$new_arr=array_diff($new_personnel_id_arr,$old_personnel_id_arr);
			$common_group_id_arr=array_intersect($new_personnel_id_arr, $old_personnel_id_arr);
			$personnel_id_arr=array_merge($new_arr,$common_group_id_arr);
			$old_arr=array_diff($old_personnel_id_arr,$new_personnel_id_arr);
			foreach($new_arr as $personnel)
			{
				if($personnel!="")
				{
					$input = array(
						'meeting_item_id'=>$id,
						'personnel_id'=>$personnel
					);
					$this->meeting_items_responsible_personnel_model->add($input);
				}
			}
			foreach($old_arr as $personnel)
			{
				if($personnel!="")
				{
					$cond="select id from meeting_items_responsible_personnel where meeting_item_id=".$id." and personnel_id=".$personnel;
					$prof_details = $this->meeting_items_model->special_fetch($cond);
					$this->meeting_items_responsible_personnel_model->delete($prof_details[0]['id']);
				}
			}
			//Students Update
			$new_student_id_arr=explode(",",$student_id);
			$cond="select group_concat(student_id) as student_id from meeting_items_responsible_students where meeting_item_id=".$id;
			$grp_details = $this->meeting_items_model->special_fetch($cond);
			$old_student_id_arr=explode(",",$grp_details[0]['student_id']);
			$new_arr=array_diff($new_student_id_arr,$old_student_id_arr);
			$common_group_id_arr=array_intersect($new_student_id_arr, $old_student_id_arr);
			$student_id_arr=array_merge($new_arr,$common_group_id_arr);
			$old_arr=array_diff($old_student_id_arr,$new_student_id_arr);
			foreach($new_arr as $student)
			{
				if($student!="")
				{
					$input = array(
						'meeting_item_id'=>$id,
						'student_id'=>$student
					);
					$this->meeting_items_responsible_students_model->add($input);
				}
			}
			foreach($old_arr as $student)
			{
				if($student!="")
				{
					$cond="select id from meeting_items_responsible_students where meeting_item_id=".$id." and student_id=".$student;
					$prof_details = $this->meeting_items_model->special_fetch($cond);
					$this->meeting_items_responsible_students_model->delete($prof_details[0]['id']);
				}
			}
			if($mid==1)
				$this->send_team_notifications($n_id,$group_id_arr,$personnel_id_arr,$student_id_arr);
			$out = array('statuscode'=>'200','id'=>$id,'meeting_item_id'=>$id,'statusdescription'=>$label_details[122]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function add_team_notifications(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$team_meeting_id = $data['token_id'];
		$student_rbtn = $data['student_rbtn'];
		$personnel_rbtn = $data['personnel_rbtn'];
		$parent_rbtn = $data['parent_rbtn'];
		$personnel_id = $data['personnel_id'];
		$student_course_id = $data['student_course_id'];
		$student_id = $data['student_id'];
		$parent_course_id = $data['parent_course_id'];
		$parent_id = $data['parent_id'];
		$reply_enabled = $data['reply_enabled'];
		$created_at_timestamp=time();
		$created_at=date('F j, Y h:i', $created_at_timestamp);
		$cond="select m.title,m.deadline_date,c.name from meeting_items m,meeting_item_categories c where c.id=m.meeting_item_category_id and m.id=".$team_meeting_id;
		$meeting_details = $this->users_model->special_fetch($cond);
		if(count($meeting_details)>0)
			$subject=$meeting_details[0]['title']." - ".$meeting_details[0]['name'];
		else
			$subject="";
		$input = array(
			'sender_id'=>$id,
			'type'=>'appointment',
			'subject'=>$subject,
			'message'=>'',
			'due_datetime'=>$meeting_details[0]['deadline_date'],
			'is_reply_enabled'=>$reply_enabled,
			'created_at'=>$created_at,
			'created_at_timestamp'=>$created_at_timestamp
		);
		$n_id = $this->notifications_model->add($input);
		$recipient_info=$this->get_recipients($n_id,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id);
		$input = array(
			'recipients_info'=>$recipient_info,
			'path'=>$n_id
		);
		$this->notifications_model->edit($input,$n_id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[267]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }   
	function get_recipients($n_id,$student_rbtn,$personnel_rbtn,$parent_rbtn,$personnel_id,$student_course_id,$student_id,$parent_course_id,$parent_id)
	{
		$recipients=array();
		if($personnel_rbtn=="all")
		{
			$recipients[]=array(
				"personnel"=>"all"
			);
			$cond="select distinct(u.id) from users u,user_groups ug,personnel p where u.id=ug.user_id and u.id=p.id and ug.group_id in(1,2,3) and p.is_deleted=0 and u.is_active=1";
			$personnel_details = $this->users_model->special_fetch($cond);
			foreach($personnel_details as $per)
			{
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$per['id']
				);
				$this->notifications_recipients_model->add($input);
			}
		}
		else if($personnel_rbtn=="list")
		{
			$personnel=array();
			foreach($personnel_id as $per)
			{
				$per_arr=explode("-",$per);
				$id=trim($per_arr[0]);
				$name=trim($per_arr[1]);
				$personnel[]=array(
					$id=>$name
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$id
				);
				$this->notifications_recipients_model->add($input);
			}
			$recipients[]=array(
				"personnel_list"=>$personnel
			);
		}
		
		if($student_rbtn=="all")
		{
			$recipients[]=array(
				"students"=>"all"
			);
			$cond="select s.id from students s,users u where u.id=s.id and s.is_deleted=0 and u.is_active=1";
			$student_details = $this->users_model->special_fetch($cond);
			foreach($student_details as $per)
			{
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$per['id']
				);
				$this->notifications_recipients_model->add($input);
			}
		}
		else if($student_rbtn=="list")
		{
			$student=array();
			foreach($student_id as $per)
			{
				$per_arr=explode("-",$per);
				$id=trim($per_arr[0]);
				$name=trim($per_arr[1]);
				$student[]=array(
					$id=>$name
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$id
				);
				$this->notifications_recipients_model->add($input);
			}
			$recipients[]=array(
				"students_list"=>$student
			);
		}
		else if($student_rbtn=="course")
		{
			$course=array();
			foreach($student_course_id as $stu_course_id)
			{
				$per_arr=explode("-",$stu_course_id);
				$id=trim($per_arr[0]);
				$name=trim($per_arr[1]);
				$course[]=array(
					$id=>$name
				);
				$cond="SELECT DISTINCT(st.student_id) as id FROM students_terms st,course_attendants c,users u WHERE st.id=c.student_term_id and u.id=st.student_id and c.course_id=".$id;
				$student_details = $this->users_model->special_fetch($cond);
				foreach($student_details as $stu)
				{
					$input = array(
						'notification_id'=>$n_id,
						'recipient_id'=>$stu['id']
					);
					$this->notifications_recipients_model->add($input);
				}
			}
			$recipients[]=array(
				"student_courses"=>$course
			);
		}
		if($parent_rbtn=="course")
		{
			$course=array();
			foreach($parent_course_id as $par_course_id)
			{
				$per_arr=explode("-",$par_course_id);
				$id=trim($per_arr[0]);
				$name=trim($per_arr[1]);
				$course[]=array(
					$id=>$name
				);
				$cond="SELECT DISTINCT(sp.parent_id) as id FROM students_terms st,course_attendants c,students_parents sp WHERE st.id=c.student_term_id and sp.student_id=st.student_id and c.course_id=".$id;
				$parent_details = $this->users_model->special_fetch($cond);
				foreach($parent_details as $stu)
				{
					$input = array(
						'notification_id'=>$n_id,
						'recipient_id'=>$stu['id']
					);
					$this->notifications_recipients_model->add($input);
				}
			}
			$recipients[]=array(
				"parent_courses"=>$course
			);
		}
		else if($parent_rbtn=="list")
		{
			$parent=array();
			foreach($parent_id as $per)
			{
				$per_arr=explode("-",$per);
				$id=trim($per_arr[0]);
				$name=trim($per_arr[1]);
				$parent[]=array(
					$id=>$name
				);
				$input = array(
					'notification_id'=>$n_id,
					'recipient_id'=>$id
				);
				$this->notifications_recipients_model->add($input);
			}
			$recipients[]=array(
				"parent_list"=>$parent
			);
		}
		$recipient_info=json_encode($recipients);
		return $recipient_info;
	}
    function delete_team_meetings(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{
			$cond="select title from meeting_items where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['title'];
			$cond="select id from meeting_items_responsible_groups where meeting_item_id=".$id." limit 1";
			$ab_details = $this->users_model->special_fetch($cond);
			$cond="select id from meeting_items_responsible_personnel where meeting_item_id=".$id." limit 1";
			$cur_details = $this->users_model->special_fetch($cond);
			$cond="select id from meeting_items_responsible_students where meeting_item_id=".$id." limit 1";
			$mee_details = $this->users_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($cur_details)<=0&&count($mee_details)<=0)
			{	
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->meeting_items_model->edit($input,$id);
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}			
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[143]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[268]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);             
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_team_meetings(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->meeting_items_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[145]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_meeting_categories(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select id,name from meeting_item_categories where is_deleted=0 and is_active=1 order by name asc";
		$category_details = $this->meeting_items_model->special_fetch($cond);
		$out = array('statuscode'=>'200','category_details'=>$category_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_personnel(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$id = $data['id'];
		$group_id = $data['group_id'];
		$personnel_details=array();
		if($group_id==4)
		{
			$cond="select group_concat(s.id) as id from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
			$student_details = $this->users_model->special_fetch($cond);
			if($student_details[0]['id']!="")
			{
				$cond="select group_concat(distinct c.id) as course_id from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id in(".$student_details[0]['id'].")";
				$course_details = $this->users_model->special_fetch($cond);
				if($course_details[0]['course_id']!="")
				{
					$cond="select group_concat(distinct personnel_id) as personnel_id from courses where id in(".$course_details[0]['course_id'].")";
					$per_details = $this->users_model->special_fetch($cond);
					if($per_details[0]['personnel_id']!="")
					{
						$cond="select distinct u.id,CONCAT(u.first_name, ' ',u.last_name) as name from users u,personnel p,user_groups ug where u.id=p.id and u.id=ug.user_id and (u.id in(".$per_details[0]['personnel_id'].") or ug.group_id in(1,3)) and p.is_deleted=0 and u.is_active=1 order by name asc";
						$personnel_details = $this->users_model->special_fetch($cond);
					}	
				}
			}
		}
		else if($group_id==5)
		{
			$cond="select group_concat(distinct c.id) as course_id from courses c,students_terms st,course_attendants ca where st.id=ca.student_term_id and ca.course_id=c.id and c.is_deleted=0 and c.is_active=1 and st.student_id=".$id;
			$course_details = $this->users_model->special_fetch($cond);
			if($course_details[0]['course_id']!="")
			{
				$cond="select group_concat(distinct personnel_id) as personnel_id from courses where id in(".$course_details[0]['course_id'].")";
				$per_details = $this->users_model->special_fetch($cond);
				if($per_details[0]['personnel_id']!="")
				{
					$cond="select u.id,CONCAT(u.first_name, ' ',u.last_name) as name from users u,personnel p where u.id=p.id and u.id in(".$per_details[0]['personnel_id'].") and p.is_deleted=0 and u.is_active=1 order by name asc";
					$personnel_details = $this->users_model->special_fetch($cond);
				}	
			}
		}
		else
		{ 
			$cond="select distinct(u.id),CONCAT(u.first_name, ' ', u.last_name) as name from users u,user_groups ug,personnel p where u.id=ug.user_id and u.id=p.id and ug.group_id in(1,2,3) and p.is_deleted=0 and u.is_active=1 order by name asc";
			$personnel_details = $this->users_model->special_fetch($cond);	
		}	
		$out = array('statuscode'=>'200','personnel_details'=>$personnel_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
