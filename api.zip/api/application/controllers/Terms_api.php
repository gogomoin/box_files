<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Terms_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
    function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=32 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    } 
	//Career Goals
	function view_terms(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$term_fld = $data['term_fld'];
		$searchQuery = "";
		$delQuery = "";	
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(name) like '%".$searchValue."%' or start_date like '%".$searchValue."%' or end_date like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and is_active=".$status_fld;			
	    }
		if($term_fld != ''){
			$searchQuery .= " and name='".$term_fld."'";			
	    }
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}		
		$cond="select * from terms where 1".$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
		$page_details = $this->users_model->special_fetch($cond);
		$cond="select COUNT(id) as cnt from terms where 1".$delQuery;
        $maps_count = $this->users_model->special_fetch($cond);
        $totalRecord = $maps_count[0]['cnt'];
        $totalRecordwithFilter = $totalRecord;
        if($searchQuery != ''||$delQuery != ''){
            $cond="select COUNT(id) as cnt from terms where 1".$delQuery.$searchQuery;
            $maps_count = $this->users_model->special_fetch($cond);
            $totalRecordwithFilter = $maps_count[0]['cnt'];
        }
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function convert_date($date)
    {
		$new_date="";
		if(strpos($date, "/") !== false){
        	$str_date=explode("/",$date);
			$new_date=$str_date[1]."/".$str_date[0]."/".$str_date[2];
			return strtotime($new_date);
		}
		else if(strpos($date, "-") !== false){
        	$str_date=explode("-",$date);
			$new_date=$str_date[1]."-".$str_date[0]."-".$str_date[2];
			return strtotime($new_date);
		}
        return "";
    }
	function check()
	{
		$from="31/12/2021";
		echo $from_date=$this->convert_date($from);
	}
	function check_date_range($from_date,$to_date,$cur_from_date,$cur_to_date)
	{
		if(strpos($from_date, "/") !== false){
			$from_date=str_replace("/","-",$from_date);
		}
		if(strpos($to_date, "/") !== false){
			$to_date=str_replace("/","-",$to_date);
		}
		$from_date = strtotime($from_date);
		$to_date = strtotime($to_date);
		if($cur_from_date>$to_date||$cur_to_date<$from_date)
			return 0;
		else
			return 1;
	}
	function add_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$name = $data['name'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$start_date_timestamp = strtotime($data['start_date']);
		$end_date_timestamp = strtotime($data['end_date']);
		$status = $data['status'];
		$data_arr=array(
				'name'=>$name
			);
        $terms_details = $this->terms_model->get_records($data_arr);
		if(count($terms_details)<=0)
		{
			$flag=true;
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			foreach($term_details as $terms)
			{
				$check=$this->check_date_range($terms['start_date'],$terms['end_date'],$start_date_timestamp,$end_date_timestamp);
				if($check==1)
				{
					$flag=false;
					break;
				}
			}
			if($flag)
			{
				$input = array(
					'name'=>$name,
					'start_date'=>$start_date,
					'end_date'=>$end_date,
					'start_date_timestamp'=>$start_date_timestamp,
					'end_date_timestamp'=>$end_date_timestamp,
					'created_at'=>time()
				);
				$mid = $this->terms_model->add($input);
				if($mid){				
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[104]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[105]['name']);
				}
			}
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[134]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[106]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$name = $data['name'];
		$start_date = $data['start_date'];
		$end_date = $data['end_date'];
		$start_date_timestamp = strtotime($data['start_date']);
		$end_date_timestamp = strtotime($data['end_date']);
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from terms where name='".$name."' and is_deleted=0 and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$flag=true;
			$cond="select * from terms where is_deleted=0 and id<>".$id;
			$term_details = $this->users_model->special_fetch($cond);
			foreach($term_details as $terms)
			{
				$check=$this->check_date_range($terms['start_date'],$terms['end_date'],$start_date_timestamp,$end_date_timestamp);
				if($check==1)
				{
					$flag=false;
					break;
				}
			}
			if($flag)
			{
				$input = array(
					'name'=>$name,
					'start_date'=>$start_date,
					'end_date'=>$end_date,
					'start_date_timestamp'=>$start_date_timestamp,
					'end_date_timestamp'=>$end_date_timestamp,
					'updated_at'=>time()
				);
				$mid = $this->terms_model->edit($input,$id);
				if($mid){
					$cond="select is_active from terms where id=".$id;
					$status_term_details = $this->users_model->special_fetch($cond);
					if($status_term_details[0]['is_active']==0)
					{
						$input = array(
							'is_active'=>0
						);
						$this->terms_model->edit_all($input);
						$input = array(
							'is_active'=>1
						);
						$this->terms_model->edit($input,$id);
					}
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[107]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[108]['name']);
				} 
			}
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[134]['name']);
			}
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[109]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function test_dates()
	{
		$start_date='22-08-2022';
		$end_date='04-11-2022';
		$start_date_timestamp = strtotime($start_date);
		$end_date_timestamp = strtotime($end_date);
		$cond="select * from terms where is_deleted=0 and id<>2";
		$term_details = $this->users_model->special_fetch($cond);
		foreach($term_details as $terms)
		{
			echo $terms['start_date'];echo "<br>";
			echo $terms['end_date'];echo "<br>";
			$check=$this->check_date_range($terms['start_date'],$terms['end_date'],$start_date_timestamp,$end_date_timestamp);
			echo $check;echo "<br>";
			if($check==1)
			{
				$flag=false;
				break;
			}
		}		
	}   
    function delete_terms(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name="";
		foreach($id_arr as $id)
		{	
			$cond="select name,is_active from terms where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from course_upload_settings where term_id=".$id;
			$ab_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from dossiers where term_id=".$id;
			$dos_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from students_terms where term_id=".$id;
			$stu_details = $this->subject_types_model->special_fetch($cond);
			$cond="select id from timetable where term_id=".$id;
			$tab_details = $this->subject_types_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($dos_details)<=0&&count($stu_details)<=0&&count($tab_details)<=0)
			{
				if($p_details[0]['is_active']==0)
				{
					$input = array(
						'is_deleted'=>1,
						'deleted_at'=>time()
					);
					$this->terms_model->edit($input,$id);		
					$not_in_use_name=$not_in_use_name.",".$name;
				}
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}		
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[110]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[64]['name'];	
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);             
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function restore_terms(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->terms_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[111]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_terms(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id); 
		$ids = $data['ids'];
		/* $id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from terms where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->terms_model->edit($input,$id);			
		} */
		$cond="select is_active from terms where id=".$ids;
		$st_details = $this->users_model->special_fetch($cond);
		if($st_details[0]['is_active']==1)
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[137]['name']);  
		}
		else
		{
			$input = array(
				'is_active'=>0
			);
			$this->terms_model->edit_all($input);
			$input = array(
				'is_active'=>1
			);
			$this->terms_model->edit($input,$ids);
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[112]['name']);  
		}            
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
    function import_terms(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{			
			if($page['name']==""||$page['start_date']==""||$page['end_date']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['start_date'];
				$corrupt_arr[] =$page['end_date'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[113]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else if(!$this->validateDate($page['start_date']))
			{
				$error_arr=array();
				$error_arr[] =$page['name'];
				$error_arr[] =$page['start_date'];
				$error_arr[] =$page['end_date'];
				$error_arr[] =$page['status'];
				$error_arr[] =$label_details[114]['name'];
				$error_rows[$r]=$error_arr;
				$r++;
			}
			else if(!$this->validateDate($page['end_date']))
			{
				$error_arr=array();
				$error_arr[] =$page['name'];
				$error_arr[] =$page['start_date'];
				$error_arr[] =$page['end_date'];
				$error_arr[] =$page['status'];
				$error_arr[] =$label_details[115]['name'];
				$error_rows[$r]=$error_arr;
				$r++;
			}
			else
			{
				$cond="select id from terms where name='".$page['name']."'";
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['name'];
					$error_arr[] =$page['start_date'];
					$error_arr[] =$page['end_date'];
					$error_arr[] =$page['status'];
					$error_arr[] =$label_details[116]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$start_date_timestamp = strtotime($page['start_date']);
					$end_date_timestamp = strtotime($page['end_date']);
					$input = array(
						'name'=>$page['name'],
						'start_date'=>$page['start_date'],
						'end_date'=>$page['end_date'],
						'start_date_timestamp'=>$start_date_timestamp,
						'end_date_timestamp'=>$end_date_timestamp,
						'created_at'=>time()
					);
					$this->terms_model->add($input);
					$flag=true;
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[117]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function validateDate($date, $format = 'd-m-Y')
	{
		$d = DateTime::createFromFormat($format, $date);
		return $d && $d->format($format) === $date;
	}
}
