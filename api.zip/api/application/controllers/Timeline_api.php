<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Timeline_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=38 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	function find_time()
	{
		$course_date='27-02-2023';
		//echo $date=strtotime($course_date);
		//$cur_day=strtolower(date('l'));
		echo $course_date_timestamp=strtotime($course_date); 
		echo "<br>";
		echo $start_date_timestamp=strtotime('27-02-2023');echo "<br>";
		echo $beginOfDay = strtotime("today", $start_date_timestamp);echo "<br>";
		$end_date_timestamp=strtotime('03-03-2023');
		$end_beginOfDay = strtotime("today", $end_date_timestamp);
		echo $endOfDay   = strtotime("tomorrow", $end_beginOfDay) - 1;echo "<br>";
		if($course_date_timestamp>=$beginOfDay&&$course_date_timestamp<=$endOfDay)
		{
			echo "found";
		}
	}
    function view_timeline(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$weekday_fld = $data['weekday_fld'];
		$course_date = $data['course_date'];
		$cur_student_id = $data['cur_student_id'];
		$id = $data['id'];
		if($cur_student_id!="")
			$id=$cur_student_id;
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		//$cur_time=time();
		$cur_time=strtotime($course_date);
		$term_id='';
		$daily_timeline_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		if($term_id=="")
		{
			$out = array('statuscode'=>'201');
			header('Content-Type:application/json');
			echo json_encode($out);die();
		}
		else
		{
			$term="";
			if($term_id!="")
			{
				$cond="select name from terms where id=".$term_id;
				$term_det = $this->users_model->special_fetch($cond);
				if(count($term_det)>0)
					$term=$term_det[0]['name'];
				else
					$term="";
			}
			if($weekday_fld=="")
			{
				$cur_day=strtolower(date('l'));
				$cond="select id from weekdays where lower(dup_name)='".$cur_day."'";
				$weekday_details = $this->users_model->special_fetch($cond);
				$weekday_fld=$weekday_details[0]['id'];
			}
			else
			{
				$cond="select id from weekdays where lower(dup_name)='".$weekday_fld."'";
				$weekday_details = $this->users_model->special_fetch($cond);
				$weekday_fld=$weekday_details[0]['id'];
			}
			$start_timestamp=strtotime($course_date);
			$beginOfDay = strtotime("today", $start_timestamp);
			$endOfDay   = strtotime("tomorrow", $beginOfDay) - 1;
			$cond="select n.id,n.type,n.due_date_timestamp,nr.is_seen,n.message,CONCAT(u.first_name, ' ', u.last_name) as created_by_name from notifications n,notifications_recipients nr,users u where n.id=nr.notification_id and n.sender_id=u.id and n.is_deleted=0 and nr.recipient_id=".$id." and ord is null and due_date_timestamp>=".$beginOfDay." and due_date_timestamp<=".$endOfDay;
			$notify_details = $this->users_model->special_fetch($cond);
			$cond="select entity_class from users where id=".$id;
			$user_details = $this->users_model->special_fetch($cond);
			$entity_class=$user_details[0]['entity_class'];
			if($entity_class=="personnelentity")
			{
				$no_of_course_attendants=0;
				$avg_marks=0;
				$student_details=array();
				$dossier_details = array();
				$cond="select id,lesson_number,time_from,time_to from lesson_numbers where is_active=1 and is_deleted=0 order by lesson_number asc";
				$lesson_number_details = $this->users_model->special_fetch($cond);
				foreach($lesson_number_details as $lesson_number)
				{
					$timeline_details=array();
					$dossier_details = array();
					$cond="select t.course_id,t.room_id,c.name as course_name,c.personnel_id from timetable t,courses c where t.course_id=c.id and t.term_id =".$term_id." and weekday_id =".$weekday_fld." and lesson_number_id=".$lesson_number['id']." and c.personnel_id=".$id;
					$time_details = $this->users_model->special_fetch($cond);
					if(count($time_details)>0)
					{
						//rooms details
						$cond="select name from rooms where id=".$time_details[0]['room_id'];
						$room_details = $this->users_model->special_fetch($cond);
						$room_name=$room_details[0]['name'];
						//Course Attendants
						$cond="SELECT group_concat(c.id) as id FROM course_attendants c,students_terms st WHERE c.student_term_id=st.id and c.course_id=".$time_details[0]['course_id']." and st.term_id=".$term_id;
						$course_attendant_details = $this->users_model->special_fetch($cond);
						$avg_mark=0;
						if($course_attendant_details[0]['id']!="")
						{
							$cond="SELECT group_concat(student_term_id) as student_term_id FROM course_attendants WHERE id in(".$course_attendant_details[0]['id'].")";
							$student_term_details = $this->users_model->special_fetch($cond);
							$cond="select distinct u.id,u.first_name,u.last_name from users u,students_terms st where u.id=st.student_id and st.id in(".$student_term_details[0]['student_term_id'].")";
							$student_details = $this->users_model->special_fetch($cond);
							$no_of_course_attendants=count($student_details);
							//Avg Marks
							$cond="SELECT group_concat(id) as id FROM course_attendants WHERE course_id=".$time_details[0]['course_id'];
							$cor_details = $this->users_model->special_fetch($cond);
							$ids=$cor_details[0]['id'];
							/* $cond="select avg(m.number_value) as avg_marks,c.dossier_id from course_attendants_marks c,marks m where m.id=c.mark_id and c.course_attendant_id in(".$ids.") and c.evaluation_date='".$course_date."'"; */
							$cond="select round((sum(m.number_value*mc.factor)/sum(mc.factor)),2) as marks,c.dossier_id from course_attendants_marks c,marks m,mark_categories mc where m.id=c.mark_id and mc.id=c.mark_category_id  and c.course_attendant_id in(".$course_attendant_details[0]['id'].")";
							$course_attendant_marks_details = $this->users_model->special_fetch($cond);
							
							if(count($course_attendant_marks_details)>0)
							{
								if($course_attendant_marks_details[0]['marks']!="")
									$avg_mark=$course_attendant_marks_details[0]['marks'];
							}
							//Lesson Details
							/* if($course_attendant_marks_details[0]['dossier_id']!="")
							{
								$dossier_id=$course_attendant_marks_details[0]['dossier_id'];
								$cond="SELECT id,name,teaser_image,teaser_text,local_share FROM dossiers WHERE id=".$dossier_id." and is_deleted=0";
								$dos_details = $this->users_model->special_fetch($cond);
								foreach($dos_details as $dos)
								{
									if (str_contains($dos['local_share'], 'view')) { 
										$dossier_details1[]=array(
											"id"=>$dos['id'],
											"name"=>$dos['name'],
											"teaser_image"=>$dos['teaser_image'],
											"teaser_text"=>$dos['teaser_text']
										);
									}
								}
							} */
						}
						$cond="SELECT id,name,teaser_image,teaser_text,start_date,end_date,local_share,dossier_key FROM dossiers WHERE course_id=".$time_details[0]['course_id']." and is_deleted=0";	
						$dos_details = $this->users_model->special_fetch($cond);
						foreach($dos_details as $dos)
						{
							$course_date_timestamp=strtotime($course_date);
							$start_date_timestamp=strtotime($dos['start_date']);
							$beginOfDay = strtotime("today", $start_date_timestamp);
							$end_date_timestamp=strtotime($dos['end_date']);
							$end_beginOfDay = strtotime("today", $end_date_timestamp);
							$endOfDay   = strtotime("tomorrow", $end_beginOfDay) - 1;
							if($course_date_timestamp>=$beginOfDay&&$course_date_timestamp<=$endOfDay)
							{
								if(str_contains($dos['local_share'], 'view')) { 
									$dossier_details[]=array(
										"id"=>$dos['id'],
										"name"=>$dos['name'],
										"teaser_image"=>$dos['teaser_image'],
										"dossier_key"=>$dos['dossier_key'],
										"teaser_text"=>$dos['teaser_text']
									);
								}
							}
						}
						//$merged_array = array_merge($dossier_details1, $dossier_details2);
						// Remove duplicates from the merged array using array_unique
						//$dossier_details = array_unique($merged_array, SORT_REGULAR);
						//$dossier_details =  array_map("unserialize", array_unique(array_map("serialize", $dossier_details)));
							//Absent Details
						$absent_student_details = array();
						$from_date=$course_date." ".$lesson_number['time_from'];
						$to_date=$course_date." ".$lesson_number['time_to'];
						if($course_attendant_details[0]['id']!="")
						{
							foreach($student_details as $students)
							{
								$cond="SELECT a.id FROM students_terms st,absences a WHERE st.id=a.student_term_id and a.datetime_from='".$from_date."' and a.datetime_to='".$to_date."' and student_id=".$students['id'];
								$st_term_details = $this->users_model->special_fetch($cond);
								if(count($st_term_details)>0)
								{
									$cond="select id,first_name,last_name from users where id=".$students['id'];
									$user_details = $this->users_model->special_fetch($cond);
									$absent_student_details[]=array(
										"id"=>$user_details[0]['id'],
										"first_name"=>$user_details[0]['first_name'],
										"last_name"=>$user_details[0]['last_name']
									);
								}
							}
						}
						$date_from = strtotime($from_date);
						$date_to = strtotime($to_date);
						$from_dis_date=date('F j, Y', $date_from)." ".$lesson_number['time_from'];
						$to_dis_date=date('F j, Y', $date_to)." ".$lesson_number['time_to'];
						//Allow Upload Details
						$cond="SELECT allow_student_uploads FROM course_upload_settings WHERE term_id=".$term_id." and course_id=".$time_details[0]['course_id'];
						$course_upload_details = $this->users_model->special_fetch($cond);
						$allow_student_uploads="";
						if(count($course_upload_details)>0)
							$allow_student_uploads=$course_upload_details[0]['allow_student_uploads'];
						
							$timeline_details[]=array(
							"course_id"=>$time_details[0]['course_id'],
							"course_name"=>$time_details[0]['course_name'],
							"room_name"=>$room_name,
							"dossier_details"=>$dossier_details,
							"no_of_course_attendants"=>$no_of_course_attendants,
							"avg_marks"=>$avg_mark,
							"absent_student_details"=>$absent_student_details,
							"from_date"=>$from_dis_date,
							"to_date"=>$to_dis_date,
							"student_details"=>$student_details,
							"allow_student_uploads"=>$allow_student_uploads,
							"notifications"=>$notify_details
						);					
					}
					else
					{
						$timeline_details[]=array(
							"course_id"=>"",
							"student_details"=>$student_details
						);
					}
					$daily_timeline_details[]=array(
						"term"=>$term,
						"lesson"=>$lesson_number['lesson_number'],
						"time_from"=>$lesson_number['time_from'],
						"time_to"=>$lesson_number['time_to'],	
						"timeline_details"=>$timeline_details,
						"entity_class"=>$entity_class
					);
				}
			}
			else if($entity_class=="studententity")
			{
				$cond="select id,lesson_number,time_from,time_to from lesson_numbers where is_active=1 and is_deleted=0 order by lesson_number asc";
				$lesson_number_details = $this->users_model->special_fetch($cond);
				foreach($lesson_number_details as $lesson_number)
				{
					$timeline_details=array();
					$dossier_details=array();
					$cond="SELECT c.id,c.course_id FROM course_attendants c,students_terms st WHERE c.student_term_id=st.id and st.term_id=".$term_id." and st.student_id=".$id;
					$course_attendant_details = $this->users_model->special_fetch($cond);
					if(count($course_attendant_details)>0)
					{	
						$course_id="";$course_attendant_id="";
						foreach($course_attendant_details as $cor)
						{
							$cond="select room_id from timetable where term_id =".$term_id." and weekday_id =".$weekday_fld." and lesson_number_id=".$lesson_number['id']." and course_id=".$cor['course_id'];
							$time_details = $this->users_model->special_fetch($cond);
							if(count($time_details)>0)
							{
								$course_id=$cor['course_id'];
								//Course Details
								$cond="select name from courses where id=".$course_id;
								$cor_details = $this->users_model->special_fetch($cond);
								$course_name=$cor_details[0]['name'];
								//Course Attendants
								$course_attendant_id=$cor['id'];
								break;
							}
						}
						if($course_id!="")
						{
							//rooms details
							$cond="select name from rooms where id=".$time_details[0]['room_id'];
							$room_details = $this->users_model->special_fetch($cond);
							$room_name=$room_details[0]['name'];
							$cond="select dossier_id from course_attendants_marks where course_attendant_id=".$course_attendant_id." and evaluation_date='".$course_date."'";
							$course_attendant_marks_details = $this->users_model->special_fetch($cond);
							//Lesson Details
							$dossier_details = array();
							/* if(count($course_attendant_marks_details)>0)
							{
								$dossier_id=$course_attendant_marks_details[0]['dossier_id'];
								$cond="SELECT id,name,teaser_image,teaser_text FROM dossiers WHERE id=".$dossier_id." and is_deleted=0";
								$dos_details = $this->users_model->special_fetch($cond);
								foreach($dos_details as $dos)
								{
									$dossier_details[]=array(
										"id"=>$dos['id'],
										"name"=>$dos['name'],
										"teaser_image"=>$dos['teaser_image'],
										"teaser_text"=>$dos['teaser_text']
									);
								}
							} */
							$cond="SELECT id,name,teaser_image,teaser_text,start_date,end_date FROM dossiers WHERE course_id=".$course_id." and is_deleted=0";	
							$dos_details = $this->users_model->special_fetch($cond);
							foreach($dos_details as $dos)
							{
								$course_date_timestamp=strtotime($course_date);
								$start_date_timestamp=strtotime($dos['start_date']);
								$beginOfDay = strtotime("today", $start_date_timestamp);
								$end_date_timestamp=strtotime($dos['end_date']);
								$end_beginOfDay = strtotime("today", $end_date_timestamp);
								$endOfDay   = strtotime("tomorrow", $end_beginOfDay) - 1;
								if($course_date_timestamp>$beginOfDay&&$course_date_timestamp<$endOfDay)
								{
									$dossier_details[]=array(
										"id"=>$dos['id'],
										"name"=>$dos['name'],
										"teaser_image"=>$dos['teaser_image'],
										"teaser_text"=>$dos['teaser_text']
									);
								}
							}	
							//$dossier_details =  array_map("unserialize", array_unique(array_map("serialize", $dossier_details)));
							//Allow Upload Details
							$cond="SELECT id,allow_student_uploads FROM course_upload_settings WHERE term_id=".$term_id." and course_id=".$course_id;
							$course_upload_setting_details = $this->users_model->special_fetch($cond);
							$allow_student_uploads="";
							$course_upload_count=0;
							if(count($course_upload_setting_details)>0)
							{
								$allow_student_uploads=$course_upload_setting_details[0]['allow_student_uploads'];
								$cond="SELECT id,course_attendant_id FROM course_uploads WHERE course_upload_setting_id =".$course_upload_setting_details[0]['id']." and (course_attendant_id is null or uploaded_by=".$id.")";
								$course_upload_details = $this->users_model->special_fetch($cond);
								$course_upload_count=count($course_upload_details);
							}
							/* $notification_details=array();
							$from_date=$course_date." ".$lesson_number['time_from'];
							$date = new DateTime($from_date, new DateTimeZone("UTC"));
							$from_date=$date->format("Y-m-d H:i:s e") . "\n";
							$date_from = strtotime($from_date);
							$to_date=$course_date." ".$lesson_number['time_to'];
							$date = new DateTime($to_date, new DateTimeZone("UTC"));
							$to_date=$date->format("Y-m-d H:i:s e") . "\n";
							$date_to = strtotime($to_date);
							foreach($notify_details as $not)
							{
								if($not['due_date_timestamp']>=$date_from&&$not['due_date_timestamp']<=$date_to)
								{
									$notification_details[]=array(
										"id"=>$not['id'],
										"type"=>$not['type'],
										"message"=>$not['message'],
										"created_by_name"=>$not['created_by_name']
									);
								}
							} */
							$timeline_details[]=array(
								"course_attendant_id"=>$course_attendant_id,
								"course_id"=>$course_id,
								"course_name"=>$course_name,
								"room_name"=>$room_name,
								"dossier_details"=>$dossier_details,
								"course_upload_details_count"=>$course_upload_count,
								"allow_student_uploads"=>$allow_student_uploads,
								"notifications"=>$notify_details
							);
						}
						else
						{
							$timeline_details[]=array(
								"course_id"=>""
							);
						}
					}
					else
					{
						$timeline_details[]=array(
							"course_id"=>""
						);
					}
					$daily_timeline_details[]=array(
						"lesson"=>$lesson_number['lesson_number'],
						"time_from"=>$lesson_number['time_from'],
						"time_to"=>$lesson_number['time_to'],	
						"timeline_details"=>$timeline_details,
						"entity_class"=>$entity_class
					);
				}
			}
			if(count($daily_timeline_details)<=0)
				$daily_timeline_details=array();
			$out = array('statuscode'=>'200','daily_timeline_details'=>$daily_timeline_details);
			header('Content-Type:application/json');
			echo json_encode($out);
		}
    }
	function view_timeline_student_details()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$student_details = $data['student_details'];
		$course_id = $data['course_id'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		foreach($student_details as $students)
		{
			$cond="select personnel_id from courses where id=".$course_id;
			$cor_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)>0)
			{
				$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$cor_details[0]['personnel_id'];
				$usr_details = $this->users_model->special_fetch($cond);
				$cond="select group_concat(id) as ids from students_terms where student_id=".$students['id']." and term_id=".$term_id;
				$page_details = $this->users_model->special_fetch($cond);
				if($page_details[0]['ids']!="")
				{
					$student_name=$students['first_name']." ".$students['last_name'];
					$cond="select id from course_attendants where student_term_id in(".$page_details[0]['ids'].") and course_id=".$course_id;
					$cor_details = $this->users_model->special_fetch($cond);
					if(count($cor_details)>0)
					{
						$all_student_details[]=array(
							"id"=>$cor_details[0]['id'],
							"student_id"=>$students['id'],
							"student_name"=>$student_name,
							"teacher_name"=>$usr_details[0]['name']
						);
					}
				}
			}
		}
		$totalRecord=count($all_student_details);
		$totalRecordwithFilter = $totalRecord;
		$search_count=0;
		$student_details=array();
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			for($i=0;$i<count($all_student_details);$i++)
			{
				if(strpos(strtolower($all_student_details[$i]['student_name']), $searchValue) !== false||strpos(strtolower($all_student_details[$i]['teacher_name']), $searchValue) !== false)
				{
					$student_details[]=$all_student_details[$i];
				}
			}
			$search_count=count($student_details);
		}
		else{
			$student_details=$all_student_details;
		}
		if($search_count!=0)
			$totalRecordwithFilter=$search_count;
		if($totalRecord=="")
		{
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		if(count($student_details)<=0)
		{
			$student_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		$output = array_slice($student_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	function view_timeline_student_files(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$id = $data['id'];
		$student_id = $data['student_id'];
		$cond="select id,created_at,original_file_name,filename,teacher_checked,description from course_uploads where course_attendant_id =".$id." and uploaded_by=".$student_id;

		$student_file_details = $this->course_attendants_marks_model->special_fetch($cond);
		if(count($student_file_details)>0)
        {
			$out = array('statuscode'=>'200','student_file_details'=>$student_file_details);
		}
		else
		{
			$out = array('statuscode'=>'201');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function view_timeline_teacher_details()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$id = $data['id'];
		$course_id = $data['course_id'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$cor_details=array();
		if($course_id!="")
		{
			$cond="select id from course_upload_settings where course_id=".$course_id." and term_id=".$term_id;
			$upl_details = $this->users_model->special_fetch($cond);
			if(count($upl_details)>0)
			{
				$cond="select * from course_uploads where course_upload_setting_id=".$upl_details[0]['id']." and uploaded_by =".$id." order by ".$columnName." ".$columnSortOrder;
				$cor_details = $this->users_model->special_fetch($cond);
			}
		}
		$totalRecord=count($cor_details);
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
		{
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		if(count($cor_details)<=0)
		{
			$cor_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		$output = array_slice($cor_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	function view_timeline_student_file_details(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$id = $data['id'];
		$course_id = $data['course_id'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		if($columnName=="")
		{
			$columnName = "created_at";
			$columnSortOrder = "desc";
		}
		$course_upload_details=array();
		$cond="select id from course_upload_settings where course_id=".$course_id." and term_id=".$term_id;
		$upl_details = $this->users_model->special_fetch($cond);
		if(count($upl_details)>0)
		{
			$cond="SELECT * FROM course_uploads WHERE course_upload_setting_id =".$upl_details[0]['id']." and (course_attendant_id is null or uploaded_by=".$id.") order by ".$columnName." ".$columnSortOrder;
			$course_upload_details = $this->users_model->special_fetch($cond);
			for($i=0;$i<count($course_upload_details);$i++)
			{
				$cond="select homework_completed from course_upload_students where upload_id=".$course_upload_details[$i]['id']." and student_id=".$id." and filename='".$course_upload_details[$i]['filename']."'";
				$stu_details = $this->users_model->special_fetch($cond);
				if(count($stu_details)>0)
					$course_upload_details[$i]['homework_completed']=$stu_details[0]['homework_completed'];
				else
					$course_upload_details[$i]['homework_completed']="";
			}
		}
		$totalRecord=count($course_upload_details);
		$totalRecordwithFilter = $totalRecord;
		if($totalRecord=="")
		{
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		if(count($course_upload_details)<=0)
		{
			$course_upload_details=array();
			$totalRecord=0;
			$totalRecordwithFilter=0;
		}
		$output = array_slice($course_upload_details, $start, $rowperpage);
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$output);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function add_timeline_absence(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$absences_arr=$data['absences'];
		foreach($absences_arr as $absence)
		{
			$start_date=$absence['eval_date']." ".$absence['from_time'];
			$end_date=$absence['eval_date']." ".$absence['to_time'];
			$start_timestamp=strtotime($start_date);
			$end_timestamp=strtotime($end_date);
			$cond="select id from students_terms where student_id=".$absence['student_term_id'];
        	$st_details = $this->users_model->special_fetch($cond);
			$input = array(
				'student_term_id'=>$st_details[0]['id'],
				'absence_category_id'=>$absence['absence_category_id'],
				'personnel_id'=>$absence['id'],
				'datetime_from'=>$start_date,
				'datetime_to'=>$end_date,
				'startdate_timestamp'=>$start_timestamp,
				'enddate_timestamp'=>$end_timestamp,
				'is_excusable'=>$absence['is_excusable'],
				'is_excused'=>$absence['is_excused']
			);
			$this->absences_model->add($input);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[130]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function add_timeline_disciplinary(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$disciplinary_arr=$data['disciplinary'];
		foreach($disciplinary_arr as $disciplinary)
		{
			$cond="select id from students_terms where student_id=".$disciplinary['student_id'];
        	$st_details = $this->users_model->special_fetch($cond);
			$input = array(
				'student_term_id'=>$st_details[0]['id'],
				'disciplinary_category_id'=>$disciplinary['disciplinary_category_id'],
				'description'=>$disciplinary['description'],
				'personnel_id'=>$disciplinary['id'],
				'is_parent_check_needed'=>$disciplinary['parental_check'],
				'points_value'=>0
			);
			$this->disciplinary_model->add($input);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[131]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function add_timeline_marks()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		$course_id = $data['course_id'];
		$mark_category_id = $data['mark_category_id'];
		$remark = $data['remark'];
		$evaluation_date = $data['evaluation_date'];
		$dossier_id = $data['dossier_id'];
		if($dossier_id=="")
			$dossier_id=0;
		$mark_counts = $data['mark_counts'];
		$students = $data['students'];
		$marks = $data['marks'];
		$mark_type = $data['mark_type'];
		$mark_schema = $data['mark_schema'];
		$mark_schema =json_encode($mark_schema);
		$flag=false;
		for($i=0;$i<count($students);$i++)
		{
			$cond="SELECT c.id FROM course_attendants c,students_terms st where c.student_term_id=st.id and st.student_id=".$students[$i]." and c.course_id=".$course_id." and st.term_id=".$term_id;
			$course_details = $this->course_attendants_marks_model->special_fetch($cond);
			if(count($course_details)>0)
			{
				$course_attendant_id=$course_details[0]['id'];
				$input = array(
					'course_attendant_id'=>$course_attendant_id,
					'mark_id'=>$marks[$i],
					'mark_category_id'=>$mark_category_id,
					'remark'=>$remark,
					'evaluation_date'=>$evaluation_date,
					'dossier_id'=>$dossier_id,
					'mark_type'=>$mark_type,
					'mark_schema'=>$mark_schema,
					'is_counted'=>$mark_counts
				);
				$this->course_attendants_marks_model->add($input);
				$flag=true;
			}
		}
		if($flag)
			$out = array('statuscode'=>'200','statusdescription'=>$label_details[133]['name']);		
		else
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[132]['name']);		
	    header('Content-Type:application/json');
        echo json_encode($out);
	}
    function add_timeline_teacher_uploads(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$course_id = $data['course_id'];
		$allow_uploads = $data['allow_uploads'];
		$description = $data['description'];
		$fileorgName = $data['fileorgName'];
		$unqfilename = $data['unqfilename'];
		$lastModified = $data['lastModified'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		$cond="SELECT id FROM course_upload_settings where course_id=".$course_id." and term_id=".$term_id;
		$course_details = $this->course_attendants_marks_model->special_fetch($cond);
		$course_upload_setting_id="";
		if(count($course_details)>0)
		{
			$course_upload_setting_id=$course_details[0]['id'];
		}
		else
		{
			$input = array(
				'course_id'=>$course_id,
				'term_id'=>$term_id,
				'allow_student_uploads'=>$allow_uploads,
				'created_at'=>time()
			);
			$course_upload_setting_id=$this->course_upload_settings_model->add($input);
		}
		$input = array(
			'course_upload_setting_id'=>$course_upload_setting_id,
			'uploaded_by'=>$id,
			'original_file_name'=>$fileorgName,
			'filename'=>$unqfilename,
			'description'=>$description,
			'upload_type'=>'teacher',
			'updated_at'=>$lastModified,
			'created_at'=>time()
		);
		$this->course_uploads_model->add($input);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[134]['name']);
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function add_timeline_student_uploads(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$course_id = $data['course_id'];
		$course_attendant_id = $data['course_attendant_id'];
		$description = $data['description'];
		$fileorgName = $data['fileorgName'];
		$unqfilename = $data['unqfilename'];
		$lastModified = $data['lastModified'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		$cond="SELECT id FROM course_upload_settings where course_id=".$course_id." and term_id=".$term_id;
		$course_details = $this->course_attendants_marks_model->special_fetch($cond);
		$course_upload_setting_id="";
		if(count($course_details)>0)
		{
			$course_upload_setting_id=$course_details[0]['id'];
		}
		else
		{
			$input = array(
				'course_id'=>$course_id,
				'term_id'=>$term_id,
				'allow_student_uploads'=>0,
				'created_at'=>time()
			);
			$course_upload_setting_id=$this->course_upload_settings_model->add($input);
		}
		$input = array(
			'course_upload_setting_id'=>$course_upload_setting_id,
			'course_attendant_id'=>$course_attendant_id,
			'uploaded_by'=>$id,
			'original_file_name'=>$fileorgName,
			'filename'=>$unqfilename,
			'description'=>$description,
			'upload_type'=>'student',
			'updated_at'=>$lastModified,
			'created_at'=>time()
		);
		$this->course_uploads_model->add($input);
		$out = array('statuscode'=>'200');
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
	    
    function delete_timeline(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>1,
				'deleted_at'=>time()
			);
			$this->timeline_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[137]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function update_course_upload_settings(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$course_id = $data['id'];
		$allow_uploads = $data['allow_uploads'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		$cond="SELECT id FROM course_upload_settings where course_id=".$course_id." and term_id=".$term_id;
		$course_details = $this->course_attendants_marks_model->special_fetch($cond);
		$course_upload_setting_id="";
		if(count($course_details)>0)
		{
			$course_upload_setting_id=$course_details[0]['id'];
			$input = array(
				'allow_student_uploads'=>$allow_uploads
			);
			$this->course_upload_settings_model->edit($input,$course_upload_setting_id);
		}
		else
		{
			$input = array(
				'course_id'=>$course_id,
				'term_id'=>$term_id,
				'allow_student_uploads'=>$allow_uploads,
				'created_at'=>time()
			);
			$course_upload_setting_id=$this->course_upload_settings_model->add($input);
		}
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function update_course_uploads(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$teacher_checked = $data['teacher_checked'];
		$input = array(
			'teacher_checked'=>$teacher_checked
		);
		$this->course_uploads_model->edit($input,$id);
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function update_student_course_uploads(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$student_id = $data['student_id'];
		$homework_completed = $data['homework_completed'];
		$cond="SELECT filename FROM course_uploads where id=".$id;
		$course_details = $this->course_attendants_marks_model->special_fetch($cond);
		$cond="SELECT id FROM course_upload_students where upload_id=".$id." and student_id=".$student_id;
		$course_student_details = $this->course_attendants_marks_model->special_fetch($cond);
		if(count($course_student_details)<=0)
		{
			$input = array(
				'upload_id'=>$id,
				'student_id'=>$student_id,
				'filename'=>$course_details[0]['filename'],
				'homework_completed'=>$homework_completed,
				'created_at'=>time()
			);
			$this->course_upload_students_model->add($input);
		}
		else
		{
			$input = array(
				'homework_completed'=>$homework_completed
			);
			$this->course_upload_students_model->edit($input,$course_student_details[0]['id']);
		}
		$out = array('statuscode'=>'200');              
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function delete_course_uploads(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$not_in_use_name="";$in_use_name="";
		$cond="select original_file_name from course_uploads where id=".$id;
		$p_details = $this->users_model->special_fetch($cond);
		$name=$p_details[0]['original_file_name'];
		$cond="select id from course_upload_students where upload_id=".$id;
		$ab_details = $this->subject_types_model->special_fetch($cond);
		if(count($ab_details)<=0)
		{
			$this->course_uploads_model->delete($id);	
			$not_in_use_name=$not_in_use_name.",".$name;
		}
		else
		{
			$in_use_name=$in_use_name.",".$name;
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[137]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[138]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);             
        header('Content-Type:application/json');
        echo json_encode($out);               
	}
	function get_dossier_by_id(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$cond="SELECT * FROM dossiers where id=".$id;
		$dossier_details = $this->course_attendants_marks_model->special_fetch($cond);
		if($dossier_details[0]['term_id']!="")
		{
			$cond="select name from terms where id=".$dossier_details[0]['term_id'];
			$comp_details = $this->users_model->special_fetch($cond);
			if(count($comp_details)>0)
				$dossier_details[0]['term']=$comp_details[0]['name'];
			else
				$dossier_details[0]['term']="";
		}
		else
			$dossier_details[0]['term']="";
		if($dossier_details[0]['personnel_id']!="")
		{
			$cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$dossier_details[0]['personnel_id'];
			$usr_details = $this->users_model->special_fetch($cond);
			if(count($usr_details)>0)
				$dossier_details[0]['teacher']=$usr_details[0]['name'];
			else
				$dossier_details[0]['teacher']="";
		}
		else
			$dossier_details[0]['teacher']="";
		if($dossier_details[0]['course_id']!="")
		{
			$cond="select name from courses where id=".$dossier_details[0]['course_id'];
			$cor_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)>0)
				$dossier_details[0]['course']=$cor_details[0]['name'];
			else
				$dossier_details[0]['course']="";
		}
		else
			$dossier_details[0]['course']="";
		if($dossier_details[0]['dossier_language_id']!="")
		{
			$cond="select name from dossier_languages where id=".$dossier_details[0]['dossier_language_id'];
			$cor_details = $this->users_model->special_fetch($cond);
			if(count($cor_details)>0)
				$dossier_details[0]['language']=$cor_details[0]['name'];
			else
				$dossier_details[0]['language']="";
		}
		else
			$dossier_details[0]['language']="";
		$cond="select d.id,d.document_name,d.document_unique_name from dossiers_related_files df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_related_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['document_files']=$doc_related_details;
		$cond="select d.id,d.document_name,d.document_unique_name from dossiers_solutions df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_solution_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['solution_files']=$doc_solution_details;
		$cond="select df.mark_category_id,df.keywords,df.description,df.evaluation_date,d.id,d.document_name,d.document_unique_name from dossiers_evaluations df,documents d where d.id=df.dossier_file_id and df.dossier_id=".$dossier_details[0]['id'];
		$doc_solution_details = $this->users_model->special_fetch($cond);
		$dossier_details[0]['evaluation_files']=$doc_solution_details;
		$out = array('statuscode'=>'200','dossier_details'=>$dossier_details);             
        header('Content-Type:application/json');
        echo json_encode($out);  
	}
	function get_upload_count(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$course_id = $data['course_id'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$cur_time=time();
		$term_id='';
		$all_student_details=array();
		foreach($term_details as $term)
		{
			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
				break;
			}
		}
		$cond="select id from course_upload_settings where term_id =".$term_id." and course_id=".$course_id;
		$cor_details = $this->users_model->special_fetch($cond);
		$cond="SELECT count(id) as cr_cnt FROM course_uploads WHERE course_upload_setting_id =".$cor_details[0]['id']." and (course_attendant_id is null or uploaded_by=".$id.")";
		$course_upload_details = $this->users_model->special_fetch($cond);
		$out = array('statuscode'=>'200','upload_count'=>$course_upload_details[0]['cr_cnt']);             
        header('Content-Type:application/json');
        echo json_encode($out); 
	}
	function get_students_for_timeline(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$id = $data['id'];
		$group_id = $data['group_id'];
		$student_details=array();
		if($group_id==4)
		{
			$cond="select distinct u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id;
			$student_details = $this->users_model->special_fetch($cond);
		}
		$out = array('statuscode'=>'200','student_details'=>$student_details);             
        header('Content-Type:application/json');
        echo json_encode($out); 
	}
}
