<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Timetable_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=37 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	function search_revisions($dataArray, $search_value, $key_to_search, $other_matching_value = null, $other_matching_key = null) {
		// This function will search the revisions for a certain value
		// related to the associative key you are looking for.
		$keys = array();
		foreach ($dataArray as $key => $cur_value) {
			if ($cur_value[$key_to_search] == $search_value) {
				if (isset($other_matching_key) && isset($other_matching_value)) {
					if ($cur_value[$other_matching_key] == $other_matching_value) {
						$keys[] = $key;
					}
				} else {
					// I must keep in mind that some searches may have multiple
					// matches and others would not, so leave it open with no continues.
					$keys[] = $key;
				}
			}
		}
		return $keys;
	}
	
	//timetable
	function view_daily_timetable(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$weekday_fld = $data['weekday_fld'];
		$term_fld = $data['term_fld'];
		$teacher_fld = $data['teacher_fld'];
		if($term_fld=="")
		{
			$cond="select id from terms where is_deleted=0 and is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			$term_fld=$term_details[0]['id'];
		}
		if($weekday_fld=="")
		{
			$flag=false;
			$i=0;
			$cur_day=strtolower(date('l'));
			while(!$flag)
			{	
				$cond="select id from weekdays where lower(dup_name)='".$cur_day."' and is_active=1";
				$weekday_details = $this->users_model->special_fetch($cond);
				if(count($weekday_details)>0)
				{
					$weekday_fld=$weekday_details[0]['id'];
					$flag=true;
				}
				else
				{
					$i++;
					$cur_day=Date('l', strtotime('+".$i." days'));
				}
			}
		}
		$cond="select id,lesson_number from lesson_numbers where is_active=1 and is_deleted=0 order by lesson_number asc";
		$lesson_number_details = $this->users_model->special_fetch($cond);
		$cond="select id,name from rooms where is_active=1 and is_deleted=0 order by name asc";
		$room_details = $this->users_model->special_fetch($cond);
		$daily_timetable_details=array();
		$colors=array("#f6f9cb","#f9d5cb","#f9e3cb","#d5f9cb","#cbf9e9","#cbe8f9","#cdcbf9","#f0cbf9","#f9cbe0","#f4b8c1","#ed9a9a","#edbe9a","#edda9a","#c2ed9a","#9aedb1","#83e3e2","#83c0e3","#8393e3","#c497ea","#e397ea","#ea97b2","#fca04e","#fcdb4e","#6efc4e","#4ebcfc","#4e7afc","#dc7b7b","#dcad7b","#dcca7b","#cadc7b","#95dc7b","#7bdc7e","#7bdca2","#7bd9dc","#7bbcdc","#7b9cdc","#7b87dc","#8f7bdc","#ac7bdc","#c87bdc","#dc7bc3","#998a86","#999486","#929986","#889986","#86998d","#869899","#868b99","#8b8699","#988699");
		$color_arr=array();
		$k=0;
		foreach($lesson_number_details as $lesson_number)
		{
			$room_arr=array();
			foreach($room_details as $rooms)
			{
				$cond="select id,course_id from timetable where term_id =".$term_fld." and weekday_id =".$weekday_fld." and lesson_number_id=".$lesson_number['id']." and room_id=".$rooms['id'];
				$time_details = $this->users_model->special_fetch($cond);	
				if(count($time_details)>0)
				{
					$course_id=$time_details[0]['course_id'];
					$cond="select name,personnel_id from courses where id=".$course_id;
					$course_details = $this->users_model->special_fetch($cond);
					$course_name=$course_details[0]['name'];
					$cond="select first_name,last_name from users where id=".$course_details[0]['personnel_id'];
					$teacher_details = $this->users_model->special_fetch($cond);
					$tutor_name=$teacher_details[0]['first_name']." ".$teacher_details[0]['last_name'];
					$per_id=$course_details[0]['personnel_id'];
					if($teacher_fld!="")
					{
						if($teacher_fld==$course_details[0]['personnel_id'])
						{
							if (!array_key_exists($per_id,$color_arr))
							{
								$color_arr[$per_id]=$k;
								$k++;
							}
							$val=$color_arr[$per_id];
							$color_val=$colors[$val];
							$room_arr[]=array(
								"id"=>$time_details[0]['id'],
								"term_id"=>$term_fld,
								"room_id"=>$rooms['id'],
								"lesson_number_id"=>$lesson_number['id'],
								"weekday_id"=>$weekday_fld,
								"course_id"=>$time_details[0]['course_id'],
								"course_name"=>$course_name,
								"tutor_name"=>$tutor_name,
								"color"=>$color_val
							);
						}
						else
						{
							$room_arr[]=array(
								"id"=>$time_details[0]['id'],
								"term_id"=>$term_fld,
								"room_id"=>$rooms['id'],
								"lesson_number_id"=>$lesson_number['id'],
								"weekday_id"=>$weekday_fld,
								"course_id"=>"",
								"course_name"=>"",
								"tutor_name"=>"",
								"color"=>""
							);
						}
					}
					else
					{
						if (!array_key_exists($per_id,$color_arr))
						{
							$color_arr[$per_id]=$k;
							$k++;
						}
						$val=$color_arr[$per_id];
						$color_val=$colors[$val];
						$room_arr[]=array(
							"id"=>$time_details[0]['id'],
							"term_id"=>$term_fld,
							"room_id"=>$rooms['id'],
							"lesson_number_id"=>$lesson_number['id'],
							"weekday_id"=>$weekday_fld,
							"course_id"=>$time_details[0]['course_id'],
							"course_name"=>$course_name,
							"tutor_name"=>$tutor_name,
							"color"=>$color_val
						);
					}
				}
				else
				{
					$room_arr[]=array(
						"id"=>"",
						"term_id"=>$term_fld,
						"room_id"=>$rooms['id'],
						"lesson_number_id"=>$lesson_number['id'],
						"weekday_id"=>$weekday_fld,
						"course_id"=>"",
						"course_name"=>"",
						"tutor_name"=>"",
						"color"=>""
					);
				}				
			}
			$daily_timetable_details[]=array(
				"lesson"=>$lesson_number['lesson_number'],
				"room_details"=>$room_arr
			);
		}
		if(count($daily_timetable_details)<=0)
			$daily_timetable_details=array();
        $out = array('statuscode'=>'200','rooms'=>$room_details,'daily_timetable_details'=>$daily_timetable_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function test_date()
	{
		$i=1;
		echo $NewDate=Date('l', strtotime('+".$i." days'));
	}
	function view_weekly_timetable(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$term_fld = $data['term_fld'];
		if($term_fld=="")
		{
			$cond="select * from terms where is_deleted=0";
			$term_details = $this->users_model->special_fetch($cond);
			$cur_time=time();
			foreach($term_details as $term)
			{

				if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
				{
					$term_fld=$term['id'];
				}
			}
			if($term_fld=="")
			{
				$cond="select id from terms where is_active=1";
				$term_details = $this->users_model->special_fetch($cond);
				$term_fld=$term_details[0]['id'];
			}
		}
		$cond="select id,lesson_number from lesson_numbers where is_active=1 and is_deleted=0 order by lesson_number asc";
		$lesson_number_details = $this->users_model->special_fetch($cond);
		$cond="select id,name from rooms where is_active=1 and is_deleted=0 order by name asc";
		$room_details = $this->users_model->special_fetch($cond);
		$cond="select id,name from weekdays where is_active=1 and is_deleted=0 order by weekday_number asc";
		$weekday_details = $this->users_model->special_fetch($cond);
		$daily_timetable_details=array();
		$colors=array("#f6f9cb","#f9d5cb","#f9e3cb","#d5f9cb","#cbf9e9","#cbe8f9","#cdcbf9","#f0cbf9","#f9cbe0","#f4b8c1","#f6f9cb","#ed9a9a","#edbe9a","#edda9a","#c2ed9a","#9aedb1","#83e3e2","#83c0e3","#8393e3","#c497ea","#e397ea","#ea97b2");
		$color_arr=array();
		$k=0;
		foreach($lesson_number_details as $lesson_number)
		{
			$weekly_arr=array();
			foreach($weekday_details as $week)
			{
				$day=substr($week['name'], 0, 2);
				$room_arr=array();
				foreach($room_details as $rooms)
				{					
					$cond="select id,course_id from timetable where term_id =".$term_fld." and weekday_id =".$week['id']." and lesson_number_id=".$lesson_number['id']." and room_id=".$rooms['id'];
					$time_details = $this->users_model->special_fetch($cond);	
					if(count($time_details)>0)
					{						
						$course_id=$time_details[0]['course_id'];
						$cond="select name,personnel_id from courses where id=".$course_id;
						$course_details = $this->users_model->special_fetch($cond);
						$course_name=$course_details[0]['name'];
						$cond="select first_name,last_name from users where id=".$course_details[0]['personnel_id'];
						$teacher_details = $this->users_model->special_fetch($cond);
						$tutor_name=$teacher_details[0]['first_name']." ".$teacher_details[0]['last_name'];
						$per_id=$course_details[0]['personnel_id'];
						if (!array_key_exists($per_id,$color_arr))
						{
							$color_arr[$per_id]=$k;
							$k++;
						}
						$val=$color_arr[$per_id];
						$color_val=$colors[$val];
						$room_arr[]=array(
							"course_name"=>$course_name,
							"tutor_name"=>$tutor_name,
							"color"=>$color_val
						);
					}
					else
					{
						$room_arr[]=array(
							"course_name"=>"",
							"tutor_name"=>"",
							"color"=>""
						);
					}	
				}
				$weekly_arr[]=array(
					"day"=>$day,
					"room_details"=>$room_arr
				);			
			}
			$daily_timetable_details[]=array(
				"lesson"=>$lesson_number['lesson_number'],
				"weekly_details"=>$weekly_arr
			);
		}
		if(count($daily_timetable_details)<=0)
			$daily_timetable_details=array();
        $out = array('statuscode'=>'200','rooms'=>$room_details,'daily_timetable_details'=>$daily_timetable_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	
	function add_timetable(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);	
		$time_table_id = $data['time_table_id'];
		$course_id= $data['course_id'];
		$time_table_arr=explode("-",$time_table_id);
		$term_id=$time_table_arr[0];
		$room_id=$time_table_arr[1];
		$lesson_number_id=$time_table_arr[2];
		$weekday_id=$time_table_arr[3];
		$cond="select id from timetable where lesson_number_id=".$lesson_number_id." and weekday_id=".$weekday_id." and term_id=".$term_id." and course_id=".$course_id." and room_id<>".$room_id;
        $timetable_details = $this->users_model->special_fetch($cond);
		if(count($timetable_details)<=0)
		{
			$cond="select personnel_id from courses where id=".$course_id;
        	$course_details = $this->users_model->special_fetch($cond);
			$cur_personnel_id=$course_details[0]['personnel_id'];
			$cond="select course_id from timetable where lesson_number_id=".$lesson_number_id." and weekday_id=".$weekday_id." and term_id=".$term_id." and room_id<>".$room_id;
			$room_details = $this->users_model->special_fetch($cond);
			$not_found_personnel=true;
			foreach($room_details as $room)
			{
				$cond="select personnel_id from courses where id=".$room['course_id'];
        		$cor_details = $this->users_model->special_fetch($cond);
				if($cor_details[0]['personnel_id']==$cur_personnel_id)
				{
					$not_found_personnel=false;
					break;
				}
			}
			if($not_found_personnel)
			{
				$input = array(
					'lesson_number_id'=>$lesson_number_id,
					'weekday_id'=>$weekday_id,
					'term_id'=>$term_id,
					'course_id'=>$course_id,
					'room_id'=>$room_id,
					'created_at'=>time()
				);
				$mid = $this->timetable_model->add($input);
				if($mid){				
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[49]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[50]['name']);
				}
			}
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[51]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[52]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function edit_timetable(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);	
		$time_table_id = $data['time_table_id'];
		$course_id= $data['course_id'];
		$time_table_arr=explode("-",$time_table_id);
		$id=$time_table_arr[1];
		$cond="select * from timetable where id=".$id;
        $t_details = $this->users_model->special_fetch($cond);
		$room_id=$t_details[0]['room_id'];
		$lesson_number_id=$t_details[0]['lesson_number_id'];
		$weekday_id=$t_details[0]['weekday_id'];
		$term_id=$t_details[0]['term_id'];
		$cond="select id from timetable where lesson_number_id=".$lesson_number_id." and weekday_id=".$weekday_id." and term_id=".$term_id." and course_id=".$course_id." and room_id<>".$room_id;
        $timetable_details = $this->users_model->special_fetch($cond);
		if(count($timetable_details)<=0)
		{
			$cond="select personnel_id from courses where id=".$course_id;
        	$course_details = $this->users_model->special_fetch($cond);
			$cur_personnel_id=$course_details[0]['personnel_id'];
			$cond="select course_id from timetable where lesson_number_id=".$lesson_number_id." and weekday_id=".$weekday_id." and term_id=".$term_id." and room_id<>".$room_id;
			$room_details = $this->users_model->special_fetch($cond);
			$not_found_personnel=true;
			foreach($room_details as $room)
			{
				$cond="select personnel_id from courses where id=".$room['course_id'];
        		$cor_details = $this->users_model->special_fetch($cond);
				if($cor_details[0]['personnel_id']==$cur_personnel_id)
				{
					$not_found_personnel=false;
					break;
				}
			}
			if($not_found_personnel)
			{
				$input = array(
					'course_id'=>$course_id,
					'updated_at'=>time()
				);
				$mid = $this->timetable_model->edit($input,$id);
				if($mid){				
					$out = array('statuscode'=>'200','statusdescription'=>$label_details[53]['name']);
				}
				else{
					$out = array('statuscode'=>'201','statusdescription'=>$label_details[54]['name']);
				}
			}
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[55]['name']);
			}
		}  
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[56]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
      
    function delete_timetable(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$time_table_id = $data['time_table_id'];
		$time_table_arr=explode("-",$time_table_id);
		$id=$time_table_arr[1];
		$this->timetable_model->delete($id);
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[57]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function duplicate_timetable(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$source_term_id = $data['source_term_id'];
		$destination_term_id = $data['destination_term_id'];
		$cond="select * from timetable where term_id=".$source_term_id;
		$timetable_details = $this->users_model->special_fetch($cond);
		$input = array(
			'term_id'=>$destination_term_id
		);
		$this->timetable_model->delete_timetable($input);
		foreach($timetable_details as $time)
		{
			$input = array(
				'term_id'=>$destination_term_id,
				'room_id'=>$time['room_id'],
				'lesson_number_id'=>$time['lesson_number_id'],
				'weekday_id'=>$time['weekday_id'],
				'course_id'=>$time['course_id'],
				'created_at'=>time()
			);
			$this->timetable_model->add($input);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[94]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function clear_timetable(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$term_fld = $data['term_fld'];
		$weekday_fld = $data['weekday_fld'];
		$teacher_fld = $data['teacher_fld'];
		if($teacher_fld!="")
		{
			$cond="select id,course_id from timetable where weekday_id=".$weekday_fld." and term_id=".$term_fld;
			$timetable_details = $this->users_model->special_fetch($cond);
			foreach($timetable_details as $time)
			{
				$cond="select personnel_id from courses where id=".$time['course_id'];
				$course_details = $this->users_model->special_fetch($cond);
				if($course_details[0]['personnel_id']==$teacher_fld)
					$this->timetable_model->delete($time['id']);
			}
		}
		else
		{
			$cond="select id from timetable where weekday_id=".$weekday_fld." and term_id=".$term_fld;
			$timetable_details = $this->users_model->special_fetch($cond);
			foreach($timetable_details as $time)
			{
				$this->timetable_model->delete($time['id']);
			}
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[58]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function get_weekdays(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from weekdays where is_active=1 and is_deleted=0 order by weekday_number asc";
		$weekday_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','weekday_details'=>$weekday_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	
    function import_timetable(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['term']==""||$page['weekday']==""||$page['lesson_number']==""||$page['room']==""||$page['course']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['term'];
				$corrupt_arr[] =$page['weekday'];
				$corrupt_arr[] =$page['lesson_number'];
				$corrupt_arr[] =$page['room'];
				$corrupt_arr[] =$page['course'];
				$corrupt_arr[] =$label_details[112]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				$cond="select id from timetable where term_id =".$page['term_id']." and weekday_id  =".$page['weekday_id']." and room_id  =".$page['room_id']." and lesson_number_id  =".$page['lesson_number_id']." and course_id=".$page['course_id'];
				$pg_details = $this->users_model->special_fetch($cond);
				if(count($pg_details)>0)
				{
					$error_arr=array();
					$error_arr[] =$page['term'];
					$error_arr[] =$page['weekday'];
					$error_arr[] =$page['lesson_number'];
					$error_arr[] =$page['room'];
					$error_arr[] =$page['course'];
					$error_arr[] =$label_details[113]['name'];
					$error_rows[$r]=$error_arr;
					$r++;
				}
				else
				{
					$cond="select id from timetable where lesson_number_id=".$page['lesson_number_id']." and weekday_id=".$page['weekday_id']." and term_id=".$page['term_id']." and course_id=".$page['course_id']." and room_id<>".$page['room_id'];
					$timetable_details = $this->users_model->special_fetch($cond);
					if(count($timetable_details)>0)
					{
						$error_arr[] =$page['term'];
						$error_arr[] =$page['weekday'];
						$error_arr[] =$page['lesson_number'];
						$error_arr[] =$page['room'];
						$error_arr[] =$page['course'];
						$error_arr[] =$label_details[114]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						
						$cond="select personnel_id from courses where id=".$page['course_id'];
						$course_details = $this->users_model->special_fetch($cond);
						$cur_personnel_id=$course_details[0]['personnel_id'];
						$cond="select course_id from timetable where lesson_number_id=".$page['lesson_number_id']." and weekday_id=".$page['weekday_id']." and term_id=".$page['term_id']." and room_id<>".$page['room_id'];
						$room_details = $this->users_model->special_fetch($cond);
						$not_found_personnel=true;
						foreach($room_details as $room)
						{
							$cond="select personnel_id from courses where id=".$room['course_id'];
							$cor_details = $this->users_model->special_fetch($cond);
							if($cor_details[0]['personnel_id']==$cur_personnel_id)
							{
								$not_found_personnel=false;
								break;
							}
						}
						if(!$not_found_personnel)
						{
							$error_arr[] =$page['term'];
							$error_arr[] =$page['weekday'];
							$error_arr[] =$page['lesson_number'];
							$error_arr[] =$page['room'];
							$error_arr[] =$page['course'];
							$error_arr[] =$label_details[115]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else
						{
							if($page['term_id']=="")
							{
								$error_arr=array();
								$error_arr[] =$page['term'];
								$error_arr[] =$page['weekday'];
								$error_arr[] =$page['lesson_number'];
								$error_arr[] =$page['room'];
								$error_arr[] =$page['course'];
								$error_arr[] =$label_details[63]['name'];
								$error_rows[$r]=$error_arr;
								$r++;
							}
							else if($page['weekday_id']=="")
							{
								$error_arr=array();
								$error_arr[] =$page['term'];
								$error_arr[] =$page['weekday'];
								$error_arr[] =$page['lesson_number'];
								$error_arr[] =$page['room'];
								$error_arr[] =$page['course'];
								$error_arr[] =$label_details[64]['name'];
								$error_rows[$r]=$error_arr;
								$r++;
							}
							else if($page['lesson_number_id']=="")
							{
								$error_arr=array();
								$error_arr[] =$page['term'];
								$error_arr[] =$page['weekday'];
								$error_arr[] =$page['lesson_number'];
								$error_arr[] =$page['room'];
								$error_arr[] =$page['course'];
								$error_arr[] =$label_details[65]['name'];
								$error_rows[$r]=$error_arr;
								$r++;
							}
							else if($page['room_id']=="")
							{
								$error_arr=array();
								$error_arr[] =$page['term'];
								$error_arr[] =$page['weekday'];
								$error_arr[] =$page['lesson_number'];
								$error_arr[] =$page['room'];
								$error_arr[] =$page['course'];
								$error_arr[] =$label_details[66]['name'];
								$error_rows[$r]=$error_arr;
								$r++;
							}
							else if($page['course_id']=="")
							{
								$error_arr=array();
								$error_arr[] =$page['term'];
								$error_arr[] =$page['weekday'];
								$error_arr[] =$page['lesson_number'];
								$error_arr[] =$page['room'];
								$error_arr[] =$page['course'];
								$error_arr[] =$label_details[67]['name'];
								$error_rows[$r]=$error_arr;
								$r++;
							}
							else
							{
								$input = array(
									'lesson_number_id'=>$page['lesson_number_id'],
									'weekday_id'=>$page['weekday_id'],
									'term_id'=>$page['term_id'],
									'course_id'=>$page['course_id'],
									'room_id'=>$page['room_id'],
									'created_at'=>time()
								);
								$this->timetable_model->add($input);
								$flag=true;
							}
						}						
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[68]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
}
