<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */

class Timetable_weekly_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	}   
	//timetable
	function get_weekly_timetable(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true);
		$personnel_fld = $data['personnel_fld'];
		$id = $data['id'];
		$cond="select * from terms where is_deleted=0";
		$term_details = $this->users_model->special_fetch($cond);
		$active_terms=array();
		$cur_time=time();
		$term_id="";
		foreach($term_details as $term)
		{

			if(($cur_time>$term['start_date_timestamp']&&$cur_time<$term['end_date_timestamp']))
			{
				$term_id=$term['id'];
			}
		}
		if($term_id=="")
		{
			$cond="select id from terms where is_active=1";
			$term_details = $this->users_model->special_fetch($cond);
			$term_id=$term_details[0]['id'];
		}
		$student="";
		if($personnel_fld!="")
		{
			$personnel_arr=explode("-",$personnel_fld);
			$id=$personnel_arr[0];
			$student=$personnel_arr[1];
		}
		else
		{
			$cond="select id from students where id=".$id;
			$student_details = $this->users_model->special_fetch($cond);
			if(count($student_details)>0)
			{
				$student="0";
			}
		}
		if($student=="0")
		{
			$cond="select group_concat(c.course_id) as course_id from course_attendants c,students_terms s where s.id=c.student_term_id and s.student_id=".$id." and s.term_id=".$term_id;
			$student_details = $this->users_model->special_fetch($cond);
			$course_ids=$student_details[0]['course_id'];
		}
		else
		{
			$cond="select group_concat(id) as id from courses where personnel_id=".$id;
			$course_details = $this->users_model->special_fetch($cond);
			$course_ids=$course_details[0]['id'];
		}
		$cond="select id,lesson_number from lesson_numbers where is_active=1 and is_deleted=0 order by lesson_number asc";
		$lesson_number_details = $this->users_model->special_fetch($cond);
		$cond="select id,name from weekdays where is_active=1 and is_deleted=0 order by weekday_number asc";
		$weekday = $this->users_model->special_fetch($cond);
		//$weekday = array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
		$weekly_timetable_details=array();
		foreach($lesson_number_details as $lesson_number)
		{
			$lesson_number_id=$lesson_number['id'];
			$week_arr=array();
			foreach($weekday as $day)
			{
				//$cond="select id from weekdays where name ='".$day."'";
				//$week_details = $this->users_model->special_fetch($cond);
				$weekday_id=$day['id'];	
				if($course_ids!="")
				{
					$cond="select room_id,course_id from timetable where term_id=".$term_id." and lesson_number_id=".$lesson_number_id." and weekday_id=".$weekday_id." and course_id in(".$course_ids.")";
					$timetable_details = $this->users_model->special_fetch($cond);
					if(count($timetable_details)>0)
					{
						$course_id=$timetable_details[0]['course_id'];
						$cond="select name from courses where id=".$course_id;
						$course_details = $this->users_model->special_fetch($cond);
						$course_name=$course_details[0]['name'];
						$cond="select name from rooms where id=".$timetable_details[0]['room_id'];
						$room_details = $this->users_model->special_fetch($cond);
						$room_name=$room_details[0]['name'];
						$week_arr[]=array(
							"course_name"=>$course_name,
							"room_name"=>$room_name
						);
					}
					else
					{
						$week_arr[]=array(
							"course_name"=>"",
							"room_name"=>""
						);
					}	
				}	
				else
				{
					$week_arr[]=array(
						"course_name"=>"",
						"room_name"=>""
					);
				}		
			}
			$weekly_timetable_details[]=array(
				"lesson"=>$lesson_number['lesson_number'],
				"week_details"=>$week_arr
			);
		}
		if(count($weekly_timetable_details)<=0)
			$weekly_timetable_details=array();
		$out = array('statuscode'=>'200','weekly_timetable_details'=>$weekly_timetable_details,'weekdays'=>$weekday);
		header('Content-Type:application/json');
		echo json_encode($out);
		
    }
	function get_student_teacher(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$search_term = strtolower($data['search_term']);
		$id = $data['id'];
		$personnel_details=array();
		$cond="select id from user_groups where user_id=".$id." and group_id=4";
		$usr_details = $this->users_model->special_fetch($cond);
		if(count($usr_details)>0)
		{
			$cond="select distinct u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s,students_parents sp where u.id=s.id and sp.student_id=s.id and u.is_active=1 and s.is_deleted=0 and sp.parent_id=".$id." order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
			$stu_details=array();	
			foreach($student_details as $student)
			{
				$name=$student['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$id=$student['id']."-0";
					$stu_details[]=array("id"=>$id,"name"=>$name);
				}
			}
			$personnel_details[]=array("name"=>"Students","children"=>$stu_details);
		}
		else
		{
			$cond="select distinct u.id,concat(u.first_name,' ',u.last_name) as name from users u,students s where u.id=s.id and u.is_active=1 and s.is_deleted=0 order by name asc";
			$student_details = $this->users_model->special_fetch($cond);
			$stu_details=array();	
			foreach($student_details as $student)
			{
				$name=$student['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$id=$student['id']."-0";
					$stu_details[]=array("id"=>$id,"name"=>$name);
				}
			}
			$personnel_details[]=array("name"=>"Students","children"=>$stu_details);
			$cond="select u.id,concat(u.first_name,' ',u.last_name) as name from users u,personnel p,user_groups ug where u.id=p.id and u.id=ug.user_id and ug.group_id=2 and u.is_active=1 and p.is_deleted=0 order by name asc";
			$teacher_details = $this->users_model->special_fetch($cond);	
			$tea_details=array();
			foreach($teacher_details as $teacher)
			{
				$name=$teacher['name'];
				if(strpos(strtolower($name), $search_term)!==false)
				{
					$id=$teacher['id']."-1";
					$tea_details[]=array("id"=>$id,"name"=>$name);
				}
			}
			$personnel_details[]=array("name"=>"Teachers","children"=>$tea_details);
		}    
		$total_count=count($personnel_details);
		$out = array('total_count'=>$total_count,'items'=>$personnel_details);          
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
}
