<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');



/**

 * Class For User Management.  

 */
//use Mailgun\Mailgun;
class Users_api extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
		$this->load->library('mails');
    }    
    
	function index() 
	{		
		
	} 
	
	function get_labels_page($lang_id)
    {     
		$cond="select name,label_id from labels where page_id=34 and lang_id=".$lang_id." order by label_id asc";
		$lbl_details = $this->users_model->special_fetch($cond);
		$label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
    function search_all()
	{
		$group_id="1,2";
		$user_groups="3,2,1";
		$groups=explode(",",$group_id);
		$users=explode(",",$user_groups);
		$containsAllValues = !array_diff($groups, $users);
		echo $containsAllValues;
		$all = array
		(
			0 => 307,
			1 => 157,
			2 => 234,
			3 => 201,
			4 => 322,
			5 => 324
		);
		$search_this = array
		(
			0 => 200,
			1 => 234
		);	
		//$containsAllValues = !array_diff($search_this, $all);
		//echo $containsAllValues;
	}
	//users
	function view_users(){
        $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$start = $data['start'];
		$rowperpage = $data['rowperpage'];
		$searchValue = $data['searchValue'];
		$columnName = $data['columnName'];
		$columnSortOrder = $data['columnSortOrder'];
		$status_fld = $data['status_fld'];
		$del_fld = $data['del_fld'];
		$function_fld = $data['function_fld'];	
		$teacher_fld = $data['teacher_fld'];
		$admin_fld = $data['admin_fld'];
		$sysadmin_fld = $data['sysadmin_fld'];			
		$searchQuery = "";
		$searchGroup = "";
		$delQuery = "";
		$users = "";
		if($searchValue != ''){
			$searchValue=strtolower($searchValue);
			$searchQuery = " and (lower(u.last_name) like '%".$searchValue."%' or lower(u.first_name) like '%".$searchValue."%' or lower(p.mobile_phone) like '%".$searchValue."%' or lower(u.email) like '%".$searchValue."%' or lower(p.city) like '%".$searchValue."%' or lower(c.name) like '%".$searchValue."%' or lower(p.zip) like '%".$searchValue."%' or lower(p.address) like '%".$searchValue."%' or lower(p.address2) like '%".$searchValue."%')";
	   	}
		if($status_fld != ''&&$status_fld != 'all'){
			$searchQuery .= " and u.is_active=".$status_fld;			
	    }
		if($function_fld != ''){
			$searchQuery .= " and p.personnel_function_id=".$function_fld;			
	    }
		$selected_group="";
		if($teacher_fld != ""&&$admin_fld != ""&&$sysadmin_fld != ""){
			if($teacher_fld != "0"||$admin_fld != "0"||$sysadmin_fld != "0"){
				if($teacher_fld != "0"){
					$selected_group = $selected_group.",".$teacher_fld;			
				}
				if($admin_fld != "0"){
					$selected_group = $selected_group.",".$admin_fld;			
				}
				if($sysadmin_fld != "0"){
					$selected_group = $selected_group.",".$sysadmin_fld;			
				}
				$selected_group=trim($selected_group,",");				
				$selected_group_arr=explode(",",$selected_group);
				$cond="SELECT user_id,GROUP_CONCAT(group_id) as group_ids from user_groups group by user_id";
				$u_details = $this->users_model->special_fetch($cond);
				$user_ids="";
				foreach($u_details as $user)
				{
					$user_group_arr=explode(",",$user['group_ids']);
					$common_arr = array_intersect($selected_group_arr, $user_group_arr);
					if(count($common_arr)==count($selected_group_arr))
						$users=$users.",".$user['user_id'];
				}
			}
		}
		$users=trim($users,",");
		$user_found=true;
		if($users!='')
		{
			$searchGroup = " and u.id in(".$users.")";
		}
		else
		{
			if($selected_group!="")
				$user_found=false;
		}
		if($del_fld != ''){
			if($del_fld != 'all')
				$delQuery = " and p.is_deleted=".$del_fld;
	    }
		else
		{
			$delQuery = " and p.is_deleted=0";	
		}
		if($columnName=="")
		{
			$columnName = "u.created_at";
			$columnSortOrder = "desc";
		}
		$totalRecord="";$totalRecordwithFilter="";$page_details=array();
		if($user_found)
		{
			$cond="select u.id,u.email,u.username,u.first_name,u.last_name,u.is_active,c.name as country_name,p.country,p.gender_id,g.name as gender,p.city,p.address,p.address2,p.zip,p.mobile_phone,p.fixed_phone,p.birth_date,p.admission,p.emission,p.diploma,p.is_deleted,pf.name as function,p.personnel_function_id from users u,countries c,personnel p,personnel_functions pf,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and pf.id=p.personnel_function_id and lower(pf.name)<>'parent'".$searchGroup.$delQuery.$searchQuery." order by ".$columnName." ".$columnSortOrder." limit ".$start.",".$rowperpage;
			$page_details = $this->users_model->special_fetch($cond);
			$cond="select COUNT(u.id) as cnt from users u,countries c,personnel p,personnel_functions pf,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and pf.id=p.personnel_function_id and lower(pf.name)<>'parent'".$searchGroup.$delQuery;
			$maps_count = $this->users_model->special_fetch($cond);
			$totalRecord = $maps_count[0]['cnt'];
			$totalRecordwithFilter = $totalRecord;
			if($searchQuery != ''||$delQuery != ''){
				$cond="select COUNT(u.id) as cnt from users u,countries c,personnel p,personnel_functions pf,genders g where u.id=p.id and c.id=p.country and g.id=p.gender_id and pf.id=p.personnel_function_id and lower(pf.name)<>'parent'".$searchGroup.$delQuery.$searchQuery;
				$maps_count = $this->users_model->special_fetch($cond);
				$totalRecordwithFilter = $maps_count[0]['cnt'];
			}
			$i=0;
			
			foreach($page_details as $user)
			{
				$cond="select group_id from user_groups where user_id=".$user['id']." and group_id<>4";
				$usr_details = $this->users_model->special_fetch($cond);
				if(count($usr_details)>0)
				{
					$page_details[$i]['is_teacher']="";
					$page_details[$i]['is_admin']="";
					$page_details[$i]['is_sysadmin']="";
					foreach($usr_details as $grp)
					{
						if($grp['group_id']==2)
							$page_details[$i]['is_teacher']="0";
						if($grp['group_id']==1)
							$page_details[$i]['is_admin']="0";
						if($grp['group_id']==3)
							$page_details[$i]['is_sysadmin']="0";
					}
				}
				else
				{
					$page_details[$i]['is_teacher']="";
					$page_details[$i]['is_admin']="";
					$page_details[$i]['is_sysadmin']="";
				}
				$i++;
			}
		}
		if($totalRecord=="")
			$totalRecord=0;
		if($totalRecordwithFilter=="")
			$totalRecordwithFilter=0;
		if(count($page_details)<=0)
			$page_details=array();
        $out = array('statuscode'=>'200','totalRecord'=>$totalRecord,'totalRecordwithFilter'=>$totalRecordwithFilter,'page_details'=>$page_details);
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	function create_folders()
    {
        $cond="select id from users where entity_class='personnelentity'";
        $cu_details = $this->users_model->special_fetch($cond);
        foreach($cu_details as $per)
        {
            $input = array(
				'user_id'=>$per['id'],
				'folder'=>"Public",
				'parent_folder'=>2,
				'is_deleted'=>1
			);
			$public_id=$this->folder_manager_model->add($input);
			$input = array(
				'user_id'=>$per['id'],
				'folder'=>"PTSFRRP",
				'parent_folder'=>$public_id,
				'is_deleted'=>1
			);
			$public_id=$this->folder_manager_model->add($input);
			$input = array(
				'user_id'=>$per['id'],
				'folder'=>"Lessons",
				'parent_folder'=>2,
				'is_deleted'=>1
			);
			$this->folder_manager_model->add($input);
			$input = array(
				'user_id'=>$per['id'],
				'folder'=>"Duplicate",
				'parent_folder'=>2,
				'is_deleted'=>1
			);
			$this->folder_manager_model->add($input);
        }
		echo 'Done';
    }
	function randomPassword($num) {
        $alphabet = '1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < $num; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
	function add_users(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$salt = $data['salt'];
		$password = $data['password'];
		$personnel_function_id = $data['personnel_function_id'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$birth_date = $data['birth_date'];
		$admission = $data['admission'];
		$emission = $data['emission'];
		$diploma = $data['diploma'];
		$no_email = $data['no_email'];
		$status = $data['status'];
		$teacher = $data['teacher'];
		$admin = $data['admin'];
		$sysadmin = $data['sysadmin'];
		$data_arr=array(
				'username'=>$email
			);
        $users_details = $this->users_model->get_records($data_arr);
		if($id=="")
		{
			if(count($users_details)<=0)
			{
				if($no_email==1)
				{
					$num=$this->randomPassword(5);
					$username="NR".$num;
					$salt=$username;
        			$password=md5($salt);
					$email="";
				}
				else
				{
					$username=$email;
				}
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'salt'=>$salt,
					'password'=>$password,
					'is_active'=>$status,
					'entity_class'=>'personnelentity',
					'created_at'=>time()
				);
				$id = $this->users_model->add($input);
				if($teacher==2)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$teacher
					);
					$this->user_groups_model->add($input);
				}
				if($admin==1)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$admin
					);
					$this->user_groups_model->add($input);
				}
				if($sysadmin==3)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$sysadmin
					);
					$this->user_groups_model->add($input);
				}				
				$input = array(
					'id'=>$id,
					'personnel_function_id'=>$personnel_function_id,
					'gender_id'=>$gender_id,
					'city'=>$city,
					'country'=>$country,
					'zip'=>$zip,
					'address'=>$address,
					'address2'=>$address2,
					'mobile_phone'=>$mobile_phone,
					'fixed_phone'=>$fixed_phone,
					'birth_date'=>$birth_date,
					'admission'=>$admission,
					'emission'=>$emission,
					'diploma'=>$diploma
				);
				$this->personnel_model->add($input);
				$user_folder=$first_name." ".$last_name;
				$input = array(
					'user_id'=>$id,
					'folder'=>$user_folder,
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Public",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$public_id=$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"PTSFRRP",
					'parent_folder'=>$public_id,
					'is_deleted'=>1
				);
				$public_id=$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Lessons",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$this->folder_manager_model->add($input);
				$input = array(
					'user_id'=>$id,
					'folder'=>"Duplicate",
					'parent_folder'=>2,
					'is_deleted'=>1
				);
				$this->folder_manager_model->add($input);
				if($no_email==0)
					$this->send_registration_mail($id,$first_name,$last_name,$email,$salt);
				$out = array('statuscode'=>'200','id'=>$id,'statusdescription'=>$label_details[173]['name']);			
			}  
			else
			{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[174]['name']);
			}
		}
		else
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{	
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$mid = $this->users_model->edit($input,$id);
			$input = array(
				'personnel_function_id'=>$personnel_function_id,
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'birth_date'=>$birth_date,
				'admission'=>$admission,
				'emission'=>$emission,
				'diploma'=>$diploma
			);
			$mid = $this->personnel_model->edit($input,$id);
			if($teacher==2)
			{
				$cond="select id from user_groups where user_id=".$id." and group_id=".$teacher;
				$role_details = $this->users_model->special_fetch($cond);				
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$teacher
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($teacher!="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=".$teacher;
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}
			}			
			if($admin==1)
			{
				$cond="select id from user_groups where user_id=".$id." and group_id=".$admin;
				$role_details = $this->users_model->special_fetch($cond);
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$admin
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($admin!="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=".$admin;
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}
			}			
			if($sysadmin==3)
			{
				$cond="select id from user_groups where user_id=".$id." and group_id=".$sysadmin;
				$role_details = $this->users_model->special_fetch($cond);
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$sysadmin
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($sysadmin!="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=".$sysadmin;
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}
			}
			$out = array('statuscode'=>'200','id'=>$id,'statusdescription'=>$label_details[175]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
    
    function edit_users(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$last_name = $data['last_name'];
		$first_name = $data['first_name'];
		$email = $data['email'];
		$personnel_function_id = $data['personnel_function_id'];
		$gender_id = $data['gender_id'];
		$address2 = $data['address2'];
		$address = $data['address'];
		$city = $data['city'];
		$country = $data['country'];
		$zip = $data['zip'];
		$mobile_phone = $data['mobile_phone'];
		$fixed_phone = $data['fixed_phone'];
		$birth_date = $data['birth_date'];
		$admission = $data['admission'];
		$emission = $data['emission'];
		$diploma = $data['diploma'];
		$no_email = $data['no_email'];
		$teacher = $data['teacher'];
		$admin = $data['admin'];
		$sysadmin = $data['sysadmin'];
		$status = $data['status'];
		$id = $data['id'];
		$cond="select id from users where username='".$email."' and id<>".$id;
        $career_details = $this->users_model->special_fetch($cond);
		if(count($career_details)<=0)
		{
			$cond="select email from users where id=".$id;
			$ur_details = $this->users_model->special_fetch($cond);
			if($no_email==1&&$ur_details[0]['email']!="")
			{	
				$num=$this->randomPassword(5);
				$username="NR".$num;
				$salt=$username;
				$password=md5($salt);
				$email="";
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'salt'=>$salt,
					'password'=>$password,
					'username'=>$username,
					'is_active'=>$status,
					'last_login'=>NULL,
					'updated_at'=>time()
				);
			}
			else if($no_email==1)
			{
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			else
			{
				$username=$email;
				$input = array(
					'last_name'=>$last_name,
					'first_name'=>$first_name,
					'email'=>$email,
					'username'=>$username,
					'is_active'=>$status,
					'updated_at'=>time()
				);
			}
			$mid = $this->users_model->edit($input,$id);
			$input = array(
				'personnel_function_id'=>$personnel_function_id,
				'gender_id'=>$gender_id,
				'city'=>$city,
				'country'=>$country,
				'zip'=>$zip,
				'address'=>$address,
				'address2'=>$address2,
				'mobile_phone'=>$mobile_phone,
				'fixed_phone'=>$fixed_phone,
				'birth_date'=>$birth_date,
				'admission'=>$admission,
				'emission'=>$emission,
				'diploma'=>$diploma
			);
			$mid = $this->personnel_model->edit($input,$id);			
			if($teacher==2)
			{		
				$cond="select id from user_groups where user_id=".$id." and group_id=".$teacher;
				$role_details = $this->users_model->special_fetch($cond);		
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$teacher
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($teacher=="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=2";
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}
			}			
			if($admin==1)
			{
				$cond="select id from user_groups where user_id=".$id." and group_id=".$admin;
				$role_details = $this->users_model->special_fetch($cond);
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$admin
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($admin=="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=1";
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}
			}			
			if($sysadmin==3)
			{
				$cond="select id from user_groups where user_id=".$id." and group_id=".$sysadmin;
				$role_details = $this->users_model->special_fetch($cond);
				if(count($role_details)<=0)
				{
					$input = array(
						'user_id'=>$id,
						'group_id'=>$sysadmin
					);
					$this->user_groups_model->add($input);
				}
			}
			else
			{
				if($sysadmin=="")
				{
					$cond="select id from user_groups where user_id=".$id." and group_id=3";
					$role_details = $this->users_model->special_fetch($cond);
					if(count($role_details)>0)
					{
						$this->user_groups_model->delete($role_details[0]['id']);
					}
				}	
			}
			if($mid){
				$out = array('statuscode'=>'200','statusdescription'=>$label_details[175]['name']);
			}
			else{
				$out = array('statuscode'=>'201','statusdescription'=>$label_details[176]['name']);
			} 
		}	
		else
		{
			$out = array('statuscode'=>'201','statusdescription'=>$label_details[177]['name']);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
    }
	    
    function delete_users(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		$not_in_use_name="";$in_use_name=""; 
		foreach($id_arr as $id)
		{
			$cond="select concat(first_name,' ',last_name) as name from users where id=".$id;
			$p_details = $this->users_model->special_fetch($cond);
			$name=$p_details[0]['name'];
			$cond="select id from absences where personnel_id=".$id." limit 1";
			$ab_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from courses where personnel_id=".$id." limit 1";
			$cor_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from course_uploads where uploaded_by=".$id." limit 1";
			$cur_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from disciplinary_protocols where personnel_id=".$id." limit 1";
			$dis_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from dossiers where personnel_id=".$id." limit 1";
			$dos_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from meeting_items_responsible_personnel where personnel_id=".$id." limit 1";
			$mee_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from notifications where sender_id=".$id." limit 1";
			$not_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from notifications_recipients where recipient_id=".$id." limit 1";
			$nor_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from students	where id=".$id." limit 1";
			$stu_details = $this->career_goals_model->special_fetch($cond);
			$cond="select id from students_terms where coach_id=".$id." limit 1";
			$ter_details = $this->career_goals_model->special_fetch($cond);
			if(count($ab_details)<=0&&count($cor_details)<=0&&count($cur_details)<=0&&count($dis_details)<=0&&count($dos_details)<=0&&count($mee_details)<=0&&count($not_details)<=0&&count($nor_details)<=0&&count($stu_details)<=0&&count($ter_details)<=0)
			{	
				$input = array(
					'is_deleted'=>1,
					'deleted_at'=>time()
				);
				$this->personnel_model->edit($input,$id);	
				$not_in_use_name=$not_in_use_name.",".$name;
			}
			else
			{
				$in_use_name=$in_use_name.",".$name;
			}
		}
		$not_in_use_msg="";$in_use_msg="";
		if($not_in_use_name!="")
			$not_in_use_msg=" ".trim($not_in_use_name,", ")." ".$label_details[114]['name'];
		if($in_use_name!="")
			$in_use_msg=" ".trim($in_use_name,",")." ".$label_details[118]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$not_in_use_msg,'in_use_msg'=>$in_use_msg);              
        header('Content-Type:application/json');
        echo json_encode($out);       
    }
	function restore_users(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$input = array(
				'is_deleted'=>0
			);
			$this->personnel_model->edit($input,$id);
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[179]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function set_status_users(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$ids = $data['ids'];
		$id_arr=explode(",",$ids);
		foreach($id_arr as $id)
		{
			$cond="select is_active from users where id=".$id;
			$st_details = $this->users_model->special_fetch($cond);
			if($st_details[0]['is_active']==0)
				$status=1;
			else
				$status=0;
			$input = array(
				'is_active'=>$status,
				'updated_at'=>time()
			);
			$this->users_model->edit($input,$id);			
		}
		$out = array('statuscode'=>'200','statusdescription'=>$label_details[180]['name']);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }	
    function get_personnel_functions(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from personnel_functions where is_deleted=0 and is_active=1 and lower(name)<>'parent' order by name asc";
		$function_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','function_details'=>$function_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function get_gender(){
		
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$cond="select * from genders where is_deleted=0 and is_active=1 order by name asc";
		$gender_details = $this->users_model->special_fetch($cond);		
		$out = array('statuscode'=>'200','gender_details'=>$gender_details);              
        header('Content-Type:application/json');
        echo json_encode($out);        
    }
	function import_users(){
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$page_column_details = $data['page_details'];
		$r=0;
		$corrupt=array();
		$error_rows=array();
		$flag=false;
		foreach($page_column_details as $page)
		{
			if($page['name']==""||$page['first_name']==""||$page['personnel']==""||$page['gender']==""||$page['country']==""||$page['admission']=="")
			{
				$corrupt_arr=array();
				$corrupt_arr[] =$page['name'];
				$corrupt_arr[] =$page['first_name'];
				$corrupt_arr[] =$page['email'];
				$corrupt_arr[] =$page['personnel'];
				$corrupt_arr[] =$page['gender'];
				$corrupt_arr[] =$page['admission'];
				$corrupt_arr[] =$page['country'];
				$corrupt_arr[] =$page['teacher'];
				$corrupt_arr[] =$page['admin'];
				$corrupt_arr[] =$page['sysadmin'];
				$corrupt_arr[] =$page['birth_date'];
				$corrupt_arr[] =$page['emission'];
				$corrupt_arr[] =$page['diploma'];
				$corrupt_arr[] =$page['city'];
				$corrupt_arr[] =$page['address'];
				$corrupt_arr[] =$page['zip'];
				$corrupt_arr[] =$page['address2'];
				$corrupt_arr[] =$page['mobile_phone'];
				$corrupt_arr[] =$page['fixed_phone'];
				$corrupt_arr[] =$page['status'];
				$corrupt_arr[] =$label_details[279]['name'];
				$corrupt[$r]=$corrupt_arr;
				$r++;
			}
			else
			{
				if($page['teacher']==""&&$page['admin']==""&&$page['sysadmin']=="")
				{
					$corrupt_arr=array();
					$corrupt_arr[] =$page['name'];
					$corrupt_arr[] =$page['first_name'];
					$corrupt_arr[] =$page['email'];
					$corrupt_arr[] =$page['personnel'];
					$corrupt_arr[] =$page['gender'];
					$corrupt_arr[] =$page['admission'];
					$corrupt_arr[] =$page['country'];
					$corrupt_arr[] =$page['teacher'];
					$corrupt_arr[] =$page['admin'];
					$corrupt_arr[] =$page['sysadmin'];
					$corrupt_arr[] =$page['birth_date'];
					$corrupt_arr[] =$page['emission'];
					$corrupt_arr[] =$page['diploma'];
					$corrupt_arr[] =$page['city'];
					$corrupt_arr[] =$page['address'];
					$corrupt_arr[] =$page['zip'];
					$corrupt_arr[] =$page['address2'];
					$corrupt_arr[] =$page['mobile_phone'];
					$corrupt_arr[] =$page['fixed_phone'];
					$corrupt_arr[] =$page['status'];
					$corrupt_arr[] =$label_details[280]['name'];
					$corrupt[$r]=$corrupt_arr;
					$r++;
				}
				else
				{
					if($page['email']=="")
						$pg_details=array();
					else
					{
						$cond="select id from users where email='".$page['email']."'";
						$pg_details = $this->users_model->special_fetch($cond);
					}
					if(count($pg_details)>0)
					{
						$error_arr=array();
						$error_arr[] =$page['name'];
						$error_arr[] =$page['first_name'];
						$error_arr[] =$page['email'];
						$error_arr[] =$page['personnel'];
						$error_arr[] =$page['gender'];
						$error_arr[] =$page['admission'];
						$error_arr[] =$page['country'];
						$error_arr[] =$page['teacher'];
						$error_arr[] =$page['admin'];
						$error_arr[] =$page['sysadmin'];
						$error_arr[] =$page['birth_date'];
						$error_arr[] =$page['emission'];
						$error_arr[] =$page['diploma'];
						$error_arr[] =$page['city'];
						$error_arr[] =$page['address'];
						$error_arr[] =$page['zip'];
						$error_arr[] =$page['address2'];
						$error_arr[] =$page['mobile_phone'];
						$error_arr[] =$page['fixed_phone'];
						$error_arr[] =$page['status'];
						$error_arr[] =$label_details[281]['name'];
						$error_rows[$r]=$error_arr;
						$r++;
					}
					else
					{
						$admission_date=false;$birth_date=false;$emission_date=false;
						if($page['admission']!='')
						{
							$date = DateTime::createFromFormat('d-m-Y', $page['admission']);
							if (!$date) {
								$date = DateTime::createFromFormat('d/m/Y',  $page['admission']);
							}
							if (!$date) {
								$admission_date=true;
							} 
						}
						if($page['birth_date']!='')
						{
							$date = DateTime::createFromFormat('d-m-Y', $page['birth_date']);
							if (!$date) {
								$date = DateTime::createFromFormat('d/m/Y',  $page['birth_date']);
							}
							if (!$date) {
								$birth_date=true;
							} 
						}
						if($page['emission']!='')
						{
							$date = DateTime::createFromFormat('d-m-Y', $page['emission']);
							if (!$date) {
								$date = DateTime::createFromFormat('d/m/Y',  $page['emission']);
							}
							if (!$date) {
								$emission_date=true;
							} 
						}
						if($page['personnel_function_id']=="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[183]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($page['gender_id']=="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[184]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}					
						else if($page['country_id']=="")
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[185]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($admission_date)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[282]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($birth_date)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[283]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else if($emission_date)
						{
							$error_arr=array();
							$error_arr[] =$page['name'];
							$error_arr[] =$page['first_name'];
							$error_arr[] =$page['email'];
							$error_arr[] =$page['personnel'];
							$error_arr[] =$page['gender'];
							$error_arr[] =$page['admission'];
							$error_arr[] =$page['country'];
							$error_arr[] =$page['teacher'];
							$error_arr[] =$page['admin'];
							$error_arr[] =$page['sysadmin'];
							$error_arr[] =$page['birth_date'];
							$error_arr[] =$page['emission'];
							$error_arr[] =$page['diploma'];
							$error_arr[] =$page['city'];
							$error_arr[] =$page['address'];
							$error_arr[] =$page['zip'];
							$error_arr[] =$page['address2'];
							$error_arr[] =$page['mobile_phone'];
							$error_arr[] =$page['fixed_phone'];
							$error_arr[] =$page['status'];
							$error_arr[] =$label_details[284]['name'];
							$error_rows[$r]=$error_arr;
							$r++;
						}
						else
						{
							$status_text="active";$role_text="yes";
							$status_val=0;$teacher_val=0;$admin_val=0; $sysadmin_val=0;
							if($lang_id!=1)
							{
								$cond="select code from languages where id=".$lang_id;
        						$lang_details = $this->users_model->special_fetch($cond);
								if(count($label_details)>0)
								{
									$status_text=$this->translate_lang($lang_details[0]['code'],"active");
									$role_text=$this->translate_lang($lang_details[0]['code'],"yes");
								}
							}
							if(strtolower($page['status'])==strtolower($status_text))
								$status_val=1;
								
							if(strtolower($page['teacher'])==strtolower($role_text))
								$teacher_val=2;
								
							if(strtolower($page['admin'])==strtolower($role_text))
								$admin_val=1;
								 
							if(strtolower($page['sysadmin'])==strtolower($role_text))
								$sysadmin_val=3;
								  
							if($page['email']=='')
							{
								$num=$this->randomPassword(5);
								$username="NR".$num;
								$page['salt']=$username;
								$page['password']=md5($page['salt']);
								$page['email']="";
							}
							else
							{
								$username=$page['email'];
							}
							$input = array(
								'last_name'=>$page['name'],
								'first_name'=>$page['first_name'],
								'email'=>$page['email'],
								'username'=>$username,
								'salt'=>$page['salt'],
								'password'=>$page['password'],
								'is_active'=>$status_val,
								'entity_class'=>'personnelentity',
								'created_at'=>time()
							);
							$id = $this->users_model->add($input);
							if($teacher_val==2)
							{
								$input = array(
									'user_id'=>$id,
									'group_id'=>$teacher_val
								);
								$this->user_groups_model->add($input);
							}
							if($admin_val==1)
							{
								$input = array(
									'user_id'=>$id,
									'group_id'=>$admin_val
								);
								$this->user_groups_model->add($input);
							}
							if($sysadmin_val==3)
							{
								$input = array(
									'user_id'=>$id,
									'group_id'=>$sysadmin_val
								);
								$this->user_groups_model->add($input);
							}	
										
							$input = array(
								'id'=>$id,
								'personnel_function_id'=>$page['personnel_function_id'],
								'gender_id'=>$page['gender_id'],
								'city'=>$page['city'],
								'country'=>$page['country_id'],
								'zip'=>$page['zip'],
								'address'=>$page['address'],
								'address2'=>$page['address2'],
								'mobile_phone'=>$page['mobile_phone'],
								'fixed_phone'=>$page['fixed_phone'],
								'birth_date'=>$page['birth_date'],
								'admission'=>$page['admission'],
								'emission'=>$page['emission'],
								'diploma'=>$page['diploma']
							);
							$this->personnel_model->add($input);
							$flag=true;
						}
					}
				}
			}
		}
		$out = array(
			'statuscode' => "200",
			'flag' => $flag,
			'statusdescription'=>$label_details[186]['name'],
			'error_rows'=>$error_rows
		);
		$out['error_rows'] =  array_merge($corrupt,$out['error_rows']);
		echo json_encode($out);
	}
	function lang_trans()
	{
		//$status_text=$this->translate_lang($lang_details[0]['code'],"active");
		echo $this->translate_lang("de","yes");
	}
	function edit_password()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$new_password = $data['new_password'];
		$new_pwd=md5($new_password);
		$current_password = md5($data['current_password']);
		$cond="select id from users where password='".$current_password."' and id=".$id;
        $user_details = $this->users_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			$input = array(
				'salt'=>$new_password,
				'password'=>$new_pwd
			);
			$this->users_model->edit($input,$id);
			$msg=" ".$label_details[244]['name'];
			$out = array('statuscode'=>'200','statusdescription'=>$msg);
			
		}	
		else
		{
			$msg=" ".$label_details[245]['name'];
			$out = array('statuscode'=>'201','statusdescription'=>$msg);
		}
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	function admin_reset_password()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$label_details = $this->get_labels_page($lang_id);
		$id = $data['id'];
		$new_password = $data['new_password'];
		$new_pwd=md5($new_password);
		$input = array(
			'salt'=>$new_password,
			'password'=>$new_pwd
		);
		$this->users_model->edit($input,$id);
		$msg=" ".$label_details[246]['name'];
		$out = array('statuscode'=>'200','statusdescription'=>$msg);
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	function send_forgot_password() 
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$email=$data['email'];
		$cond="select first_name,last_name,id,email from users where username='".$data['email']."'";
		$user_details = $this->users_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			if($user_details[0]['email']=="")
			{
				header('Content-type: application/json');
				$msg=" ".$label_details[247]['name'];
				$data = array(
				'statuscode' => "201",'statusdescription' => $msg
				);
				echo json_encode($data);
			}
			else
			{
				$user_id=$user_details[0]['id'];
				$input = array(
					'password_requested_at'=>time()
				);
				$this->users_model->edit($input,$user_id);
				$link_id=$this->encrypt($user_id);
				$cond="select s.key,s.value from system_settings s";
				$settings = $this->users_model->special_fetch($cond);
				$res_link='';;
				foreach($settings as $set)
				{
					if($set['key']=='reset-link')
						$res_link=$set['value'];
				}
				$reset_link=$res_link.$link_id;
				$cond="select * from email_templates where id=2";
				$email_details = $this->users_model->special_fetch($cond);
				$html_content='';
				$cond="select * from email_templates_i18n where email_template_id=2 and language_id=1";
				$email_setting_details = $this->users_model->special_fetch($cond);
				if(count($email_setting_details)>0){
					$html_content=$email_setting_details[0]['html_content'];
					$html_content=str_replace("{FIRST_NAME}",$user_details[0]['first_name'],$html_content);
					$html_content=str_replace("{LAST_NAME}",$user_details[0]['last_name'],$html_content);
					$html_content=str_replace("{RESET_URL}",$reset_link,$html_content);
				}
				$formname = 'Proscola Admin';
				$formaddrs = $formname." <".$email_setting_details[0]['from'].">";
				$subject=$email_setting_details[0]['subject'];
				$to=$data['email'];
				$this->send_mail($formaddrs,$to,$subject,$html_content);
				header('Content-type: application/json');
				$data = array(
				'statuscode' => "200"
				);
				echo json_encode($data);
			}
		}
		else
		{
			header('Content-type: application/json');
			$msg=" ".$label_details[248]['name'];
			$data = array(
			'statuscode' => "201",'statusdescription' => $msg
			);
			echo json_encode($data);
		}
    }
	
	function send_registration_mail($id,$first_name,$last_name,$email,$password) 
	{
		$cond="select s.key,s.value from system_settings s";
		$settings = $this->users_model->special_fetch($cond);
		$login_link='';
		foreach($settings as $set)
		{
			if($set['key']=='login-link')
				$login_link=$set['value'];
		}
		$html_content='';
		$cond="select * from email_templates_i18n where email_template_id=1 and language_id=1";
		$email_setting_details = $this->users_model->special_fetch($cond);
		if(count($email_setting_details)>0){
			$html_content=$email_setting_details[0]['html_content'];
			$html_content=str_replace("{FIRST_NAME}",$first_name,$html_content);
			$html_content=str_replace("{LAST_NAME}",$last_name,$html_content);
			$html_content=str_replace("{LOGIN_PAGE}",$login_link,$html_content);
			$html_content=str_replace("{USERNAME}",$email,$html_content);
			$html_content=str_replace("{PASSWORD}",$password,$html_content);
		}
		$formname = 'Proscola Admin';
		$formaddrs = $formname." <".$email_setting_details[0]['from'].">";
		$subject=$email_setting_details[0]['subject'];
		$to=$email;
		$this->send_mail($formaddrs,$to,$subject,$html_content);
    }
	function send_mail($formaddrs,$to,$subject,$html_content)
	{
		$params = array(
			'from'	=> $formaddrs,
			'to'	=> $to,
			'subject' => $subject,
			'html'	=> $html_content
		);
		$result=$this->mails->send_message($params);
		return $result;
	}
	function encrypt($sData)
	{
		$id=(double)$sData*118479.24;
		return base64_encode($id);
	}
	function decrypt($sData){
		$url_id=base64_decode($sData);
		$id=(double)$url_id/118479.24;
		return $id;
	}
	function add_content()
	{
		$html='';
		$html.=PHP_EOL;
		$html.="\$db['2']['hostname'] = 'localhost';" . PHP_EOL;
		$html.="\$db['2']['username'] = 'root';" . PHP_EOL;
		$html.="\$db['4']['password'] = '';" . PHP_EOL;
		$html.="\$db['2']['database'] = 'proscola';" . PHP_EOL; 
		$html.="\$db['2']['dbdriver'] = 'mysqli';" . PHP_EOL;
		$html.="\$db['2']['dbprefix'] = '';" . PHP_EOL;
		$html.="\$db['2']['pconnect'] = TRUE;" . PHP_EOL;
		$html.="\$db['2']['db_debug'] = TRUE;" . PHP_EOL;
		$html.="\$db['2']['cache_on'] = FALSE;" . PHP_EOL;
		$html.="\$db['2']['cachedir'] = '';" . PHP_EOL;
		$html.="\$db['2']['char_set'] = 'utf8';" . PHP_EOL;
		$html.="\$db['2']['dbcollat'] = 'utf8_general_ci';" . PHP_EOL;
		$html.="\$db['2']['swap_pre'] = '';" . PHP_EOL;
		$html.="\$db['2']['autoinit'] = TRUE;" . PHP_EOL;
		$html.="\$db['2']['stricton'] = FALSE;" . PHP_EOL;
		$html.=PHP_EOL;
		$target_dir = "./application/config/database.php";
		file_put_contents($target_dir,$html,FILE_APPEND);
		echo "done";
	}
	
	function test_enc()
	{
		echo $this->rand_dec();
		/* $id=768;
		$url=$this->encrypt($id);
		echo $url."<br>";
		echo $this->decrypt($url); */
	}
	function disciplinary_convert_dates()
    {
        $cond="select id,protocol_date from disciplinary_protocols where id<>1";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$remark_date=$pro['protocol_date'];
			$pro_date=date('d-m-Y', $remark_date);
			$input = array(
				'protocol_date'=>$pro_date,
				'remarkdate_timestamp'=>$remark_date
			);
			$this->disciplinary_model->edit($input,$pro['id']);
		}
		echo "Done";
    }
	function lessons_convert_dates()
    {
        $cond="select id,start_date,end_date from dossiers where id<>1";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$start_date_time=$pro['start_date'];
			$end_date_time=$pro['end_date'];
			$start_date=date('d-m-Y', $start_date_time);
			$end_date=date('d-m-Y', $end_date_time);
			$input = array(
				'start_date'=>$start_date,
				'end_date'=>$end_date
			);
			$this->dossiers_model->edit($input,$pro['id']);
		}
		echo "Done";
    }
	
	function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}
	function messages_convert_dates()
    {
        $cond="select id,due_datetime,type from notifications where due_datetime is not null";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$due_date_timestamp=$pro['due_datetime'];
			$type=$pro['type'];
			if($type=="task")
			{
				$due_datetime=date('d-m-Y', $due_date_timestamp);
			}
			else
			{
				$due_datetime=date('d-m-Y h:i', $due_date_timestamp);
			}
			$input = array(
				'due_datetime'=>$due_datetime,
				'due_date_timestamp'=>$due_date_timestamp
			);
			$this->notifications_model->edit($input,$pro['id']);
		}
		echo "Done";
    }
	function upload_lessons()
	{
		$cond="select id,dossier_key,personnel_id,local_share,global_share from dossiers where id=1";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$cond="select dossier_file_id from dossiers_related_files where dossier_id=".$pro['id'];
			$rel_details = $this->users_model->special_fetch($cond);
			$cond="select id,location,created_at from dossiers_solutions where dossier_id=".$pro['id'];
			$sol_details = $this->users_model->special_fetch($cond);
			$cond="select id,location,created_at from dossiers_evaluations where dossier_id=".$pro['id'];
			$eva_details = $this->users_model->special_fetch($cond);
			if(count($rel_details)>0||count($sol_details)>0||count($eva_details)>0)
			{
				$permission=0;$global_permission=0;
				if (strpos($pro['local_share'], 'view') !== false) {
					$permission=1;
				}
				if (strpos($pro['global_share'], 'view') !== false) {
					$global_permission=1;
				}	
				$cond="select id from folders where user_id=".$pro['personnel_id']." and folder='Lessons'";
				$fol_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder'=>$pro['dossier_key'],
					'parent_folder'=>$fol_details[0]['id'],
					'user_id'=>$pro['personnel_id'],
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1
				);
				$dos_fold_id=$this->folder_manager_model->add($input);
				if($permission==1)
				{
					$cond="select id from folders where folder='Public' and user_id=".$pro['personnel_id'];
					$fold_pub_details = $this->users_model->special_fetch($cond);
					$input = array(
						'user_id'=>0,
						'folder'=>$pro['dossier_key'],
						'permission'=>$permission,
						'global_permission'=>$global_permission,
						'is_deleted'=>1,
						'parent_folder'=>$fold_pub_details[0]['id']
					);
					$this->folder_manager_model->add($input);
				}
				if(count($rel_details)>0)
				{
					$input = array(
						'folder'=>"Learning Materials",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$rel_fold_id=$this->folder_manager_model->add($input);
				}
				if(count($sol_details)>0)
				{
					$input = array(
						'folder'=>"Solutions",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$sol_fold_id=$this->folder_manager_model->add($input);
				}
				if(count($eva_details)>0)
				{
					$input = array(
						'folder'=>"Evaluations",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$eva_fold_id=$this->folder_manager_model->add($input);
				}
				foreach($rel_details as $rel)
				{
					$cond="select created_at,location,indexed_text from dossiers_files where id=".$rel['dossier_file_id'];
					$dos_file_details = $this->users_model->special_fetch($cond);
					if(count($dos_file_details)>0)
					{
						$input = array(
							'folder_id'=>$rel_fold_id,
							'document_name'=>$dos_file_details[0]['location'],
							'document_unique_name'=>$dos_file_details[0]['location'],
							'document_text'=>$dos_file_details[0]['indexed_text'],
							'document_indexed'=>1,
							'created_at'=>$dos_file_details[0]['created_at']
						);
						$rel_doc_id=$this->file_manager_model->add($input);
						$input = array(
							'dossier_id'=>$pro['id'],
							'dossier_file_id'=>$rel_doc_id
						);
						$this->dossiers_related_files_model->add($input);
					}
				}
				foreach($sol_details as $sol)
				{	
					$input = array(
						'folder_id'=>$sol_fold_id,
						'document_name'=>$sol['location'],
						'document_unique_name'=>$sol['location'],
						'created_at'=>$sol['created_at']
					);
					$sol_doc_id=$this->file_manager_model->add($input);
					$input = array(
						'dossier_file_id'=>$sol_doc_id
					);
					$this->dossiers_solutions_model->edit($input,$sol['id']);
				}
				foreach($eva_details as $eva)
				{	
					$input = array(
						'folder_id'=>$eva_fold_id,
						'document_name'=>$eva['location'],
						'document_unique_name'=>$eva['location'],
						'created_at'=>$eva['created_at']
					);
					$eva_doc_id=$this->file_manager_model->add($input);
					$input = array(
						'dossier_file_id'=>$eva_doc_id
					);
					$this->dossiers_solutions_model->edit($input,$eva['id']);
				}
			}
		}
		echo "Done";
	}
	function update_dos_lessons()
	{
		$cond="select id,dossier_key,personnel_id,local_share,global_share from dossiers";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$cond="select dossier_file_id from dossiers_related_files where dossier_id=".$pro['id'];
			$rel_details = $this->users_model->special_fetch($cond);
			$cond="select id,location,created_at from dossiers_solutions where dossier_id=".$pro['id'];
			$sol_details = $this->users_model->special_fetch($cond);
			$cond="select id,location,created_at from dossiers_evaluations where dossier_id=".$pro['id'];
			$eva_details = $this->users_model->special_fetch($cond);
			if(count($rel_details)>0||count($sol_details)>0||count($eva_details)>0)
			{
				$permission=0;$global_permission=0;
				if (strpos($pro['local_share'], 'view') !== false) {
					$permission=1;
				}
				if (strpos($pro['global_share'], 'view') !== false) {
					$global_permission=1;
				}	
				$cond="select id from folders where user_id=".$pro['personnel_id']." and folder='Lessons'";
				$fol_details = $this->users_model->special_fetch($cond);
				$input = array(
					'folder'=>$pro['dossier_key'],
					'parent_folder'=>$fol_details[0]['id'],
					'user_id'=>$pro['personnel_id'],
					'permission'=>$permission,
					'global_permission'=>$global_permission,
					'is_deleted'=>1
				);
				$dos_fold_id=$this->folder_manager_model->add($input);
				if($permission==1)
				{
					$cond="select id from folders where folder='Public' and user_id=".$pro['personnel_id'];
					$fold_pub_details = $this->users_model->special_fetch($cond);
					$input = array(
						'user_id'=>0,
						'folder'=>$pro['dossier_key'],
						'permission'=>$permission,
						'global_permission'=>$global_permission,
						'is_deleted'=>1,
						'parent_folder'=>$fold_pub_details[0]['id']
					);
					$this->folder_manager_model->add($input);
				}
				if(count($rel_details)>0)
				{
					$input = array(
						'folder'=>"Learning Materials",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$rel_fold_id=$this->folder_manager_model->add($input);
				}
				if(count($sol_details)>0)
				{
					$input = array(
						'folder'=>"Solutions",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$sol_fold_id=$this->folder_manager_model->add($input);
				}
				if(count($eva_details)>0)
				{
					$input = array(
						'folder'=>"Evaluations",
						'parent_folder'=>$dos_fold_id,
						'user_id'=>$pro['personnel_id'],
						'is_deleted'=>1
					);
					$eva_fold_id=$this->folder_manager_model->add($input);
				}
				foreach($rel_details as $rel)
				{	
					$input = array(
						'folder_id'=>$rel_fold_id
					);
					$this->file_manager_model->edit($input,$rel['dossier_file_id']);
				}
				foreach($sol_details as $sol)
				{	
					$input = array(
						'folder_id'=>$sol_fold_id
					);
					$this->file_manager_model->edit($input,$rel['dossier_file_id']);
				}
				foreach($eva_details as $eva)
				{	
					$input = array(
						'folder_id'=>$eva_fold_id
					);
					$this->file_manager_model->edit($input,$rel['dossier_file_id']);
				}
			}
		}
		echo "Done";
	}
	function load_languages()
	{
		$json = file_get_contents('php://input');
		$data = json_decode($json,true); 
		$lang_id = $data['lang_id'];
		$id = $data['id'];
		$cond="select id from users where id=".$id;
        $user_details = $this->users_model->special_fetch($cond);
		if(count($user_details)>0)
		{
			$input = array(
				'default_language'=>$lang_id
			);
			$this->users_model->edit($input,$id);
			$out = array('statuscode'=>'200');
		}	
		else
		{
			$out = array('statuscode'=>'201');
		}
        header('Content-Type:application/json');
        echo json_encode($out);
	}
	
}
