<?php



class MY_Controller extends CI_Controller {



    public $view_dir = 'frontend/';
    public $header = '';
    public $banner = '';
    public $footer = '';
	public $user_id = '';
    public $data = array();

    function __construct() {
        parent::__construct();
		
		$this->load->model(array('users_model','career_goals_model','countries_model','curriculums_model','subject_types_model','subjects_model','curriculum_items_model','disciplinary_categories_model','dossier_languages_model','lesson_numbers_model','mark_categories_model','marks_model','personnel_functions_model','rooms_model','terms_model','school_model','personnel_model','user_groups_model','courses_model','students_in_profession_model','students_model','students_parents_model','students_post_career_goals_model','students_terms_model','students_courses_model','timetable_model','absences_model','disciplinary_model','coaching_model','course_attendants_marks_model','dossiers_evaluations_model','dossiers_files_model','dossiers_model','dossiers_preparation_types_model','dossiers_ratings_model','dossiers_related_files_model','dossiers_solutions_model','file_manager_model','folder_manager_model','students_documents_model','course_upload_settings_model','course_uploads_model','course_upload_students_model','meeting_items_model','meeting_items_responsible_groups_model','meeting_items_responsible_personnel_model','meeting_items_responsible_students_model','notifications_model','notifications_recipients_model','email_templates_model','email_templates_i18n_model','system_settings_model','languages_model','bulk_labeling_model','acl_groups_model','inner_pages_model','group_roles_model','roles_model','labels_model','reports_model','reports_name_model','weekdays_model','parents_model','modules_model','builds_model','tasks_model','tasks_document_model','tasks_log_model','student_tasks_model','annotations_model'));
        $host = $_SERVER['HTTP_HOST'];
        $host = str_replace("www.","",$host);
        $cond="select * from admin where domain like '%".$host."%'";
        $admin_details = $this->users_model->special_fetch($cond);
        $this->data['admin_details'] = $admin_details[0];
        $this->load_database($admin_details[0]['domain_id']);
    }    
    function get_labels()
    {     
        $actual_link = $this->uri->segment(1);
        $page_layout = str_replace("_api","",$actual_link);
        $cond="select id from inner_pages where name='".$page_layout."'";
        $pg_details = $this->users_model->special_fetch($cond);
        if(count($pg_details)>0)
        {
            $cond="select name from labels where page_id=".$pg_details[0]['id']." and lang_id=1";
            $label_details = $this->users_model->special_fetch($cond);
        }
        else
            $label_details=array();
        return $label_details;
    }
    function get_paginate_numbers()
    {
        $cond="select number from paginate_numbers where lang_id=1";
        $pgn_details = $this->users_model->special_fetch($cond);
        return $pgn_details;
    }
    function get_include() {
        $this->data['header'] = $this->load->view($this->view_dir . 'admin/common/header', $this->data, true);
        $this->data['sideheader'] = $this->load->view($this->view_dir . 'admin/common/sideheader', $this->data, true);
        $this->data['footer'] = $this->load->view($this->view_dir . 'admin/common/footer', $this->data, true);
    }
    function translate_lang($code,$text)
	{
		$url = 'https://www.googleapis.com/language/translate/v2?key='. APIKEY.'&q='.rawurlencode($text).'&source=en&target='.$code;
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($handle); 
		$responseDecoded = json_decode($response, true);
		curl_close($handle);
        if (array_key_exists("error",$responseDecoded))
        {
            return "";
        }
        else
        {
		    $res_text=$responseDecoded['data']['translations'][0]['translatedText'];
		    return $res_text;
        }
	}
    /* function load_database($domain){
        $db_name = 'live';
        for($i=1;$i<100;$i++)
        {
            if($domain == '1'){
                $db_name = 'school';
                break;
            }
            else if($domain == $i){
                $db_name = $i;
                break;
            }    
        }   
        $str_db_name = (string)$db_name; 
        if($str_db_name == 'live')
        {
            $this->db = $this->load->database($str_db_name, TRUE);
        }
        else
        {
            $mysqli = new mysqli("localhost", "proscoladb1", "spwXjWFvVspwXjWFvV");
            if ($mysqli->select_db($str_db_name) === true) {
                $this->db = $this->load->database($str_db_name, TRUE);
                return true;
            }
            else
                return false;
        }
        return true;
    } */
    function load_database($domain){
        $db_name = 'live';
        if($domain=='gogomo_test')
        {
            $db_name = 'gogomo_test';
        }
        else if($domain=='ps_test')
        {
            $db_name = 'ps_test';
        }
        else
        {
            for($i=1;$i<100;$i++)
            {
                if($domain == '1'){
                    $db_name = 'school';
                    break;
                }
                else if($domain == $i){
                    $db_name = $i;
                    break;
                }    
            } 
        }  
        $str_db_name = (string)$db_name; 
        $this->db = $this->load->database($str_db_name, TRUE);
    }
}

