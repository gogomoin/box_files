<?php

require 'vendor/autoload.php';
use Mailgun\Mailgun;
class Mails extends Mailgun
{
	public $mgClient ='';
  	public function __construct() {
		
	}
	public function send_message($params)
	{
		$mgClient = Mailgun::create('66c68ba164c5c5c74b4fbf90336786cb-dbc22c93-a614ba35', 'https://api.eu.mailgun.net/v3/proscola.org');
		$domain = "proscola.org";
		$res=$mgClient->messages()->send($domain, $params);
		return $res;
	}
}