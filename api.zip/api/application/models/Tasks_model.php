<?php
class Tasks_model extends CI_Model
{
	public $table='tasks';
	public $primary_key='id';
	function __construct()
	{
		//load the parent constructor
		parent::__construct();
	}
	function fetch($cond,$select, $limit, $offset)
	{
		if($cond)
		{
			$where = ' 1 '.$cond;
			$this->db->where($where, null, false);
		}
		$this->db->select($select);
		$this->db->limit($limit, $offset);
		$query = $this->db->get($this->table);
		return $query->result_array();
	}
	function get_records($data_field) 
	{
		if($data_field)
		{
			$query = $this->db->get_where($this->table, $data_field);
			return $query->result_array(); 
		}
		$query = $this->db->get($this->table);
		return $query->result_array();
	}
	function get_table_records($table,$data_field) 
	{
		if($data_field)
		{
			$query = $this->db->get_where($table,$data_field);
			return $query->result_array(); 
		}
		$query = $this->db->get($table);
		return $query->result_array();
	}
	function add($data_field)
	{
		$this->db->insert($this->table,$data_field);
		return $this->db->insert_id();
	}
	function add_table($data_field,$table)
	{
		$this->db->insert($table,$data_field);
		return $this->db->insert_id();
	}
	function testadd($data_field)
	{
		$this->db->insert($this->testtable,$data_field);
		return $this->db->insert_id();
	}

	function edit($data_field,$id)
	{
		$re=$this->db->update($this->table, $data_field, array($this->primary_key=>$id));
		return $re;
	}
	function edit_all($data_field)
	{
		$re=$this->db->update($this->table, $data_field);
		return $re;
	}
	function edit_table($data_field,$id,$table)
	{
		$re=$this->db->update($table, $data_field, array($this->primary_key=>$id));
		return $re;
	}

	function update_status($id)
	{
		$this->db->update($this->table, array('status'=>'0'), ' id<>'.$id);
		$re=$this->db->update($this->table, array('status'=>'1'), array($this->primary_key=>$id));
		return $re;
	}

	function delete($id)
	{
		$this->db->where($this->primary_key, $id)->delete($this->table);
		return $this->db->affected_rows();
	}
	

	function delete_cond($cond)
	{
		$where = ' 1 '.$cond;
		$this->db->where($where, NULL, false);
		$this->db->delete($this->table);
		return $this->db->affected_rows();
	}

	function count_all()
	{
		return $this->db->count_all_results($this->table);
	}

	function count_all_cond($cond)
	{
		if($cond)
		{
			$where = ' 1 '.$cond;
			$this->db->where($where, null, false);
		}

		$this->db->select('COUNT(*) AS cnt');
		$query = $this->db->get($this->table);
		$arrcnt = $query->result_array();
		return $arrcnt[0]['cnt'];
	}
	function special_fetch($con) {
		$query =null;

		if ($con) {
			$query = $this->db->query($con);
		}
		return $query->result_array();
	}
	function special_ret($con,$data_field) {
		$query =null;

		if ($con) {

			$query = $this->db->query($con,$data);
		}
		return $query->result_array();
	}

}
