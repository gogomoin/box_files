<?php echo $header; 
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Address</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Address</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['s_a_add']==0) {?>
					<div class="button-group">
						<button type="button" class="btn waves-effect waves-light btn-primary" id="add_address_btn" data-toggle="modal" data-target="#add_address">Add Address </button>
					</div>
					<?php } ?>
					<?php if($roles['s_a_import']==0) {?>
					<div class="button-group">
						<button type="button" class="btn waves-effect waves-light btn-primary" id="import_address_btn" data-toggle="modal" data-target="#import_address"><i class="fas fa-download"></i> Import Address </button>
					</div>
					<?php } ?>
					<?php if($roles['s_a_export']==0) {?>
					<div class="button-group">
						<button type="button" class="btn waves-effect waves-light btn-primary" data-toggle="modal" data-target="#export_address" id="export_address_exp"><i class="fas fa-sign-in-alt"></i> Export Address </button>
					</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">					
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
								<tr class="bg-light">
									<th>S.No.</th>
									<th>Country</th>
									<th>Address</th>
									<th>Admin</th>
									<th>Created On</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Address -->
	<div id="add_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Address</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>				
				</div>
				<div class="modal-body">    
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_address_form" id="add_address_form" action="#" class="add_address_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Country</label>
								<select class="form-control" name="country" id="country">
									<option value="">Country *</option>
								</select>
							</div>
						</div>
						<div class="all-fields" style="display:none">
							
						</div> 
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_address_form">
					<button type="button" class="btn btn-primary" id="add_address_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Address Fields -->
	<div id="edit_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
		  <h4 class="modal-title">Edit Address</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>			
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<form name="edit_address_form" id="edit_address_form" action="#" class="edit_address_form">
			 <div class="form-group pst_relt">
				<div class="add_user_frm">
					<select class="form-control" name="country" id="country_up">
						<option value="">Country *</option>
					</select>
					<input type="hidden" name="address_id" id="address_id" value="" />
				</div>
			</div>
			  <div class="all-fields-up">
				<div class="form-group pst_relt">
					<div class="input-group add_user_frm">
						 <input class="form-control" placeholder="Fields*" type="text" name="fields_up"/>
					</div>
				</div> 
			</div>
			</form>
			<div class="text-center edit_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer edit_address_form">
			<button type="button" class="btn btn-primary" id="edit_address_sub">Update</button>
			<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>
	  </div>
	</div>

	<!-- delete Address -->
	<div id="delete_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h4 class="modal-title">Delete Address</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<div class="delete_address_form">
			  <div class="form-group">
				<p>If You Delete Address, Related Information Will Be Removed</p>
				<p>Are You Sure You Want To Delete Address?</p>
			  </div>
			</div>
			<div class="text-center delete_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer delete_address_form">
			<button type="button" class="btn btn-primary" id="delete_address_sub">Delete</button>
			<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>

	  </div>
	</div>
	<!-- Import Address -->
	<div id="import_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Import Address</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="import_address_form" id="import_address_form" action="#" class="import_address_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<select class="form-control" name="country_id_imp" id="country_id_imp">
									<option value="">Select Country *</option>
								</select>
							</div>
						</div>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<div class="custom-file">
									<input type="file" name="import_address_file" id="import_address_file" class="custom-file-input" accept=".xls">
									<label class="custom-file-label" for="customFile" id="import_label">Choose file (.xls only)</label>
									<input class="gui-input" id="import_uploader" style="display:none" type="text">
								</div>
							</div>
						</div>
						<div class="form-group pst_relt pull-right">
							<div class="add_user_frm">
								<a class="" style="cursor:pointer" id="sample_excel"><i class="fa fa-download"></i> <span>Download Sample Excel Format To Upload Address</span></a>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_address_form">
					<button type="button" class="btn btn-primary" id="import_address_sub">Import</button>
					<button type="button" class="btn btn-danger" id="close_import_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Export Address -->
	<div id="export_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Export Address</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="exp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="exp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="export_address_form" id="export_address_form" action="#" class="export_address_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<select class="form-control" name="country_id_exp" id="country_id_exp">
									<option value="">Select Country *</option>
								</select>
							</div>
						</div>
					</form>
					<div class="text-center exp_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_address_form">
					<button type="button" class="btn btn-primary" id="export_address_btn">Export</button>
					<button type="button" class="btn btn-danger" id="close_exp_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
</div>

<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>address.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],address_fields=[],id="<?php  echo $user_det['id'];?>";
var edit_add_role = "<?php echo $roles['s_a_edit']; ?>";
var del_add_role = "<?php echo $roles['s_a_del']; ?>";
var export_add_role = "<?php echo $roles['s_a_export']; ?>";
var import_add_fld_role = "<?php echo $roles['s_a_import']; ?>";
$(document).ready(function() {    
	address_details();
});

</script>
