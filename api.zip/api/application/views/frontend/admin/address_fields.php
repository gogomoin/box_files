<?php echo $header; 
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Address Fields</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Address Fields</li>
						</ol>
					</nav>
				</div>
			</div>
			<?php if($roles['s_af_add']==0) {?>
			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<div class="button-group">
						<button type="button" class="btn waves-effect waves-light btn-primary" id="add_address_fields_btn" data-toggle="modal" data-target="#add_address_fields">Add Address Fields</button>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">					
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
								<tr class="bg-light">
									<th>S.No.</th>
									<th>Country</th>
									<th>Fields</th>
									<th>Created By</th>
									<th>Created On</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Address Fields -->
	<div id="add_address_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Address Fields</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>				
				</div>
				<div class="modal-body">    
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_address_fields_form" id="add_address_fields_form" action="#" class="add_address_fields_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Country</label>
								<select class="form-control" name="country" id="country">
									<option value="">Country *</option>
								</select>
							</div>
						</div>
						<label for="email">Fields</label>
						<div class="all-fields">
							<div class="form-group pst_relt">
								<div class="input-group add_user_frm">

									 <input class="form-control" placeholder="Fields *" type="text" name="fields"/>
									  <div class="input-group-addon add-class">
										<i class="fa fa-plus"></i>
									  </div>
								</div>
							</div> 
						</div> 
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_address_fields_form">
					<button type="button" class="btn btn-primary" id="add_address_fields_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Address Fields -->
	<div id="edit_address_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
		  <h4 class="modal-title">Edit Address Fields</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>			
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<form name="edit_address_fields_form" id="edit_address_fields_form" action="#" class="edit_address_fields_form">
			 <div class="form-group pst_relt">
				<div class="add_user_frm">
					<label for="email">Country</label>
					<select class="form-control" name="country" id="country_up">
						<option value="">Country *</option>
					</select>
					<input type="hidden" name="address_fields_id" id="address_fields_id" value="" />
				</div>
			</div>
				<label for="email">Fields</label>
			  <div class="all-fields-up">
				<div class="form-group pst_relt">
					<div class="input-group add_user_frm">
						 <input class="form-control" placeholder="Fields *" type="text" name="fields_up"/>
						  <div class="input-group-addon add-class">
							<i class="fa fa-plus"></i>
						  </div>
					</div>
				</div> 
			</div>
			</form>
			<div class="text-center edit_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer edit_address_fields_form">
			<button type="button" class="btn btn-primary" id="edit_address_fields_sub">Update</button>
			<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>
	  </div>
	</div>

	<!-- delete Address Fields -->
	<div id="delete_address_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h4 class="modal-title">Delete Address Fields</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<div class="delete_address_fields_form">
			  <div class="form-group">
				<p>If You Delete Address Fields, Related Information Will Be Removed</p>
				<p>Are You Sure You Want To Delete Address Fields?</p>
			  </div>
			</div>
			<div class="text-center delete_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer delete_address_fields_form">
			<button type="button" class="btn btn-primary" id="delete_address_fields_sub">Delete</button>
			<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>

	  </div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>address_fields.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],id="<?php  echo $user_det['id'];?>";
var edit_fld_role = "<?php echo $roles['s_af_edit']; ?>";
var del_fld_role = "<?php echo $roles['s_af_del']; ?>";
$(document).ready(function() {    
	address_fields_details();
});
</script>
