<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Company</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Company</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['s_com_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_company_btn" data-toggle="modal" data-target="#add_company">Add Company </button>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Company Name</th>
								<th>Email</th>
								<th>Contact No</th>
								<th>Address</th>
								<th>Contact Name</th>
								<th>Logo</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Company Modal -->
	<div id="add_company" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Company</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="com_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="com_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_company_form" id="add_company_form" action="#" class="add_company_form">

						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Company Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="com_name" name="com_name" placeholder="Company Name *">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Email</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="com_email" name="com_email" placeholder="Email">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Contact No</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="com_conact_no" name="com_conact_no" placeholder="Contact No">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Address</label>
								<div class="add_user_frm">
									<textarea type="text" class="form-control" id="com_address" name="com_address" placeholder="Address"></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Contact Name</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="contact_person_name" name="contact_person_name" placeholder="Contact Name">
								</div>
							</div>
						</div>
						<label for="email">Company Logo</label>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<div class="custom-file">
									<input type="file" name="com_logo_file" id="com_logo_file" class="custom-file-input" accept="image/*">
									<label class="custom-file-label" for="customFile" id="com_logo_label">Choose Logo (Images only)</label>
									<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Logo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="com_logo_preview">
									<a class="" style="cursor:pointer" id="remove_com_logo_file"><span>Remove</span></a>
								</div>
							</div>
						</div>
					</form>
					<div class="text-center com_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_company_form">
					<button type="button" class="btn btn-primary" id="add_company_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_com_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Company Modal -->
	<div id="edit_company" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Company</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_company_form" id="edit_company_form" action="#" class="edit_company_form">
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Company Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="com_name_up" name="com_name" placeholder="Company Name *">
									<input type="hidden" id="com_id" name="com_id">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Email</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="com_email_up" name="com_email" placeholder="Email">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">Contact No</label>
									<input type="text" class="form-control" id="com_conact_no_up" name="com_conact_no" placeholder="Contact No">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Address</label>
								<div class="add_user_frm">
									<textarea type="text" class="form-control" id="com_address_up" name="com_address" placeholder="Address"></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Contact Name</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="contact_person_name_up" name="contact_person_name" placeholder="Contact Name">
								</div>
							</div>
						</div>
						<label for="email">Company Logo</label>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<div class="custom-file">
									<input type="file" name="com_logo_file" id="com_logo_file_up" class="custom-file-input" accept="image/*">
									<label class="custom-file-label" for="customFile" id="com_logo_label_up">Choose Logo (Images only)</label>
									<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Icon" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="com_logo_preview_up">
									<a class="" style="cursor:pointer" id="remove_com_logo_file_up"><span>Remove</span></a>
								</div>
							</div>
						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_company_form">
					<button type="button" class="btn btn-primary" id="edit_company_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_com_edit_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete Company Modal -->
	<div id="delete_company" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Company</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_company_form">
						<div class="form-group">
							<p>If You Delete Company, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Company?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_company_form">
					<button type="button" class="btn btn-primary" id="delete_company_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_com_del_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>company.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],address_fields=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['s_com_edit']; ?>";
	var del_add_role = "<?php echo $roles['s_com_delete']; ?>";
	$(document).ready(function() {
		company_details();
	});

</script>
