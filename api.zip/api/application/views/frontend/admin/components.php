<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<link href="<?php echo $css_path;?>jquery-ui.css"" rel="stylesheet" type="text/css"/>
<script src="<?php echo $js_path;?>jquery.min.js"></script>
<script src="<?php echo $js_path;?>jquery-ui.min.js"></script>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Components</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Components</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['cmp_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_components_btn" data-toggle="modal" data-target="#add_components">Add Components </button>
						</div>
					<?php } ?>
					<?php if($roles['cmp_import']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="import_components_imp" data-toggle="modal" data-target="#import_components">Import Components</button>
						</div>
					<?php } ?>
					<?php if($roles['cmp_export']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="export_components_exp">Export Components</button>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Serial No</th>
								<th>Name</th>								
								<th>Photo</th>
								<th>Quantity</th>
								<th>Specifications</th>
								<th>Price</th>
								<th>Date of Purchase</th>
								<th>Date of Expiry</th>
								<th>Notes</th>
								<th>Created By</th>
								<th>Maintenance</th>
								<th>Status</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Components Modal -->
	<div id="add_components" class="modal fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Components</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="com_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="com_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_components_form" id="add_components_form" action="#" class="add_components_form">
						<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Serial No *</label>
								<input type="text" class="form-control" id="serial_no" name="serial_no" placeholder="Serial No *">
							</div>
							<div class="form-group col-sm-6">
								<label for="email">Name *</label>
								<input type="text" class="form-control" id="name" name="name" placeholder="Name *">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Quantity</label>
								<input type="text" class="form-control" id="quantity" name="quantity" placeholder="Quantity">
							</div>
							<div class="form-group col-sm-6">
								<label for="email">Price</label>
								<input type="text" class="form-control" id="price" name="price" placeholder="Price">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">Specifications</label>
									<textarea type="text" class="form-control" id="specifications" name="specifications" placeholder="Specifications"></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Photo</label>
								<div class="custom-file">
									<input type="file" name="photo_file" id="photo_file" class="custom-file-input" accept="image/*">
									<label class="custom-file-label" for="customFile" id="photo_label">Choose Photo (Images only)</label>
									<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="photo_preview">
									<a class="" style="cursor:pointer" id="remove_photo_file"><span>Remove</span></a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
							</div>
							<div class="form-group col-sm-6">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Date Of Purchase</label>
								<input type="text" class="form-control" id="date_of_purchase" name="date_of_purchase" placeholder="Date Of Purchase" autocomplete="off">
							</div>
							<script type="text/javascript">
								$('#date_of_purchase').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
									changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
							</script>
							<div class="form-group col-sm-6">
								<label for="email">Date Of Expiry</label>
								<input type="text" class="form-control" id="date_of_expiry" name="date_of_expiry" placeholder="Date Of Expiry" autocomplete="off">
							</div>
							<script type="text/javascript">
								$('#date_of_expiry').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
									changeYear: true,yearRange: (new Date).getFullYear()+':2050'});
							</script>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">Notes</label>
									<textarea type="text" class="form-control" id="notes" name="notes" placeholder="Notes"></textarea>
								</div>
							</div>
						</div>
					</form>
					<div class="text-center com_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_components_form">
					<button type="button" class="btn btn-primary" id="add_components_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_com_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Components Modal -->
	<div id="edit_components" class="modal fade fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Components</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_components_form" id="edit_components_form" action="#" class="edit_components_form">
					<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Serial No *</label>
								<input type="text" class="form-control" id="serial_no_up" name="serial_no" placeholder="Serial No *">
								<input type="hidden" id="component_id" name="component_id">
							</div>
							<div class="form-group col-sm-6">
								<label for="email">Name *</label>
								<input type="text" class="form-control" id="name_up" name="name" placeholder="Name *">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Quantity</label>
								<input type="text" class="form-control" id="quantity_up" name="quantity" placeholder="Quantity">
							</div>
							<div class="form-group col-sm-6">
								<label for="email">Price</label>
								<input type="text" class="form-control" id="price_up" name="price" placeholder="Price">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">Specifications</label>
									<textarea type="text" class="form-control" id="specifications_up" name="specifications" placeholder="Specifications"></textarea>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Photo</label>
								<div class="custom-file">
									<input type="file" name="photo_file" id="photo_file_up" class="custom-file-input" accept="image/*">
									<label class="custom-file-label" for="customFile" id="photo_label_up">Choose Photo (Images only)</label>
									<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="photo_preview_up">
									<a class="" style="cursor:pointer" id="remove_photo_file_up"><span>Remove</span></a>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
							</div>
							<div class="form-group col-sm-6">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-6">
								<label for="email">Date Of Purchase</label>
								<input type="text" class="form-control" id="date_of_purchase_up" name="date_of_purchase" placeholder="Date Of Purchase" autocomplete="off">
							</div>
							<script type="text/javascript">
								$('#date_of_purchase_up').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
									changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
							</script>
							<div class="form-group col-sm-6">
								<label for="email">Date Of Expiry</label>
								<input type="text" class="form-control" id="date_of_expiry_up" name="date_of_expiry" placeholder="Date Of Expiry" autocomplete="off">
							</div>
							<script type="text/javascript">
								$('#date_of_expiry_up').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
									changeYear: true,yearRange: (new Date).getFullYear()+':2050'});
							</script>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">Notes</label>
									<textarea type="text" class="form-control" id="notes_up" name="notes" placeholder="Notes"></textarea>
								</div>
							</div>
						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_components_form">
					<button type="button" class="btn btn-primary" id="edit_components_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_com_edit_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete Components Modal -->
	<div id="delete_components" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Components</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_components_form">
						<div class="form-group">
							<p>If You Delete Components, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Components?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_components_form">
					<button type="button" class="btn btn-primary" id="delete_components_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_com_del_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
	<!-- Components status -->
	<div id="status_components" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Components Status</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sts_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sts_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="status_components_form" id="status_components_form" action="#" class="status_components_form">
						<div class="form-group col-sm-12">
							<label for="email">Status</label>
							<select class="form-control" id="status" name="status">
								<option>Select Status</option>
								<option value="0">Purchased</option>
								<option value="1">Installed</option>
								<option value="2">Under Maintenance</option>
								<option value="3">Expired</option>
							</select>							
						</div>						
					</form>
					<div class="text-center status_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer status_components_form">
					<button type="button" class="btn btn-primary" id="status_mark_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_mrk_st_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Import Components -->
	<div id="import_components" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Import Components</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="import_components_form" id="import_components_form" action="#" class="import_components_form">
						<div class="form-group pst_relt">
							<div class="add_components_frm">
								<div class="custom-file">
									<input type="file" name="import_components_file" id="import_components_file" class="custom-file-input" accept=".xls">
									<label class="custom-file-label" for="customFile" id="import_label">Choose file (.xls only)</label>
									<input class="gui-input" id="import_uploader" style="display:none" type="text">
								</div>
							</div>
						</div>
						<div class="form-group pst_relt pull-right">
							<div class="add_components_frm">
								<a class="" style="cursor:pointer" href="<?php echo $base_url."assets/uploads/address/components_sample.xls"; ?>" download><i class="fa fa-download"></i> <span>Download Sample Excel Format To Upload Components</span></a>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_components_form">
					<button type="button" class="btn btn-primary" id="import_components_sub">Import</button>
					<button type="button" class="btn btn-danger" id="close_import_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>	
</div>

<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>components.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],company=[],roles=[],id_proofs=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['cmp_edit']; ?>";
	var del_add_role = "<?php echo $roles['cmp_delete']; ?>";
	var status_add_role = "<?php echo $roles['cmp_status']; ?>";
	var maintain_add_role = "<?php echo $roles['cmp_maintain']; ?>";
	$(document).ready(function() {
		components_details();
	});
</script>
