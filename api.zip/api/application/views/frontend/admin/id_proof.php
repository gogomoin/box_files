<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">ID Proof</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">ID Proof</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['s_id_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_id_proof_btn" data-toggle="modal" data-target="#add_id_proof">Add ID Proof </button>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Country</th>
								<th>ID Proof</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new ID Proof -->
	<div id="add_id_proof" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add ID Proof</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_id_proof_form" id="add_id_proof_form" action="#" class="add_id_proof_form">
						<div class="form-group pst_relt">
							<label for="email">Country *</label>
							<div class="add_user_frm">
								<select class="form-control" name="country_id" id="country_id">
									<option value="">Country *</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">ID Proof Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="id_proof" name="id_proof" placeholder="ID Proof Name *">
								</div>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_id_proof_form">
					<button type="button" class="btn btn-primary" id="add_id_proof_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit ID Proof -->
	<div id="edit_id_proof" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit ID Proof</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_id_proof_form" id="edit_id_proof_form" action="#" class="edit_id_proof_form">
						<div class="form-group pst_relt">
							<label for="email">Country *</label>
							<div class="add_user_frm">
								<select class="form-control" name="country_id" id="country_id_up">
									<option value="">Country *</option>
								</select>
								<input type="hidden" name="id_proof_id" id="id_proof_id" value="" />
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">ID Proof Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="id_proof_up" name="id_proof_up" placeholder="ID Proof Name *">
								</div>
							</div>
						</div>

					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_id_proof_form">
					<button type="button" class="btn btn-primary" id="edit_id_proof_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete ID Proof -->
	<div id="delete_id_proof" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete ID Proof</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_id_proof_form">
						<div class="form-group">
							<p>If You Delete ID Proof, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete ID Proof?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_id_proof_form">
					<button type="button" class="btn btn-primary" id="delete_id_proof_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>id_proof.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['s_id_edit']; ?>";
	var del_add_role = "<?php echo $roles['s_id_delete']; ?>";
	$(document).ready(function() {
		id_proof_details();
	});

</script>
