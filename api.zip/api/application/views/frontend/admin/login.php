<!DOCTYPE html>
<html dir="ltr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo $admin_images_path; ?>favicon-.png">
    <title>Smart Box - Admin Login</title>
    <!-- Custom CSS -->
    <link href="<?php echo $admin_css_path; ?>style.css" rel="stylesheet">  
</head>

<body>
    <div class="main-wrapper">
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center" style="background:url(<?php echo $admin_images_path; ?>login_img1.jpg) no-repeat center center; background-size: cover;">
            <div class="bg_overlay"></div>
            <div class="over_img"><img src="<?php echo $admin_images_path; ?>map-logo-big.png" alt=""></div>
            <div class="auth-box on-sidebar">
                <div id="loginform">
                    <div class="logo">
                        <span class="db"><img src="<?php echo $admin_images_path; ?>map-logo.png" alt="logo" /></span>
                        <h5 class="font-medium m-b-20">Sign In to Admin</h5>
                    </div>
					<div class="login__check"> <span id="error_message" style="color:red;margin: 10% 0% 0% 21%; display:none;">Please Fill The Required Field</span></div>
                  <div class="login__check"> <span id="error_email" style="color:red;margin: 10% 0% 0% 21%; display:none;">Please Give Valid Email Address </span>
                  </div>
                    <!-- Form -->
                    <div class="row">
                        <div class="col-12">
                            <form method="post" class="form-horizontal m-t-20" name="login_form" action="<?php echo $base_url . "admin/login"; ?>" autocomplete="off">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon1"><i class="ti-user"></i></span>
                                    </div>
                                    <input type="text" class="form-control form-control-lg" placeholder="Username" aria-label="Username" aria-describedby="basic-addon1" name="username" value="<?php echo $username;?>" id="username" autofocus  autocomplete="off">
									
                                </div>
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text" id="basic-addon2"><i class="ti-pencil"></i></span>
                                    </div>
                                    <input type="password" class="form-control form-control-lg" placeholder="Password" aria-label="Password" aria-describedby="basic-addon1" name="password" id="password" autocomplete="off" onFocus="this.type='password'">
									<input type="hidden" name="uzone" id="uzone" />
                                </div>
                                
                                <div class="form-group text-center">
                                    <div class="col-xs-12 p-b-20">
									<span style="color:#ea4646; font-weight:bold;display: block;padding: 10px 0px;"  id="status"><?php echo $error_message ?></span>
                                        <button class="btn btn-block btn-lg btn-info" type="submit"  onClick="return check_add_form();">Log In</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>                
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper scss in scafholding.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Page wrapper scss in scafholding.scss -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right Sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- Right Sidebar -->
        <!-- ============================================================== -->
    </div>
    <!-- ============================================================== -->
    <!-- All Required js -->
    <!-- ============================================================== -->
    <script src="<?php echo $admin_libs_path; ?>jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo $admin_libs_path; ?>popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo $admin_libs_path; ?>bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- ============================================================== -->
    <!-- This page plugin js -->
    <!-- ============================================================== -->
    <script>
        $('[data-toggle="tooltip"]').tooltip();
        $(".preloader").fadeOut();
		setTimeout(function(){
		  $('#status').fadeOut();
		}, 5000);
        // ============================================================== 
        // Login and Recover Password 
        // ============================================================== 
        $('#to-recover').on("click", function() {
            $("#loginform").slideUp();
            $("#recoverform").fadeIn();
        });
    </script>
	<script src="<?php echo $js_path . 'jstz-1.0.4.min.js'; ?>"></script>
	<script> 
var tz = jstz.determine();
var timezone = tz.name();
$('#uzone').val(timezone);

function check_add_form(){
	
	usrSubPrev = true;
	var email = document.forms["login_form"]["username"].value;
	var password = document.forms["login_form"]["password"].value;
	if(email=="" && password=="")
	{	
		$('#error_message').show();
		$('#error_email').hide();
		$(".login__row").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
		return false; 
	}
	else if(email==""){
			$('#error_message').show();
			$('#error_email').hide();
			$("#email_id").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
			return false;
	}else if(password==""){
        $('#error_message').show();
        $('#error_email').hide();
        $("#password").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
        return false;
	}  
}
    
</script>
</body>

</html>