<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Sub Category Fields</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Sub Category Fields</li>
						</ol>
					</nav>
				</div>
			</div>
			<?php if($roles['cat_fld_add']==0) {?>
				<div class="col-7 align-self-center">
					<div class="d-flex no-block justify-content-end align-items-center">
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_sub_category_fields_btn" data-toggle="modal" data-target="#add_sub_category_fields">Add Sub Category Fields</button>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Country</th>
								<th>Category</th>
								<th>Fields</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Sub Category Fields -->
	<div id="add_sub_category_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Sub Category Fields</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_sub_category_fields_form" id="add_sub_category_fields_form" action="#" class="add_sub_category_fields_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Country *</label>
								<select class="form-control" name="country_id" id="country_id">
									<option value="">Country *</option>
								</select>
							</div>
						</div>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Category *</label>
								<select class="form-control" name="category_id" id="category_id">
									<option value="">Category *</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">No Of Fields *</label>
									<input type="text" class="form-control" id="fields" name="fields" placeholder="No Of Fields *">
								</div>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_sub_category_fields_form">
					<button type="button" class="btn btn-primary" id="add_sub_category_fields_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit sub_category Fields -->
	<div id="edit_sub_category_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Sub Category Fields</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_sub_category_fields_form" id="edit_sub_category_fields_form" action="#" class="edit_sub_category_fields_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Country *</label>
								<select class="form-control" name="country_id" id="country_id_up">
									<option value="">Country *</option>
								</select>
								<input type="hidden" name="sub_category_fields_id" id="sub_category_fields_id" value="" />
							</div>
						</div>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Category *</label>
								<select class="form-control" name="category_id" id="category_id_up">
									<option value="">Category *</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<div class="add_user_frm">
									<label for="email">No Of Fields *</label>
									<input type="text" class="form-control" id="fields_up" name="fields" placeholder="No Of Fields *">
								</div>
							</div>
						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_sub_category_fields_form">
					<button type="button" class="btn btn-primary" id="edit_sub_category_fields_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete sub_category Fields -->
	<div id="delete_sub_category_fields" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Sub Category Fields</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_sub_category_fields_form">
						<div class="form-group">
							<p>If You Delete Sub Category Fields, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Sub Category Fields?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_sub_category_fields_form">
					<button type="button" class="btn btn-primary" id="delete_sub_category_fields_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>sub_category_fields.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],category=[],id="<?php  echo $user_det['id'];?>";
	var edit_fld_role = "<?php echo $roles['cat_fld_edit']; ?>";
	var del_fld_role = "<?php echo $roles['cat_fld_delete']; ?>";
	$(document).ready(function() {
		sub_category_fields_details();
	});
</script>
