<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/** Login **/
$route['login'] = 'home/login';
$route['logout'] = 'home/logout';

/** Single Column Layout **/
$route['absence_categories'] = 'home/single_column_layout';
$route['coaching_categories'] = 'home/single_column_layout';
$route['competence_levels'] = 'home/single_column_layout';
$route['curriculum_categories'] = 'home/single_column_layout';
$route['curriculum_item_cycles'] = 'home/single_column_layout';
$route['curriculum_item_types'] = 'home/single_column_layout';
$route['genders'] = 'home/single_column_layout';
$route['classes'] = 'home/single_column_layout';
$route['intended_professions'] = 'home/single_column_layout';
$route['main_levels'] = 'home/single_column_layout';
$route['meeting_item_categories'] = 'home/single_column_layout';
$route['room_functions'] = 'home/single_column_layout';
$route['preparation_types'] = 'home/single_column_layout';
$route['student_course_statuses'] = 'home/single_column_layout';
$route['subject_categories'] = 'home/single_column_layout';
$route['weekdays'] = 'home/single_column_layout';
$route['get_un_seen_messages'] = 'home/get_un_seen_messages';
$route['get_msg_count'] = 'home/get_msg_count';
$route['update_is_seen_all'] = 'home/update_is_seen_all';
$route['load_languages'] = 'home/load_languages';
$route['task_categories'] = 'home/single_column_layout';

$route['get_single_column_page'] = 'home/get_single_column_page';
$route['add_single_column_page'] = 'home/add_single_column_page';
$route['edit_single_column_page'] = 'home/edit_single_column_page';
$route['delete_single_column_page'] = 'home/delete_single_column_page';
$route['restore_single_column_page'] = 'home/restore_single_column_page';
$route['set_status_single_column_page'] = 'home/set_status_single_column_page';
$route['import_single_column_page'] = 'home/import_single_column_page'; 

/** Career Goals **/
$route['career_goals'] = 'career_goals/career_goals';
$route['view_career_goals'] = 'career_goals/view_career_goals';
$route['add_career_goals'] = 'career_goals/add_career_goals';
$route['edit_career_goals'] = 'career_goals/edit_career_goals';
$route['delete_career_goals'] = 'career_goals/delete_career_goals';
$route['restore_career_goals'] = 'career_goals/restore_career_goals';
$route['set_status_career_goals'] = 'career_goals/set_status_career_goals';
$route['set_standard_career_goals'] = 'career_goals/set_standard_career_goals';
$route['import_career_goals'] = 'career_goals/import_career_goals';

/** Countries **/
$route['countries'] = 'countries/countries';
$route['view_countries'] = 'countries/view_countries';
$route['add_countries'] = 'countries/add_countries';
$route['edit_countries'] = 'countries/edit_countries';
$route['delete_countries'] = 'countries/delete_countries';
$route['restore_countries'] = 'countries/restore_countries';
$route['set_status_countries'] = 'countries/set_status_countries';
$route['import_countries'] = 'countries/import_countries';

/** Curriculums **/
$route['curricula'] = 'curriculums/curriculums';
$route['get_curriculum_categories'] = 'curriculums/get_curriculum_categories';
$route['view_curriculums'] = 'curriculums/view_curriculums';
$route['add_curriculums'] = 'curriculums/add_curriculums';
$route['edit_curriculums'] = 'curriculums/edit_curriculums';
$route['delete_curriculums'] = 'curriculums/delete_curriculums';
$route['restore_curriculums'] = 'curriculums/restore_curriculums';
$route['set_status_curriculums'] = 'curriculums/set_status_curriculums';
$route['import_curriculums'] = 'curriculums/import_curriculums';

/** Subject Types **/
$route['subject_types'] = 'subject_types/subject_types';
$route['view_subject_types'] = 'subject_types/view_subject_types';
$route['add_subject_types'] = 'subject_types/add_subject_types';
$route['edit_subject_types'] = 'subject_types/edit_subject_types';
$route['delete_subject_types'] = 'subject_types/delete_subject_types';
$route['restore_subject_types'] = 'subject_types/restore_subject_types';
$route['set_status_subject_types'] = 'subject_types/set_status_subject_types';
$route['import_subject_types'] = 'subject_types/import_subject_types';

/** Subjects **/
$route['subjects'] = 'subjects/subjects';
$route['get_subject_categories'] = 'subjects/get_subject_categories';
$route['get_subject_types'] = 'subjects/get_subject_types';
$route['view_subjects'] = 'subjects/view_subjects';
$route['add_subjects'] = 'subjects/add_subjects';
$route['edit_subjects'] = 'subjects/edit_subjects';
$route['delete_subjects'] = 'subjects/delete_subjects';
$route['restore_subjects'] = 'subjects/restore_subjects';
$route['set_status_subjects'] = 'subjects/set_status_subjects';
$route['import_subjects'] = 'subjects/import_subjects';

/** Curriculums **/
$route['curriculum_items'] = 'curriculum_items/curriculum_items';
$route['get_curriculums'] = 'curriculum_items/get_curriculums';
$route['get_subjects'] = 'curriculum_items/get_subjects';
$route['get_curriculum_item_types'] = 'curriculum_items/get_curriculum_item_types';
$route['get_competence_levels'] = 'curriculum_items/get_competence_levels';
$route['get_curriculum_item_cycles'] = 'curriculum_items/get_curriculum_item_cycles';
$route['view_curriculum_items'] = 'curriculum_items/view_curriculum_items';
$route['add_curriculum_items'] = 'curriculum_items/add_curriculum_items';
$route['edit_curriculum_items'] = 'curriculum_items/edit_curriculum_items';
$route['delete_curriculum_items'] = 'curriculum_items/delete_curriculum_items';
$route['restore_curriculum_items'] = 'curriculum_items/restore_curriculum_items';
$route['set_status_curriculum_items'] = 'curriculum_items/set_status_curriculum_items';
$route['import_curriculum_items'] = 'curriculum_items/import_curriculum_items';

/** Disciplinary Categories **/
$route['disciplinary_categories'] = 'disciplinary_categories/disciplinary_categories';
$route['view_disciplinary_categories'] = 'disciplinary_categories/view_disciplinary_categories';
$route['add_disciplinary_categories'] = 'disciplinary_categories/add_disciplinary_categories';
$route['edit_disciplinary_categories'] = 'disciplinary_categories/edit_disciplinary_categories';
$route['delete_disciplinary_categories'] = 'disciplinary_categories/delete_disciplinary_categories';
$route['restore_disciplinary_categories'] = 'disciplinary_categories/restore_disciplinary_categories';
$route['set_status_disciplinary_categories'] = 'disciplinary_categories/set_status_disciplinary_categories';
$route['import_disciplinary_categories'] = 'disciplinary_categories/import_disciplinary_categories';

/** Dossier Languages **/
$route['dossier_languages'] = 'dossier_languages/dossier_languages';
$route['view_dossier_languages'] = 'dossier_languages/view_dossier_languages';
$route['add_dossier_languages'] = 'dossier_languages/add_dossier_languages';
$route['edit_dossier_languages'] = 'dossier_languages/edit_dossier_languages';
$route['delete_dossier_languages'] = 'dossier_languages/delete_dossier_languages';
$route['restore_dossier_languages'] = 'dossier_languages/restore_dossier_languages';
$route['set_status_dossier_languages'] = 'dossier_languages/set_status_dossier_languages';
$route['import_dossier_languages'] = 'dossier_languages/import_dossier_languages';

/** Lesson Numbers **/
$route['lesson_numbers'] = 'lesson_numbers/lesson_numbers';
$route['view_lesson_numbers'] = 'lesson_numbers/view_lesson_numbers';
$route['add_lesson_numbers'] = 'lesson_numbers/add_lesson_numbers';
$route['edit_lesson_numbers'] = 'lesson_numbers/edit_lesson_numbers';
$route['delete_lesson_numbers'] = 'lesson_numbers/delete_lesson_numbers';
$route['restore_lesson_numbers'] = 'lesson_numbers/restore_lesson_numbers';
$route['set_status_lesson_numbers'] = 'lesson_numbers/set_status_lesson_numbers';
$route['import_lesson_numbers'] = 'lesson_numbers/import_lesson_numbers';

/** Marks Categories **/
$route['mark_categories'] = 'mark_categories/mark_categories';
$route['view_mark_categories'] = 'mark_categories/view_mark_categories';
$route['add_mark_categories'] = 'mark_categories/add_mark_categories';
$route['edit_mark_categories'] = 'mark_categories/edit_mark_categories';
$route['delete_mark_categories'] = 'mark_categories/delete_mark_categories';
$route['restore_mark_categories'] = 'mark_categories/restore_mark_categories';
$route['set_status_mark_categories'] = 'mark_categories/set_status_mark_categories';
$route['set_default_mark_categories'] = 'mark_categories/set_default_mark_categories';
$route['import_mark_categories'] = 'mark_categories/import_mark_categories';

/** Marks **/
$route['marks'] = 'marks/marks';
$route['view_marks'] = 'marks/view_marks';
$route['add_marks'] = 'marks/add_marks';
$route['edit_marks'] = 'marks/edit_marks';
$route['delete_marks'] = 'marks/delete_marks';
$route['restore_marks'] = 'marks/restore_marks';
$route['set_status_marks'] = 'marks/set_status_marks';
$route['import_marks'] = 'marks/import_marks';

/** Personnel Functions **/
$route['personnel_functions'] = 'personnel_functions/personnel_functions';
$route['view_personnel_functions'] = 'personnel_functions/view_personnel_functions';
$route['add_personnel_functions'] = 'personnel_functions/add_personnel_functions';
$route['edit_personnel_functions'] = 'personnel_functions/edit_personnel_functions';
$route['delete_personnel_functions'] = 'personnel_functions/delete_personnel_functions';
$route['restore_personnel_functions'] = 'personnel_functions/restore_personnel_functions';
$route['set_status_personnel_functions'] = 'personnel_functions/set_status_personnel_functions';
$route['set_standard_personnel_functions'] = 'personnel_functions/set_standard_personnel_functions';
$route['import_personnel_functions'] = 'personnel_functions/import_personnel_functions';

/** Rooms **/
$route['rooms'] = 'rooms/rooms';
$route['view_rooms'] = 'rooms/view_rooms';
$route['add_rooms'] = 'rooms/add_rooms';
$route['edit_rooms'] = 'rooms/edit_rooms';
$route['delete_rooms'] = 'rooms/delete_rooms';
$route['restore_rooms'] = 'rooms/restore_rooms';
$route['set_status_rooms'] = 'rooms/set_status_rooms';
$route['import_rooms'] = 'rooms/import_rooms';
$route['get_room_functions'] = 'rooms/get_room_functions';

/** Terms **/
$route['terms'] = 'terms/terms';
$route['view_terms'] = 'terms/view_terms';
$route['add_terms'] = 'terms/add_terms';
$route['edit_terms'] = 'terms/edit_terms';
$route['delete_terms'] = 'terms/delete_terms';
$route['restore_terms'] = 'terms/restore_terms';
$route['set_status_terms'] = 'terms/set_status_terms';
$route['import_terms'] = 'terms/import_terms';

/** school **/
$route['school'] = 'school/school';
$route['view_school'] = 'school/view_school';
$route['add_school'] = 'school/add_school';
$route['edit_school'] = 'school/edit_school';
$route['delete_school'] = 'school/delete_school';
$route['restore_school'] = 'school/restore_school';
$route['set_status_school'] = 'school/set_status_school';
$route['get_countries'] = 'school/get_countries';

/** school data **/
$route['school_data'] = 'school/school_data';

/** Users **/
$route['users'] = 'users/users';
$route['view_users'] = 'users/view_users';
$route['add_users'] = 'users/add_users';
$route['edit_users'] = 'users/edit_users';
$route['delete_users'] = 'users/delete_users';
$route['restore_users'] = 'users/restore_users';
$route['set_status_users'] = 'users/set_status_users';
$route['import_users'] = 'users/import_users';
$route['get_personnel_functions'] = 'users/get_personnel_functions';
$route['get_gender'] = 'users/get_gender';
$route['admin_reset_password'] = 'users/admin_reset_password';

/** parents **/
$route['parents'] = 'parents/parents';
$route['view_parents'] = 'parents/view_parents';
$route['add_parents'] = 'parents/add_parents';
$route['edit_parents'] = 'parents/edit_parents';
$route['delete_parents'] = 'parents/delete_parents';
$route['restore_parents'] = 'parents/restore_parents';
$route['set_status_parents'] = 'parents/set_status_parents';
$route['import_parents'] = 'parents/import_parents';

/** Courses **/
$route['courses'] = 'courses/courses';
$route['view_courses'] = 'courses/view_courses';
$route['add_courses'] = 'courses/add_courses';
$route['edit_courses'] = 'courses/edit_courses';
$route['delete_courses'] = 'courses/delete_courses';
$route['restore_courses'] = 'courses/restore_courses';
$route['set_status_courses'] = 'courses/set_status_courses';
$route['set_individual_courses'] = 'courses/set_individual_courses';
$route['import_courses'] = 'courses/import_courses';
$route['get_teachers'] = 'courses/get_teachers';

/** students **/
$route['students'] = 'students/students';
$route['view_students'] = 'students/view_students';
$route['view_student_assignments'] = 'students/view_student_assignments';
$route['add_students'] = 'students/add_students';
$route['edit_students'] = 'students/edit_students';
$route['delete_students'] = 'students/delete_students';
$route['restore_students'] = 'students/restore_students';
$route['set_status_students'] = 'students/set_status_students';
$route['set_resigned_students'] = 'students/set_resigned_students';
$route['import_students'] = 'students/import_students';
$route['get_grades'] = 'students/get_grades';
$route['get_study_level'] = 'students/get_study_level';
$route['get_professions'] = 'students/get_professions';
$route['get_career_goals'] = 'students/get_career_goals';
$route['get_parents'] = 'students/get_parents';
$route['get_terms'] = 'students/get_terms';
$route['get_parent_info'] = 'students/get_parent_info';

/** students terms **/
$route['students_terms'] = 'students_terms/students_terms';
$route['view_students_terms'] = 'students_terms/view_students_terms';
$route['add_students_terms'] = 'students_terms/add_students_terms';
$route['edit_students_terms'] = 'students_terms/edit_students_terms';
$route['delete_students_terms'] = 'students_terms/delete_students_terms';
$route['import_students_terms'] = 'students_terms/import_students_terms';
$route['get_students'] = 'students_terms/get_students';
$route['get_active_terms'] = 'students_terms/get_active_terms';
$route['view_all_students_terms'] = 'students_terms/view_all_students_terms';
$route['view_selected_students_terms'] = 'students_terms/view_selected_students_terms';
$route['view_final_students_terms'] = 'students_terms/view_final_students_terms';
$route['duplicate_student_terms'] = 'students_terms/duplicate_student_terms';

/** Students Courses **/
$route['students_courses'] = 'students_courses/students_courses';
$route['view_students_courses'] = 'students_courses/view_students_courses';
$route['add_students_courses'] = 'students_courses/add_students_courses';
$route['edit_students_courses'] = 'students_courses/edit_students_courses';
$route['delete_students_courses'] = 'students_courses/delete_students_courses';
$route['import_students_courses'] = 'students_courses/import_students_courses';
$route['view_all_students_courses'] = 'students_courses/view_all_students_courses';
$route['view_selected_students_courses'] = 'students_courses/view_selected_students_courses';
$route['view_all_courses'] = 'students_courses/view_all_courses';
$route['view_all_selected_courses'] = 'students_courses/view_all_selected_courses';
$route['view_final_students_courses'] = 'students_courses/view_final_students_courses';
$route['get_courses'] = 'students_courses/get_courses';
$route['get_student_course_status'] = 'students_courses/get_student_course_status';
$route['duplicate_student_courses'] = 'students_courses/duplicate_student_courses';

/** timetable **/
$route['timetable'] = 'timetable/timetable';
$route['get_weekdays'] = 'timetable/get_weekdays';
$route['view_daily_timetable'] = 'timetable/view_daily_timetable';
$route['view_weekly_timetable'] = 'timetable/view_weekly_timetable';
$route['add_timetable'] = 'timetable/add_timetable';
$route['edit_timetable'] = 'timetable/edit_timetable';
$route['delete_timetable'] = 'timetable/delete_timetable';
$route['clear_timetable'] = 'timetable/clear_timetable';
$route['duplicate_timetable'] = 'timetable/duplicate_timetable';
$route['import_timetable'] = 'timetable/import_timetable';

/** timetable_weekly **/
$route['timetable_weekly'] = 'timetable_weekly/timetable_weekly';
$route['get_weekly_timetable'] = 'timetable_weekly/get_weekly_timetable';
$route['get_student_teacher'] = 'timetable_weekly/get_student_teacher';

/** absences **/
$route['absences'] = 'absences/absences';
$route['view_absences'] = 'absences/view_absences';
$route['add_absences'] = 'absences/add_absences';
$route['edit_absences'] = 'absences/edit_absences';
$route['delete_absences'] = 'absences/delete_absences';
$route['restore_absences'] = 'absences/restore_absences';
$route['excuse_absences'] = 'absences/excuse_absences';
$route['import_absences'] = 'absences/import_absences';
$route['get_absences_type'] = 'absences/get_absences_type';
$route['get_reported_by'] = 'absences/get_reported_by';
$route['get_students_for_search'] = 'absences/get_students_for_search';
$route['view_students_for_absences'] = 'absences/view_students_for_absences';


/** disciplinary **/
$route['disciplinary'] = 'disciplinary/disciplinary';
$route['view_disciplinary'] = 'disciplinary/view_disciplinary';
$route['add_disciplinary'] = 'disciplinary/add_disciplinary';
$route['edit_disciplinary'] = 'disciplinary/edit_disciplinary';
$route['delete_disciplinary'] = 'disciplinary/delete_disciplinary';
$route['restore_disciplinary'] = 'disciplinary/restore_disciplinary';
$route['excuse_disciplinary'] = 'disciplinary/excuse_disciplinary';
$route['import_disciplinary'] = 'disciplinary/import_disciplinary';
$route['get_disciplinary_type'] = 'disciplinary/get_disciplinary_type';

/** coaching **/
$route['coaching'] = 'coaching/coaching';
$route['view_coaching'] = 'coaching/view_coaching';
$route['add_coaching'] = 'coaching/add_coaching';
$route['edit_coaching'] = 'coaching/edit_coaching';
$route['delete_coaching'] = 'coaching/delete_coaching';
$route['restore_coaching'] = 'coaching/restore_coaching';
$route['excuse_coaching'] = 'coaching/excuse_coaching';
$route['import_coaching'] = 'coaching/import_coaching';
$route['get_coaching_type'] = 'coaching/get_coaching_type';
$route['view_students_for_coaching'] = 'coaching/view_students_for_coaching';
$route['get_student_details'] = 'coaching/get_student_details';
$route['get_student_marks'] = 'coaching/get_student_marks';
$route['get_student_disciplinary'] = 'coaching/get_student_disciplinary';
$route['get_student_absences'] = 'coaching/get_student_absences';
$route['get_student_marks_data'] = 'coaching/get_student_marks_data';
$route['get_max_mark'] = 'coaching/get_max_mark';

/** file_manager **/
$route['file_manager'] = 'file_manager/file_manager';
$route['view_file_manager'] = 'file_manager/view_file_manager';
$route['add_files'] = 'file_manager/add_files';
$route['delete_files'] = 'file_manager/delete_files';
$route['rename_files'] = 'file_manager/rename_files';
$route['move_to_folder_files'] = 'file_manager/move_to_folder_files';
$route['download_file/(:any)'] = 'file_manager/download_file/$1';
$route['edit_file_manager'] = 'file_manager/edit_file_manager';
$route['get_folder_tree'] = 'file_manager/get_folder_tree';
$route['view_files'] = 'file_manager/view_files';
$route['view_folders'] = 'file_manager/view_folders';
$route['add_new_folder'] = 'file_manager/add_new_folder';
$route['delete_folder'] = 'file_manager/delete_folder';
$route['move_to_folder'] = 'file_manager/move_to_folder';
$route['copy_to_folder'] = 'file_manager/copy_to_folder';
$route['rename_folder'] = 'file_manager/rename_folder';
$route['get_folder_tree/(:any)'] = 'file_manager/get_folder_tree/$1';

/** dossiers **/
$route['dossiers'] = 'dossiers/dossiers';
$route['view_dossiers'] = 'dossiers/view_dossiers';
$route['add_dossiers'] = 'dossiers/add_dossiers';
$route['edit_dossiers'] = 'dossiers/edit_dossiers';
$route['duplicate_dossiers'] = 'dossiers/duplicate_dossiers';
$route['send_task_dossiers'] = 'dossiers/send_task_dossiers';
$route['delete_dossiers'] = 'dossiers/delete_dossiers';
$route['restore_dossiers'] = 'dossiers/restore_dossiers';
$route['excuse_dossiers'] = 'dossiers/excuse_dossiers';
$route['import_dossiers'] = 'dossiers/import_dossiers';
$route['get_dossiers_type'] = 'dossiers/get_dossiers_type';
$route['get_dossiers_type_global'] = 'dossiers/get_dossiers_type_global';
$route['get_curriculum_items'] = 'dossiers/get_curriculum_items';
$route['get_school_data'] = 'dossiers/get_school_data';
$route['download_doc/(:any)'] = 'dossiers/download_doc/$1';
$route['download_messages_doc/(:any)'] = 'dossiers/download_messages_doc/$1';
$route['dossier_preview/(:any)'] = 'dossiers/dossier_preview/$1';
$route['get_dossier_preview_by_id'] = 'dossiers/get_dossier_preview_by_id';
$route['dossier_pdfeditor/(:any)'] = 'dossiers/dossier_pdfeditor/$1';
$route['dossier_pdftron/(:any)'] = 'dossiers/dossier_pdftron/$1';
$route['save_pdf_file'] = 'file_manager/save_pdf_file';

/** course_attendants_marks **/
$route['course_attendants_marks'] = 'course_attendants_marks/course_attendants_marks';
$route['view_course_attendants_marks'] = 'course_attendants_marks/view_course_attendants_marks';
$route['view_students_for_course_attendants_marks'] = 'course_attendants_marks/view_students_for_course_attendants_marks';
$route['view_student_marks'] = 'course_attendants_marks/view_student_marks';
$route['view_general_marks'] = 'course_attendants_marks/view_general_marks';
$route['add_course_attendants_marks'] = 'course_attendants_marks/add_course_attendants_marks';
$route['add_student_attendants_marks'] = 'course_attendants_marks/add_student_attendants_marks';
$route['edit_course_attendants_marks'] = 'course_attendants_marks/edit_course_attendants_marks';
$route['delete_course_attendants_marks'] = 'course_attendants_marks/delete_course_attendants_marks';
$route['restore_course_attendants_marks'] = 'course_attendants_marks/restore_course_attendants_marks';
$route['excuse_course_attendants_marks'] = 'course_attendants_marks/excuse_course_attendants_marks';
$route['import_course_attendants_marks'] = 'course_attendants_marks/import_course_attendants_marks';
$route['get_mark_points'] = 'course_attendants_marks/get_mark_points';
$route['get_mark_categories'] = 'course_attendants_marks/get_mark_categories';
$route['get_dossiers'] = 'course_attendants_marks/get_dossiers';
$route['get_course_attendants_marks'] = 'course_attendants_marks/get_course_attendants_marks';


/** Timeline **/
$route['timeline'] = 'timeline/timeline';
$route['view_timeline'] = 'timeline/view_timeline';
$route['add_timeline_absence'] = 'timeline/add_timeline_absence';
$route['add_timeline_disciplinary'] = 'timeline/add_timeline_disciplinary';
$route['add_timeline_marks'] = 'timeline/add_timeline_marks';
$route['view_timeline_student_details'] = 'timeline/view_timeline_student_details';
$route['view_timeline_student_files'] = 'timeline/view_timeline_student_files';
$route['view_timeline_teacher_details'] = 'timeline/view_timeline_teacher_details';
$route['view_timeline_student_file_details'] = 'timeline/view_timeline_student_file_details';
$route['add_timeline_teacher_uploads'] = 'timeline/add_timeline_teacher_uploads';
$route['add_timeline_student_uploads'] = 'timeline/add_timeline_student_uploads';
$route['update_course_upload_settings'] = 'timeline/update_course_upload_settings';
$route['update_course_uploads'] = 'timeline/update_course_uploads';
$route['delete_course_uploads'] = 'timeline/delete_course_uploads';
$route['get_dossier_by_id'] = 'timeline/get_dossier_by_id';
$route['update_student_course_uploads'] = 'timeline/update_student_course_uploads';
$route['get_upload_count'] = 'timeline/get_upload_count';
$route['get_students_for_timeline'] = 'timeline/get_students_for_timeline';

/** team_meetings **/
$route['team_meetings'] = 'team_meetings/team_meetings';
$route['view_team_meetings'] = 'team_meetings/view_team_meetings';
$route['add_team_meetings'] = 'team_meetings/add_team_meetings';
$route['add_team_notifications'] = 'team_meetings/add_team_notifications';
$route['delete_team_meetings'] = 'team_meetings/delete_team_meetings';
$route['restore_team_meetings'] = 'team_meetings/restore_team_meetings';
$route['get_personnel'] = 'team_meetings/get_personnel';
$route['get_meeting_categories'] = 'team_meetings/get_meeting_categories';

/** Notifications **/
$route['notifications'] = 'notifications/notifications';
$route['view_inbox_messages'] = 'notifications/view_inbox_messages';
$route['view_outbox_messages'] = 'notifications/view_outbox_messages';
$route['view_inbox_task'] = 'notifications/view_inbox_task';
$route['view_outbox_task'] = 'notifications/view_outbox_task';
$route['view_inbox_meetings'] = 'notifications/view_inbox_meetings';
$route['view_outbox_meetings'] = 'notifications/view_outbox_meetings';
$route['view_inbox_feedback'] = 'notifications/view_inbox_feedback';
$route['view_outbox_feedback'] = 'notifications/view_outbox_feedback';
$route['view_inbox_document'] = 'notifications/view_inbox_document';
$route['view_outbox_document'] = 'notifications/view_outbox_document';
$route['view_inbox_archive'] = 'notifications/view_inbox_archive';
$route['view_outbox_archive'] = 'notifications/view_outbox_archive';
$route['get_student_by_course'] = 'notifications/get_student_by_course';
$route['get_parent_by_course'] = 'notifications/get_parent_by_course';
$route['add_notifications'] = 'notifications/add_notifications';
$route['archive_notifications'] = 'notifications/archive_notifications';
$route['restore_notifications'] = 'notifications/restore_notifications';
$route['preview_notifications'] = 'notifications/preview_notifications';
$route['reply_notifications'] = 'notifications/reply_notifications';
$route['mark_as_unread_notifications'] = 'notifications/mark_as_unread_notifications';
$route['mark_as_read_notifications'] = 'notifications/mark_as_read_notifications';
$route['mark_as_read_or_unread_notifications'] = 'notifications/mark_as_read_or_unread_notifications';
$route['get_inbox_count'] = 'notifications/get_inbox_count';
$route['update_is_seen'] = 'notifications/update_is_seen';
$route['get_subjects_for_search'] = 'notifications/get_subjects_for_search';

/** email templates **/
$route['email_templates'] = 'email_templates/email_templates';
$route['view_email_templates'] = 'email_templates/view_email_templates';
$route['edit_email_templates'] = 'email_templates/edit_email_templates';
$route['get_languages'] = 'email_templates/get_languages';
$route['get_email_template_by_id'] = 'email_templates/get_email_template_by_id';
/** email settings **/
$route['email_settings'] = 'email_templates/email_settings';
$route['update_email_settings'] = 'email_templates/update_email_settings';

/** Language **/
$route['languages'] = 'languages/languages';
$route['view_languages'] = 'languages/view_languages';
$route['add_languages'] = 'languages/add_languages';
$route['edit_languages'] = 'languages/edit_languages';
$route['delete_languages'] = 'languages/delete_languages';
$route['restore_languages'] = 'languages/restore_languages';
$route['set_status_languages'] = 'languages/set_status_languages';

/** System Settings **/
$route['system_settings'] = 'system_settings/system_settings';
$route['view_system_settings'] = 'system_settings/view_system_settings';
$route['add_system_settings'] = 'system_settings/add_system_settings';
$route['edit_system_settings'] = 'system_settings/edit_system_settings';
$route['delete_system_settings'] = 'system_settings/delete_system_settings';
$route['restore_system_settings'] = 'system_settings/restore_system_settings';
$route['set_status_system_settings'] = 'system_settings/set_status_system_settings';

/** Bulk Labeling **/
$route['bulk_labeling'] = 'bulk_labeling/bulk_labeling';
$route['view_modules'] = 'bulk_labeling/view_modules';
$route['view_filter_section'] = 'bulk_labeling/view_filter_section';
$route['view_filter_sub_section'] = 'bulk_labeling/view_filter_sub_section';
$route['edit_bulk_labeling'] = 'bulk_labeling/edit_bulk_labeling';
$route['edit_modules'] = 'bulk_labeling/edit_modules';



/** ACL Groups **/
$route['acl_groups'] = 'acl_groups/acl_groups';
$route['view_acl_groups'] = 'acl_groups/view_acl_groups';
$route['edit_acl_groups'] = 'acl_groups/edit_acl_groups';
$route['get_roles'] = 'acl_groups/get_roles';

/** Change Password **/
$route['change_password'] = 'change_password/change_password';
$route['edit_password'] = 'change_password/edit_password';

/** Forgot Password **/
$route['forgot_password'] = 'home/forgot_password';
$route['send_forgot_password'] = 'home/send_forgot_password';

/** Reset Password **/
$route['reset_password/(:any)'] = 'home/reset_password/$1';
$route['update_password'] = 'change_password/update_password';
$route['update_new_password'] = 'change_password/update_new_password';

/** Labels **/
$route['labels'] = 'labels/labels';
$route['view_labels'] = 'labels/view_labels';
$route['add_labels'] = 'labels/add_labels';
$route['edit_labels'] = 'labels/edit_labels';
$route['set_status_labels'] = 'labels/set_status_labels';
$route['get_pages'] = 'labels/get_pages';
$route['get_sections'] = 'labels/get_sections';
$route['get_labels_language'] = 'labels/get_labels_language';

/** reports **/
$route['reports'] = 'reports/reports';
$route['get_presets'] = 'reports/get_presets';
$route['save_report'] = 'reports/save_report';
$route['filter_report'] = 'reports/filter_report';
$route['open_preset_report'] = 'reports/open_preset_report';
$route['delete_reports'] = 'reports/delete_reports';

/** Weekdays **/
$route['weekdays'] = 'weekdays/weekdays';
$route['view_weekdays'] = 'weekdays/view_weekdays';
$route['add_weekdays'] = 'weekdays/add_weekdays';
$route['edit_weekdays'] = 'weekdays/edit_weekdays';
$route['delete_weekdays'] = 'weekdays/delete_weekdays';
$route['restore_weekdays'] = 'weekdays/restore_weekdays';
$route['set_status_weekdays'] = 'weekdays/set_status_weekdays';
$route['import_weekdays'] = 'weekdays/import_weekdays';

/** Builds **/
$route['builds'] = 'builds/builds';
$route['view_builds'] = 'builds/view_builds';
$route['add_builds'] = 'builds/add_builds';
$route['edit_builds'] = 'builds/edit_builds';
$route['delete_builds'] = 'builds/delete_builds';

/** Builds Gogomo **/
$route['builds_gogomo'] = 'builds_gogomo/builds_gogomo';
$route['view_builds_gogomo'] = 'builds_gogomo/view_builds_gogomo';
$route['release_builds_gogomo'] = 'builds_gogomo/release_builds_gogomo';

/** Builds PS **/
$route['builds_ps'] = 'builds_ps/builds_ps';
$route['view_builds_ps'] = 'builds_ps/view_builds_ps';
$route['deploy_builds_ps'] = 'builds_ps/deploy_builds_ps';
$route['deploy_live_builds_ps'] = 'builds_ps/deploy_live_builds_ps';

/** Builds Box **/
$route['builds_box'] = 'builds_box/builds_box';
$route['view_builds_box'] = 'builds_box/view_builds_box';
$route['download_builds_box'] = 'builds_box/download_builds_box';
$route['download_zip/(:any)'] = 'builds_box/download_zip/$1';

/** Box **/
$route['box'] = 'box/box';
$route['view_box'] = 'box/view_box';
$route['upload_build'] = 'box/upload_build';
$route['repair_builds'] = 'box/repair_builds';

/** task **/
$route['view_tasks'] = 'tasks/view_tasks';
$route['add_tasks'] = 'tasks/add_tasks';
$route['change_tasks_status'] = 'tasks/change_tasks_status';
$route['get_task_categories'] = 'tasks/get_task_categories';
$route['view_students_task'] = 'tasks/view_students_task';
$route['check_task_user'] = 'tasks/check_task_user';
$route['set_task_rating'] = 'tasks/set_task_rating';
$route['set_task_comment'] = 'tasks/set_task_comment';
$route['set_annotations'] = 'tasks/set_annotations';
$route['get_annotations'] = 'tasks/get_annotations';
$route['check_task_dates'] = 'tasks/check_task_dates';
$route['get_view_annotations'] = 'tasks/get_view_annotations';
$route['view_task_logs'] = 'tasks/view_task_logs';
$route['check_annotation'] = 'tasks/check_annotation';