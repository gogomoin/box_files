<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Career_goals extends MY_Controller
{
    
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function career_goals() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
			$this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['role_details'] = $this->get_role_details();
            $this->data['pgn_details'] = $pgn_details;
			$this->data['page_layout'] = $page_layout;
			$this->get_include();
            $this->load->view($this->view_dir . 'career_goals', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
    
	function view_career_goals() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['standard_fld']))
			$standard_fld = $_POST['standard_fld'];
		else
			$standard_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = $this->get_service_api().'view_career_goals';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'standard_fld'=>$standard_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_career_goals(){
        
		$cUrl = $this->get_service_api().'add_career_goals';
        $name = trim($this->input->post('name'));
        $status = $this->input->post('status');
        $user_det = $this->session->userdata('user_det');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $standard = $this->input->post('standard');
        if(isset($standard))
            $standard=1;
        else
            $standard=0;
        $post_data = array(
            'name'=>$name,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'standard'=>$standard
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_career_goals(){
        
		$cUrl = $this->get_service_api().'edit_career_goals';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $status = $this->input->post('status');
        $user_det = $this->session->userdata('user_det');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $standard = $this->input->post('standard');
        if(isset($standard))
            $standard=1;
        else
            $standard=0;
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'standard'=>$standard
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_career_goals(){
        
		$cUrl = $this->get_service_api().'delete_career_goals';
        $ids = $this->input->post('ids');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'ids'=>$ids,
            'lang_id'=>$user_det['lang_id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_career_goals(){
        
		$cUrl = $this->get_service_api().'restore_career_goals';
        $ids = $this->input->post('ids');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_career_goals(){
        
		$cUrl = $this->get_service_api().'set_status_career_goals';
        $ids = $this->input->post('ids');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_standard_career_goals(){
        
		$cUrl = $this->get_service_api().'set_standard_career_goals';
        $ids = $this->input->post('ids');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_career_goals(){
		
		$cUrl = $this->get_service_api().'import_career_goals';
        $user_det = $this->session->userdata('user_det');
        $label_details = $this->get_labels();
		$path = $_FILES["import_career_goals_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
        $sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";$col3="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if(isset($sheet_data[0][0][2]))
            $col3=$sheet_data[0][0][2];
        else
            $col3="";
        if($col1==""&&$col2==""&&$col3=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[167]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        /* if(isset($excel->sheets[0]['cells'][1][1]))
            $col1=trim($excel->sheets[0]['cells'][1][1]);
        if(isset($excel->sheets[0]['cells'][1][2]))
            $col2=trim($excel->sheets[0]['cells'][1][2]);
        if(isset($excel->sheets[0]['cells'][1][3]))
            $col3=trim($excel->sheets[0]['cells'][1][3]); */
        $lbl1=$label_details[157]['name']." *";
        if($col1!=$lbl1||$col2!=$label_details[158]['name']||$col3!=$label_details[159]['name'])
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[168]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
        foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                if(isset($sheets[$i][1]))
                    $status=trim($sheets[$i][1]);
                else
                    $status="";
                if(isset($sheets[$i][2]))
                    $standard=trim($sheets[$i][2]);
                else
                    $standard="";
                if($name!=""||$standard!=""||$status!="")
                {
                    $lang_id=$user_det['lang_id'];
                    $status_text="active";$standard_text="active";
                    if($lang_id!=1)
                    {
                        $cond="select label_id from labels where lang_id=1 and name='Active' limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lb_details)>0)
                        {
                            $cond="select name from labels where lang_id=".$lang_id." and label_id=".$lb_details[0]['label_id']." limit 1";
                            $lb_details = $this->users_model->special_fetch($cond);
                            if(count($lb_details)>0)
                                $status_text=$lb_details[0]['name'];
                            else
                                $status_text="";
                        }
                        $cond="select label_id from labels where lang_id=1 and name='Yes' limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lb_details)>0)
                        {
                            $cond="select name from labels where lang_id=".$lang_id." and label_id=".$lb_details[0]['label_id']." limit 1";
                            $lb_details = $this->users_model->special_fetch($cond);
                            if(count($lb_details)>0)
                                $standard_text=$lb_details[0]['name'];
                            else
                                $standard_text="";
                        }
                    }
                    if(strtolower($status)==strtolower($status_text))
                        $status_val=1;
                    else
                        $status_val=0;
                    if(strtolower($standard)==strtolower($standard_text))
                        $standard_val=1;
                    else
                        $standard_val=0;
                    $page_details[]=array(
                        "name"=>$name,
                        "status"=>$status,
                        "status_val"=>$status_val,
                        "standard"=>$standard,
                        "standard_val"=>$standard_val                    
                    );
                }
			}			
		}
        /* foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				if(isset($sheet['cells'][$r][1]))
                    $name=trim($sheet['cells'][$r][1]);
                else
                    $name="";
                if(isset($sheet['cells'][$r][2]))
                    $status=trim($sheet['cells'][$r][2]);
                else
                    $status="";                
                if(isset($sheet['cells'][$r][3]))
                    $standard=trim($sheet['cells'][$r][3]);
                else
                    $standard="";
                if($name!=""||$standard!=""||$status!="")
                {
                    if($status=="Active")
                    $status_val=1;
                    else
                    $status_val=0;
                    if($standard=="Yes")
                        $standard_val=1;
                    else
                        $standard_val=0;
                    $page_details[]=array(
                        "name"=>$name,
                        "status"=>$status,
                        "status_val"=>$status_val,
                        "standard"=>$standard,
                        "standard_val"=>$standard_val                    
                    );
                }
                else 
                    break;
			} 
		}*/
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[167]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}	
}
