<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Change_password extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function change_password() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $this->data['label_details'] = $label_details;
            $this->get_include();
            $this->load->view($this->view_dir . 'change_password', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function edit_password(){
        $cUrl = $this->get_service_api().'edit_password';
        $current_password = $this->input->post('current_password');
		$new_password = $this->input->post('new_password');
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$user_det['id'],
            'lang_id'=>$user_det['lang_id'],
            'current_password'=>$current_password,
			'new_password'=>$new_password
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function decrypt($sData){
		$url_id=base64_decode($sData);
		$id=(double)$url_id/118479.24;
		return $id;
	}
    function update_password(){
        
        $token_id = $this->input->post('token_id');
        $user_id=$this->decrypt($token_id);
        $cond="select password_requested_at from users where id=".$user_id;
        $usr_details = $this->users_model->special_fetch($cond);
        if(count($usr_details)>0)
        {
            if($usr_details[0]['password_requested_at']=='')
            {
                $this->load->view($this->view_dir . 'reset_link_expiry', $this->data);
            }
            else
            {
                $new_password = $this->input->post('new_password');
                $new_pwd=md5($new_password);
                $input = array(
                    'password'=>$new_pwd,
                    'salt'=>$new_password,
                    'password_requested_at'=>''
                );
                $this->users_model->edit($input,$user_id);
                $this->data['username'] = '';
                $this->data['error_message'] = 'Password Reset Successfully';
                $this->load->view($this->view_dir . 'login', $this->data);
            }
        }
        else
        {
            $this->data['username'] = '';
            $this->data['error_message'] = 'Invalid User';
            $this->load->view($this->view_dir . 'forgot_password', $this->data);
        }
    }
    function update_new_password(){

        $email = $this->input->post('email');
        $cur_password = $this->input->post('cur_password');
        $cur_pwd=md5($cur_password);
        $cond="select id from users where username='".$email."' and password='".$cur_pwd."'";
        $usr_details = $this->users_model->special_fetch($cond);
        if(count($usr_details)>0)
        {
            $new_password = $this->input->post('new_password');
            $new_pwd=md5($new_password);
            $input = array(
                'password'=>$new_pwd,
                'salt'=>$new_password,
                'last_login'=>time()
            );
            $this->users_model->edit($input,$usr_details[0]['id']);
            $this->data['username'] = '';
            $this->data['error_message'] = 'Password Reset Successfully';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
        else
        {
            $this->data['username'] = '';
            $this->data['error_message'] = 'Invalid Current Password';
            $this->load->view($this->view_dir . 'reset_new_password', $this->data);
        }
    }
}
