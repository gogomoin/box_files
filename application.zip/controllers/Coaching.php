<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Coaching extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function coaching() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'coaching', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_coaching() 
	{
        $draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
		if(isset($_POST['tutor_fld']))
			$tutor_fld = $_POST['tutor_fld'];
		else
			$tutor_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";	
        if(isset($_POST['deadline_fld']))
			$deadline_fld = $_POST['deadline_fld'];
		else
			$deadline_fld ="";
        if(isset($_POST['coaching_date_fld']))
			$coaching_date_fld = $_POST['coaching_date_fld'];
		else
			$coaching_date_fld ="";
        if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
        if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        $cUrl = $this->get_service_api().'view_coaching';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld'=>$term_fld,
			'tutor_fld'=>$tutor_fld,
            'student_fld'=>$student_fld,
            'deadline_fld'=>$deadline_fld,
            'coaching_date_fld'=>$coaching_date_fld,
            'status_fld'=>$status_fld,
            'del_fld'=>$del_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
          
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function get_student_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'get_student_disciplinary';
        $draw = $_POST['draw'];
        $student_id = $_POST['student_id'];
        $post_data = array(
            'student_id'=>$student_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $result['totalRecord'],
            "iTotalDisplayRecords" => $result['totalRecordwithFilter'],
            "aaData" => $result['page_details']
        );
        echo json_encode($response);                
    } 
    function get_student_absences(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'get_student_absences';
        $draw = $_POST['draw'];
		$student_id = $_POST['student_id'];
        $post_data = array(
        	'student_id'=>$student_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $result['totalRecord'],
            "iTotalDisplayRecords" => $result['totalRecordwithFilter'],
            "aaData" => $result['page_details']
        );
        echo json_encode($response);                
    }
    function get_student_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'get_student_marks';
        $draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $student_id = $_POST['student_id'];
        $term_id = $_POST['term_id'];
        $post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'student_id'=>$student_id,
			'term_id'=>$term_id,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
        $response = array(
            "draw" => intval($draw),
            "iTotalRecords" => $result['totalRecord'],
            "iTotalDisplayRecords" => $result['totalRecordwithFilter'],
            "aaData" => $result['page_details']
        );
        echo json_encode($response);                
    } 
    function view_students_for_coaching() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld_list']))
			$term_fld_list = $_POST['term_fld_list'];
		else
			$term_fld_list ="";
		if(isset($_POST['status_fld_list']))
			$status_fld_list = $_POST['status_fld_list'];
		else
			$status_fld_list ="";
        if(isset($_POST['student_fld_list']))
			$student_fld_list = $_POST['student_fld_list'];
		else
			$student_fld_list ="";
        $cUrl = $this->get_service_api().'view_students_for_coaching';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld_list'=>$term_fld_list,
			'status_fld_list'=>$status_fld_list,
            'student_fld_list'=>$student_fld_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        //var_dump($json);die();
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
       
	function add_coaching(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_coaching';
        $term_id = $this->input->post('term_fld');
        $student_id = $this->input->post('student_id');
        $coaching_category_id = $this->input->post('coaching_category_id');
        $deadline_date = $this->input->post('deadline_date');
        $coaching_date = $this->input->post('coaching_date');
        $student_agenda = $this->input->post('student_agenda');
        $personnel_agenda = $this->input->post('personnel_agenda');
        $protocol = $this->input->post('protocol');
        $arrangement = $this->input->post('arrangement');
        $is_fulfilled = $this->input->post('is_fulfilled');
        $status = $this->input->post('status');
        if(isset($is_fulfilled))
            $is_fulfilled=1;
        else
            $is_fulfilled=0;
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'term_id'=>$term_id,
            'student_id'=>$student_id,
            'coaching_category_id'=>$coaching_category_id,
			'deadline_date'=>$deadline_date,
			'coaching_date'=>$coaching_date,
			'student_agenda'=>$student_agenda,
			'personnel_agenda'=>$personnel_agenda,
			'protocol'=>$protocol,
			'arrangement'=>$arrangement,
			'is_fulfilled'=>$is_fulfilled,
            'lang_id'=>$user_det['lang_id'],
			'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_coaching(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_coaching';
        $id = $this->input->post('token_id');    
        $term_id = $this->input->post('term_fld');
        $student_id = $this->input->post('student_id');
        $coaching_category_id = $this->input->post('coaching_category_id');
        $deadline_date = $this->input->post('deadline_date');
        $coaching_date = $this->input->post('coaching_date');
        $student_agenda = $this->input->post('student_agenda');
        $personnel_agenda = $this->input->post('personnel_agenda');
        $protocol = $this->input->post('protocol');
        $arrangement = $this->input->post('arrangement');
        $is_fulfilled = $this->input->post('is_fulfilled');
        $status = $this->input->post('status');
        if(isset($is_fulfilled))
            $is_fulfilled=1;
        else
            $is_fulfilled=0;
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
            'term_id'=>$term_id,
            'student_id'=>$student_id,
            'coaching_category_id'=>$coaching_category_id,
			'deadline_date'=>$deadline_date,
			'coaching_date'=>$coaching_date,
			'student_agenda'=>$student_agenda,
			'personnel_agenda'=>$personnel_agenda,
			'protocol'=>$protocol,
			'arrangement'=>$arrangement,
			'is_fulfilled'=>$is_fulfilled,
            'lang_id'=>$user_det['lang_id'],
			'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_coaching(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_coaching';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    function restore_coaching(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_coaching';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }  
    
    
    function get_student_details(){
        
		$cUrl = $this->get_service_api().'get_student_details';
        $id = $this->input->post('id');
		$post_data = array(
            'id'=>$id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    function get_coaching_type(){        
		$cUrl = $this->get_service_api().'get_coaching_type';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_max_mark(){        
		$cUrl = $this->get_service_api().'get_max_mark';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    
    function get_student_marks_data(){
        
		$cUrl = $this->get_service_api().'get_student_marks_data';
        $id = $this->input->post('id');
        $subject_id = $this->input->post('subject_id');
        $student_term_id = $this->input->post('student_term_id');
		$post_data = array(
            'id'=>$id,
            'subject_id'=>$subject_id,
            'student_term_id'=>$student_term_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    
    function import_coaching(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_coaching';
        $label_details = $this->get_labels();
		$path = $_FILES["import_coaching_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";$col3="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if(isset($sheet_data[0][0][2]))
            $col3=$sheet_data[0][0][2];
        else
            $col3="";
        if($col1==""&&$col2==""&&$col3=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[161]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $stu_name=$label_details[236]['name']." *";
        $co_cat=$label_details[237]['name']." *";
        $co_date=$label_details[238]['name']." *";
        if($col1!=$stu_name||$col2!=$co_cat||$col3!=$co_date)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[160]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{   
                $student_id="";             
                if(isset($sheets[$i][0]))
                {
                    $student_name=trim($sheets[$i][0]);
                    if($student_name!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $student=$users['first_name']." ".$users['last_name'];
                            if($student==$student_name)
                            {
                                $student_id=$users['id'];
                                break;
                            }
                            else
                                $student_id="";
                        }                        
                    }                   
                }
                else
                    $student_name="";
                $coaching_category_id="";
                if(isset($sheets[$i][1]))
                {
                    $coaching_category=trim($sheets[$i][1]);
                    if($coaching_category!="")
                    {
                        $cond="select id from coaching_categories where name='".$coaching_category."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $coaching_category_id=$cu_details[0]['id'];
                        else
                            $coaching_category_id="";
                    }                    
                }
                else
                    $coaching_category="";
                if(isset($sheets[$i][2]))
                {
                    $coaching_date=trim($sheets[$i][2]);
                    $coaching_date=str_replace("/","-",$coaching_date);
                }
                else
                    $coaching_date="";
                if(isset($sheets[$i][3]))
                {
                    $deadline_date=trim($sheets[$i][3]);
                    $deadline_date=str_replace("/","-",$deadline_date);
                }
                else
                    $deadline_date="";
                if(isset($sheets[$i][4]))
                {
                    $student_agenda=trim($sheets[$i][4]);
                }
                else
                    $student_agenda="";
                if(isset($sheets[$i][5]))
                {
                    $personnel_agenda=trim($sheets[$i][5]);
                }
                else
                    $personnel_agenda="";
                if(isset($sheets[$i][6]))
                {
                    $protocol=trim($sheets[$i][6]);
                }
                else
                    $protocol="";
                if(isset($sheets[$i][7]))
                {
                    $arrangement=trim($sheets[$i][7]);
                }
                else
                    $arrangement="";
                if(isset($sheets[$i][8]))
                {
                    $is_fulfilled=trim($sheets[$i][8]);
                }
                else
                    $is_fulfilled="";
                if(isset($sheets[$i][9]))
                {
                    $status=trim($sheets[$i][9]);
                }
                else
                    $status="";
                if($student_name!=""||$coaching_category!=""||$coaching_date!=""||$deadline_date!=""||$student_agenda!=""||$personnel_agenda!=""||$protocol!=""||$arrangement!=""||$is_fulfilled!=""||$status!="")
                {
                    if($is_fulfilled=="Yes")
                        $is_fulfilled_val=1;
                    else
                        $is_fulfilled_val=0;
                    if($status=="Active")
                        $status_val=1;
                    else
                        $status_val=0;
                    $page_details[]=array(
                        "student_name"=>$student_name,
                        "student_id"=>$student_id,
                        "coaching_category"=>$coaching_category,
                        "coaching_category_id"=>$coaching_category_id,
                        "deadline_date"=>$deadline_date,
                        "coaching_date"=>$coaching_date,
                        "student_agenda"=>$student_agenda,
                        "personnel_agenda"=>$personnel_agenda,
                        "protocol"=>$protocol,
                        "arrangement"=>$arrangement,
                        "is_fulfilled"=>$is_fulfilled,
                        "is_fulfilled_val"=>$is_fulfilled_val,
                        "status"=>$status,
                        "status_val"=>$status_val                 
                    );	
                }	
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[161]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
}
