<?php



if (!defined('BASEPATH'))



    exit('No direct script access allowed');







/**



 * Class For User Management.  



 */



class Compress_image extends MY_Controller

{

    function __construct() 

	{

        parent::__construct();

				

    }

	function index() 
	{
		echo "Helo";		
	}

	function upload_photo()
	{
       $uploads_dir = './assets/upload/avatar/'; 
        if ($_FILES["file"]["error"] == UPLOAD_ERR_OK) 
		{
			$tmp_name = $_FILES["file"]["tmp_name"];
			$name = time()."_".$_FILES["file"]["name"];
			$icon_name100 = time()."_icon100_".$_FILES["file"]["name"];
			$icon_name32 = time()."_icon32_".$_FILES["file"]["name"];
			$res = move_uploaded_file($tmp_name, "$uploads_dir/$name");			
            if($res)
			{
				$path='./assets/upload/avatar/'; 
				copy($path.$name,$path.$icon_name100);
				$this->resizeImage($icon_name100,100,100);
				copy($path.$name,$path.$icon_name32);
				$this->resizeImage($icon_name32,32,32);				
				echo json_encode(array('status' => '0','status_description' => "File Uploaded Successfully",'profile_image' => $name,'profile_image_thumbnail100' => $icon_name100,'profile_image_thumbnail32' => $icon_name32));	
			}				
            else
                echo json_encode(array('status_description' => "File Uploaded UnSuccessfully",'attachname' => $name));
		}
		else
		{
			echo json_encode(array('status' => '1','status_description' => "File Upload Failed","attachname"=>$_FILES["file"]["name"]));
		}
	}
	
	public function resizeImage($filename,$width,$height)
	{
		$source_path = './assets/upload/avatar/' . $filename;
		$target_path = './assets/upload/avatar/';
		$config_manip = array(
			  'image_library' => 'gd2',
			  'source_image' => $source_path,
			  'new_image' => $target_path,
			  'maintain_ratio' => FALSE,
			  'width' => $width,
			  'height' => $height,
		);
	    $this->load->library('image_lib', $config_manip);
		$this->image_lib->initialize($config_manip);
		if (!$this->image_lib->resize()) 
		{
			echo $this->image_lib->display_errors();
		}   
		$this->image_lib->clear();
	}
}