<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Course_attendants_marks extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function course_attendants_marks() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
			$page_details = $this->users_model->special_fetch($cond);
			$this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
            $cond="select s.value from system_settings s where s.key='mark-evaluation-type'";
			$settings_details = $this->users_model->special_fetch($cond);
            if(count($settings_details)>0)
                $this->data['number_system'] = $settings_details[0]['value'];
            else
                $this->data['number_system'] = 'number';
			$this->get_include();
            $this->load->view($this->view_dir . 'course_attendants_marks', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_course_attendants_marks() 
	{	
        if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
		if(isset($_POST['course_fld']))
			$course_fld = $_POST['course_fld'];
		else
			$course_fld ="";
        if(isset($_POST['evaluation_date_fld']))
			$evaluation_date_fld = $_POST['evaluation_date_fld'];
		else
			$evaluation_date_fld ="";
        if(isset($_POST['has_mark_fld']))
			$has_mark_fld = $_POST['has_mark_fld'];
		else
			$has_mark_fld ="";
        $cUrl = $this->get_service_api().'view_course_attendants_marks';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'term_fld'=>$term_fld,
			'course_fld'=>$course_fld,
            'evaluation_date_fld'=>$evaluation_date_fld,
            'has_mark_fld'=>$has_mark_fld
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
       
        //$result = json_decode($json, true);
        echo $json; 
	} 
    function view_students_for_course_attendants_marks() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['course_fld']))
			$course_fld = $_POST['course_fld'];
		else
			$course_fld ="";
		if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";
        if($student_fld=='dash')
            $student_fld ="";
        $cUrl = $this->get_service_api().'view_students_for_course_attendants_marks';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld'=>$term_fld,
			'course_fld'=>$course_fld,
            'student_fld'=>$student_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
            "aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_general_marks() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['course_fld']))
			$course_fld = $_POST['course_fld'];
		else
			$course_fld ="";
		if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";
        if(isset($_POST['evaluation_date_fld']))
			$evaluation_date_fld = $_POST['evaluation_date_fld'];
		else
			$evaluation_date_fld ="";
        if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if($student_fld=='dash')
            $student_fld ="";
        $cUrl = $this->get_service_api().'view_general_marks';
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'searchValue'=>$searchValue,
			'term_fld'=>$term_fld,
			'course_fld'=>$course_fld,
            'student_fld'=>$student_fld,
            'evaluation_date_fld'=>$evaluation_date_fld,
            'del_fld'=>$del_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
            "aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}    
	function add_course_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_course_attendants_marks';
        $term_id = $this->input->post('term_id');
        $course_id = $this->input->post('course_id');
        $mark_category_id = $this->input->post('mark_category_id');
        $remark = $this->input->post('remark');
        $evaluation_date = $this->input->post('evaluation_date');
        $dossier_id = $this->input->post('dossier_id');
        $mark_counts = $this->input->post('mark_counts');
        $total_students = $this->input->post('total_students');
        $marks_assignment = $this->input->post('marks_assignment');
        $min_mark = $this->input->post('min_mark');
        $max_mark = $this->input->post('max_mark');
        $medium_mark = $this->input->post('medium_mark');
        $min_points = $this->input->post('min_points');
        $max_points = $this->input->post('max_points');
        $medium_points = $this->input->post('medium_points');
        if($marks_assignment==1)
        {
            $mark_type="predefined";
            $mark_schema=array("min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==2)
        {
            $mark_type="max_points_custom_mark";
            $mark_schema=array("max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==3)
        {
            $mark_type="complex_points_custom_mark";
            $mark_schema=array("min_points"=>$min_points,"medium_points"=>$medium_points,"max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        if(isset($mark_counts))
            $mark_counts=1;
        else
            $mark_counts=0;
        $students=array();
        $marks=array();
        for($i=0;$i<$total_students;$i++)
        {
            $stu_id_val="student_id_".$i;
            $mark_id_val="mark_points_".$i;
            $mk_id=$this->input->post($mark_id_val);
            if($mk_id!="")
            {
                $students[]=$this->input->post($stu_id_val);
                $marks[]=$this->input->post($mark_id_val);
            }
        }
        if($dossier_id=="")
            $dossier_id=0;
        $post_data = array(
            'term_id'=>$term_id,
            'course_id'=>$course_id,
            'mark_category_id'=>$mark_category_id,
            'remark'=>$remark,
            'evaluation_date'=>$evaluation_date,
            'dossier_id'=>$dossier_id,
            'mark_schema'=>$mark_schema,
            'mark_type'=>$mark_type,
            'mark_counts'=>$mark_counts,
            'students'=>$students,
            'lang_id'=>$user_det['lang_id'],
            'marks'=>$marks
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function add_student_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_student_attendants_marks';
        $term_id = $this->input->post('term_id');
        $course_id = $this->input->post('course_id');
        $student_id = $this->input->post('student_course_attendant_id');
        $course_attendant_id = $this->input->post('student_attendant_id');
        $course_attendant_marks_id = $this->input->post('general_course_attendant_id');
        $mark_category_id = $this->input->post('mark_category_id');
        $remark = $this->input->post('remark');
        $evaluation_date = $this->input->post('evaluation_date');
        $dossier_id = $this->input->post('dossier_id');
        $mark_counts = $this->input->post('mark_counts');
        $marks_assignment = $this->input->post('student_marks_assignment');
        $min_mark = $this->input->post('min_mark');
        $max_mark = $this->input->post('max_mark');
        $medium_mark = $this->input->post('medium_mark');
        $min_points = $this->input->post('min_points');
        $max_points = $this->input->post('max_points');
        $medium_points = $this->input->post('medium_points');
        $cur_points = $this->input->post('mark_points');
        if($marks_assignment==1)
        {
            $mark_type="predefined";
            $mark_schema=array("min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==2)
        {
            $mark_type="max_points_custom_mark";
            $mark_schema=array("max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==3)
        {
            $mark_type="complex_points_custom_mark";
            $mark_schema=array("min_points"=>$min_points,"medium_points"=>$medium_points,"max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        if(isset($mark_counts))
            $mark_counts=1;
        else
            $mark_counts=0;
        if($dossier_id=="")
            $dossier_id=0;
        $post_data = array(
            'term_id'=>$term_id,
            'course_id'=>$course_id,
            'mark_category_id'=>$mark_category_id,
            'remark'=>$remark,
            'evaluation_date'=>$evaluation_date,
            'dossier_id'=>$dossier_id,
            'mark_schema'=>$mark_schema,
            'mark_type'=>$mark_type,
            'mark_counts'=>$mark_counts,
            'student_id'=>$student_id,
            'course_attendant_id'=>$course_attendant_id,
            'course_attendant_marks_id'=>$course_attendant_marks_id,
            'lang_id'=>$user_det['lang_id'],
            'marks'=>$cur_points
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_course_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_course_attendants_marks';
        $course_attendant_id = $this->input->post('student_course_attendant_id');
        $mark_category_id = $this->input->post('mark_category_id');
        $remark = $this->input->post('remark');
        $evaluation_date = $this->input->post('evaluation_date');
        $dossier_id = $this->input->post('dossier_id');
        if($dossier_id=="")
            $dossier_id=0;
        $mark_counts = $this->input->post('mark_counts');
        $marks_assignment = $this->input->post('student_marks_assignment_up');
        $min_mark = $this->input->post('min_mark');
        $max_mark = $this->input->post('max_mark');
        $medium_mark = $this->input->post('medium_mark');
        $min_points = $this->input->post('min_points');
        $max_points = $this->input->post('max_points');
        $medium_points = $this->input->post('medium_points');
        $cur_points = $this->input->post('mark_points');
        if($marks_assignment==1)
        {
            $mark_type="predefined";
            $mark_schema=array("min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==2)
        {
            $mark_type="max_points_custom_mark";
            $mark_schema=array("max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==3)
        {
            $mark_type="complex_points_custom_mark";
            $mark_schema=array("min_points"=>$min_points,"medium_points"=>$medium_points,"max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        if(isset($mark_counts))
            $mark_counts=1;
        else
            $mark_counts=0;
        $post_data = array(
            'mark_category_id'=>$mark_category_id,
            'remark'=>$remark,
            'evaluation_date'=>$evaluation_date,
            'dossier_id'=>$dossier_id,
            'mark_schema'=>$mark_schema,
            'mark_type'=>$mark_type,
            'mark_counts'=>$mark_counts,
            'course_attendant_id'=>$course_attendant_id,
            'lang_id'=>$user_det['lang_id'],
            'marks'=>$cur_points
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_course_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_course_attendants_marks';
        $id = $this->input->post('id');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'id'=>$id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    function restore_course_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_course_attendants_marks';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }  
    function excuse_course_attendants_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'excuse_course_attendants_marks';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }   
    function view_student_marks(){
        
		$cUrl = $this->get_service_api().'view_student_marks';
        $id = $this->input->post('id');
		$post_data = array(
            'id'=>$id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    
    function get_reported_by(){        
		$cUrl = $this->get_service_api().'get_reported_by';
        $reqhdrs = array('Accept: application/json');    
        $search_term = $this->input->post('searchTerm');
		$post_data = array(
            'search_term'=>$search_term
        );     
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_course_attendants_marks_type(){        
		$cUrl = $this->get_service_api().'get_course_attendants_marks_type';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_students_for_search(){        
        $cUrl = $this->get_service_api().'get_students_for_search';
        $reqhdrs = array('Accept: application/json');    
        $search_term = $this->input->post('searchTerm');
		$post_data = array(
            'search_term'=>$search_term
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_course_attendants_marks(){        
        $cUrl = $this->get_service_api().'get_course_attendants_marks';
        $reqhdrs = array('Accept: application/json');    
        $id = $this->input->post('id');
		$post_data = array(
            'id'=>$id
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_mark_points(){        
        $cUrl = $this->get_service_api().'get_mark_points';
        $reqhdrs = array('Accept: application/json');    
        $post_data = "";  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_mark_categories(){        
        $cUrl = $this->get_service_api().'get_mark_categories';
        $reqhdrs = array('Accept: application/json');    
        $post_data = "";  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_dossiers(){        
        $cUrl = $this->get_service_api().'get_dossiers';
        $reqhdrs = array('Accept: application/json');    
        $post_data = "";  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
