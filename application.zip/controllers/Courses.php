<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Courses extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//courses	
	
	function courses() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'courses', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){                       
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['individual_fld']))
			$individual_fld = $_POST['individual_fld'];
		else
			$individual_fld ="";
        if(isset($_POST['subject_fld']))
			$subject_fld = $_POST['subject_fld'];
		else
			$subject_fld ="";
        if(isset($_POST['teacher_fld']))
			$teacher_fld = $_POST['teacher_fld'];
		else
			$teacher_fld ="";
        if(isset($_POST['competence_level_fld']))
			$competence_level_fld = $_POST['competence_level_fld'];
		else
			$competence_level_fld ="";			
		$cUrl = $this->get_service_api().'view_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'individual_fld'=>$individual_fld,
			'subject_fld'=>$subject_fld,
            'teacher_fld'=>$teacher_fld,
			'competence_level_fld'=>$competence_level_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_courses';
        $name = trim($this->input->post('name'));
        $personnel_id  = $this->input->post('personnel_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $individual  = $this->input->post('individual');
        $subject_id  = $this->input->post('subject_id');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($individual))
            $individual=1;
        else
            $individual=0;
        $post_data = array(
            'name'=>$name,
            'personnel_id'=>$personnel_id,
            'competence_level_id'=>$competence_level_id,
            'subject_id'=>$subject_id,
            'individual'=>$individual,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_courses';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $personnel_id  = $this->input->post('personnel_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $individual  = $this->input->post('individual');
        $subject_id  = $this->input->post('subject_id');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($individual))
            $individual=1;
        else
            $individual=0;
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'personnel_id'=>$personnel_id,
            'competence_level_id'=>$competence_level_id,
            'subject_id'=>$subject_id,
            'individual'=>$individual,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_courses';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_courses';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_courses';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function set_individual_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_individual_courses';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
        
	function import_courses(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_courses';
        $label_details = $this->get_labels();
		$path = $_FILES["import_courses_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[97]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $name=$label_details[175]['name']." *";
        $subj=$label_details[176]['name']." *";
        if($col1!=$name||$col2!=$subj)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[96]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
        foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                $personnel_id="";
                if(isset($sheets[$i][2]))
                {
                    $personnel=trim($sheets[$i][2]);
                    if($personnel!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $personnel_name=$users['first_name']." ".$users['last_name'];
                            if($personnel_name==$personnel)
                            {
                                $personnel_id=$users['id'];
                                break;
                            }
                            else
                                $personnel_id="";
                        }                        
                    }                    
                }
                else
                    $personnel="";
                $subject_id="";
                if(isset($sheets[$i][1]))
                {
                    $subject=trim($sheets[$i][1]);
                    if($subject!="")
                    {
                        $cond="select id from subjects where name='".$subject."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $subject_id=$cu_details[0]['id'];
                        else
                            $subject_id="";
                    }                    
                }
                else
                    $subject="";  
                $competence_level_id="";    
                if(isset($sheets[$i][3]))
                {
                    $competence_level=trim($sheets[$i][3]);
                    if($competence_level!="")
                    {
                        $cond="select id from competence_levels where name='".$competence_level."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $competence_level_id=$cu_details[0]['id'];
                        else
                            $competence_level_id=0;
                    }                    
                }
                else
                    $competence_level="";    
                if(isset($sheets[$i][4]))
                    $individual=trim($sheets[$i][4]);
                else
                    $individual="";
                if(isset($sheets[$i][5]))
                    $status=trim($sheets[$i][5]);
                else
                    $status="";
                if($name!=""||$personnel!=""||$subject!=""||$competence_level!=""||$individual!=""||$status!="")
                {
                    if($individual=="Yes")
                        $individual_val=1;
                    else
                        $individual_val=0;
                    if($status=="Active")
                        $status_val=1;
                    else
                        $status_val=0;   
                    $page_details[]=array(
                        "name"=>$name,
                        "personnel"=>$personnel,
                        "personnel_id"=>$personnel_id,
                        "subject"=>$subject,
                        "subject_id"=>$subject_id,
                        "competence_level"=>$competence_level,
                        "competence_level_id"=>$competence_level_id,
                        "individual"=>$individual,
                        "individual_val"=>$individual_val,
                        "status"=>$status,
                        "status_val"=>$status_val
                    );
                }				
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[97]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
    function get_teachers(){        
		$cUrl = $this->get_service_api().'get_teachers';
        $reqhdrs = array('Accept: application/json');    
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id']
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
}
