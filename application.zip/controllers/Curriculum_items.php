<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Curriculum_items extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//curriculum_items	
	
	function curriculum_items() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
			$this->data['page_layout'] = $page_layout;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'curriculum_items', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_curriculum_items() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){                       
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['curriculum_fld']))
			$curriculum_fld = $_POST['curriculum_fld'];
		else
			$curriculum_fld ="";
        if(isset($_POST['subject_fld']))
			$subject_fld = $_POST['subject_fld'];
		else
			$subject_fld ="";
        if(isset($_POST['curriculum_item_type_fld']))
			$curriculum_item_type_fld = $_POST['curriculum_item_type_fld'];
		else
			$curriculum_item_type_fld ="";
        if(isset($_POST['curriculum_item_cycle_fld']))
			$curriculum_item_cycle_fld = $_POST['curriculum_item_cycle_fld'];
		else
			$curriculum_item_cycle_fld ="";
        if(isset($_POST['competence_level_fld']))
			$competence_level_fld = $_POST['competence_level_fld'];
		else
			$competence_level_fld ="";			
		$cUrl = $this->get_service_api().'view_curriculum_items';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'curriculum_fld'=>$curriculum_fld,
			'subject_fld'=>$subject_fld,
            'curriculum_item_type_fld'=>$curriculum_item_type_fld,
			'curriculum_item_cycle_fld'=>$curriculum_item_cycle_fld,
            'competence_level_fld'=>$competence_level_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_curriculum_items(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_curriculum_items';
        $title = trim($this->input->post('title'));
        $curriculum_id = $this->input->post('curriculum_id');
        $curriculum_item_type_id = $this->input->post('curriculum_item_type_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $curriculum_item_cycle_id  = $this->input->post('curriculum_item_cycle_id');
        $subject_id  = $this->input->post('subject_id');
        $description = $this->input->post('description');
        $example = $this->input->post('example');
        $additional_category = $this->input->post('additional_category');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'title'=>$title,
            'curriculum_id'=>$curriculum_id,
            'curriculum_item_type_id'=>$curriculum_item_type_id,
            'competence_level_id'=>$competence_level_id,
            'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
            'subject_id'=>$subject_id,
            'description'=>$description,
            'example'=>$example,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'additional_category'=>$additional_category
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_curriculum_items(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_curriculum_items';
        $id = $this->input->post('token_id');
		$title = trim($this->input->post('title'));
        $curriculum_id = $this->input->post('curriculum_id');
        $curriculum_item_type_id = $this->input->post('curriculum_item_type_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $curriculum_item_cycle_id  = $this->input->post('curriculum_item_cycle_id');
        $subject_id  = $this->input->post('subject_id');
        $description = $this->input->post('description');
        $example = $this->input->post('example');
        $additional_category = $this->input->post('additional_category');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
			'title'=>$title,
            'curriculum_id'=>$curriculum_id,
            'curriculum_item_type_id'=>$curriculum_item_type_id,
            'competence_level_id'=>$competence_level_id,
            'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
            'subject_id'=>$subject_id,
            'description'=>$description,
            'example'=>$example,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'additional_category'=>$additional_category
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_curriculum_items(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_curriculum_items(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_curriculum_items(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculums(){        
		$cUrl = $this->get_service_api().'get_curriculums';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function get_subjects(){        
		$cUrl = $this->get_service_api().'get_subjects';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculum_item_types(){        
		$cUrl = $this->get_service_api().'get_curriculum_item_types';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_competence_levels(){        
		$cUrl = $this->get_service_api().'get_competence_levels';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculum_item_cycles(){        
		$cUrl = $this->get_service_api().'get_curriculum_item_cycles';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_curriculum_items(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_curriculum_items';
        $label_details = $this->get_labels();
		$path = $_FILES["import_curriculum_items_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[97]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $title=$label_details[176]['name']." *";
        $cur=$label_details[177]['name']." *";
        if($col1!=$title||$col2!=$cur)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[96]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                    $title=trim($sheets[$i][0]);
                else
                    $title="";
                $curriculum_id="";
                if(isset($sheets[$i][1]))
                {
                    $curriculum=trim($sheets[$i][1]);
                    if($curriculum!="")
                    {
                        $cond="select id from curriculums where name='".$curriculum."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_id=$cu_details[0]['id'];
                        else
                            $curriculum_id="";
                    }                    
                }
                else
                    $curriculum="";
                $subject_id="";
                if(isset($sheets[$i][2]))
                {
                    $subject=trim($sheets[$i][2]);
                    if($subject!="")
                    {
                        $cond="select id from subjects where name='".$subject."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $subject_id=$cu_details[0]['id'];
                        else
                            $subject_id="";
                    }                    
                }
                else
                    $subject="";  
                $curriculum_item_type_id="";
                if(isset($sheets[$i][3]))
                {
                    $curriculum_item_type=trim($sheets[$i][3]);
                    if($curriculum_item_type!="")
                    {
                        $cond="select id from curriculum_item_types where name='".$curriculum_item_type."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_item_type_id=$cu_details[0]['id'];
                        else
                            $curriculum_item_type_id="";
                    }                    
                }
                else
                    $curriculum_item_type="";  
                $curriculum_item_cycle_id="";
                if(isset($sheets[$i][4]))
                {
                    $curriculum_item_cycle=trim($sheets[$i][4]);
                    if($curriculum_item_cycle!="")
                    {
                        $cond="select id from curriculum_item_cycles where name='".$curriculum_item_cycle."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_item_cycle_id=$cu_details[0]['id'];
                        else
                            $curriculum_item_cycle_id="";
                    }                    
                }
                else
                    $curriculum_item_cycle="";
                $competence_level_id="";
                if(isset($sheets[$i][5]))
                {
                    $competence_level=trim($sheets[$i][5]);
                    if($competence_level!="")
                    {
                        $cond="select id from competence_levels where name='".$competence_level."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $competence_level_id=$cu_details[0]['id'];
                        else
                            $competence_level_id=0;
                    }                    
                }
                else
                    $competence_level="";    
                if(isset($sheets[$i][6]))
                    $description=trim($sheets[$i][6]);
                else
                    $description="";
                if(isset($sheets[$i][7]))
                    $example=trim($sheets[$i][7]);
                else
                    $example="";
                if(isset($sheets[$i][8]))
                    $additional_category=trim($sheets[$i][8]);
                else
                    $additional_category="";  
                if(isset($sheets[$i][9]))
                    $status=trim($sheets[$i][9]);
                else
                    $status="";
                if($title!=""||$curriculum!=""||$subject!=""||$curriculum_item_type!=""||$curriculum_item_cycle!=""||$competence_level!=""||$description!=""||$example!=""||$additional_category!=""||$status!="")
                {
                    if($status=="Active")
                        $status_val=1;
                    else
                        $status_val=0;   
                    $page_details[]=array(
                        "title"=>$title,
                        "curriculum"=>$curriculum,
                        "curriculum_id"=>$curriculum_id,
                        "subject"=>$subject,
                        "subject_id"=>$subject_id,
                        "curriculum_item_type"=>$curriculum_item_type,
                        "curriculum_item_type_id"=>$curriculum_item_type_id,
                        "curriculum_item_cycle"=>$curriculum_item_cycle,
                        "curriculum_item_cycle_id"=>$curriculum_item_cycle_id,
                        "competence_level"=>$competence_level,
                        "competence_level_id"=>$competence_level_id,
                        "description"=>$description,
                        "example"=>$example,
                        "status"=>$status,
                        "status_val"=>$status_val,
                        "additional_category"=>$additional_category
                    );	
                }			
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[97]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}	
}
