<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Disciplinary extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function disciplinary() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
			$page_details = $this->users_model->special_fetch($cond);
			$this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'disciplinary', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_disciplinary() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
		if(isset($_POST['type_fld']))
			$type_fld = $_POST['type_fld'];
		else
			$type_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";	
        if(isset($_POST['reported_by_fld']))
			$reported_by_fld = $_POST['reported_by_fld'];
		else
			$reported_by_fld ="";
        if(isset($_POST['parent_check_needed_fld']))
			$parent_check_needed_fld = $_POST['parent_check_needed_fld'];
		else
			$parent_check_needed_fld ="";
        if(isset($_POST['parents_check_fld']))
			$parents_check_fld = $_POST['parents_check_fld'];
		else
			$parents_check_fld ="";
        if(isset($_POST['remark_date_fld']))
			$remark_date_fld = $_POST['remark_date_fld'];
		else
			$remark_date_fld ="";
        if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
        if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        $cUrl = $this->get_service_api().'view_disciplinary';
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld'=>$term_fld,
			'type_fld'=>$type_fld,
            'student_fld'=>$student_fld,
            'reported_by_fld'=>$reported_by_fld,
            'parent_check_needed_fld'=>$parent_check_needed_fld,
            'parents_check_fld'=>$parents_check_fld,
			'remark_date_fld'=>$remark_date_fld,
            'status_fld'=>$status_fld,
            'del_fld'=>$del_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_students_for_disciplinary() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld_list']))
			$term_fld_list = $_POST['term_fld_list'];
		else
			$term_fld_list ="";
		if(isset($_POST['grade_fld_list']))
			$grade_fld_list = $_POST['grade_fld_list'];
		else
			$grade_fld_list ="";
        if(isset($_POST['teacher_fld_list']))
			$teacher_fld_list = $_POST['teacher_fld_list'];
		else
			$teacher_fld_list ="";	
        if(isset($_POST['study_level_fld_list']))
			$study_level_fld_list = $_POST['study_level_fld_list'];
		else
			$study_level_fld_list ="";
        if(isset($_POST['student_fld_list']))
			$student_fld_list = $_POST['student_fld_list'];
		else
			$student_fld_list ="";
        $cUrl = $this->get_service_api().'view_students_for_disciplinary';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld_list'=>$term_fld_list,
			'grade_fld_list'=>$grade_fld_list,
            'teacher_fld_list'=>$teacher_fld_list,
            'study_level_fld_list'=>$study_level_fld_list,
            'student_fld_list'=>$student_fld_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
       
	function add_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_disciplinary';
        $term_id = $this->input->post('term_fld');
        $student_id = $this->input->post('student_id');
        $reported_by_id = $this->input->post('reported_by_id');
        $type_id = $this->input->post('type_id');
        $remark_date = $this->input->post('remark_date');
        $remark_date = str_replace("/","-",$remark_date);
        $points = $this->input->post('points');
        $description = $this->input->post('description');
        $is_parent_check_needed = $this->input->post('is_parent_check_needed');
        $status = $this->input->post('status');
        if(isset($is_parent_check_needed))
            $is_parent_check_needed=1;
        else
            $is_parent_check_needed=0;
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'term_id'=>$term_id,
            'student_id'=>$student_id,
            'reported_by_id'=>$reported_by_id,
            'type_id'=>$type_id,
            'remark_date'=>$remark_date,
            'points'=>$points,
            'description'=>$description,
            'is_parent_check_needed'=>$is_parent_check_needed,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_disciplinary';
        $id = $this->input->post('token_id');    
        $term_id = $this->input->post('term_fld');
        $student_id = $this->input->post('student_id');
        $reported_by_id = $this->input->post('reported_by_id');
        $type_id = $this->input->post('type_id');
        $remark_date = $this->input->post('remark_date');
        $remark_date = str_replace("/","-",$remark_date);
        $points = $this->input->post('points');
        $description = $this->input->post('description');
        $is_parent_check_needed = $this->input->post('is_parent_check_needed');
        $status = $this->input->post('status');
        if(isset($is_parent_check_needed))
            $is_parent_check_needed=1;
        else
            $is_parent_check_needed=0;
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
            'term_id'=>$term_id,
            'student_id'=>$student_id,
            'reported_by_id'=>$reported_by_id,
            'type_id'=>$type_id,
            'remark_date'=>$remark_date,
            'points'=>$points,
            'description'=>$description,
            'is_parent_check_needed'=>$is_parent_check_needed,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_disciplinary';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    } 
    function restore_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_disciplinary';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }  
    
    function get_disciplinary_type(){        
		$cUrl = $this->get_service_api().'get_disciplinary_type';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    
    function import_disciplinary(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_disciplinary';
        $label_details = $this->get_labels();
		$path = $_FILES["import_disciplinary_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[140]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $stu_name=$label_details[205]['name']." *";
        $rp_by=$label_details[206]['name']." *";
        if($col1!=$stu_name||$col2!=$rp_by)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[139]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{                
                if(isset($sheets[$i][0]))
                {
                    $student_name=trim($sheets[$i][0]);
                    if($student_name!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $student=$users['first_name']." ".$users['last_name'];
                            if($student==$student_name)
                            {
                                $student_id=$users['id'];
                                break;
                            }
                            else
                                $student_id="";
                        }                        
                    }                   
                }
                else
                    $student_name="";
                if(isset($sheets[$i][1]))
                {
                    $reported_by=trim($sheets[$i][1]);
                    if($reported_by!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $student=$users['first_name']." ".$users['last_name'];
                            if($student==$reported_by)
                            {
                                $reported_by_id=$users['id'];
                                break;
                            }
                            else
                                $reported_by_id="";
                        }                        
                    }                   
                }
                else
                    $reported_by="";
                if(isset($sheets[$i][2]))
                {
                    $disciplinary_category=trim($sheets[$i][2]);
                    if($disciplinary_category!="")
                    {
                        $cond="select id from disciplinary_categories where name='".$disciplinary_category."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $disciplinary_category_id=$cu_details[0]['id'];
                        else
                            $disciplinary_category_id="";
                    }                    
                }
                else
                    $disciplinary_category="";
                if(isset($sheets[$i][3]))
                {
                    $remark_date=trim($sheets[$i][3]);
                    $remark_date=str_replace("/","-",$remark_date);
                }
                else
                    $remark_date="";
                if(isset($sheets[$i][4]))
                {
                    $description=trim($sheets[$i][4]);
                }
                else
                    $description="";
                if(isset($sheets[$i][5]))
                {
                    $points_value=trim($sheets[$i][5]);
                }
                else
                    $points_value="";
                if(isset($sheets[$i][6]))
                {
                    $is_parent_check_needed=trim($sheets[$i][6]);
                }
                else
                    $is_parent_check_needed="";
                if(isset($sheets[$i][7]))
                {
                    $status=trim($sheets[$i][7]);
                }
                else
                    $status="";
                if($student_name!=""||$reported_by!=""||$disciplinary_category!=""||$remark_date!=""||$description!=""||$points_value!=""||$is_parent_check_needed!=""||$status!="")
                {
                    if($is_parent_check_needed=="Yes")
                        $is_parent_check_needed_val=1;
                    else
                        $is_parent_check_needed_val=0;
                    if($status=="Active")
                        $status_val=1;
                    else
                        $status_val=0;
                    $page_details[]=array(
                        "student_name"=>$student_name,
                        "student_id"=>$student_id,
                        "reported_by"=>$reported_by,
                        "reported_by_id"=>$reported_by_id,
                        "disciplinary_category"=>$disciplinary_category,
                        "disciplinary_category_id"=>$disciplinary_category_id,
                        "remark_date"=>$remark_date,
                        "description"=>$description,
                        "points_value"=>$points_value,
                        "is_parent_check_needed"=>$is_parent_check_needed,
                        "is_parent_check_needed_val"=>$is_parent_check_needed_val,
                        "status"=>$status,
                        "status_val"=>$status_val                 
                    );	
                }	
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[140]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
}
