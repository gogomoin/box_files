<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Dossiers extends MY_Controller
{
        
    function __construct() 
	{
        parent::__construct();
        $this->load->helper('url');
        $this->load->library('session');
        $this->load->library('excel_reader');
        $this->load->library('ciqrcode');
        $this->load->library('pdf');
        $this->load->library('concatpdf');
        $this->load->library('ocr_convertor');
        $this->load->library('pdf_convertor');
        $this->load->library('word_convertor');
    }    
    
    function index() 
    {

    } 
	
	//Career Goals	
	
	function dossiers() 
	{
                if($this->session->userdata('user_det') != '' 
                && $this->session->userdata('user_det') != 'undefined'
                && $this->session->userdata('user_det') != null){
                        $user_det = $this->session->userdata('user_det');
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                        $link_array = explode('/',$actual_link);
                        $page_layout = end($link_array);
                        $cond="select * from pages where page_layout='".$page_layout."'";
                        $page_details = $this->users_model->special_fetch($cond);
                        $this->data['page_details'] = $page_details;
                        $this->session->set_userdata('page_layout',$page_layout);
                        $label_details = $this->get_labels();
                        $pgn_details = $this->get_paginate_numbers();                        
                        $cond="select is_active from system_settings s where s.key='lesson-curriculums'";
                        $sys_details = $this->users_model->special_fetch($cond);
                        if(count($sys_details)>0){
                                if($sys_details[0]['is_active']==1)
                                        $this->data['curriculum_flag'] = true;
                                else
                                        $this->data['curriculum_flag'] = false;  
                        }
                        else
                                $this->data['curriculum_flag'] = true;
                        $cond="select is_active from system_settings s where s.key='global-search'";
                        $sys_details = $this->users_model->special_fetch($cond);
                        if(count($sys_details)>0){
                                if($sys_details[0]['is_active']==1)
                                        $this->data['global_share_flag'] = true;
                                else
                                        $this->data['global_share_flag'] = false;  
                        }
                        else
                                $this->data['global_share_flag'] = true;
                        $cond="select is_active from system_settings s where s.key='learning-type'";
                        $sys_details = $this->users_model->special_fetch($cond);
                        if(count($sys_details)>0){
                                if($sys_details[0]['is_active']==1)
                                        $this->data['learning_flag'] = true;
                                else
                                        $this->data['learning_flag'] = false;  
                        }
                        else
                                $this->data['learning_flag'] = true;
                        $lang_code="en";
                        $cond="select s.code from languages s where s.id=".$user_det['lang_id'];
                        $lang_code_details = $this->users_model->special_fetch($cond);
                        if(count($lang_code_details)>0){
                                $lang_code = $lang_code_details[0]['code'];
                        }
                        $this->data['lang_code'] = $lang_code;
                        $this->data['label_details'] = $label_details;
                        $this->data['pgn_details'] = $pgn_details;
                        $this->data['role_details'] = $this->get_role_details();                        
                        $this->get_include();
                        $this->get_file_manager();
                        $this->data['task_module'] = $this->load->view($this->view_dir . 'task_module', $this->data, true);
                        $this->load->view($this->view_dir . 'dossiers', $this->data);
                }
                else{
                        $this->data['error_message'] = '';
                        $this->data['username'] = '';
                        $this->load->view($this->view_dir . 'login', $this->data);
                }
	}
        function dossier_pdfeditor($pdf_file) 
	{
                if($this->session->userdata('user_det') != '' 
                && $this->session->userdata('user_det') != 'undefined'
                && $this->session->userdata('user_det') != null){
                        $user_det = $this->session->userdata('user_det');
                        $this->data['pdf_file'] = $pdf_file;
                        $this->load->view($this->view_dir . 'dossier_pdfeditor', $this->data);
                }
                else{
                        $this->data['error_message'] = '';
                        $this->data['username'] = '';
                        $this->load->view($this->view_dir . 'login', $this->data);
                }
	} 
        function dossier_pdftron($pdf_file) 
	{
                if($this->session->userdata('user_det') != '' 
                && $this->session->userdata('user_det') != 'undefined'
                && $this->session->userdata('user_det') != null){
                        $user_det = $this->session->userdata('user_det');
                        $this->data['pdf_file'] = $pdf_file;
                        $this->load->view($this->view_dir . 'dossier_pdftron', $this->data);
                }
                else{
                        $this->data['error_message'] = '';
                        $this->data['username'] = '';
                        $this->load->view($this->view_dir . 'login', $this->data);
                }
	}    
	function view_dossiers() 
	{
                $draw = $_POST['draw'];
                $start = $_POST['start'];
                        $rowperpage = $_POST['length'];
                        $searchValue = $_POST['search']['value'];
                $columnIndex = $_POST['order'][0]['column'];
                $columnName="";
                $columnSortOrder ="";
                if($_POST['columns'][$columnIndex]['orderable'] != 'false'){

                $columnName = $_POST['columns'][$columnIndex]['data'];
                $columnSortOrder = $_POST['order'][0]['dir'];
                        }
                        if(isset($_POST['term_fld']))
                        $term_fld = $_POST['term_fld'];
                else
                        $term_fld ="";
                if(isset($_POST['course_fld']))
                        $course_fld = $_POST['course_fld'];
                else
                        $course_fld ="";
                        if(isset($_POST['teacher_fld']))
                        $teacher_fld = $_POST['teacher_fld'];
                else
                        $teacher_fld ="";
                if(isset($_POST['local_fld']))
                        $local_fld = $_POST['local_fld'];
                else
                        $local_fld ="1";	
                if(isset($_POST['type_fld']))
                {
                        $type_fld = $_POST['type_fld'];
                        if($local_fld==2)
                        {
                                if($type_fld=="Select Language Type")
                                        $type_fld="";
                        }
                }
                else
                        $type_fld ="";
                if(isset($_POST['del_fld']))
                        $del_fld = $_POST['del_fld'];
                else
                        $del_fld ="";
                if(isset($_POST['search_fld']))
                        $search_fld = $_POST['search_fld'];
                else
                        $search_fld ="";
                
                $cUrl = $this->get_service_api().'view_dossiers';
                $user_det = $this->session->userdata('user_det');
                $post_data = array(
                'start'=>$start,
                'rowperpage'=>$rowperpage,
                'term_fld'=>$term_fld,
                'type_fld'=>$type_fld,
                'course_fld'=>$course_fld,
                'teacher_fld'=>$teacher_fld,
                'del_fld'=>$del_fld,
                'search_fld'=>$search_fld,
                'local_fld'=>$local_fld,
                'id'=>$user_det['id'],
                'group_id'=>$user_det['group_id'],
                'columnName'=>$columnName,
                'columnSortOrder'=>$columnSortOrder,
                'searchValue'=>$searchValue
                );
                $reqhdrs = array('Accept: application/json');       
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
                curl_setopt($ch, CURLOPT_VERBOSE, 1);
                $json = curl_exec($ch); 
                //var_dump($json);die();
                $result = json_decode($json, true);
                curl_close($ch);
                $response = array(
                        "draw" => intval($draw),
                        "iTotalRecords" => $result['totalRecord'],
                        "iTotalDisplayRecords" => $result['totalRecordwithFilter'],
                        "aaData" => $result['page_details']
                );
                echo json_encode($response);
	} 
        function generate_qr_code()
	{
		$cond="select id,dossier_key from dossiers";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
                        $file_name = $pro['dossier_key']."-Qrcode" . rand(2,200) . ".png";
                        $uploads_dir = 'assets/uploads/user_files';
                        $file_path=$uploads_dir.'/'.$file_name;
                        $params=array();
                        $params['data'] = $pro['dossier_key'];
                        $params['level'] = 'H';
                        $params['size'] = 10;
                        $params['savename'] = $file_path;
                        $this->ciqrcode->generate($params);
                        $input = array(
				'qr_code'=>$file_name
			);
			$this->dossiers_model->edit($input,$pro['id']);
                }
                echo "Done";
	}
        function generate_qr_code_test()
	{
                $uploads_dir = 'assets/uploads/user_files';
                $file_name = "DEU-22_-15-08-2022-1154-Qrcode196.png";
                $file_path=$uploads_dir.'/'.$file_name;
                $dos_key_hash=urlencode(base64_encode('DEU-22_-15-08-2022-1154'));
                $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                $url = $actual_link."/dossiers/dossier_preview/".$dos_key_hash;
                $params=array();
                $params['data'] = $url;
                $params['level'] = 'H';
                $params['size'] = 10;
                $params['savename'] = $file_path;
                $this->ciqrcode->generate($params);
                echo "Done";
	}
        
    function add_dossiers(){
        $user_det = $this->session->userdata('user_det');
        $cUrl = $this->get_service_api().'add_dossiers';
        $user_det = $this->session->userdata('user_det');
        $personnel_id=$user_det['id'];
        $term_id = $this->input->post('term_id');
        $subject_id = $this->input->post('subject_id');
        $dossier_language_id = $this->input->post('language_id');
        $course_id = $this->input->post('course_id');
        $curriculum_item_id = $this->input->post('curriculum_item_id');
        if($curriculum_item_id=="")
        {
                $curriculum_item_id = 0;
        }
        $teaser_image = $this->input->post('school_logo_file_name');
        $teaser_text = $this->input->post('teaser_text');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $group_chk = $this->input->post('group_chk');
        $individual_chk = $this->input->post('individual_chk');
        $remote_chk = $this->input->post('remote_chk');
        $published = $this->input->post('published');
        $local_visible = $this->input->post('local_visible');
        $local_duplication = $this->input->post('local_duplication');
        $global_visible = $this->input->post('global_visible');
        $global_duplication = $this->input->post('global_duplication');
        $title = $this->input->post('title');
        $estimated_time = $this->input->post('estimated_time');
        $goals = $this->input->post('goals');
        $path_to_success = $this->input->post('path_to_success');
        $task = $this->input->post('task');
        $keywords = json_decode($this->input->post('keywords'),true);
        $useful_links = $this->input->post('useful_links');
        $document_files = $this->input->post('document_files');
        $files_order = $this->input->post('files_order');
        $description = $this->input->post('description');
        $solution_files = $this->input->post('solution_files');
        $solutions_published = $this->input->post('solutions_published');
        $evaluation_files = $this->input->post('evaluation_files');
        $rating = $this->input->post('rating');
        $eva_total_count = $this->input->post('eva_total_count');
        $evaluation_details=array();
        $eva_total_count_arr=explode(",",$eva_total_count);
        foreach($eva_total_count_arr as $id_val)
        {
                $m_id="eva_mark_category_id_".$id_val;
                $eva_mark_category_id = $this->input->post($m_id);
                $d_id="eva_date_".$id_val;
                $eva_evaluation_date = $this->input->post($d_id);
                $k_id="eva_keywords_".$id_val;
                $eva_keywords = json_decode($this->input->post($k_id),true);
                $eva_words="";
                foreach($eva_keywords as $eva_keys)
                {
                if($eva_words=="")
                        $eva_words=$eva_keys['value'];
                else
                        $eva_words=$eva_words.",".$eva_keys['value'];
                }
                $de_id="eva_description_".$id_val;
                $eva_description = $this->input->post($de_id);
                $evaluation_details[]=array(
                "mark_category_id"=>$eva_mark_category_id,
                "evaluation_date"=>$eva_evaluation_date,
                "keywords"=>$eva_words,
                "description"=>$eva_description,
                );
        }
        $words="";
        foreach($keywords as $keys)
        {
                if($words=="")
                        $words=$keys['value'];
                else
                        $words=$words.",".$keys['value'];
        }
        if(!isset($group_chk))
                $group_chk=0;
        else
                $group_chk=5;
        if(!isset($individual_chk))
                $individual_chk=0;
        else
                $individual_chk=6;
        if(!isset($remote_chk))
                $remote_chk=0;
        else
                $remote_chk=1;
        if(isset($local_visible))
                $local_visible=1;
        else
                $local_visible=0;   
        if(isset($local_duplication))
                $local_duplication=1;
        else
                $local_duplication=0; 
        if(isset($global_visible))
                $global_visible=1;
        else
                $global_visible=0; 
        if(isset($global_duplication))
                $global_duplication=1;
        else
                $global_duplication=0;
        if(isset($published))
                $published=1;
        else
                $published=0;
        if(isset($solutions_published))
                $solutions_published=1;
        else
                $solutions_published=0;
        $des_path=getcwd();
        $file_des_name="temp_doc_".time().".png";
        $file_des_path=$des_path."/assets/uploads/user_files/".$file_des_name;
        $no_occ=substr_count($content, 'src="data:image/');
        for($i=0;$i<$no_occ;$i++)
        {
                if (stripos($content, 'src="data:image/') !== false) 
                {
                        $data = $this->get_string_between($content, 'src="data:image/','"');
                        $data='data:image/'.$data;
                        $base64_data = explode(',', $data);
                        $base64_string=base64_decode($base64_data[1]);
                        $list = explode(';', $data);
                        $ext_data=explode("/",$list[0]);
                        $ext=$ext_data[1];
                        $file_name="temp_doc_".$i.time().".".$ext;
                        file_put_contents($file_path, $base64_string);
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                        $url = $actual_link."/assets/uploads/user_files/".$file_name;
                        $description=str_replace($data,$url,$description);
                }
        }
        $cond="select name from subjects where id=".$subject_id;
        $sub_details = $this->users_model->special_fetch($cond);
        $sub_details[0]['name'] = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '', $sub_details[0]['name']);
        $sub=strtoupper(substr($sub_details[0]['name'],0,3));
        $cond="select name from terms where id=".$term_id;
        $term_details = $this->users_model->special_fetch($cond);
        $term_sub=strtoupper(substr($term_details[0]['name'],0,3));
        $start_date_arr=explode("/",$start_date);
        $hour_date = date("H");
        $min_date = date("i");
        $dossier_key=$sub."-".$term_sub."-".$start_date_arr[2].$start_date_arr[1].$start_date_arr[0]."-".$hour_date.$min_date;
        $file_name = $dossier_key."-Qrcode" . rand(2,200) . ".png";
        $uploads_dir = 'assets/uploads/user_files';
        $file_path=$uploads_dir.'/'.$file_name;
        $dos_key_hash=urlencode(base64_encode($dossier_key));
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
        $url = $actual_link."/dossiers/dossier_preview/".$dos_key_hash;
        $params=array();
        $params['data'] = $url;
        $params['level'] = 'H';
        $params['size'] = 10;
        $params['savename'] = $file_path;
        $this->ciqrcode->generate($params);
        $post_data = array(
                'dossier_key'=>$dossier_key,
                'term_id'=>$term_id,
                'subject_id'=>$subject_id,
                'personnel_id'=>$personnel_id,
                'dossier_language_id'=>$dossier_language_id ,
                'course_id'=>$course_id,
                'curriculum_item_id'=>$curriculum_item_id,
                'teaser_image'=>$teaser_image,
                'teaser_text'=>$teaser_text,
                'start_date'=>$start_date,
                'end_date'=>$end_date,
                'group_chk'=>$group_chk,
                'individual_chk'=>$individual_chk,
                'remote_chk'=>$remote_chk,
                'local_visible'=>$local_visible,
                'local_duplication'=>$local_duplication,
                'global_visible'=>$global_visible,
                'global_duplication'=>$global_duplication,
                'published'=>$published,
                'title'=>$title,
                'estimated_time'=>$estimated_time,
                'goals'=>$goals,
                'path_to_success'=>$path_to_success,
                'task'=>$task,
                'keywords'=>$words,
                'useful_links'=>$useful_links,
                'description'=>$description,
                'solution_files'=>$solution_files,
                'document_files'=>$document_files,
                'files_order'=>$files_order,
                'solutions_published'=>$solutions_published,
                'evaluation_files'=>$evaluation_files,
                'evaluation_details'=>$evaluation_details,
                'lang_id'=>$user_det['lang_id'],
                'rating'=>$rating,
                'qr_code'=>$file_name
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        
        curl_close($ch);
        set_time_limit(0);
        ob_end_clean();
        header("Connection: close");
        ob_start();
        echo $result;
        $size = ob_get_length();
        header("Content-Length: $size");
        ob_end_flush(); // Strange behaviour, will not work
        flush();            // Unless both are called !
        session_write_close(); // Added a line suggested in the comment */
        // Do processing here
        $files_order_arr=explode(",",$files_order);
        $document_files_arr=explode(",",$document_files);
        $files_arr=array();
        foreach($files_order_arr as $fil)
        {  
                if($fil !='')     
                        $files_arr[]= $document_files_arr[$fil];
        }
        $document_files=implode(",",$files_arr);
        $pdf_data = array(
                'dossier_key'=>$dossier_key,
                'term_id'=>$term_id,
                'personnel_id'=>$personnel_id,
                'dossier_language_id'=>$dossier_language_id ,
                'course_id'=>$course_id,
                'curriculum_item_id'=>$curriculum_item_id,
                'teaser_image'=>$teaser_image,
                'teaser_text'=>$teaser_text,
                'start_date'=>$start_date,
                'end_date'=>$end_date,
                'local'=>"",
                'task'=>$task,
                'title'=>$title,
                'estimated_time'=>$estimated_time,
                'goals'=>$goals,
                'path_to_success'=>$path_to_success,
                'useful_links'=>$useful_links,
                'description'=>$description,
                'solution_files'=>$solution_files,
                'document_files'=>$document_files,
                'evaluation_files'=>$evaluation_files,
                'qr_code'=>$file_name
        );
        $this->generate_pdf($pdf_data); 
        $pdf_post_data = array(
                'dossier_key'=>$dossier_key
        );
        $cUrl = $this->get_service_api().'update_dossiers_pdf_status';
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pdf_post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result1 = curl_exec($ch);
        curl_close($ch);
        if($document_files!="")
        {
            $cond="select * from documents where id in(".$document_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $solution_html="";
        if($solution_files!="")
        {
            $cond="select * from documents where id in(".$solution_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $evaluation_html="";
        if($evaluation_files!="")
        {
            $cond="select * from documents where id in(".$evaluation_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        die();
    }
    function test_document()
    {
        echo "Hello";
        $document='1.doc';
        $ext = strtolower(pathinfo($document, PATHINFO_EXTENSION));
        $path = "./assets/uploads/".$document;
        $content="";
        if($ext=='docx')
                echo $content=$this->word_convertor->extracttext($path,$ext);
        else
                echo $content=$this->word_convertor->read_doc($path);
        //echo $content=$this->word_convertor->convert_word($path,$ext);
    }
    function store_document_content($document,$id)
    {
        $cond="select * from documents where id=".$id." and document_indexed=0";
        $document_details = $this->users_model->special_fetch($cond);
        if(count($document_details)>0)
        {
                $ext = strtolower(pathinfo($document, PATHINFO_EXTENSION));
                $path = "./assets/uploads/user_files/".$document;
                $content="";
                if($ext=='gif'||$ext=='jpg'||$ext=='jpeg'||$ext=='png')
                {
                        $content=$this->ocr_convertor->convert_image($path);
                }
                else if($ext=='pdf')
                {
                        $content=$this->pdf_convertor->convert_pdf($path);
                }
                else if($ext=='docx')
                {
                        $content=$this->word_convertor->read_from_docx($path,$ext);
                }
                else if($ext=='doc')
                {
                        $content=$this->word_convertor->read_doc($path);
                }
                else if($ext=='txt')
                {
                        $content=file_get_contents($path);
                }
                else if($ext=='ppt'||$ext=='pptx')
                {
                        $content=$this->word_convertor->pptx_to_text($path);
                }
                else if($ext=='xls'||$ext=='xlsx')
                {
                        $content=$this->word_convertor->xlsx_to_text($path);
                }
                $content_arr=$this->split_content($content,3000);
                foreach($content_arr as $con)
                {       
                        $input = array(
                                'document_id'=>$id,
                                'document_text'=>$con
                        );
                        $this->document_text_model->add($input);
                }
                $input = array(
                        'document_indexed'=>1
                );
                $this->file_manager_model->edit($input,$id);
        }

    }
    
    function split_content($content,$len)
    {   
        $con_arr = str_split($content, $len);
        return $con_arr;
    }
    
    function test_clean()
    {
        /* set_time_limit(0);
        ob_end_clean();
        header("Connection: close");
        ob_start();
        echo 'Done Processing';
        $size = ob_get_length();
        header("Content-Length: $size");
        ob_end_flush(); // Strange behaviour, will not work
        flush();            // Unless both are called !
        session_write_close(); // Added a line suggested in the comment */
        $pdf_data = array(
                'dossier_key'=>'SCI-22_-21-10-2022-1558',
                'term_id'=>2,
                'personnel_id'=>17,
                'dossier_language_id'=>3,
                'course_id'=>12,
                'curriculum_item_id'=>11,
                'teaser_image'=>'1666282070834_benefitsofseparatingmixture2.jpg',
                'teaser_text'=>'Want to Know More About the Benefits of Separating Mixture? Lets explore this lesson. ',
                'start_date'=>'19-10-2022',
                'end_date'=>'22-10-2022',
                'title'=>'The Benefits and Importance of Separating Mixture',
                'task'=>'1. Identify the ways in separating mixtures using the different techniques<br>2. Understand  the advantage and disadvantages of separating mixtures using the different techniques <br>3. Explain the importance of separating mixtures using the different techniques <br>',
                'local'=>"1",
                'estimated_time'=>'1 hour',
                'goals'=>'1.	Enumerate the ways and describe the benefits of separating the mixture.<br> 2. Explain the importance of separating mixtures using techniques such as decantation, evaporation, filtering, sieving, and using magnets as the community applies.<br>',
                'path_to_success'=>'scucess',
                'description'=>'<p>&nbsp;</p><p>&nbsp;</p><p><img class="max_width_css" src="http://ampayonsses.proscola.org/assets/uploads/user_files/1666318422618_benefitsofseparatingmixture2.jpg" /></p>',
                'useful_links'=>'Teaching Procedure: (4As Strategy)

                Activate Prior Knowledge (4 Pics 1 Word)
                
                The teacher will show different pictures of the different ways of separating mixtures, the participants will guess the word based on the 4 pictures.	
                
                Acquire New Knowledge (Learning Bazaar)
                The teacher will discuss the benefits and importance of separating mixtures using different techniques such as decantation, evaporation, filtering, sieving and using magnets as applied by the community using different pictures and activities.
                
                Application 
                The teacher will give individual activities to the participants about the benefits and importance of separating mixtures using different techniques such as decantation, evaporation, filtering, sieving, and using magnets as applied by the community.
                        
                Explain the importance of separating mixtures using different techniques such as decantation, evaporation, filtering, sieving, and using magnets as applied by the community.	The teacher will ask the participants about the benefits and importance of separating mixtures using different techniques such as decantation, evaporation, filtering, sieving and using magnets as applied by the community. 
                 (Open-ended question)	
                
                Generalization:	Ask what are the benefits of separating the mixture and why is separating the mixture important. 	
                
                Assessment	(Pen and paper test)	
                A 10-item exam will be given to the learners.
                
                ',
                'files_order'=>'0,1',
                'solution_files'=>'',
                'document_files'=>'1993,1991',
                'evaluation_files'=>'1991',
                'qr_code'=>'SCI-22_-21-10-2022-1558-Qrcode36.png'
        );
        
  
        $this->generate_pdf($pdf_data); 
       /*  $pdf_post_data = array(
                'dossier_key'=>'ENG-202-20220201-1940'
          );
        $cUrl = $this->get_service_api().'update_dossiers_pdf_status';
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pdf_post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch); */
        echo 'Done';
        die(); 
    }
    function get_icon($ext)
        {               
        $str="";
	if($ext=='aif'||$ext=='cda'||$ext=='mid'||$ext=='mp3'||$ext=='midi'||$ext=='mpa'||$ext=='ogg'||$ext=='wav'||$ext=='wma'||$ext=='wpl')
	{
		$str='audio_image.png';
	}
	else if($ext=='3g2'||$ext=='3gp'||$ext=='avi'||$ext=='flv'||$ext=='h264'||$ext=='m4v'||$ext=='mkv'||$ext=='mov'||$ext=='mp4'||$ext=='mpg'||$ext=='rm'||$ext=='swf'||$ext=='vob'||$ext=='wmv')
	{
		$str='video_image.png';
	}	
	else if($ext=='ods'||$ext=='xls'||$ext=='xlsm'||$ext=='xlsx')
	{
		$str='xls_image.png';
	}
	else if($ext=='doc'||$ext=='docx'||$ext=='odt'||$ext=='rtf'||$ext=='tex'||$ext=='txt'||$ext=='wpd')
                $str='word_image.png';
	else if($ext=='pdf')
                $str='pdf_image.png';
	else if($ext=='key'||$ext=='odp'||$ext=='pps'||$ext=='ppt'||$ext=='pptx')
                $str='powerpoint_image.png';
	else if($ext=='7z'||$ext=='arj'||$ext=='deb'||$ext=='pkg'||$ext=='rar'||$ext=='rpm'||$ext=='z'||$ext=='zip')
                $str='zip_image.png';
	else if($ext=='ai'||$ext=='bmp'||$ext=='gif'||$ext=='ico'||$ext=='ps'||$ext=='psd'||$ext=='svg'||$ext=='tif'||$ext=='tiff')
                $str='other_images.png';
        else if($ext=='jpg'||$ext=='jpeg')
                $str='jpg_image.png';
        else if($ext=='png')
                $str='png_image.png';
	else
                $str='others.png';
	return $str;
        }
    function generate_pdf($post_data)
    {
        $label_details = $this->get_labels();
        $base_url=$this->data['base_url'];
        $cond="select * from school limit 1";
        $school_details = $this->users_model->special_fetch($cond);
        $cond="select name from courses where id=".$post_data['course_id'];
        $cor_details = $this->users_model->special_fetch($cond);
        $course=$cor_details[0]['name'];
        $cond="select name from terms where id=".$post_data['term_id'];
        $term_details = $this->users_model->special_fetch($cond);
        $term=$term_details[0]['name'];
        $cond="select description from curriculum_item where id=".$post_data['curriculum_item_id'];
        $cur_details = $this->users_model->special_fetch($cond);
        $curriculum=$cur_details[0]['description'];
        $cond="select CONCAT(first_name, ' ', last_name) as name from users where id=".$post_data['personnel_id'];
        $teacher_details = $this->users_model->special_fetch($cond);
        $teacher=$teacher_details[0]['name'];
        $cond="select name from dossier_languages where id=".$post_data['dossier_language_id'];
        $lang_details = $this->users_model->special_fetch($cond);
        $language=$lang_details[0]['name'];
        $school_address=$school_details[0]['address1'];
        if($school_details[0]['address2']!="")
        $school_address.= ','.$school_details[0]['address2'];
                if($school_details[0]['city']!="")
        $school_address.= ','.$school_details[0]['city'];
                if($school_details[0]['zip_code']!="")
        $school_address.= ','.$school_details[0]['zip_code'];        
        $logo_path=$base_url.'assets/uploads/user_files/100_'.$school_details[0]['logo'];
        $qr_code_path=$base_url.'assets/uploads/user_files/'.$post_data['qr_code'];
        if($post_data['teaser_image']!="")
                $teaser_image_path=$base_url.'assets/uploads/user_files/'.$post_data['teaser_image'];
        else
                $teaser_image_path=$base_url.'assets/uploads/user_files/'.$school_details[0]['logo'];
        $useful_links_arr = preg_split('/\r\n|\r|\n/', $post_data['useful_links']);
        $i=0;$j=0;$k=0;
        $first=false;
	    $useful_arr=array();
        foreach($useful_links_arr as $usl)
        {
                $usl=trim($usl);
                if($j==0)
                        $first=true;
                if(!(filter_var($usl, FILTER_VALIDATE_URL) === FALSE))
                {
                $useful_arr[$i][$k]=$usl;
                $k++;
                }
                else
                {
                if($first)
                {
                        $useful_arr[$i][$k]=$usl;
                        $k++;
                }
                else
                {
                        $i++;
                        $k=0;
                        $useful_arr[$i][$k]=$usl;
                        $k++;
                }
                } 	
                $j++;
                $first=false;
        }
        $useful_links_html="";
        $link_title_html="";
        $links_html="";
        foreach($useful_arr as $row)
        {
            $useful_links_html="";
            foreach($row as $col)
            {
                if(!(filter_var($col, FILTER_VALIDATE_URL) === FALSE))
                {
                    $useful_links_html.='<tr><td colspan="2"><a href="'.$col.'" target="_blank" class="fs-4 cks"><span style="font-size: 15px;">'.$col.'</span></a></td></tr>';
                }
                else
                {
                        if($col!="")
                                $link_title_html='<tr><td colspan="2" class="fs-4 cls"><span style="font-size: 15px;">'.$col.'</span></td></tr>';
                }
            }
            if($useful_links_html!="")
            {
                //if($link_title_html=="")
                    //$link_title_html='<tr><td colspan="2">&nbsp;</td></tr>';
                $links_html.=$link_title_html.$useful_links_html;
            }
        }
        $document_html="";$media_html="";
        if($post_data['document_files']!="")
        {
                $doc_details =array();
                if($post_data['local']=="2")
                {
                        $doc_arr=explode(",",$post_data['document_files']);
                        $doc_list="";
                        foreach($doc_arr as $arr)
                        {
                                $doc_id="";
                                if (strpos($arr, "d*o*m") !== false) 
				{
                                        $doc_loc=explode("d*o*m",$arr);
                                        $cond="select id from documents where document_unique_name='".$doc_loc[2]."'";
                                        $doc_id_details = $this->users_model->special_fetch($cond);
                                        if(count($doc_id_details)>0)
                                                $doc_id=$doc_id_details[0]['id'];
                                }
                                else
                                {
                                        $doc_id=$arr;
                                }
                                if($doc_list=="")
                                        $doc_list=$doc_id;
                                else
                                        $doc_list=$doc_list.",".$doc_id;
                        }
                        $cond="select document_unique_name from documents where id in(".$doc_list.") ORDER BY FIELD(id,".$doc_list.")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
                else
                {
                        $cond="select document_unique_name from documents where id in(".$post_data['document_files'].") ORDER BY FIELD(id,".$post_data['document_files'].")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
                
            foreach($doc_details as $doc)
            {
                $ext = strtolower(pathinfo($doc['document_unique_name'], PATHINFO_EXTENSION));
                $icon=$this->get_icon($ext);
                if($ext=='aif'||$ext=='cda'||$ext=='mid'||$ext=='mp3'||$ext=='midi'||$ext=='mpa'||$ext=='ogg'||$ext=='wav'||$ext=='wma'||$ext=='wpl'||$ext=='3g2'||$ext=='3gp'||$ext=='avi'||$ext=='flv'||$ext=='h264'||$ext=='m4v'||$ext=='mkv'||$ext=='mov'||$ext=='mp4'||$ext=='mpg'||$ext=='rm'||$ext=='swf'||$ext=='vob'||$ext=='wmv')
                {
                        $media_html.='<tr>';
                        $media_html.='<td width="10%"><img style="width:30px;" src="'.$base_url . 'assets/uploads/user_files/'.$icon.'" /></td><td width="90%" valign="bottom"><span style="font-size:16px;color:blue;text-decoration:underline;">'.$base_url.'download_file/'.$doc['document_unique_name'].'</span></td>';
                        $media_html.='</tr>';
                }
                else
                {
                        $document_html.='<tr>';
                        $document_html.='<td width="10%"><img style="width:30px;" src="'.$base_url . 'assets/uploads/user_files/'.$icon.'" /></td><td width="90%" valign="bottom"><span style="font-size:16px;color:blue;text-decoration:underline;">'.$base_url.'download_file/'.$doc['document_unique_name'].'</span></td>';
                        $document_html.='</tr>';
                }
            }
        }
        $solution_html="";
        if($post_data['solution_files']!="")
        {
                $doc_details =array();
                if($post_data['local']=="2")
                {
                        $doc_arr=explode(",",$post_data['solution_files']);
                        $doc_list="";
                        foreach($doc_arr as $arr)
                        {
                                $doc_id="";
                                if (strpos($arr, "d*o*m") !== false) 
				{
                                        $doc_loc=explode("d*o*m",$arr);
                                        $cond="select id from documents where document_unique_name='".$doc_loc[2]."'";
                                        $doc_id_details = $this->users_model->special_fetch($cond);
                                        if(count($doc_id_details)>0)
                                                $doc_id=$doc_id_details[0]['id'];
                                }
                                else
                                {
                                        $doc_id=$arr;
                                }
                                if($doc_list=="")
                                        $doc_list=$doc_id;
                                else
                                        $doc_list=$doc_list.",".$doc_id;
                        }
                        $cond="select document_unique_name from documents where id in(".$doc_list.") ORDER BY FIELD(id,".$doc_list.")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
                else
                {
                        $cond="select document_unique_name from documents where id in(".$post_data['solution_files'].") ORDER BY FIELD(id,".$post_data['solution_files'].")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
            foreach($doc_details as $doc)
            {   
                $ext = strtolower(pathinfo($doc['document_unique_name'], PATHINFO_EXTENSION));
                $icon=$this->get_icon($ext);
                $solution_html.='<tr>';
                $solution_html.='<td width="10%"><img style="width:30px;" src="'.$base_url . 'assets/uploads/user_files/'.$icon.'" /></td><td width="90%"><span style="font-size:16px;color:blue;text-decoration:underline;">'.$base_url.'download_file/'.$doc['document_unique_name'].'</span></td>';
                $solution_html.='</tr>';
            }
        }
        $evaluation_html="";
        /* if($post_data['evaluation_files']!="")
        {
            $cond="select * from documents where id in(".$post_data['evaluation_files'].")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {
                $ext = strtolower(pathinfo($doc['document_unique_name'], PATHINFO_EXTENSION));
                $icon=$this->get_icon($ext);
                $evaluation_html.='<tr>';
                $evaluation_html.='<td width="10%"><img style="width:30px;" src="'.$base_url . 'assets/uploads/user_files/'.$icon.'" /></td><td width="90%" valign="middle"><span style="font-size:16px;color:blue;text-decoration:underline;">'.$base_url.'download_file/'.$doc['document_unique_name'].'</span></td>';
                $evaluation_html.='</tr>';
            }
        } */
        $html="";
        $html.='<apex:page applyHtmlTag="false" showHeader="false" applyBodyTag="false"><html>';
        $html.='<body>';
        $html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td>';
        $html.='<table width="100%" cellspacing="0" cellpadding="10">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td>';
        $html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td align="center"><img src="'.$teaser_image_path.'" alt="" width="300" /></td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/lesson_details.png" /></td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td bgcolor="#EFEFEF">';
        $html.='<table width="100%" cellspacing="0" cellpadding="10">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td><span style="color: #000; font-size: 16px;">'.$label_details[218]['name'].': </span><span style="color: #2ab4c0; font-size: 16px;">'.$term.'</span></td>';
        $html.='<td rowspan="3" align="right"><img src="'.$qr_code_path.'" alt="" width="125" height="125" /><br><span>'.$post_data['dossier_key'].'</span></td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td><span style="color: #000; font-size: 16px;">'.$label_details[220]['name'].': </span><span style="color: #2ab4c0; font-size: 16px;"> '.$course.'</span></td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td><span style="color: #000; font-size: 16px;">'.$label_details[221]['name'].': </span><span style="color: #2ab4c0; font-size: 16px;">'.$teacher.'</span></td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='<table width="100%" cellspacing="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/schedule_details.png" /></td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td bgcolor="#EFEFEF">';
        $html.='<table width="100%" cellspacing="0" cellpadding="10">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td colspan="2"><span style="color: #2ab4c0; font-size: 16px;">'.$post_data['title'].'</span></td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td valign="top" rowspan="4" width="70%">'.$curriculum.'</td>';
        $html.='<td align="right" width="30%">'.$label_details[216]['name'].': '.$post_data['start_date'].'</td>';   
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td align="right">'.$label_details[217]['name'].': '.$post_data['end_date'].'</td>'; 
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td align="right">'.$label_details[222]['name'].': '.$language.'</td>';  
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td align="right">'.$label_details[223]['name'].': '.$post_data['estimated_time'].'</td>';    
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        $html.='<table width="100%" cellspacing="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        //Space for next page
        $html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $html.='<tbody>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='<tr>';
        $html.='<td>';
        $html.='&nbsp;';
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table>';
        //Goals
        if($post_data['goals']!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='&nbsp;';
                $html.='</td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/goals.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" cellspacing="10" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><span style="font-size: 15px;">'.$post_data['goals'].'</span></td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //Path to success
        if($post_data['path_to_success']!="")
        {
                $html.='<table width="100%" cellspacing="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='&nbsp;';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/path_to_success.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" cellspacing="0" cellpadding="10">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><span style="font-size: 15px;">'.$post_data['path_to_success'].'</span></td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //Task
        if($post_data['task']!="")
        {
                $html.='<table width="100%" cellspacing="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='&nbsp;';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/task.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" cellspacing="0" cellpadding="10">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><span style="font-size: 15px;">'.$post_data['task'].'</span></td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //Links
        if($links_html!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/links.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td bgcolor="#FFFFFF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.=$links_html;
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //End Links
        //Media
        if($media_html!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/media_files_pdf_image.jpg" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td bgcolor="#FFFFFF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.=$media_html;
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //End Media
        
        //Learning Materials
        if($document_html!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/learning_materials.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td bgcolor="#FFFFFF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.=$document_html;
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //End Learning Materials
        if($post_data['description']!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='&nbsp;';
                $html.='</td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td bgcolor="#FFFFFF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
		$html.='<td><span style="font-size: 15px;">'.$post_data['description'].'</span></td>';
		$html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //End Documents
        //Solutions
        if($solution_html!="")
        {
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td><img src="'.$base_url . 'assets/uploads/user_files/solutions.png" /></td>';
                $html.='</tr>';
                $html.='<tr>';
                $html.='<td bgcolor="#EFEFEF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td>';
                $html.='<table width="100%" cellspacing="0" cellpadding="0">';
                $html.='<tbody>';
                $html.='<tr>';
                $html.='<td bgcolor="#FFFFFF">';
                $html.='<table width="100%" style="padding:10px">';
                $html.='<tbody>';
                $html.=$solution_html;
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
                $html.='</td>';
                $html.='</tr>';
                $html.='</tbody>';
                $html.='</table>';
        }
        //End Solutions
        $html.='</td>';
        $html.='</tr>';
        $html.='</tbody>';
        $html.='</table></body></html></apex:page>';
        // create new PDF document
        $pdf = new Pdf(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        // set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('Jason Thompson');
        $pdf->SetTitle('PROSCOLA');
        $pdf->SetSubject('Proscola Lessons');
        $pdf->SetKeywords('Proscola, Lesson');
        $header_html="";
        $header_html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $header_html.='<tbody>';
        $header_html.='<tr>';
        $header_html.='<td>';
        $header_html.='<table width="100%" cellspacing="0" cellpadding="0">';
        $header_html.='<tbody>';
        $header_html.='<tr>';
        $header_html.='<td width="70%" rowspan="4" align="left" valign="middle"><img width="150px" height="75px" src="'.$logo_path.'" alt="" /></td>';
        $header_html.='<td width="30%"><strong><span style="font-size: 14px;">'.$school_details[0]['name'].'</span></strong></td>';
        $header_html.='</tr>';
        $header_html.='<tr>';
        $header_html.='<td><a href="mailto:'.$school_details[0]['gen_email'].'">'.$school_details[0]['gen_email'].'</a></td>';
        $header_html.='</tr>';
        $header_html.='<tr>';
        $header_html.='<td>'.$school_address.'</td>';
        $header_html.='</tr>';
        $header_html.='<tr>';
        $header_html.='<td>'.$school_details[0]['phone_no'].'</td>';
        $header_html.='</tr>';
        $header_html.='</tbody>';
        $header_html.='</table>';
        $header_html.='</td>';
        $header_html.='</tr>';
        $header_html.='</tbody>';
        $header_html.='</table>';
        $pdf->setHeaderData($ln='', $lw=0, $ht='', $hs=$header_html, $tc=array(0,0,0), $lc=array(0,0,0));
        $cond="select s.value from system_settings s where s.key='dossier-pdf-footer-text'";
        $sys_details = $this->users_model->special_fetch($cond);
        $pdf->setFooterText($sys_details[0]['value']);
        // set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
        $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
        $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

        // set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

        // set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
        // set font
        $pdf->SetFont('helvetica', '', 10);
        // add a page
        $pdf->AddPage();
        $pdf->writeHTML($html, true, false, true, false, '');
        $path=getcwd();
        $server_path=$path."/assets/uploads/pdf_files";
        $filename="temp_".time().".pdf"; 
        $fileNL = $server_path."/".$filename;
        $pdf->Output($fileNL, 'F');
        $con_pdf =new Concatpdf();
        $con_pdf->SetPrintHeader(false);
        $con_pdf->SetPrintFooter(false);
        $filePDF = $server_path."/".$filename;
        $con_pdf->addPdf_to_pdf($filePDF);
        if($post_data['document_files']!="")
        {
                $file_server_path=$path."/assets/uploads/user_files";
                $doc_details =array();
                if($post_data['local']=="2")
                {
                        $doc_arr=explode(",",$post_data['document_files']);
                        $doc_list="";
                        foreach($doc_arr as $arr)
                        {
                                $doc_id="";
                                if (strpos($arr, "d*o*m") !== false) 
                                {
                                        $doc_loc=explode("d*o*m",$arr);
                                        $cond="select id from documents where document_unique_name='".$doc_loc[2]."'";
                                        $doc_id_details = $this->users_model->special_fetch($cond);
                                        if(count($doc_id_details)>0)
                                                $doc_id=$doc_id_details[0]['id'];
                                }
                                else
                                {
                                        $doc_id=$arr;
                                }
                                if($doc_list=="")
                                        $doc_list=$doc_id;
                                else
                                        $doc_list=$doc_list.",".$doc_id;
                        }
                        $cond="select document_unique_name from documents where id in(".$doc_list.") ORDER BY FIELD(id,".$doc_list.")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
                else
                {
                        $cond="select document_unique_name from documents where id in(".$post_data['document_files'].") ORDER BY FIELD(id,".$post_data['document_files'].")";
                        $doc_details = $this->users_model->special_fetch($cond);
                }
            foreach($doc_details as $doc)
            {
                $ext = strtolower(pathinfo($doc['document_unique_name'], PATHINFO_EXTENSION));
                $filePath = $file_server_path."/".$doc['document_unique_name'];
                if($ext=='pptx'||$ext=='ppt'||$ext=='jpg'||$ext=='jpeg'||$ext=='png'||$ext=='docx'||$ext=='doc'||$ext=='xlsx'||$ext=='xls'||$ext=='rtf')
                {       
                        if (file_exists($filePath)) 
                        {       
                                $file_name="temp_doc_".time().".pdf";
                                $this->word_convertor->convert_to_pdf($file_server_path,$filePath,$file_name);
                                $target_server_path=$path."/assets/uploads/user_files/".$file_name;
                                $con_pdf->addPdf_to_pdf($target_server_path,"");
                                unlink($target_server_path);
                        }
                        //$imagePath = $file_server_path."/".$doc['document_unique_name'];
                        //$con_pdf->addImage_to_pdf($imagePath,"");
                }
                else if($ext=='pdf')
                {
                        if (file_exists($filePath)) 
                        {
                                $con_pdf->addPdf_to_pdf($filePath,"");
                        }
                }
                /*else if($ext=='doc'||$ext=='docx')
                {
                        
                        $target_server_path=$path."/assets/uploads/pdf_files/temp_doc_".time().".pdf";
                        $this->word_convertor->doc_to_html($filePath,$target_server_path,$ext);
                        $con_pdf->addPdf_to_pdf($target_server_path,"");
                        unlink($target_server_path);
                } */
            }
        }
        $final_pdf = $server_path."/".$post_data['dossier_key'].".pdf";
        $con_pdf->Output($final_pdf, 'F');
        unlink($fileNL);
    }
    function merge_pdf()
    {
        $path=getcwd();
        $server_path=$path."/assets/uploads/user_files";
        $con_pdf =new Concatpdf();
        $con_pdf->SetPrintHeader(false);
        $con_pdf->SetPrintFooter(false);
        $filePDF = $server_path."/new_ppt_testing.pdf";
        $con_pdf->addPdf_to_pdf($filePDF);
        $final_pdf = $server_path."/final.pdf";
        $con_pdf->Output($final_pdf, 'F');
    }
    function convert_to_ppt()
    {
        $path=getcwd();
        $file_server_path=$path."/assets/uploads/user_files";
        $filePath = $file_server_path."/ppt_for_new_testing.pptx";
        $file_name="new_ppt_testing.pdf";
        $this->word_convertor->convert_to_pdf($file_server_path,$filePath,$file_name);
        echo "done";
    }
    function get_string_between($string, $start, $end){
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }
    function file_find()
    {
        $path=getcwd();
        $file_server_path=$path."/assets/uploads/user_files";
        $filePath = $file_server_path."/1655366008905_1.pdf";
        if (file_exists($filePath)) 
        {
                echo "found";
        }
        else
        {
                echo "not found";
        } 
    }
    function get_word_content()
    {   
        /* $path=getcwd();
        $file_server_path=$path."/assets/uploads"; */
        //$filePath = $file_server_path."/1655366037488_2.docx";
        /* $filePath = $file_server_path."/Structure of the lesson and content view.docx";
        $target_server_path=$path."/assets/uploads/pdf_files/temp_doc_".time().".pdf"; */
        //$this->word_convertor->doc_to_html($filePath,$target_server_path);
        $this->word_convertor->convert_to_ppt();
        /* $path=getcwd();
        $server_path=$path."/assets/uploads/pdf_files";
        $file_server_path=$path."/assets/uploads/user_files/Upwork steps.docx";
        $content=$this->word_convertor->doc_to_html($file_server_path);
        echo $content; */
    }
    function gen_html_to_pdf()
    {
        $html = '<html>
        <head>
            <style>
                /** 
                    Set the margins of the page to 0, so the footer and the header
                    can be of the full height and width !
                 **/
                @page {
                    margin: 0cm 0cm;
                }
    
                /** Define now the real margins of every page in the PDF **/
                body {
                    margin-top: 2cm;
                    margin-left: 2cm;
                    margin-right: 2cm;
                    margin-bottom: 2cm;
                }
    
                /** Define the header rules **/
                header {
                    position: fixed;
                    top: 0cm;
                    left: 0cm;
                    right: 0cm;
                    height: 2cm;
    
                    /** Extra personal styles **/
                    background-color: #03a9f4;
                    color: white;
                    text-align: center;
                    line-height: 1.5cm;
                }
    
                /** Define the footer rules **/
                footer {
                    position: fixed; 
                    bottom: 0cm; 
                    left: 0cm; 
                    right: 0cm;
                    height: 2cm;
    
                    /** Extra personal styles **/
                    background-color: #03a9f4;
                    color: white;
                    text-align: center;
                    line-height: 1.5cm;
                }
            </style>
        </head>
        <body>
            <!-- Define header and footer blocks before your content -->
            <header>
                Our Code World
            </header>
    
            <footer>
                Copyright &copy; <?php echo date("Y");?> 
            </footer>
    
            <!-- Wrap the content of your PDF inside a main tag -->
            <main>
                <h1>Hello World</h1>
            </main>
        </body>
    </html>
    ';
        $this->word_convertor->convert_pdf_to_html($html);
    }
    
    
        function edit_dossiers(){
                $user_det = $this->session->userdata('user_det');
        $cUrl = $this->get_service_api().'edit_dossiers';
        $id = $this->input->post('token_id');    
        $user_det = $this->session->userdata('user_det');
        $personnel_id=$user_det['id'];
        $term_id = $this->input->post('term_id');
        $subject_id = $this->input->post('subject_id');
        $dossier_language_id = $this->input->post('language_id');
        $course_id = $this->input->post('course_id');
        $curriculum_item_id = $this->input->post('curriculum_item_id');
        if($curriculum_item_id=="")
        {
                $curriculum_item_id = 0;
        }
        $teaser_image = $this->input->post('school_logo_file_name');
        $teaser_text = $this->input->post('teaser_text');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $group_chk = $this->input->post('group_chk');
        $individual_chk = $this->input->post('individual_chk');
        $remote_chk = $this->input->post('remote_chk');
        $published = $this->input->post('published');
        $local_visible = $this->input->post('local_visible');
        $local_duplication = $this->input->post('local_duplication');
        $global_visible = $this->input->post('global_visible');
        $global_duplication = $this->input->post('global_duplication');
        $title = $this->input->post('title');
        $estimated_time = $this->input->post('estimated_time');
        $goals = $this->input->post('goals');
        $path_to_success = $this->input->post('path_to_success');
        $task = $this->input->post('task');
        $keywords = json_decode($this->input->post('keywords'),true);
        $useful_links = $this->input->post('useful_links');
        $document_files = $this->input->post('document_files');
        $files_order = $this->input->post('files_order');
        $description = $this->input->post('description');
        $solution_files = $this->input->post('solution_files');
        $solutions_published = $this->input->post('solutions_published');
        $evaluation_files = $this->input->post('evaluation_files');
        $rating = $this->input->post('rating');
        $eva_total_count = $this->input->post('eva_total_count');
        $qr_code = $this->input->post('qr_code_up');
        $evaluation_details=array();
        $evaluation_files_arr=explode(",",$evaluation_files);
        $eva_total_count_arr=explode(",",$eva_total_count);
        $i=0;
        if($evaluation_files!="")
        {
                foreach($eva_total_count_arr as $id_val)
                {
                        $m_id="eva_mark_category_id_up_".$id_val;
                        $eva_mark_category_id = $this->input->post($m_id);
                        $d_id="eva_date_up_".$id_val;
                        $eva_evaluation_date = $this->input->post($d_id);
                        $k_id="eva_keywords_up_".$id_val;
                        $post_keywords=$this->input->post($k_id);
                        $eva_words="";
                        if($post_keywords!="")
                        {
                                $eva_keywords = json_decode($post_keywords,true);
                                foreach($eva_keywords as $eva_keys)
                                {
                                        if($eva_words=="")
                                                $eva_words=$eva_keys['value'];
                                        else
                                                $eva_words=$eva_words.",".$eva_keys['value'];
                                }
                        }
                        $de_id="eva_description_up_".$id_val;
                        $eva_description = $this->input->post($de_id);
                        $evaluation_details[]=array(
                        "dossier_id"=>$id,
                        "dossier_file_id"=>$evaluation_files_arr[$i],
                        "mark_category_id"=>$eva_mark_category_id,
                        "evaluation_date"=>$eva_evaluation_date,
                        "keywords"=>$eva_words,
                        "description"=>$eva_description,
                        );
                }
        }
        $words="";
        foreach($keywords as $keys)
        {
                if($words=="")
        $words=$keys['value'];
                else
        $words=$words.",".$keys['value'];
        }
                if(!isset($group_chk))
        $group_chk=0;
                else
        $group_chk=5;
                if(!isset($individual_chk))
        $individual_chk=0;
                else
        $individual_chk=6;
                if(!isset($remote_chk))
        $remote_chk=0;
                else
        $remote_chk=7;
                if(isset($local_visible))
        $local_visible=1;
                else
        $local_visible=0;   
                if(isset($local_duplication))
        $local_duplication=1;
                else
        $local_duplication=0; 
                if(isset($global_visible))
        $global_visible=1;
                else
        $global_visible=0; 
                if(isset($global_duplication))
        $global_duplication=1;
                else
        $global_duplication=0;
                if(isset($published))
        $published=1;
                else
        $published=0;
                if(isset($solutions_published))
        $solutions_published=1;
                else
        $solutions_published=0;
        $des_path=getcwd();
        $file_des_name="temp_doc_".time().".png";
        $file_des_path=$des_path."/assets/uploads/user_files/".$file_des_name;
        $no_occ=substr_count($description, 'src="data:image/png;base64,');
        for($i=0;$i<$no_occ;$i++)
        {
                if (stripos($description, 'src="data:image/png;base64,') !== false) 
                {
                        $base64_string = $this->get_string_between($description, 'src="data:image/png;base64,', '"');
                        file_put_contents($file_des_path, base64_decode($base64_string));
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                        $url = $actual_link."/assets/uploads/user_files/".$file_des_name;
                        $description=str_replace('data:image/png;base64,'.$base64_string,$url,$description);
                }
        }
        $post_data = array(
        'id'=>$id,
        'term_id'=>$term_id,
        'subject_id'=>$subject_id,
        'personnel_id'=>$personnel_id,
        'dossier_language_id'=>$dossier_language_id ,
        'course_id'=>$course_id,
        'curriculum_item_id'=>$curriculum_item_id,
        'teaser_image'=>$teaser_image,
        'teaser_text'=>$teaser_text,
        'start_date'=>$start_date,
        'end_date'=>$end_date,
        'group_chk'=>$group_chk,
        'individual_chk'=>$individual_chk,
        'remote_chk'=>$remote_chk,
        'local_visible'=>$local_visible,
        'local_duplication'=>$local_duplication,
        'global_visible'=>$global_visible,
        'global_duplication'=>$global_duplication,
        'published'=>$published,
        'title'=>$title,
        'estimated_time'=>$estimated_time,
        'goals'=>$goals,
        'path_to_success'=>$path_to_success,
        'task'=>$task,
        'keywords'=>$words,
        'useful_links'=>$useful_links,
        'description'=>$description,
        'solution_files'=>$solution_files,
        'document_files'=>$document_files,
        'files_order'=>$files_order,
        'solutions_published'=>$solutions_published,
        'rating'=>$rating,
        'lang_id'=>$user_det['lang_id'],
        'evaluation_details'=>$evaluation_details
          );
         
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        set_time_limit(0);
        ob_end_clean();
        header("Connection: close");
        ob_start();
        echo $result;
        $size = ob_get_length();
        header("Content-Length: $size");
        ob_end_flush(); // Strange behaviour, will not work
        flush();            // Unless both are called !
        session_write_close(); // Added a line suggested in the comment */
        $evaluation_files="";
        foreach($evaluation_details as $eva)
        {
            if($evaluation_files=="")
                $evaluation_files=$eva['id'];
            else   
                $evaluation_files=$evaluation_files.",".$eva['id'];
        }
        $cond="select dossier_key from dossiers where id=".$id;
        $dos_details = $this->users_model->special_fetch($cond);
        $dossier_key=$dos_details[0]['dossier_key'];
        // Do processing here
        $files_order_arr=explode(",",$files_order);
        $document_files_arr=explode(",",$document_files);
        $files_arr=array();
        foreach($files_order_arr as $fil)
        {       
               $files_arr[]= $document_files_arr[$fil];
        }
        $document_files=implode(",",$files_arr);
        $pdf_data = array(
                'dossier_key'=>$dossier_key,
                'term_id'=>$term_id,
                'personnel_id'=>$personnel_id,
                'dossier_language_id'=>$dossier_language_id ,
                'course_id'=>$course_id,
                'curriculum_item_id'=>$curriculum_item_id,
                'teaser_image'=>$teaser_image,
                'teaser_text'=>$teaser_text,
                'start_date'=>$start_date,
                'end_date'=>$end_date,
                'local'=>"",
                'task'=>$task,
                'title'=>$title,
                'estimated_time'=>$estimated_time,
                'goals'=>$goals,
                'path_to_success'=>$path_to_success,
                'useful_links'=>$useful_links,
                'description'=>$description,
                'solution_files'=>$solution_files,
                'document_files'=>$document_files,
                'evaluation_files'=>$evaluation_files,
                'qr_code'=>$qr_code
        );
        $this->generate_pdf($pdf_data); 
        $pdf_post_data = array(
                'dossier_key'=>$dossier_key
        );
        $cUrl = $this->get_service_api().'update_dossiers_pdf_status';
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pdf_post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result1 = curl_exec($ch);
        curl_close($ch);
        if($document_files!="")
        {
            $cond="select * from documents where id in(".$document_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $solution_html="";
        if($solution_files!="")
        {
            $cond="select * from documents where id in(".$solution_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $evaluation_html="";
        if($evaluation_files!="")
        {
            $cond="select * from documents where id in(".$evaluation_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        die();    
    }
    function duplicate_dossiers(){
        $user_det = $this->session->userdata('user_det');
        $cUrl = $this->get_service_api().'duplicate_dossiers';
        $id = $this->input->post('token_id'); 
        $dom_id = $this->input->post('dom_id'); 
        $personnel_id=$user_det['id'];
        $term_id = $this->input->post('term_id');
        $subject_id = $this->input->post('subject_id');
        $dossier_language_id = $this->input->post('language_id');
        $course_id = $this->input->post('course_id');
        $curriculum_item_id = $this->input->post('curriculum_item_id');
        if($curriculum_item_id=="")
        {
                $curriculum_item_id = 0;
        }
        $teaser_image = $this->input->post('school_logo_file_name');
        $teaser_text = $this->input->post('teaser_text');
        $start_date = $this->input->post('start_date');
        $end_date = $this->input->post('end_date');
        $group_chk = $this->input->post('group_chk');
        $individual_chk = $this->input->post('individual_chk');
        $remote_chk = $this->input->post('remote_chk');
        $published = $this->input->post('published');
        $local_visible = $this->input->post('local_visible');
        $local_duplication = $this->input->post('local_duplication');
        $global_visible = $this->input->post('global_visible');
        $global_duplication = $this->input->post('global_duplication');
        $title = $this->input->post('title');
        $estimated_time = $this->input->post('estimated_time');
        $goals = $this->input->post('goals');
        $path_to_success = $this->input->post('path_to_success');
        $task = $this->input->post('task');
        $local = $this->input->post('local_global');
        $keywords = json_decode($this->input->post('keywords'),true);
        $useful_links = $this->input->post('useful_links');
        $document_files = $this->input->post('document_files');
        $files_order = $this->input->post('files_order');
        $description = $this->input->post('description');
        $solution_files = $this->input->post('solution_files');
       $solutions_published = $this->input->post('solutions_published');
       $evaluation_files = $this->input->post('evaluation_files');
       $rating = $this->input->post('rating');
       $eva_total_count = $this->input->post('eva_total_count');
        $evaluation_details=array();
        $eva_total_count_arr=array();
        if($evaluation_files!="")
        {
                $evaluation_files_arr=explode(",",$evaluation_files);
                $eva_total_count_arr=explode(",",$eva_total_count);
                $i=0;
                foreach($eva_total_count_arr as $id_val)
                {
                        $m_id="eva_mark_category_id_dup_".$id_val;
                        $eva_mark_category_id = $this->input->post($m_id);
                        $d_id="eva_date_dup_".$id_val;
                        $eva_evaluation_date = $this->input->post($d_id);
                        $k_id="eva_keywords_dup_".$id_val;
                        $post_keywords=$this->input->post($k_id);
                        $eva_words="";
                        if($post_keywords!="")
                        {
                        $eva_keywords = json_decode($post_keywords,true);
                        foreach($eva_keywords as $eva_keys)
                        {
                                if($eva_words=="")
                        $eva_words=$eva_keys['value'];
                                else
                        $eva_words=$eva_words.",".$eva_keys['value'];
                        }
                        }
                        $de_id="eva_description_dup_".$id_val;
                        $eva_description = $this->input->post($de_id);
                        $evaluation_details[]=array(
                        "dossier_id"=>$id,
                        "dossier_file_id"=>$evaluation_files_arr[$i],
                        "mark_category_id"=>$eva_mark_category_id,
                        "evaluation_date"=>$eva_evaluation_date,
                        "keywords"=>$eva_words,
                        "description"=>$eva_description
                        );
                }
        }
                $words="";
                foreach($keywords as $keys)
                {
                        if($words=="")
                $words=$keys['value'];
                        else
                $words=$words.",".$keys['value'];
                }
                        if(!isset($group_chk))
                $group_chk=0;
                        else
                $group_chk=5;
                        if(!isset($individual_chk))
                $individual_chk=0;
                        else
                $individual_chk=6;
                        if(!isset($remote_chk))
                $remote_chk=0;
                        else
                $remote_chk=7;
                        if(isset($local_visible))
                $local_visible=1;
                        else
                $local_visible=0;   
                        if(isset($local_duplication))
                $local_duplication=1;
                        else
                $local_duplication=0; 
                        if(isset($global_visible))
                $global_visible=1;
                        else
                $global_visible=0; 
                        if(isset($global_duplication))
                $global_duplication=1;
                        else
                $global_duplication=0;
                        if(isset($published))
                $published=1;
                        else
                $published=0;
                        if(isset($solutions_published))
                $solutions_published=1;
                        else
                $solutions_published=0;
        $cond="select name from subjects where id=".$subject_id;
        $sub_details = $this->users_model->special_fetch($cond);
        $sub=strtoupper(substr($sub_details[0]['name'],0,3));
        $cond="select name from terms where id=".$term_id;
        $term_details = $this->users_model->special_fetch($cond);
        $term_sub=strtoupper(substr($term_details[0]['name'],0,3));
        $start_date=str_replace("/","-",$start_date);
        $start_date_arr=explode("-",$start_date);
        $hour_date = date("H");
        $min_date = date("i");
        $dossier_key=$sub."-".$term_sub."-".$start_date_arr[2].$start_date_arr[1].$start_date_arr[0]."-".$hour_date.$min_date;
        $file_name = $dossier_key."-Qrcode" . rand(2,200) . ".png";
        $uploads_dir = 'assets/uploads/user_files';
        $file_path=$uploads_dir.'/'.$file_name;
        $dos_key_hash=urlencode(base64_encode($dossier_key));
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
        $url = $actual_link."/dossiers/dossier_preview/".$dos_key_hash;
        $params=array();
        $params['data'] = $url;
        $params['level'] = 'H';
        $params['size'] = 10;
        $params['savename'] = $file_path;
        $this->ciqrcode->generate($params);
        $post_data = array(
        'id'=>$id,
        'dossier_key'=>$dossier_key,
        'term_id'=>$term_id,
        'subject_id'=>$subject_id,
        'personnel_id'=>$personnel_id,
        'dossier_language_id'=>$dossier_language_id ,
        'course_id'=>$course_id,
        'curriculum_item_id'=>$curriculum_item_id,
        'teaser_image'=>$teaser_image,
        'teaser_text'=>$teaser_text,
        'start_date'=>$start_date,
        'end_date'=>$end_date,
        'group_chk'=>$group_chk,
        'individual_chk'=>$individual_chk,
        'remote_chk'=>$remote_chk,
        'local'=>$local,
        'local_visible'=>$local_visible,
        'local_duplication'=>$local_duplication,
        'global_visible'=>$global_visible,
        'global_duplication'=>$global_duplication,
        'published'=>$published,
        'title'=>$title,
        'estimated_time'=>$estimated_time,
        'goals'=>$goals,
        'path_to_success'=>$path_to_success,
        'task'=>$task,
        'keywords'=>$words,
        'useful_links'=>$useful_links,
        'description'=>$description,
        'solution_files'=>$solution_files,
        'document_files'=>$document_files,
        'files_order'=>$files_order,
        'solutions_published'=>$solutions_published,
        'evaluation_details'=>$evaluation_details,
        'rating'=>$rating,
        'lang_id'=>$user_det['lang_id'],
        'qr_code'=>$file_name
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        set_time_limit(0);
        ob_end_clean();
        header("Connection: close");
        ob_start();
        echo $result;
        $size = ob_get_length();
        header("Content-Length: $size");
        ob_end_flush(); // Strange behaviour, will not work
        flush();            // Unless both are called !
        session_write_close(); // Added a line suggested in the comment */
        // Do processing here
        $files_order_arr=explode(",",$files_order);
        $document_files_arr=explode(",",$document_files);
        $files_arr=array();
        foreach($files_order_arr as $fil)
        {       
               $files_arr[]= $document_files_arr[$fil];
        }
        $document_files=implode(",",$files_arr);
        $pdf_data = array(
                'dossier_key'=>$dossier_key,
                'term_id'=>$term_id,
                'personnel_id'=>$personnel_id,
                'dossier_language_id'=>$dossier_language_id ,
                'course_id'=>$course_id,
                'curriculum_item_id'=>$curriculum_item_id,
                'teaser_image'=>$teaser_image,
                'teaser_text'=>$teaser_text,
                'start_date'=>$start_date,
                'local'=>$local,
                'end_date'=>$end_date,
                'task'=>$task,
                'title'=>$title,
                'estimated_time'=>$estimated_time,
                'goals'=>$goals,
                'path_to_success'=>$path_to_success,
                'useful_links'=>$useful_links,
                'description'=>$description,
                'solution_files'=>$solution_files,
                'document_files'=>$document_files,
                'evaluation_files'=>$evaluation_files,
                'qr_code'=>$file_name
        );
        $this->generate_pdf($pdf_data); 
        $pdf_post_data = array(
                'dossier_key'=>$dossier_key
        );
        $cUrl = $this->get_service_api().'update_dossiers_pdf_status';
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pdf_post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result1 = curl_exec($ch);
        curl_close($ch);
        if($document_files!="")
        {
            $cond="select * from documents where id in(".$document_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $solution_html="";
        if($solution_files!="")
        {
            $cond="select * from documents where id in(".$solution_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        $evaluation_html="";
        if($evaluation_files!="")
        {
            $cond="select * from documents where id in(".$evaluation_files.")";
            $doc_details = $this->users_model->special_fetch($cond);
            foreach($doc_details as $doc)
            {   
                $this->store_document_content($doc['document_unique_name'],$doc['id']);
            }
        }
        die();    
    }
	function delete_dossiers(){
                $user_det = $this->session->userdata('user_det');
                $cUrl = $this->get_service_api().'delete_dossiers';
        $ids = $this->input->post('ids');
        $post_data = array(
        'lang_id'=>$user_det['lang_id'],
        'user_id'=>$user_det['id'],
        'group_id'=>$user_det['group_id'],
        'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    } 
    function restore_dossiers(){
        $user_det = $this->session->userdata('user_det');
$cUrl = $this->get_service_api().'restore_dossiers';
        $ids = $this->input->post('ids');
$post_data = array(
        'lang_id'=>$user_det['lang_id'],
'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    } 
    function send_task_dossiers(){
        $user_det = $this->session->userdata('user_det');
        $cUrl = $this->get_service_api().'send_task_dossiers';
        $ids = $this->input->post('ids');
        $post_data = array(
        'lang_id'=>$user_det['lang_id'],
        'user_id'=>$user_det['id'],
        'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
        } 
    function get_dossiers_type(){        
        $cUrl = $this->get_service_api().'get_dossiers_type';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    }
    function get_dossiers_type_global(){        
        $cUrl = $this->get_service_api().'get_dossiers_type_global';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    }
    
    function get_curriculum_items(){        
$cUrl = $this->get_service_api().'get_curriculum_items';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    }
    function get_school_data(){        
        $cUrl = $this->get_service_api().'get_school_data';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;    
    }
    function download_doc($file_name)
    {
        $path=getcwd();
        $file_name=$file_name.".pdf";
        $file_path=$path."/assets/uploads/pdf_files/".$file_name;
        //$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/pdf_files/".$file_name;
        // make sure it's a file before doing anything!
        if(is_file($file_path))
        {
                // required for IE
                if(ini_get('zlib.output_compression')) { ini_set('zlib.output_compression', 'Off'); }

                // get the file mime type using the file extension
                $this->load->helper('file');

                $mime = get_mime_by_extension($file_path);

                // Build the headers to push out the file properly.
                header('Pragma: public');     // required
                header('Expires: 0');         // no cache
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($file_path)).' GMT');
                header('Cache-Control: private',false);
                header('Content-Type: '.$mime);  // Add the mime type from Code igniter.
                header('Content-Disposition: attachment; filename="'.basename($file_name).'"');  // Add the file name
                header('Content-Transfer-Encoding: binary');
                header('Content-Length: '.filesize($file_path)); // provide file size
                header('Connection: close');
                readfile($file_path); // push it out
                exit();
        }             
    }  
    function download_messages_doc($file_name)
    {
        $path=getcwd();
        $file_path=$path."/assets/uploads/pdf_files/".$file_name;
        //$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/user_files/".$file_name;
        // make sure it's a file before doing anything!
        if(is_file($file_path))
        {
                // required for IE
                if(ini_get('zlib.output_compression')) { ini_set('zlib.output_compression', 'Off'); }

                // get the file mime type using the file extension
                $this->load->helper('file');

                $mime = get_mime_by_extension($file_path);

                // Build the headers to push out the file properly.
                header('Pragma: public');     // required
                header('Expires: 0');         // no cache
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($file_path)).' GMT');
                header('Cache-Control: private',false);
                header('Content-Type: '.$mime);  // Add the mime type from Code igniter.
                header('Content-Disposition: attachment; filename="'.basename($file_name).'"');  // Add the file name
                header('Content-Transfer-Encoding: binary');
                header('Content-Length: '.filesize($file_path)); // provide file size
                header('Connection: close');
                readfile($file_path); // push it out
                exit();
        }             
    }  
        function dossier_preview($dossier_key) 
        {
                $dossier_key = base64_decode(urldecode($dossier_key));
                $cond="select id,dossier_key from dossiers where dossier_key='".$dossier_key."'";
                $dos_details = $this->users_model->special_fetch($cond);
                if(count($dos_details)>0)
                {
                        $cond="select s.value from system_settings s where s.key='current-ui-language'";
                        $sys_details = $this->users_model->special_fetch($cond);
                        if(count($sys_details)>0)
                        {
                                $cond="select id from languages where locale='".$sys_details[0]['value']."'";
                                $lang_details = $this->users_model->special_fetch($cond);
                                if(count($lang_details)>0)
                                {
                                        $cond="select name from labels where page_id=40 and lang_id=".$lang_details[0]['id'];
                                        $label_details = $this->users_model->special_fetch($cond);
                                        $this->data['label_details'] = $label_details;
                                        $this->data['dossier_key_id'] = $dos_details[0]['id'];
                                        $this->data['dossier_key'] = $dos_details[0]['dossier_key'];
                                        $this->load->view($this->view_dir . 'dossier_preview', $this->data);
                                }
                                else
                                {
                                        $this->data['error_message'] = '';
                                        $this->data['username'] = '';
                                        $this->load->view($this->view_dir . 'login', $this->data);
                                }
                        }
                        else
                        {
                                $this->data['error_message'] = '';
                                $this->data['username'] = '';
                                $this->load->view($this->view_dir . 'login', $this->data);
                        }
                }
                else
                {
                        $this->data['error_message'] = '';
                        $this->data['username'] = '';
                        $this->load->view($this->view_dir . 'login', $this->data);
                }
        }   
        
        function test_url()
        {       
                echo $url = urlencode(base64_encode("ENG-202-31-08-2022-0540"));
                //echo $addr = base64_decode(urldecode($url));
                //http://ampayonsses.proscola.org/dossiers/dossier_preview/
                //echo $dossier_key = base64_decode(urldecode('RU5HLTIyXy0xMS0xMC0yMDIyLTA3Mjg%3D'));
        }
        function get_dossier_preview_by_id()
        {
                $cUrl = $this->get_service_api().'get_dossier_preview_by_id';
                $id = $this->input->post('id');
                $post_data = array(
                        'id'=>$id
                );
                $reqhdrs = array('Accept: application/json');       
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
                curl_setopt($ch, CURLOPT_VERBOSE, 1);
                $result = curl_exec($ch);
                curl_close($ch);
                echo $result;    
        } 
        function document_convert()
        {
                $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
                $id = $data['id'];
                $cond="select * from documents where id=".$id." and document_indexed=0";
                $document_details = $this->users_model->special_fetch($cond);
                if(count($document_details)>0)
                {
                        $ext = strtolower(pathinfo($document_details[0]['document_unique_name'], PATHINFO_EXTENSION));
                        $path = "./assets/uploads/user_files/".$document_details[0]['document_unique_name'];
                        $content="";
                        if($ext=='gif'||$ext=='jpg'||$ext=='jpeg'||$ext=='png')
                        {
                                $content=$this->ocr_convertor->convert_image($path);
                        }
                        else if($ext=='pdf')
                        {
                                $content=$this->pdf_convertor->convert_pdf($path);
                        }
                        else if($ext=='doc'||$ext=='docx')
                        {
                                $content=$this->word_convertor->convert_word($path);
                        }
                        else if($ext=='txt')
                        {
                                $content=file_get_contents($path);
                        }
                        else if($ext=='ppt'||$ext=='pptx')
                        {
                                $content=$this->word_convertor->pptx_to_text($path);
                        }
                        else if($ext=='xls'||$ext=='xlsx')
                        {
                                $content=$this->word_convertor->xlsx_to_text($path);
                        }
                        $content_arr=$this->split_content($content,3000);
                        foreach($content_arr as $con)
                        {       
                                $input = array(
                                        'document_id'=>$id,
                                        'document_text'=>$con
                                );
                                $this->document_text_model->add($input);
                        }
                        $input = array(
                                'document_indexed'=>1
                        );
                        $this->file_manager_model->edit($input,$id);
                        echo "done";
                }
        }
        function store_documents()
        {
                $json = file_get_contents('php://input');
		$data = json_decode($json,true); 
                $dossier_id = $data['id'];
                $cond="select dossier_file_id from dossiers_related_files where dossier_id=".$dossier_id;
                $dos_rel_details = $this->users_model->special_fetch($cond);
                if(count($dos_rel_details)>0)
                {	
                        foreach($dos_rel_details as $dos_rel)
                        {
                                $cond="select id,document_unique_name from documents where id=".$dos_rel['dossier_file_id'];
                                $doc = $this->users_model->special_fetch($cond);
                                $this->store_document_content($doc[0]['document_unique_name'],$doc[0]['id']);
                        }
                }
                $cond="select dossier_file_id from dossiers_solutions where dossier_id=".$dossier_id;
                $dos_sol_details = $this->users_model->special_fetch($cond);
                if(count($dos_sol_details)>0)
                {
                        foreach($dos_sol_details as $dos_sol)
                        {
                                $cond="select id,document_unique_name from documents where id=".$dos_sol['dossier_file_id'];
                                $doc = $this->users_model->special_fetch($cond);
                                $this->store_document_content($doc[0]['document_unique_name'],$doc[0]['id']);
                        }
                }
                $cond="select dossier_file_id from dossiers_evaluations where dossier_id=".$dossier_id;
                $dos_eva_details = $this->users_model->special_fetch($cond);
                if(count($dos_eva_details)>0)
                {
                        foreach($dos_eva_details as $dos_eva)
                        {
                                $cond="select id,document_unique_name from documents where id=".$dos_eva['dossier_file_id'];
                                $doc = $this->users_model->special_fetch($cond);
                                $this->store_document_content($doc[0]['document_unique_name'],$doc[0]['id']);
                        }
                }
                echo "Done";
        }
        function document_update()
        {
                $re=$this->file_manager_model->edit_content("103","hai");
                echo $re;
        }
        function convert_pdf_to_text_dos()
        {
                $this->word_convertor->convert_pdf_to_text();
        }
}


