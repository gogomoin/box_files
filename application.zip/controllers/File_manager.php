<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class File_manager extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	function get_labels()
    {     
        $user_det = $this->session->userdata('user_det');
		$cond="select name from labels where page_id=60 and lang_id=".$user_det['lang_id'];
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }
	//Career Goals	
	
	function file_manager() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$this->get_include();
            $this->load->view($this->view_dir . 'file_manager', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_files() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['folder_id']))
			$folder_id = $_POST['folder_id'];
		else
			$folder_id ="";			
		$cUrl = $this->get_service_api().'view_files';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'user_id'=>$user_det['id'],
			'folder_id'=>$folder_id,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_folders() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['folder_id']))
			$folder_id = $_POST['folder_id'];
		else
			$folder_id ="";			
		$cUrl = $this->get_service_api().'view_folders';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'user_id'=>$user_det['id'],
			'folder_id'=>$folder_id,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_files(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_files';
        $folder_id = $this->input->post('folder_id');
        $material_original_name = $this->input->post('material_original_name');
        $material_unique_name = $this->input->post('material_unique_name');
        $post_data = array(
            'folder_id'=>$folder_id,
            'material_original_name'=>$material_original_name,
            'lang_id'=>$user_det['lang_id'],
            'material_unique_name'=>$material_unique_name
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function delete_files(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_files';
        $ids = $this->input->post('ids');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function move_to_folder_files(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'move_to_folder_files';
        $ids = $this->input->post('ids');
        $selected_folder_id = $this->input->post('selected_folder_id');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids,
            'selected_folder_id'=>$selected_folder_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function rename_files(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'rename_files';
        $file_name = $this->input->post('file_name');
        $id = $this->input->post('token_id');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'id'=>$id,
            'file_name'=>$file_name
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function download_file($file_name){
        $file_path = 'assets/uploads/user_files/'.$file_name;
		//$file_path=$_SERVER['DOCUMENT_ROOT']."/assets/uploads/user_files/".$file_name;
        // make sure it's a file before doing anything!
        if(is_file($file_path))
        {
            // required for IE
            if(ini_get('zlib.output_compression')) { ini_set('zlib.output_compression', 'Off'); }

            // get the file mime type using the file extension
            $this->load->helper('file');

            $mime = get_mime_by_extension($file_path);

            // Build the headers to push out the file properly.
            header('Pragma: public');     // required
            header('Expires: 0');         // no cache
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Last-Modified: '.gmdate ('D, d M Y H:i:s', filemtime ($file_path)).' GMT');
            header('Cache-Control: private',false);
            header('Content-Type: '.$mime);  // Add the mime type from Code igniter.
            header('Content-Disposition: attachment; filename="'.basename($file_name).'"');  // Add the file name
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: '.filesize($file_path)); // provide file size
            header('Connection: close');
            readfile($file_path); // push it out
            exit();
        }             
    }
	
	function add_new_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_new_folder';
        $folder_name = $this->input->post('folder_name');
        $old_folder_name = $this->input->post('old_folder_name');
        $folder_id = $this->input->post('folder_id');
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'folder_name'=>$folder_name,
            'old_folder_name'=>$old_folder_name,
            'folder_id'=>$folder_id,
            'lang_id'=>$user_det['lang_id'],
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function delete_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_folder';
        $ids = $this->input->post('ids');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function move_to_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'move_to_folder';
        $ids = $this->input->post('ids');
        $parent = $this->input->post('selected_folder_id');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids,
            'user_id'=>$user_det['id'],
            'parent'=>$parent
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function copy_to_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'copy_to_folder';
        $ids = $this->input->post('ids');
        $parent = $this->input->post('selected_folder_id');
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'ids'=>$ids,
            'lang_id'=>$user_det['lang_id'],
            'parent'=>$parent,
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function rename_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'rename_folder';
        $folder_name = $this->input->post('folder_name');
        $id = $this->input->post('token_id');
        $post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
            'user_id'=>$user_det['id'],
            'folder_name'=>$folder_name
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function move_or_copy_folder(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'move_or_copy_folder';
        $folder_id = $this->input->post('folder_id');
        $parent = $this->input->post('parent');
        $mode = $this->input->post('mode');
        $folder_name = $this->input->post('folder_name');
        $post_data = array(
            'folder_id'=>$folder_id,
            'parent'=>$parent,
            'mode'=>$mode,
            'user_id'=>$user_det['id'],
            'lang_id'=>$user_det['lang_id'],
            'folder_name'=>$folder_name
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    public function resizeImage($filename,$height)
	{
		$source_path = 'assets/uploads/user_files/' . $filename;
		$target_path = 'assets/uploads/user_files';
		$config_manip = array(
			  'image_library' => 'gd2',
			  'source_image' => $source_path,
			  'new_image' => $target_path,
			  'maintain_ratio' => TRUE,
			  'height' => $height,
		);
	    $this->load->library('image_lib', $config_manip);
		$this->image_lib->initialize($config_manip);
		if (!$this->image_lib->resize()) 
		{
			echo $this->image_lib->display_errors();
		}   
		$this->image_lib->clear();
	}
	function upload_attachment()
	{
        $label_details = $this->get_labels();
        if ($_FILES["attachment"]["error"] == UPLOAD_ERR_OK)
		{
            $name = $this->input->post('unqfilename');
            $type = $this->input->post('type');
            $tmp_name = $_FILES["attachment"]["tmp_name"];
            $uploads_dir = 'assets/uploads/user_files';
            move_uploaded_file($tmp_name, "$uploads_dir/$name");
            $extension = pathinfo($name, PATHINFO_EXTENSION);
            if($extension=='pdf'||$extension=='PDF')
            {
                echo json_encode(array('status' => '0','status_description' => " ".$label_details[73]['name'],'attachname' => $name));
                /* $file = $uploads_dir.'/'.$name;
                $filecontent = file_get_contents($file);
                $parsed = trim($this->get_string_between($filecontent, '%', '%'));
                $version=str_replace("PDF-","",$parsed);
                if ($version<=1.4) {
                    echo json_encode(array('status' => '0','status_description' => " ".$label_details[73]['name'],'attachname' => $name));
                } else 
                {
                    if (file_exists($file)) 
                    {
                        unlink($file);
                    }
                    echo json_encode(array('status' => '1','status_description' => " ".$label_details[91]['name'],'attachname' => ''));
                } */
            }
            else
            {
                /* if($type=="add"||$type=="edit"||$type=="school_data_add")
                {
                    $icon_name100 = "100_".$name;
                    $path='assets/uploads/user_files/';
                    copy($path.$name,$path.$icon_name100);
                    $this->resizeImage($icon_name100,75);
                } */
                echo json_encode(array('status' => '0','status_description' => " ".$label_details[73]['name'],'attachname' => $name));
            }
		}
		else
		{   
			echo json_encode(array('status' => '1','status_description' => " ".$label_details[74]['name'],"attachname"=>''));
		}
     }
    function parse_file($file)
    {
        $exts = ['pptx','ppt','pdf','docx','doc','wps','dotx','docm','dotm','dot','odt','xlsx','xls','png','jpg','jpeg','jfif'];
        $path_parts = pathinfo($file);
        $file_name=strtolower($path_parts['filename']);
        foreach($exts as $ext)
        {
            $file_name=str_replace($ext,"",$file_name);
        }
        return $file_name=$file_name.".".$path_parts['extension'];
    }
    function upload_folder_attachment()
	{
        if (isset($_FILES['attachments']))
		{
            $user_det = $this->session->userdata('user_det');
            $user_id=$user_det['id'];
            $uploads_dir = 'assets/uploads/user_files/';
            $unq_name = $this->input->post('unqfilename');
            $folder_id = $this->input->post('folder_id');
            $folder_path = $this->input->post('folder_path');
            $cond="select user_id from folders where id=".$folder_id;
            $root_fol_details = $this->users_model->special_fetch($cond);
            $parent_folder_id="";
            if(count($root_fol_details)>0)
            {
                $parent_folder_user_id=$root_fol_details[0]['user_id'];
                if($parent_folder_user_id==-1)
                    $user_id=-1;
            }  
            $root_folder_arr=explode('/',$folder_path[0]);
            $root_folder_name=$root_folder_arr[0];
            $cond="select id from folders where parent_folder=".$folder_id." and folder='".$root_folder_name."'";
            $root_fol_details = $this->users_model->special_fetch($cond);
            if(count($root_fol_details)>0)
            {
                $root_folder_id=$root_fol_details[0]['id'];
            }
            else
            {
                $input = array(
                    'folder'=>$root_folder_name,
                    'parent_folder'=>$folder_id,
                    'user_id'=>$user_id
                );
                $root_folder_id=$this->folder_manager_model->add($input);
            }
            for($count = 0; $count < count($_FILES['attachments']['name']); $count++)
            {
                $folder_arr=explode('/',$folder_path[$count]);
                if(count($folder_arr)>2)
                {
                    $temp_folder_id=$root_folder_id;
                    $fol_cnt=count($folder_arr)-1;
                    for($i=1;$i<$fol_cnt;$i++)
                    {
                        $folder_name=$folder_arr[$i];
                        $cond="select id from folders where parent_folder=".$temp_folder_id." and folder='".$folder_name."'";
                        $fol_details = $this->users_model->special_fetch($cond);
                        if(count($fol_details)>0)
                        {
                            $temp_folder_id=$fol_details[0]['id'];
                        }
                        else
                        {
                            $input = array(
                                'folder'=>$folder_name,
                                'parent_folder'=>$temp_folder_id,
                                'user_id'=>$user_id
                            );
                            $temp_folder_id=$this->folder_manager_model->add($input);
                        }
                    }
                    $unq_parse_file_name=$this->parse_file($unq_name[$count]);
                    move_uploaded_file($_FILES['attachments']['tmp_name'][$count], $uploads_dir.$unq_parse_file_name);
                    $file_size_text=$this->formatSizeUnits($_FILES['attachments']['size'][$count]);
                    $arr2 = array(
                        'folder_id' => $temp_folder_id,			
                        'document_name' => $_FILES['attachments']['name'][$count],
                        'document_unique_name' => $unq_parse_file_name,
                        'file_size' => $file_size_text,
                        'created_at' => time()
                        );		
                    $this->file_manager_model->add($arr2);
                }
                else
                {
                    $unq_parse_file_name=$this->parse_file($unq_name[$count]);
                    move_uploaded_file($_FILES['attachments']['tmp_name'][$count], $uploads_dir.$unq_parse_file_name);
                    $file_size_text=$this->formatSizeUnits($_FILES['attachments']['size'][$count]);
                    $arr2 = array(
                        'folder_id' => $root_folder_id,			
                        'document_name' => $_FILES['attachments']['name'][$count],
                        'document_unique_name' => $unq_parse_file_name,
                        'file_size' => $file_size_text,
                        'created_at' => time()
                        );		
                    $this->file_manager_model->add($arr2);
                }
            }
            echo json_encode(array('statuscode' => '200','status_description' => " Files Uploaded Successfully"));
		}
    }
    function upload_file_attachment()
	{  
        if (isset($_FILES['attachments']))
		{
            $user_det = $this->session->userdata('user_det');
            $user_id=$user_det['id'];
            $uploads_dir = 'assets/uploads/user_files/';
            $unq_name = $this->input->post('unqfilename');
            $folder_id = $this->input->post('folder_id');
            for($count = 0; $count < count($_FILES['attachments']['name']); $count++)
            {   
                $unq_parse_file_name=$this->parse_file($unq_name[$count]);
                move_uploaded_file($_FILES['attachments']['tmp_name'][$count], $uploads_dir.$unq_parse_file_name);
                $file_size_text=$this->formatSizeUnits($_FILES['attachments']['size'][$count]);
                $arr2 = array(
                    'folder_id' => $folder_id,			
                    'document_name' => $_FILES['attachments']['name'][$count],
                    'document_unique_name' => $unq_parse_file_name,
                    'file_size' => $file_size_text,
                    'created_at' => time()
                        );		
                $this->file_manager_model->add($arr2);
            }
            echo json_encode(array('status' => '0','status_description' => " Files Uploaded Successfully"));
		}
    }
    function info_php()
    {
        echo phpinfo();
    }
    function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}
     function get_string_between($string, $start, $end){
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        if ($ini == 0) return '';
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }
     function get_pdf_version(){         
        
        $file = 'assets/uploads/pdf_files/pdf_version1.4.pdf';
        $file_name="pdf_version1.4.pdf";
        $extension = pathinfo($file_name, PATHINFO_EXTENSION);
        $filecontent = file_get_contents($file);
        $parsed = trim($this->get_string_between($filecontent, '%', '%'));
        $version=str_replace("PDF-","",$parsed);
        if ($version<=1.4) {
            echo "Valid pdf";
        } else {
            echo "In Valid pdf";
        }
     }
    function remove_attachment(){         
        
        $unqname = $this->input->post('attachmentorigname');
        $file = 'assets/uploads/user_files/'.$unqname;
        if (file_exists($file)) 
        {
            unlink($file);
        }
     }	
     function get_sub_folders($id,$user_id)
     {
        $folders=array();
        $cond="select * from folders where parent_folder=".$id." and (user_id=".$user_id." or folder='Shared') and is_active=0 order by folder asc";
        $sub_fol_details = $this->users_model->special_fetch($cond);
        foreach($sub_fol_details as $sub_cat)
        {
            if($sub_cat['folder']=='PTSFRRP')
            {
                $cond="select * from folders where user_id=0 and is_active=0";
                $pub_fol_details = $this->users_model->special_fetch($cond);
                foreach($pub_fol_details as $pub_cat)
                {
                    $folders[] = array(
                        'id' => $pub_cat['id'],
                        'text' => $pub_cat['folder'],
                        'children' => ''
                    );
                }
            }
            else if($sub_cat['folder']=='Shared')
            {
                $folders[] = array(
                    'id' => $sub_cat['id'],
                    'text' => $sub_cat['folder'],
                    'children' => $this->get_sub_folders($sub_cat['id'],-1),
                );
            }
            else
            {
                if($sub_cat['folder']!='Public'&&$sub_cat['folder']!='Duplicate'&&$sub_cat['folder']!='Lessons')
                {
                    $folders[] = array(
                        'id' => $sub_cat['id'],
                        'text' => $sub_cat['folder'],
                        'children' => $this->get_sub_folders($sub_cat['id'],$user_id),
                    );
                }
            }
        }
        return $folders;
     }
     function get_all_folders($fol_id)
     {
         $user_det = $this->session->userdata('user_det');
         $user_id=$user_det['id'];
         $srcQuery="";
         if($fol_id!=0)
         {
            $srcQuery=" and id=".$fol_id;
         }
         $cond="select * from folders where parent_folder=0 and is_active=0".$srcQuery;
         $sub_fol_details = $this->users_model->special_fetch($cond);
         $folders = array();
         foreach($sub_fol_details as $sub_cat)
         {
             if($fol_id==$sub_cat['id'])
             {  
                $folders[] = array(
                    'id' => $sub_cat['id'],
                    'text' => $sub_cat['folder'],
                    'state' => array("opened"=> true,"selected"=> true),
                    'children' => $this->get_sub_folders($sub_cat['id'],$user_id),
                );
             }
             else
             {
                $folders[] = array(
                'id' => $sub_cat['id'],
                'text' => $sub_cat['folder'],
                'children' => $this->get_sub_folders($sub_cat['id'],$user_id),
                );
             }
         }
         return $folders;
     }
     function get_folder_tree($fol_id)
     {
         $folders = $this->get_all_folders($fol_id);
         header('Content-Type:application/json');
         echo json_encode($folders);
     }
}
