<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Home extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }   
    
    
	function index() 
	{		
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
            $host = $_SERVER['HTTP_HOST'];
		    $host = str_replace("www.","",$host);
            $ip=exec("hostname -I");
            $school_details=array();
            if($host==$ip)
            {
                $cond="select s.*,c.name as country from school s,countries c where s.country=c.id";
            }
            else
            {
                $cond="select s.*,c.name as country from school s,countries c where s.country=c.id and domain like '%localhost%'";
            }
            $school_details = $this->users_model->special_fetch($cond);
            $user_det = $this->session->userdata('user_det');
            $lang_id=$user_det['lang_id'];
            $cond="select name from labels where page_id=55 and lang_id=".$lang_id;
            $dashboard_details = $this->users_model->special_fetch($cond);
            $cond="SELECT n.id,n.message,n.created_at_timestamp,n.sender_id,n.type,n.is_reply_enabled FROM notifications n, notifications_recipients nr WHERE n.id=nr.notification_id and nr.recipient_id=".$user_det['id']." order by created_at_timestamp desc limit 5";
            $not_details = $this->users_model->special_fetch($cond);
            for($i=0;$i<count($not_details);$i++)
            {
                $time=$not_details[$i]['created_at_timestamp'];
                $timestamp="@".$time;
                $not_details[$i]['created_at_timestamp']=$this->time_elapsed_string($timestamp,false,$time,$dashboard_details);
                $cond="select concat(first_name,' ',last_name) as name,first_name, last_name,avatar from users where id=".$not_details[$i]['sender_id'];
                $user_details = $this->users_model->special_fetch($cond);
                if($user_details[0]['avatar']=="")
                    $not_details[$i]['avatar']="";
                else
                    $not_details[$i]['avatar']=$user_details[0]['avatar'];
                $first_name=$user_details[0]['first_name'];
                $last_name=$user_details[0]['last_name'];
                $not_details[$i]['short_name']=strtoupper($first_name[0].$last_name[0]);
                $not_details[$i]['name']=$user_details[0]['name'];
                if($not_details[$i]['type']=='note')
                    $not_details[$i]['lang_type']=$dashboard_details[103]['name'];
                else if($not_details[$i]['type']=='appointment')
                    $not_details[$i]['lang_type']=$dashboard_details[104]['name'];
                else if($not_details[$i]['type']=='task')
                    $not_details[$i]['lang_type']=$dashboard_details[105]['name'];
                else if($not_details[$i]['type']=='feedback')
                    $not_details[$i]['lang_type']=$dashboard_details[106]['name'];
                else if($not_details[$i]['type']=='document')
                    $not_details[$i]['lang_type']=$dashboard_details[107]['name'];
            }
            
            $this->data['dashboard_details'] = $dashboard_details;
            $this->data['notification_details'] = $not_details;
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['school_details'] = $school_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->get_file_manager();
            $this->get_notifications_modals();
			$this->load->view($this->view_dir . 'dashboard', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
    function test_date()
    {
        $cond="select name from labels where page_id=55 and lang_id=2";
        $dashboard_details = $this->users_model->special_fetch($cond);
        $full=false;
        $datetime="@1647021316";
        $time=1647021316;
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
        
        if($diff->d<=7)
        {
            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

        
            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v) {
                if ($diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            }
            if (!$full) $string = array_slice($string, 0, 1);
            if(count($string)>0)
                $string=array_values($string)[0];
            else
                $string='';
            if($string=='')
            {
                echo $dashboard_details[102]['name'];
            }
            else
            {
                $str_arr=explode(" ",$string);
                $day_num=$str_arr[0];
                $time_num=$str_arr[1];

                if($time_num=="day")
                    $time_num=$dashboard_details[64]['name'];
                else if($time_num=="days")
                    $time_num=$dashboard_details[65]['name'];
                else if($time_num=="month")
                    $time_num=$dashboard_details[66]['name'];
                else if($time_num=="months")
                    $time_num=$dashboard_details[67]['name'];
                else if($time_num=="year")
                    $time_num=$dashboard_details[68]['name'];
                else if($time_num=="years")
                    $time_num=$dashboard_details[69]['name'];
                else if($time_num=="hour")
                    $time_num=$dashboard_details[62]['name'];
                else if($time_num=="hours")
                    $time_num=$dashboard_details[63]['name'];
                else if($time_num=="minute")
                    $time_num=$dashboard_details[60]['name'];
                else if($time_num=="minutes")
                    $time_num=$dashboard_details[61]['name'];
                else if($time_num=="second")
                    $time_num=$dashboard_details[58]['name'];
                else if($time_num=="seconds")
                    $time_num=$dashboard_details[59]['name'];
                if($day_num==1)
                    $day_num=$dashboard_details[71]['name'];
                else if($day_num==2)
                    $day_num=$dashboard_details[72]['name'];
                else if($day_num==3)
                    $day_num=$dashboard_details[73]['name'];
                else if($day_num==4)
                    $day_num=$dashboard_details[74]['name'];
                else if($day_num==5)
                    $day_num=$dashboard_details[75]['name'];
                else if($day_num==6)
                    $day_num=$dashboard_details[76]['name'];
                else if($day_num==7)
                    $day_num=$dashboard_details[77]['name'];
                else if($day_num==8)
                    $day_num=$dashboard_details[78]['name'];
                else if($day_num==9)
                    $day_num=$dashboard_details[79]['name'];
                else if($day_num==10)
                    $day_num=$dashboard_details[80]['name'];
                else if($day_num==11)
                    $day_num=$dashboard_details[81]['name'];
                else if($day_num==12)
                    $day_num=$dashboard_details[82]['name'];
                else if($day_num==13)
                    $day_num=$dashboard_details[83]['name'];
                else if($day_num==14)
                    $day_num=$dashboard_details[84]['name'];
                else if($day_num==15)
                    $day_num=$dashboard_details[85]['name'];
                else if($day_num==16)
                    $day_num=$dashboard_details[86]['name'];
                else if($day_num==17)
                    $day_num=$dashboard_details[87]['name'];
                else if($day_num==18)
                    $day_num=$dashboard_details[88]['name'];
                else if($day_num==19)
                    $day_num=$dashboard_details[89]['name'];
                else if($day_num==20)
                    $day_num=$dashboard_details[90]['name'];
                else if($day_num==21)
                    $day_num=$dashboard_details[91]['name'];
                else if($day_num==22)
                    $day_num=$dashboard_details[92]['name'];
                else if($day_num==23)
                    $day_num=$dashboard_details[93]['name'];
                else if($day_num==24)
                    $day_num=$dashboard_details[94]['name'];
                else if($day_num==25)
                    $day_num=$dashboard_details[95]['name'];
                else if($day_num==26)
                    $day_num=$dashboard_details[96]['name'];
                else if($day_num==27)
                    $day_num=$dashboard_details[97]['name'];
                else if($day_num==28)
                    $day_num=$dashboard_details[98]['name'];
                else if($day_num==29)
                    $day_num=$dashboard_details[99]['name'];
                else if($day_num==30)
                    $day_num=$dashboard_details[100]['name'];
                else if($day_num==31)
                    $day_num=$dashboard_details[101]['name'];
                echo $day_num." ".$time_num." ".$dashboard_details[70]['name'];
            }
        }
        else
        {
            $month=date('M', $time);
            $day=date('d', $time);
            if($month=='Jan')
                $month=$dashboard_details[46]['name'];
            else if($month=='Feb')
                $month=$dashboard_details[47]['name'];
            else if($month=='Mar')
                $month=$dashboard_details[48]['name'];
            else if($month=='Apr')
                $month=$dashboard_details[49]['name'];
            else if($month=='May')
                $month=$dashboard_details[50]['name'];
            else if($month=='Jun')
                $month=$dashboard_details[51]['name'];
            else if($month=='Jul')
                $month=$dashboard_details[52]['name'];
            else if($month=='Aug')
                $month=$dashboard_details[53]['name'];
            else if($month=='Sep')
                $month=$dashboard_details[54]['name'];
            else if($month=='Oct')
                $month=$dashboard_details[55]['name'];
            else if($month=='Nov')
                $month=$dashboard_details[56]['name'];
            else if($month=='Dec')
                $month=$dashboard_details[57]['name'];
            echo $month." ".$day;
        }
    } 
    function get_un_seen_messages()
    {
        $cUrl = $this->get_service_api().'get_un_seen_messages';
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$user_det['id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;  
    }
    function get_msg_count()
    {
        $cUrl = $this->get_service_api().'get_msg_count';
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$user_det['id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
    }
    function update_is_seen_all()
    {
        $cUrl = $this->get_service_api().'update_is_seen_all';
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$user_det['id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
    }
   
    function time_elapsed_string($datetime, $full,$time,$dashboard_details) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);
        if($diff->d<=7)
        {
            $diff->w = floor($diff->d / 7);
            $diff->d -= $diff->w * 7;

        
            $string = array(
                'y' => 'year',
                'm' => 'month',
                'w' => 'week',
                'd' => 'day',
                'h' => 'hour',
                'i' => 'minute',
                's' => 'second',
            );
            foreach ($string as $k => &$v) {
                if ($diff->$k) {
                    $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
                } else {
                    unset($string[$k]);
                }
            }
        
            if (!$full) $string = array_slice($string, 0, 1);
            if(count($string)>0)
                $string=array_values($string)[0];
            else
                $string='';
            if($string=='')
            {
                return $dashboard_details[102]['name'];
            }
            else
            {
                $str_arr=explode(" ",$string);
                $day_num=$str_arr[0];
                $time_num=$str_arr[1];

                if($time_num=="day")
                    $time_num=$dashboard_details[64]['name'];
                else if($time_num=="days")
                    $time_num=$dashboard_details[65]['name'];
                else if($time_num=="month")
                    $time_num=$dashboard_details[66]['name'];
                else if($time_num=="months")
                    $time_num=$dashboard_details[67]['name'];
                else if($time_num=="year")
                    $time_num=$dashboard_details[68]['name'];
                else if($time_num=="years")
                    $time_num=$dashboard_details[69]['name'];
                else if($time_num=="hour")
                    $time_num=$dashboard_details[62]['name'];
                else if($time_num=="hours")
                    $time_num=$dashboard_details[63]['name'];
                else if($time_num=="minute")
                    $time_num=$dashboard_details[60]['name'];
                else if($time_num=="minutes")
                    $time_num=$dashboard_details[61]['name'];
                else if($time_num=="second")
                    $time_num=$dashboard_details[58]['name'];
                else if($time_num=="seconds")
                    $time_num=$dashboard_details[59]['name'];
                if($day_num==1)
                    $day_num=$dashboard_details[71]['name'];
                else if($day_num==2)
                    $day_num=$dashboard_details[72]['name'];
                else if($day_num==3)
                    $day_num=$dashboard_details[73]['name'];
                else if($day_num==4)
                    $day_num=$dashboard_details[74]['name'];
                else if($day_num==5)
                    $day_num=$dashboard_details[75]['name'];
                else if($day_num==6)
                    $day_num=$dashboard_details[76]['name'];
                else if($day_num==7)
                    $day_num=$dashboard_details[77]['name'];
                else if($day_num==8)
                    $day_num=$dashboard_details[78]['name'];
                else if($day_num==9)
                    $day_num=$dashboard_details[79]['name'];
                else if($day_num==10)
                    $day_num=$dashboard_details[80]['name'];
                else if($day_num==11)
                    $day_num=$dashboard_details[81]['name'];
                else if($day_num==12)
                    $day_num=$dashboard_details[82]['name'];
                else if($day_num==13)
                    $day_num=$dashboard_details[83]['name'];
                else if($day_num==14)
                    $day_num=$dashboard_details[84]['name'];
                else if($day_num==15)
                    $day_num=$dashboard_details[85]['name'];
                else if($day_num==16)
                    $day_num=$dashboard_details[86]['name'];
                else if($day_num==17)
                    $day_num=$dashboard_details[87]['name'];
                else if($day_num==18)
                    $day_num=$dashboard_details[88]['name'];
                else if($day_num==19)
                    $day_num=$dashboard_details[89]['name'];
                else if($day_num==20)
                    $day_num=$dashboard_details[90]['name'];
                else if($day_num==21)
                    $day_num=$dashboard_details[91]['name'];
                else if($day_num==22)
                    $day_num=$dashboard_details[92]['name'];
                else if($day_num==23)
                    $day_num=$dashboard_details[93]['name'];
                else if($day_num==24)
                    $day_num=$dashboard_details[94]['name'];
                else if($day_num==25)
                    $day_num=$dashboard_details[95]['name'];
                else if($day_num==26)
                    $day_num=$dashboard_details[96]['name'];
                else if($day_num==27)
                    $day_num=$dashboard_details[97]['name'];
                else if($day_num==28)
                    $day_num=$dashboard_details[98]['name'];
                else if($day_num==29)
                    $day_num=$dashboard_details[99]['name'];
                else if($day_num==30)
                    $day_num=$dashboard_details[100]['name'];
                else if($day_num==31)
                    $day_num=$dashboard_details[101]['name'];
                return $day_num." ".$time_num." ".$dashboard_details[70]['name'];
            }
        }
        else
        {
            $month=date('M', $time);
            $day=date('d', $time);
            if($month=='Jan')
                $month=$dashboard_details[46]['name'];
            else if($month=='Feb')
                $month=$dashboard_details[47]['name'];
            else if($month=='Mar')
                $month=$dashboard_details[48]['name'];
            else if($month=='Apr')
                $month=$dashboard_details[49]['name'];
            else if($month=='May')
                $month=$dashboard_details[50]['name'];
            else if($month=='Jun')
                $month=$dashboard_details[51]['name'];
            else if($month=='Jul')
                $month=$dashboard_details[52]['name'];
            else if($month=='Aug')
                $month=$dashboard_details[53]['name'];
            else if($month=='Sep')
                $month=$dashboard_details[54]['name'];
            else if($month=='Oct')
                $month=$dashboard_details[55]['name'];
            else if($month=='Nov')
                $month=$dashboard_details[56]['name'];
            else if($month=='Dec')
                $month=$dashboard_details[57]['name'];
            return $month." ".$day;
        }
    }
	//Login and Logout
    function login(){
		$username = $this->input->post('username');
        $temp_password=$this->input->post('password');
		$password = md5($this->input->post('password'));
        $remember = $this->input->post('remember');
		$data_arr=array(
				'username'=>$username,
				'password'=>$password
			);
		$admin_details = $this->users_model->get_records($data_arr);
		if(count($admin_details)>0){
			$data_arr=array(
				'username'=>$username,
				'is_active'=>1
			);
			$adm_details = $this->users_model->get_records($data_arr);
			if(count($adm_details)>0)
			{
                if($admin_details[0]['last_login']=='')
                {
                    $this->data['email'] = $username;
                    $this->data['error_message'] = '';
                    $this->load->view($this->view_dir . 'reset_new_password', $this->data);
                }
                else
                {
                    if(isset($remember)) {
                        setcookie("username",$username,time()+ 12096000);
                        setcookie("password",$temp_password,time()+ 12096000);
                    } else {
                        setcookie("username","");
                        setcookie("password","");
                    }
                    $lang_id=$admin_details[0]['default_language'];
                    if($lang_id=='')
                        $lang_id=1;
                    $name=$admin_details[0]['first_name']." ".$admin_details[0]['last_name'];
                    $cond="select group_concat(group_id) as group_id from user_groups where user_id=".$admin_details[0]['id'];
                    $gr_details = $this->users_model->special_fetch($cond);
                    $user_det = array('id'=>$admin_details[0]['id'],'group_id'=>$gr_details[0]['group_id'],'name'=>$name,'avatar'=>$admin_details[0]['avatar'],'email'=>$admin_details[0]['email'],'lang_id'=>$lang_id);
                    $this->session->set_userdata('user_det',$user_det);
                    $groupd_ids_arr = explode(',',$gr_details[0]['group_id']);
                    $cond="select id from folders where folder='".$name."' and user_id=".$admin_details[0]['id']." and parent_folder=2";
                    $fol_details = $this->users_model->special_fetch($cond);
                    if(count($fol_details)<=0)
                    {
                        $input = array(
                            'user_id'=>$admin_details[0]['id'],
                            'folder'=>$name,
                            'parent_folder'=>2,
                            'is_deleted'=>1
                        );
                        $this->folder_manager_model->add($input);
                    }
                    $cond="select id from folders where folder='".$name."' and user_id=".$admin_details[0]['id']." and parent_folder=1";
                    $fol_details = $this->users_model->special_fetch($cond);
                    if(count($fol_details)<=0)
                    {
                        $input = array(
                            'user_id'=>$admin_details[0]['id'],
                            'folder'=>$name,
                            'parent_folder'=>1,
                            'is_deleted'=>1
                        );
                        $this->folder_manager_model->add($input);
                    }
                    if (in_array("2", $groupd_ids_arr)||in_array("4", $groupd_ids_arr)||in_array("5", $groupd_ids_arr)) 
                        redirect('/timeline');
                    else
                        redirect('/');
                }
			}
			else
			{
				$this->data['error_message'] = 'Account Deactivated - Please Contact Administrator';
				$this->data['username'] = $username;
                $this->data['success_message'] = '';
				$this->load->view($this->view_dir . 'login', $this->data);
			}
		}
		else{
				$this->data['error_message'] = 'Invalid Username/Password';
				$this->data['username'] = $username;
                $this->load->view($this->view_dir . 'login', $this->data);
		}            
    }
    
    function logout(){
         $this->session->sess_destroy();
         $this->data['error_message'] = 'Successfully Logged Out';
         $this->data['username'] = "";
         $this->load->view($this->view_dir . 'login', $this->data); 
    }  
    //Forgot Password

    function forgot_password() 
	{
        $this->data['error_message'] = '';
		$this->load->view($this->view_dir . 'forgot_password', $this->data);
	}
    function reset_password($id_hash) 
	{
        $this->data['token_id'] = $id_hash;
        $user_id=$this->decrypt($id_hash);
        $cond="select password_requested_at from users where id=".$user_id;
        $usr_details = $this->users_model->special_fetch($cond);
        if(count($usr_details)>0)
        {
            if($usr_details[0]['password_requested_at']=='')
            {
                $this->load->view($this->view_dir . 'reset_link_expiry', $this->data);
            }
            else
            {
                $this->data['error_message'] = '';
		        $this->load->view($this->view_dir . 'reset_password', $this->data);
            }
        }
        else
        {
            $this->data['username'] = '';
            $this->data['error_message'] = 'Invalid User';
            $this->load->view($this->view_dir . 'forgot_password', $this->data);
        }
	}
    function decrypt($sData){
		$url_id=base64_decode($sData);
		$id=(double)$url_id/118479.24;
		return $id;
	}
    function send_forgot_password(){
        $email = $this->input->post('username');
        if($email == '' || $email == 'undefined'){
            redirect('/');
        }
        $cUrl = $this->get_service_api().'send_forgot_password';
        $reqhdrs = array('Accept: application/json');
        $post_data = array(
            "email"=>$email
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        $out = json_decode($result,true);
        if($out['statuscode'] == '200'){
            $this->load->view($this->view_dir . 'password_confirmation', $this->data);
        }
        else{
           $this->data['error_message'] = $out['statusdescription'];
           $this->load->view($this->view_dir . 'forgot_password', $this->data);
        }
     }

	//Single Column Layout	
	
	function single_column_layout() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $cond="select id from inner_pages where name='".$page_layout."'";
        	$in_page_details = $this->users_model->special_fetch($cond);
            $this->data['in_page_details'] = $in_page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
			$this->data['page_layout'] = $page_layout;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'single_column_layout', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function get_single_column_page() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$page_layout = $_POST['page_layout'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['search_fld']))
			$search_fld = $_POST['search_fld'];
		else
			$search_fld ="";
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = $this->get_service_api().'get_single_column_page';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'page_layout'=>$page_layout,
			'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
          
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
		curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_single_column_page(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_single_column_page';
        $name = trim($this->input->post('name'));
        $page_layout = $this->input->post('page_layout');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
		$post_data = array(
            'name'=>$name,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_single_column_page(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_single_column_page';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $page_layout = $this->input->post('page_layout');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
		$post_data = array(
            'id'=>$id,
			'name'=>$name,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_single_column_page(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
            'lang_id'=>$user_det['lang_id'],
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function restore_single_column_page(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
            'lang_id'=>$user_det['lang_id'],
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_single_column_page(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
            'lang_id'=>$user_det['lang_id'],
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_single_column_page(){
        $user_det = $this->session->userdata('user_det');
        $label_details=$this->get_labels();
		$cUrl = $this->get_service_api().'import_single_column_page';
		$path = $_FILES["import_single_column_page_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[95]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $name="";$status="";
        if(isset($sheet_data[0][0][1]))
            $status=$sheet_data[0][0][1];
        if($status!=$label_details[122]['name'])
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[94]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
				if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                if(isset($sheets[$i][1]))
                    $status=trim($sheets[$i][1]);
                else
                    $status="";
                if($name!=""||$status!="")
                {
                    $lang_id=$user_det['lang_id'];
                    $status_text="active";
                    if($lang_id!=1)
                    {
                        /* $cond="select label_id from labels where lang_id=1 and name='Active' limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lang_details)>0)
                        {
                            $status_text=$this->translate_lang($lang_details[0]['code'],"active");
                        } */
                        $cond="select label_id from labels where lang_id=1 and name='Active' limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lb_details)>0)
                        {
                            $cond="select name from labels where lang_id=2 and label_id=".$lb_details[0]['label_id']." limit 1";
                            $lb_details = $this->users_model->special_fetch($cond);
                            if(count($lb_details)>0)
                                $status_text=$lb_details[0]['name'];
                            else
                                $status_text="";
                        }
                    }
                    if(strtolower($status)==strtolower($status_text))
                        $status_val=1;
                    else
                        $status_val=0;
                    $page_details[]=array(
                        "name"=>$name,
                        "status"=>$status,
                        "status_val"=>$status_val                    
                    );
                }
			}
		}
        if(count($page_details)>0)
        {
            $page_layout = $this->input->post('page_layout');
            $post_data = array(
                'page_details'=>$page_details,
                'lang_id'=>$user_det['lang_id'],
                'page_layout'=>$page_layout
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[95]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
    function bulk_labeling()
    {
        $target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . 'labels_bro.xls';
		$excel = new Excel_Reader();
		$excel->read($target_file);
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				if(isset($sheet['cells'][$r][1]))
                    $page_id=trim($sheet['cells'][$r][1]);
                else
                    $page_id="";
                if(isset($sheet['cells'][$r][2]))
                    $section_id=trim($sheet['cells'][$r][2]);
                else
                    $section_id="";
                if(isset($sheet['cells'][$r][3]))
                    $name=trim($sheet['cells'][$r][3]);
                else
                    $name="";
                if(isset($sheet['cells'][$r][4]))
                    $type=trim($sheet['cells'][$r][4]);
                else
                    $type="";
                if(isset($sheet['cells'][$r][5]))
                    $order_no=trim($sheet['cells'][$r][5]);
                else
                    $order_no="";
                if(isset($sheet['cells'][$r][7]))
                    $lang_id=trim($sheet['cells'][$r][7]);
                else
                    $lang_id="";
                if($name!=""&&$page_id!=""&&$lang_id!="")
                {
                    $data = array(
                        'page_id'=>$page_id,
                        'section_id'=>$section_id,
                        'name'=>$name,
                        'type'=>$type,
                        'order_no'=>$order_no,
                        'status'=>0,
                        'lang_id'=>$lang_id
                    );
                    $this->db->insert('labels',$data);
                }
			}
		}
        echo "Done";
    }
    function view_labels()
    {
        //$json = file_get_contents('php://input');
		//$data = json_decode($json,true); 
        //var_dump($data);die();
        //$page_id = $data['page_id'];
		//$lang_id = $data['lang_id'];
        $page_id = $this->input->post('page_id');
        $lang_id = $this->input->post('lang_id');
	    //$page_id = 45;
	    //$lang_id = 1;
        $cond="select name from labels where page_id=".$page_id." and lang_id=".$lang_id;
        //$cond="select name from labels where page_id=1 and lang_id=1";
        $pg_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($pg_details);$i++)
        {
            echo $i." - ".$pg_details[$i]['name']."<br>";
        }
        //var_dump($pg_details);
        /* $out = array('labels'=>$pg_details);              
        header('Content-Type:application/json');
        echo json_encode($out); */
    }
    function gen_numbers()
    {   
        for($r=1;$r<=300;$r++)
        {   
            $data = array(
                'page_id'=>1,
                'number'=>$r,
                'lang_id'=>1
            );
            $this->db->insert('paginate_numbers',$data);
        }		
        echo "Done";
    }
    function load_languages(){
        $cUrl = $this->get_service_api().'load_languages';
        $id = $this->input->post('id');
        $user_det = $this->session->userdata('user_det');
        $user_det['lang_id']= $id;
        $this->session->set_userdata('user_det', $user_det); 
        $post_data = array(
            'lang_id'=>$id,
            'id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        /* $out = array(
            'statuscode' => "200"
        );
        $result = json_encode($out); */
        echo $result;
    }
}

