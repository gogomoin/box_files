<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Labels extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function labels() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$this->get_include();
            $this->load->view($this->view_dir . 'labels', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_labels() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		if(isset($_POST['page_fld']))
			$page_fld = $_POST['page_fld'];
		else
			$page_fld ="";
		if(isset($_POST['section_fld']))
			$section_fld = $_POST['section_fld'];
		else
			$section_fld ="";
        if(isset($_POST['lang_fld']))
			$lang_fld = $_POST['lang_fld'];
		else
			$lang_fld ="";			
		$cUrl = $this->get_service_api().'view_labels';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'page_fld'=>$page_fld,
			'section_fld'=>$section_fld,
            'lang_fld'=>$lang_fld,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_labels(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_labels';
        $name = trim($this->input->post('name'));
        $type = $this->input->post('type');
        $order_no = $this->input->post('order_no');
        $page_id = $this->input->post('page_id');
        $section_id = $this->input->post('section_id');
        $post_data = array(
            'name'=>$name,
            'type'=>$type,
            'order_no'=>$order_no,
            'page_id'=>$page_id,
            'section_id'=>$section_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_labels(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_labels';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $type = $this->input->post('type');
        $order_no = $this->input->post('order_no');
        $page_id = $this->input->post('page_id');
        $section_id = $this->input->post('section_id');
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'type'=>$type,
            'order_no'=>$order_no,
            'page_id'=>$page_id,
            'section_id'=>$section_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_labels(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_labels';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
	function get_pages(){        
		$cUrl = $this->get_service_api().'get_pages';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }    
    function get_sections(){        
		$cUrl = $this->get_service_api().'get_sections';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_labels_language(){        
		$cUrl = $this->get_service_api().'get_labels_language';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_string_between($string, $start, $end){
        $string = ' ' . $string;
        $ini = strpos($string, $start);
        $ini += strlen($start);
        $len = strpos($string, $end, $ini) - $ini;
        return substr($string, $ini, $len);
    }	
    
    function convert_image()
    {
        $cond="select files_description from dossiers where id=97";
        $pg_details = $this->users_model->special_fetch($cond);
        $content=$pg_details[0]['files_description'];
        $path=getcwd();
        $no_occ=substr_count($content, 'src="data:image/');
        for($i=0;$i<$no_occ;$i++)
        {
            if (stripos($content, 'src="data:image/') !== false) {
                $data = $this->get_string_between($content, 'src="data:image/','"');
                $data='data:image/'.$data;
                $base64_data = explode(',', $data);
                $base64_string=base64_decode($base64_data[1]);
                $list = explode(';', $data);
                $ext_data=explode("/",$list[0]);
                $ext=$ext_data[1];
                $file_name="temp_doc_".$i.time().".".$ext;
                $file_path=$path."/assets/uploads/user_files/".$file_name;
                file_put_contents($file_path, $base64_string);
                $content=str_replace($data,$file_path,$content);
            }
        }
        echo $content;
        //echo $pg_details[0]['files_description'];
    }
    function append_text()
    {
        $text = 'VERY LONG STRING';
        $content=$this->split_content($text,3);
        foreach($content as $con)
        {
            $this->users_model->edit_location(41,$con);
        }
    }
    function split_content($content,$len)
    {   
        $con_arr = str_split($content, $len);
        return $con_arr;
    }
    function array_duplicate()
    {
        $dossier_details=array();
        $dossier_details[]=array(
            "id"=>"1",
            "name"=>"adam"
        );
        $dossier_details[]=array(
            "id"=>"2",
            "name"=>"vinny"
        );
        $dossier_details[]=array(
            "id"=>"1",
            "name"=>"adam"
        );
        $output =  array_map("unserialize", array_unique(array_map("serialize", $dossier_details)));
        var_dump($output);
    }
    function view_all_labels()
    {
        //$json = file_get_contents('php://input');
		//$data = json_decode($json,true); 
        //var_dump($data);die();
        //$page_id = $data['page_id'];
		//$lang_id = $data['lang_id'];
        //$page_id = $this->input->post('page_id');
        //$lang_id = $this->input->post('lang_id');
	    //$page_id = 45;
	    //$lang_id = 1;
        $cond="select name from labels where lang_id=1";
        //$cond="select name from labels where page_id=1 and lang_id=1";
        $pg_details = $this->users_model->special_fetch($cond);
        for($i=0;$i<count($pg_details);$i++)
        {
            echo $i." - ".$pg_details[$i]['name']."<br>";
        }
        //var_dump($pg_details);
        /* $out = array('labels'=>$pg_details);              
        header('Content-Type:application/json');
        echo json_encode($out); */
    }
}
