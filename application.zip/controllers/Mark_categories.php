<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Mark_categories extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function mark_categories() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'mark_categories', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_mark_categories() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['default_fld']))
			$default_fld = $_POST['default_fld'];
		else
			$default_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = $this->get_service_api().'view_mark_categories';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'default_fld'=>$default_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_mark_categories';
        $name = trim($this->input->post('name'));
        $factor = $this->input->post('factor');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $default = $this->input->post('default');
        if(isset($default))
            $default=1;
        else
            $default=0;
        $post_data = array(
            'name'=>$name,
            'factor'=>$factor,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'default'=>$default
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_mark_categories';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $factor = $this->input->post('factor');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $default = $this->input->post('default');
        if(isset($default))
            $default=1;
        else
            $default=0;
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'factor'=>$factor,
            'status'=>$status,
            'lang_id'=>$user_det['lang_id'],
            'default'=>$default
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_mark_categories';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_mark_categories';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_mark_categories';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_default_mark_categories(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_default_mark_categories';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_mark_categories(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_mark_categories';
        $label_details = $this->get_labels();
		$path = $_FILES["import_mark_categories_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[92]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $mrk=$label_details[135]['name']." *";
        $fac=$label_details[136]['name']." *";
        if($col1!=$mrk||$col2!=$fac)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[91]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
				if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                if(isset($sheets[$i][1]))
                    $factor=trim($sheets[$i][1]);
                else
                    $factor="";
                if(isset($sheets[$i][2]))
                    $status=trim($sheets[$i][2]);
                else
                    $status="";
                if(isset($sheets[$i][3]))
                    $default=trim($sheets[$i][3]);
                else
                    $default="";
                if($name!=""||$factor!=""||$default!=""||$status!="")
                {
                    if($status=="Active")
                        $status_val=1;
                    else
                        $status_val=0;                    
                    if($default=="Yes")
                        $default_val=1;
                    else
                        $default_val=0;
                    $page_details[]=array(
                        "name"=>$name,
                        "status"=>$status,
                        "status_val"=>$status_val,
                        "default"=>$default,
                        "default_val"=>$default_val,
                        "factor"=>$factor                    
                    );
                }
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[92]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}	
}
