<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Reports extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//reports	
	
	function reports() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'reports', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function save_report(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'save_report';
        $report_fld = $this->input->post('report_fld');
        $term_fld = $this->input->post('term_fld');
        $student_fld = $this->input->post('student_fld');
        $course_fld = $this->input->post('course_fld');
        $excusable_fld = $this->input->post('excusable_fld');
        $evaluation_date_fld = $this->input->post('evaluation_date_fld');
        $columns_order = $this->input->post('columns_order');
        $report_name = $this->input->post('report_name');
        $post_data = array(
            'report_fld'=>$report_fld,
            'term_fld'=>$term_fld,
            'course_fld'=>$course_fld,
            'student_fld'=>$student_fld,
            'excusable_fld'=>$excusable_fld,
            'evaluation_date_fld'=>$evaluation_date_fld,
            'report_name'=>$report_name,
            'lang_id'=>$user_det['lang_id'],
            'id'=>$user_det['id'],
            'columns_order'=>$columns_order
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function filter_report(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'filter_report';
        $report_fld = $this->input->post('report_fld');
        $term_fld = $this->input->post('term_fld');
        $student_fld = $this->input->post('student_fld');
        $course_fld = $this->input->post('course_fld');
        $excusable_fld = $this->input->post('excusable_fld');
        $evaluation_date_fld = $this->input->post('evaluation_date_fld');
        $columns_order = $this->input->post('columns_order');
        $post_data = array(
            'report_fld'=>$report_fld,
            'term_fld'=>$term_fld,
            'course_fld'=>$course_fld,
            'student_fld'=>$student_fld,
            'excusable_fld'=>$excusable_fld,
            'evaluation_date_fld'=>$evaluation_date_fld,
            'lang_id'=>$user_det['lang_id'],
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columns_order'=>$columns_order
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    	
    function get_presets(){        
		$cUrl = $this->get_service_api().'get_presets';
        $user_det = $this->session->userdata('user_det');
        $reqhdrs = array('Accept: application/json');    
        $post_data = array(
        	'lang_id'=>$user_det['lang_id'],
            'id'=>$user_det['id']
          );    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function open_preset_report(){        
		$cUrl = $this->get_service_api().'open_preset_report';
        $user_det = $this->session->userdata('user_det');
        $reqhdrs = array('Accept: application/json'); 
        $preset_fld = $this->input->post('preset_fld');   
        $post_data = array(
        	'preset_fld'=>$preset_fld
        );    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function delete_reports(){        
		$cUrl = $this->get_service_api().'delete_reports';
        $user_det = $this->session->userdata('user_det');
        $reqhdrs = array('Accept: application/json'); 
        $preset_fld = $this->input->post('preset_fld');   
        $post_data = array(
        	'preset_fld'=>$preset_fld,
            'lang_id'=>$user_det['lang_id'],
            'id'=>$user_det['id']
        );    
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
