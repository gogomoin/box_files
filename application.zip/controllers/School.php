<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class School extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function school() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
            
			$this->get_include();
            $this->get_file_manager();
            $this->load->view($this->view_dir . 'school', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
    function school_data() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $cUrl = $this->get_service_api().'get_school_data';
            $reqhdrs = array('Accept: application/json');    
            $post_data="";   
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            $json = json_decode($result, true);
            $this->data['school_details'] = $json['school_details'];
            $cond="select name from labels where page_id=26 and lang_id=1";
            $school_label_details = $this->users_model->special_fetch($cond);
            $this->data['school_label_details'] = $school_label_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->get_file_manager();
            $this->load->view($this->view_dir . 'school_data', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_school() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = $this->get_service_api().'view_school';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_school(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_school';
        $name = trim($this->input->post('name'));
        $school_logo = $this->input->post('school_logo_file_name');
        $gen_email = $this->input->post('gen_email');
        $specific_email = $this->input->post('specific_email');
        $phone_no = $this->input->post('phone_no');
        $address1 = $this->input->post('address1');
        $address2 = $this->input->post('address2');
        $city = $this->input->post('city');
        $country = $this->input->post('country_id');
        $zip_code = $this->input->post('zip_code');
        $domain = $this->input->post('domain');
        $db_name = $this->input->post('db_name');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'name'=>$name,
            'logo'=>$school_logo,
            'gen_email'=>$gen_email,
            'specific_email'=>$specific_email,
            'phone_no'=>$phone_no,
            'address1'=>$address1,
            'address2'=>$address2,
            'city'=>$city,
            'country'=>$country,
            'zip_code'=>$zip_code,
            'domain'=>$domain,
            'db_name'=>$db_name,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        $this->db = $this->load->database("", TRUE);
        $res=json_decode($result,true);
        if($res['statuscode']=='200')
        {
            $this->add_content($res['id'],$db_name);
            $input = array(
                'domain'=>$domain,
                'logo'=>$school_logo,
                'domain_id'=>$res['id']
            );
            $this->admin_model->add($input);
            $icon_name100 = "100_".$school_logo;
            $path='assets/uploads/user_files/';
            copy($path.$school_logo,$path.$icon_name100);
            $this->resizeImage($icon_name100);
        }
        echo $result;  
    }
    public function resizeImage($filename)
	{
		$source_path = 'assets/uploads/user_files/' . $filename;
		$target_path = 'assets/uploads/user_files';
		$config_manip = array(
			  'image_library' => 'gd2',
			  'source_image' => $source_path,
			  'new_image' => $target_path,
			  'maintain_ratio' => TRUE
		);
	    $this->load->library('image_lib', $config_manip);
		$this->image_lib->initialize($config_manip);
		if (!$this->image_lib->resize()) 
		{
			echo $this->image_lib->display_errors();
		}   
		$this->image_lib->clear();
	}
    function find_root()
    {
        echo $target_dir = "./application/config/database.php";
    }
    function add_content($id,$db_name)
	{
		$html='';
		$html.=PHP_EOL;
		$html.="\$db['".$id."']['hostname'] = 'localhost';" . PHP_EOL;
		$html.="\$db['".$id."']['username'] = 'proscoladb1';" . PHP_EOL;
		$html.="\$db['".$id."']['password'] = 'spwXjWFvVspwXjWFvV';" . PHP_EOL;
		$html.="\$db['".$id."']['database'] = '".$db_name."';" . PHP_EOL; 
		$html.="\$db['".$id."']['dbdriver'] = 'mysqli';" . PHP_EOL;
		$html.="\$db['".$id."']['dbprefix'] = '';" . PHP_EOL;
		$html.="\$db['".$id."']['pconnect'] = TRUE;" . PHP_EOL;
		$html.="\$db['".$id."']['db_debug'] = TRUE;" . PHP_EOL;
		$html.="\$db['".$id."']['cache_on'] = FALSE;" . PHP_EOL;
		$html.="\$db['".$id."']['cachedir'] = '';" . PHP_EOL;
		$html.="\$db['".$id."']['char_set'] = 'utf8';" . PHP_EOL;
		$html.="\$db['".$id."']['dbcollat'] = 'utf8_general_ci';" . PHP_EOL;
		$html.="\$db['".$id."']['swap_pre'] = '';" . PHP_EOL;
		$html.="\$db['".$id."']['autoinit'] = TRUE;" . PHP_EOL;
		$html.="\$db['".$id."']['stricton'] = FALSE;" . PHP_EOL;
		$html.=PHP_EOL;
		$target_dir = "./application/config/database.php";
		file_put_contents($target_dir,$html,FILE_APPEND);
        $target_dir = "/var/www/proscola.com/api/application/config/database.php";
		file_put_contents($target_dir,$html,FILE_APPEND);
	}
	function edit_school(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_school';
        $id = $this->input->post('token_id');
		$name = trim($this->input->post('name'));
        $school_logo = $this->input->post('school_logo_file_name');
        $gen_email = $this->input->post('gen_email');
        $specific_email = $this->input->post('specific_email');
        $phone_no = $this->input->post('phone_no');
        $address1 = $this->input->post('address1');
        $address2 = $this->input->post('address2');
        $city = $this->input->post('city');
        $country = $this->input->post('country_id');
        $zip_code = $this->input->post('zip_code');
        $domain = $this->input->post('domain');
        $db_name = $this->input->post('db_name');
        if(!isset($domain))
            $domain="";
        if(!isset($db_name))
            $db_name="";
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'logo'=>$school_logo,
            'gen_email'=>$gen_email,
            'specific_email'=>$specific_email,
            'phone_no'=>$phone_no,
            'address1'=>$address1,
            'address2'=>$address2,
            'city'=>$city,
            'country'=>$country,
            'zip_code'=>$zip_code,
            'domain'=>$domain,
            'db_name'=>$db_name,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        $res=json_decode($result,true);
        if($res['statuscode']=='200')
        {
            $icon_name100 = "100_".$school_logo;
            $path='assets/uploads/user_files/';
            $file_path='assets/uploads/user_files/'.$icon_name100;
            if (!file_exists($file_path)) 
            {   
                copy($path.$school_logo,$path.$icon_name100);
                $this->resizeImage($icon_name100);
            }
            $this->db = $this->load->database("", TRUE);
            $cond="select admin_id from admin where domain_id=".$id;
            $adn_details = $this->users_model->special_fetch($cond);
            $input = array(
                'logo'=>$school_logo
            );
            $this->admin_model->edit($input,$adn_details[0]['admin_id']);
            $this->db = $this->load->database($id, TRUE);
            $cond="select id from school where id=".$id;
            $sch_details = $this->users_model->special_fetch($cond);
            if(count($sch_details)<=0)
            {
                $input = array(
                    'id'=>$id,
                    'name'=>$name,
                    'logo'=>$school_logo,
                    'gen_email'=>$gen_email,
                    'specific_email'=>$specific_email,
                    'phone_no'=>$phone_no,
                    'address1'=>$address1,
                    'address2'=>$address2,
                    'city'=>$city,
                    'country'=>$country,
                    'zip_code'=>$zip_code,
                    'domain'=>$domain,
                    'db_name'=>$db_name,
                    'is_active'=>$status,
                    'created_at'=>time()
                );
                $this->school_model->add($input);
            }
        }
        echo $result;                
    }
	function delete_school(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_school';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_school(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_school';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_school(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_school';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_countries(){        
		$cUrl = $this->get_service_api().'get_countries';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	

}
