<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Students extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function students() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
			$page_details = $this->users_model->special_fetch($cond);
			$this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->get_file_manager();
            $this->load->view($this->view_dir . 'students', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_students() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['grade_fld']))
			$grade_fld = $_POST['grade_fld'];
		else
			$grade_fld ="";
        if(isset($_POST['teacher_fld']))
			$teacher_fld = $_POST['teacher_fld'];
		else
			$teacher_fld ="";	
        if(isset($_POST['study_level_fld']))
			$study_level_fld = $_POST['study_level_fld'];
		else
			$study_level_fld ="";
        if(isset($_POST['resigned_fld']))
			$resigned_fld = $_POST['resigned_fld'];
		else
			$resigned_fld ="";
        $cUrl = $this->get_service_api().'view_students';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'grade_fld'=>$grade_fld,
            'teacher_fld'=>$teacher_fld,
            'study_level_fld'=>$study_level_fld,
            'resigned_fld'=>$resigned_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_student_assignments() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $student_id = $_POST['student_id'];
        $cUrl = $this->get_service_api().'view_student_assignments';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'student_id'=>$student_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function randomPassword($num) {
        $alphabet = '1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < $num; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
	function add_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_students';  
        $id = $this->input->post('add_token_id');  
        $students_profile_image = $this->input->post('school_logo_file_name');  
        $last_name = $this->input->post('last_name');
        $first_name = $this->input->post('first_name');
        $email = $this->input->post('email');
        $username = $this->input->post('email');
        $pwd=$this->randomPassword(6);
        $password=md5($pwd);
        $gender_id = $this->input->post('gender_id');
        $birth_date = $this->input->post('birth_date');
        $admission = $this->input->post('admission');        
        $emission = $this->input->post('emission');
        $country = $this->input->post('country_id');
        $city = $this->input->post('city');
        $address = $this->input->post('address');
        $address2 = $this->input->post('address2');        
        $zip = $this->input->post('zip');
        $mobile_phone = $this->input->post('mobile_phone');
        $fixed_phone = $this->input->post('fixed_phone');
        $no_email = $this->input->post('no_email');
        $count=$this->input->post('parent_count');
        $parent_info=array();
        for($i=0;$i<$count;$i++)
        {
            $parent_name="parent_".$i;
            $parent_info[$i]['parent_name']=$this->input->post($parent_name);
            $relation="relation_".$i;
            $parent_info[$i]['relation']=$this->input->post($relation);
        }
        $profession_id = $this->input->post('profession_id');
        $post_school_career_goals_id = $this->input->post('career_goals_id');
        if(isset($profession_id))
            $profession_id =implode(",", $profession_id);
        if(isset($post_school_career_goals_id))
            $post_school_career_goals_id =implode(",", $post_school_career_goals_id);
        $resigned = $this->input->post('resigned');
        $special_needs = $this->input->post('special_needs');
        $status = $this->input->post('status');
        $remarks = $this->input->post('remarks');
        $detailed_career_goals = $this->input->post('detailed_career_goals');
        $disadvantages = $this->input->post('disadvantages');
        $personal_weaknesses = $this->input->post('personal_weaknesses');
        $personal_strengths = $this->input->post('personal_strengths');
        $has_smoking_permission = $this->input->post('has_smoking_permission');
        $has_outgoing_permission = $this->input->post('has_outgoing_permission');
        $other_permissions = $this->input->post('other_permissions');
        $term_id = $this->input->post('term_id');
        $grade_id = $this->input->post('grade_id');
        $teacher_id = $this->input->post('teacher_id');
        $study_level_id = $this->input->post('study_level_id');
        $document_ids = $this->input->post('document_ids');
        $new_assignment = $this->input->post('new_assignment');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($no_email))
            $no_email=1;
        else
            $no_email=0;
        if(isset($resigned))
            $resigned=1;
        else
            $resigned=0;
        if(isset($special_needs))
            $special_needs=1;
        else
            $special_needs=0;
        if(isset($has_smoking_permission))
            $has_smoking_permission=1;
        else
            $has_smoking_permission=0;
        if(isset($has_outgoing_permission))
            $has_outgoing_permission=1;
        else
            $has_outgoing_permission=0;
        if(isset($new_assignment))
            $new_assignment=1;
        else
            $new_assignment=0;
        $post_data = array(
            'id'=>$id,
            'avatar'=>$students_profile_image,
            'last_name'=>$last_name,
            'first_name'=>$first_name,
            'email'=>$email,
            'salt'=>$pwd,
            'password'=>$password,
            'gender_id'=>$gender_id,
            'country'=>$country,
            'city'=>$city,
            'address'=>$address,
            'address2'=>$address2,
            'zip'=>$zip,
            'mobile_phone'=>$mobile_phone,
            'fixed_phone'=>$fixed_phone,
            'birth_date'=>$birth_date,
            'admission'=>$admission,
            'emission'=>$emission,
            'parent_info'=>$parent_info,
            'profession_id'=>$profession_id,
            'post_school_career_goals_id'=>$post_school_career_goals_id,
            'remarks'=>$remarks,
            'detailed_career_goals'=>$detailed_career_goals,
            'personal_weaknesses'=>$personal_weaknesses,
            'personal_strengths'=>$personal_strengths,
            'has_smoking_permission'=>$has_smoking_permission,
            'has_outgoing_permission'=>$has_outgoing_permission,
            'other_permissions'=>$other_permissions,
            'new_assignment'=>$new_assignment,
            'term_id'=>$term_id,
            'grade_id'=>$grade_id,
            'teacher_id'=>$teacher_id,
            'study_level_id'=>$study_level_id,
            'document_ids'=>$document_ids,
            'resigned'=>$resigned,
            'special_needs'=>$special_needs,
            'no_email'=>$no_email,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_students';
        $id = $this->input->post('token_id');   
        $students_profile_image = $this->input->post('school_logo_file_name');  
        $last_name = $this->input->post('last_name');
        $first_name = $this->input->post('first_name');
        $email = $this->input->post('email');
        $username = $this->input->post('email');
        $pwd=$this->randomPassword(6);
        $password=md5($pwd);
        $gender_id = $this->input->post('gender_id');
        $birth_date = $this->input->post('birth_date');
        $admission = $this->input->post('admission');        
        $emission = $this->input->post('emission');
        $country = $this->input->post('country_id');
        $city = $this->input->post('city');
        $address = $this->input->post('address');
        $address2 = $this->input->post('address2');        
        $zip = $this->input->post('zip');
        $mobile_phone = $this->input->post('mobile_phone');
        $fixed_phone = $this->input->post('fixed_phone');
        $no_email = $this->input->post('no_email');        
        $count=$this->input->post('parent_count');
        $parent_info=array();
        for($i=0;$i<$count;$i++)
        {
            $parent_name="parent_".$i;
            $student_parent="student_parent_".$i;
            $student_parent=$this->input->post($student_parent);
            if(isset($student_parent))
            {
                $par=$this->input->post($parent_name);
                if(isset($par))
                {
                    $parent_info[$i]['parent_name']=$par;                    
                }
                else
                {
                    $parent_info[$i]['parent_name']="";
                }
                $relation="relation_".$i;
                $parent_info[$i]['relation']=$this->input->post($relation);
                $parent_info[$i]['student_parent']=$student_parent;
            }            
        }
        $profession_id = $this->input->post('profession_id');
        $post_school_career_goals_id = $this->input->post('career_goals_id');
        if(isset($profession_id))
            $profession_id =trim(implode(",", $profession_id),",");
        if(isset($post_school_career_goals_id))
            $post_school_career_goals_id=trim(implode(",", $post_school_career_goals_id),",");
        $resigned = $this->input->post('resigned');
        $special_needs = $this->input->post('special_needs');
        $status = $this->input->post('status');
        $remarks = $this->input->post('remarks');
        $detailed_career_goals = $this->input->post('detailed_career_goals');
        $personal_weaknesses = $this->input->post('personal_weaknesses');
        $personal_strengths = $this->input->post('personal_strengths');
        $has_smoking_permission = $this->input->post('has_smoking_permission');
        $has_outgoing_permission = $this->input->post('has_outgoing_permission');
        $other_permissions = $this->input->post('other_permissions');
        $new_assignment = $this->input->post('new_assignment');
        $term_id = $this->input->post('term_id');
        $grade_id = $this->input->post('grade_id');
        $teacher_id = $this->input->post('teacher_id');
        $study_level_id = $this->input->post('study_level_id');
        $document_ids = $this->input->post('document_ids');
        $new_assignment = $this->input->post('new_assignment');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($no_email))
            $no_email=1;
        else
            $no_email=0;
        if(isset($resigned))
            $resigned=1;
        else
            $resigned=0;
        if(isset($special_needs))
            $special_needs=1;
        else
            $special_needs=0;
        if(isset($has_smoking_permission))
            $has_smoking_permission=1;
        else
            $has_smoking_permission=0;
        if(isset($has_outgoing_permission))
            $has_outgoing_permission=1;
        else
            $has_outgoing_permission=0;
        if(isset($new_assignment))
            $new_assignment=1;
        else
            $new_assignment=0;
        $post_data = array(
            'id'=>$id,
            'avatar'=>$students_profile_image,
            'last_name'=>$last_name,
            'first_name'=>$first_name,
            'email'=>$email,
            'salt'=>$pwd,
            'password'=>$password,
            'gender_id'=>$gender_id,
            'country'=>$country,
            'city'=>$city,
            'address'=>$address,
            'address2'=>$address2,
            'zip'=>$zip,
            'mobile_phone'=>$mobile_phone,
            'fixed_phone'=>$fixed_phone,
            'birth_date'=>$birth_date,
            'admission'=>$admission,
            'emission'=>$emission,
            'parent_info'=>$parent_info,
            'profession_id'=>$profession_id,
            'post_school_career_goals_id'=>$post_school_career_goals_id,
            'remarks'=>$remarks,
            'detailed_career_goals'=>$detailed_career_goals,
            'personal_weaknesses'=>$personal_weaknesses,
            'personal_strengths'=>$personal_strengths,
            'has_smoking_permission'=>$has_smoking_permission,
            'has_outgoing_permission'=>$has_outgoing_permission,
            'other_permissions'=>$other_permissions,
            'new_assignment'=>$new_assignment,
            'term_id'=>$term_id,
            'grade_id'=>$grade_id,
            'teacher_id'=>$teacher_id,
            'study_level_id'=>$study_level_id,
            'document_ids'=>$document_ids,
            'resigned'=>$resigned,
            'special_needs'=>$special_needs,
            'no_email'=>$no_email,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
            );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_students';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_students';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_students';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function set_resigned_students(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_resigned_students';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }    
    function get_parent_info(){
        
		$cUrl = $this->get_service_api().'get_parent_info';
        $par_id = $this->input->post('par_id');
		$post_data = array(
            'par_id'=>$par_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_grades(){        
		$cUrl = $this->get_service_api().'get_grades';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_professions(){        
		$cUrl = $this->get_service_api().'get_professions';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_career_goals(){        
		$cUrl = $this->get_service_api().'get_career_goals';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_study_level(){        
		$cUrl = $this->get_service_api().'get_study_level';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_parents(){        
		$cUrl = $this->get_service_api().'get_parents';
        $search_term = $this->input->post('searchTerm');
		$post_data = array(
            'search_term'=>$search_term
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo json_encode($result);                
    }
    function get_terms(){        
		$cUrl = $this->get_service_api().'get_terms';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function import_students(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_students';
        $label_details = $this->get_labels();
		$path = $_FILES["import_students_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[282]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $nam=$label_details[365]['name']." *";
        $fir=$label_details[366]['name']." *";
        if($col1!=$nam||$col2!=$fir)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[281]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                if(isset($sheets[$i][1]))
                    $first_name=trim($sheets[$i][1]);
                else
                    $first_name="";
                if(isset($sheets[$i][2]))
                    $email =trim($sheets[$i][2]);
                else
                    $email ="";
                $gender_id="";
                if(isset($sheets[$i][3]))
                {
                    $gender=trim($sheets[$i][3]);
                    if($gender!="")
                    {
                        $cond="select id from genders where name='".$gender."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $gender_id=$cu_details[0]['id'];
                        else
                            $gender_id="";
                    }                    
                }
                else
                    $gender="";
                if(isset($sheets[$i][4]))
                {
                    $birth_date=trim($sheets[$i][4]);
                    $birth_date=str_replace("/","-",$birth_date);
                }
                else
                    $birth_date="";
                if(isset($sheets[$i][5]))
                {
                    $admission=trim($sheets[$i][5]);
                    $admission=str_replace("/","-",$admission);
                }
                else
                    $admission="";
                $parent_ids="";
                if(isset($sheets[$i][6]))
                {
                    $parent=trim($sheets[$i][6]);
                    if($parent!="")
                    {
                        $parent_arr=explode(",",$parent);
                        $parent_ids="";
                        foreach($parent_arr as $prof)
                        {
                            $cond="SELECT id FROM users WHERE concat(first_name,' ',last_name)='".$prof."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $parent_ids=$parent_ids.",".$cu_details[0]['id'];
                        }
                        if($parent_ids!="")
                            $parent_ids=trim($parent_ids,",");                        
                    }                    
                }
                else
                    $parent=""; 
                if(isset($sheets[$i][6]))
                    $parent=trim($sheets[$i][6]);
                else
                    $parent="";
                if(isset($sheets[$i][7]))
                    $relation=trim($sheets[$i][7]);
                else
                    $relation="";
                $country_id="";
                if(isset($sheets[$i][8]))
                {
                    $country=trim($sheets[$i][8]);
                    if($country!="")
                    {
                        $cond="select id from countries where name='".$country."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $country_id=$cu_details[0]['id'];
                        else
                            $country_id="";
                    }                    
                }
                else
                    $country="";
                if(isset($sheets[$i][9]))
                {
                    $emission=trim($sheets[$i][9]);
                    $emission=str_replace("/","-",$emission);
                }
                else
                    $emission="";
                if(isset($sheets[$i][10]))
                    $city=trim($sheets[$i][10]);
                else
                    $city="";
                if(isset($sheets[$i][11]))
                    $address=trim($sheets[$i][11]);
                else
                    $address="";
                if(isset($sheets[$i][12]))
                    $zip=trim($sheets[$i][12]);
                else
                    $zip="";
                if(isset($sheets[$i][13]))
                    $address2=trim($sheets[$i][13]);
                else
                    $address2="";
                if(isset($sheets[$i][14]))
                    $mobile_phone=trim($sheets[$i][14]);
                else
                    $mobile_phone="";  
                if(isset($sheets[$i][15]))
                    $fixed_phone=trim($sheets[$i][15]);
                else
                    $fixed_phone="";
                $profession_id="";
                if(isset($sheets[$i][16]))
                {
                    $profession=trim($sheets[$i][16]);
                    if($profession!="")
                    {
                        $profession_arr=explode(",",$profession);
                        foreach($profession_arr as $prof)
                        {
                            $cond="select id from intended_professions where name='".$prof."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $profession_id=$profession_id.",".$cu_details[0]['id'];
                        }
                        if($profession_id!="")
                            $profession_id=trim($profession_id,",");                        
                    }                    
                }
                else
                    $profession="";
                $career_goal_id=""; 
                if(isset($sheets[$i][17]))
                {
                    $career_goal=trim($sheets[$i][17]);
                    if($career_goal!="")
                    {
                        $career_goal_arr=explode(",",$career_goal);
                        foreach($career_goal_arr as $car)
                        {
                            $cond="select id from post_school_career_goals where name='".$car."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $career_goal_id=$career_goal_id.",".$cu_details[0]['id'];
                        }
                        if($career_goal_id!="")
                            $career_goal_id=trim($career_goal_id,",");
                    }                    
                }
                else
                    $career_goal="";
                if(isset($sheets[$i][18]))
                    $remarks=trim($sheets[$i][18]);
                else
                    $remarks="";
                if(isset($sheets[$i][19]))
                    $detailed_career_goals=trim($sheets[$i][19]);
                else
                    $detailed_career_goals="";
                if(isset($sheets[$i][20]))
                    $personal_weaknesses=trim($sheets[$i][20]);
                else
                    $personal_weaknesses="";
                if(isset($sheets[$i][21]))
                    $personal_strengths=trim($sheets[$i][21]);
                else
                    $personal_strengths="";
                if(isset($sheets[$i][22]))
                    $has_smoking_permission=trim($sheets[$i][22]);
                else
                    $has_smoking_permission="";
               
                if(isset($sheets[$i][23]))
                    $has_outgoing_permission=trim($sheets[$i][23]);
                else
                    $has_outgoing_permission="";
                if(isset($sheets[$i][24]))
                    $other_permissions=trim($sheets[$i][24]);
                else
                    $other_permissions=""; 
                $lang_id=$user_det['lang_id'];
                $status_text="active";$role_text="yes";
                if($lang_id!=1)
                {
                    $cond="select label_id from labels where lang_id=1 and name='Active' limit 1";
                    $lb_details = $this->users_model->special_fetch($cond);
                    if(count($lb_details)>0)
                    {
                        $cond="select name from labels where lang_id=".$lang_id." and label_id=".$lb_details[0]['label_id']." limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lb_details)>0)
                            $status_text=$lb_details[0]['name'];
                        else
                            $status_text="";
                    }
                    $cond="select label_id from labels where lang_id=1 and name='Yes' limit 1";
                    $lb_details = $this->users_model->special_fetch($cond);
                    if(count($lb_details)>0)
                    {
                        $cond="select name from labels where lang_id=".$lang_id." and label_id=".$lb_details[0]['label_id']." limit 1";
                        $lb_details = $this->users_model->special_fetch($cond);
                        if(count($lb_details)>0)
                            $role_text=$lb_details[0]['name'];
                        else
                            $role_text="";
                    }
                }
                if(isset($sheets[$i][25]))
                    $new_assignment=trim($sheets[$i][25]);
                else
                    $new_assignment=""; 
                $term="";$term_id="";$grade="";$grade_id="";$tutor="";$tutor_id="";$study_level="";$study_level_id="";
                if(strtolower($new_assignment)==strtolower($role_text))
                {
                    $term_id="";
                    if(isset($sheets[$i][26]))
                    {
                        $term=trim($sheets[$i][26]);
                        if($term!="")
                        {
                            $cond="select id from terms where name='".$term."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $term_id=$cu_details[0]['id'];
                            else
                                $term_id="";
                        }                    
                    }
                    else
                        $term="";
                    $grade_id="";
                    if(isset($sheets[$i][27]))
                    {
                        $grade=trim($sheets[$i][27]);
                        if($grade!="")
                        {
                            $cond="select id from classes where name='".$grade."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $grade_id=$cu_details[0]['id'];
                            else
                                $grade_id="";
                        }                    
                    }
                    else
                        $grade="";
                    $tutor_id="";
                    if(isset($sheets[$i][28]))
                    {
                        $tutor=trim($sheets[$i][28]);
                        if($tutor!="")
                        {
                            $cond="select id,first_name,last_name from users";
                            $cu_details = $this->users_model->special_fetch($cond);
                            foreach($cu_details as $users)
                            {
                                $tutor_name=$users['first_name']." ".$users['last_name'];
                                if($tutor_name==$tutor)
                                {
                                    $tutor_id=$users['id'];
                                    break;
                                }
                                else
                                    $tutor_id="";
                            }                        
                        }                   
                    }
                    else
                        $tutor="";
                    $study_level_id="";
                    if(isset($sheets[$i][29]))
                    {
                        $study_level=trim($sheets[$i][29]);
                        if($study_level!="")
                        {
                            $cond="select id from main_levels where name='".$study_level."'";
                            $cu_details = $this->users_model->special_fetch($cond);
                            if(count($cu_details)>0)
                                $study_level_id=$cu_details[0]['id'];
                            else
                                $study_level_id="";
                        }                    
                    }
                    else
                        $study_level="";
                }            
                if(isset($sheets[$i][30]))
                    $resigned=trim($sheets[$i][30]);
                else
                    $resigned="";
                if(isset($sheets[$i][31]))
                    $special_needs=trim($sheets[$i][31]);
                else
                    $special_needs="";
                if(isset($sheets[$i][32]))
                    $status=trim($sheets[$i][32]);
                else
                    $status="";
                if($name!=""||$first_name!=""||$email!=""||$gender!=""||$country!=""||$birth_date!=""||$parent!=""||$relation!=""||$emission!=""||$city!=""||$address!=""||$zip!=""||$address2!=""||$mobile_phone!=""||$fixed_phone!=""||$profession!=""||$career_goal!=""||$remarks!=""||$detailed_career_goals!=""||$personal_weaknesses!=""||$personal_strengths!=""||$has_smoking_permission!=""||$has_outgoing_permission!=""||$other_permissions!=""||$new_assignment!=""||$term!=""||$grade!=""||$tutor!=""||$study_level!=""||$resigned!=""||$special_needs!=""||$status!="")
                {
                    if(strtolower($resigned)==strtolower($role_text))
                        $resigned_val=1;
                    else
                        $resigned_val=0;
                    if(strtolower($special_needs)==strtolower($role_text))
                        $special_needs_val=1;
                    else
                        $special_needs_val=0;
                    if(strtolower($has_smoking_permission)==strtolower($role_text))
                        $has_smoking_permission_val=1;
                    else
                        $has_smoking_permission_val=0;
                    if(strtolower($has_outgoing_permission)==strtolower($role_text))
                        $has_outgoing_permission_val=1;
                    else
                        $has_outgoing_permission_val=0;
                    if(strtolower($new_assignment)==strtolower($role_text))
                        $new_assignment_val=1;
                    else
                        $new_assignment_val=0;
                    if(strtolower($status)==strtolower($status_text))
                        $status_val=1;
                    else
                        $status_val=0;
                    $pwd=$this->randomPassword(6);
                    $password=md5($pwd);              
                    $page_details[]=array(
                        "name"=>$name,
                        "first_name"=>$first_name,
                        "email"=>$email,
                        "salt"=>$pwd,
                        "password"=>$password,
                        "gender"=>$gender,
                        "gender_id"=>$gender_id,
                        "country"=>$country,
                        "country_id"=>$country_id,
                        "birth_date"=>$birth_date,
                        "admission"=>$admission,
                        "parent"=>$parent,
                        "parent_ids"=>$parent_ids,
                        "relation"=>$relation,
                        "emission"=>$emission,
                        "city"=>$city,
                        "address"=>$address,
                        "zip"=>$zip,
                        "address2"=>$address2,
                        "mobile_phone"=>$mobile_phone,
                        "fixed_phone"=>$fixed_phone,
                        "profession"=>$profession,
                        "profession_id"=>$profession_id,
                        "career_goal"=>$career_goal,
                        "career_goal_id"=>$career_goal_id,
                        "remarks"=>$remarks,
                        "detailed_career_goals"=>$detailed_career_goals,
                        "personal_weaknesses"=>$personal_weaknesses,
                        "personal_strengths"=>$personal_strengths,
                        "has_smoking_permission"=>$has_smoking_permission,
                        "has_smoking_permission_val"=>$has_smoking_permission_val,
                        "has_outgoing_permission"=>$has_outgoing_permission,
                        "has_outgoing_permission_val"=>$has_outgoing_permission_val,
                        "other_permissions"=>$other_permissions,
                        "new_assignment"=>$new_assignment,
                        "new_assignment_val"=>$new_assignment_val,
                        "term"=>$term,
                        "term_id"=>$term_id,
                        "grade"=>$grade,
                        "grade_id"=>$grade_id,
                        "tutor"=>$tutor,
                        "tutor_id"=>$tutor_id,
                        "study_level"=>$study_level,
                        "study_level_id"=>$study_level_id,
                        "resigned"=>$resigned,
                        "resigned_val"=>$resigned_val,
                        "special_needs"=>$special_needs,
                        "special_needs_val"=>$special_needs_val,
                        "status"=>$status,
                        "status_val"=>$status_val                  
                    );		
                }		
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[282]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
}
