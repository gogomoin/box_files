<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Students_courses extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function students_courses() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'students_courses', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_students_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
        if(isset($_POST['course_fld']))
			$course_fld = $_POST['course_fld'];
		else
			$course_fld ="";
		if(isset($_POST['grade_fld']))
			$grade_fld = $_POST['grade_fld'];
		else
			$grade_fld ="";
        if(isset($_POST['teacher_fld']))
			$teacher_fld = $_POST['teacher_fld'];
		else
			$teacher_fld ="";	
        if(isset($_POST['study_level_fld']))
			$study_level_fld = $_POST['study_level_fld'];
		else
			$study_level_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";
        $cUrl = $this->get_service_api().'view_students_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld'=>$term_fld,
            'course_fld'=>$course_fld,
			'grade_fld'=>$grade_fld,
            'teacher_fld'=>$teacher_fld,
            'study_level_fld'=>$study_level_fld,
            'student_fld'=>$student_fld,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);   
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_all_students_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld_list']))
			$term_fld_list = $_POST['term_fld_list'];
		else
			$term_fld_list ="";
		if(isset($_POST['grade_fld_list']))
			$grade_fld_list = $_POST['grade_fld_list'];
		else
			$grade_fld_list ="";
        if(isset($_POST['teacher_fld_list']))
			$teacher_fld_list = $_POST['teacher_fld_list'];
		else
			$teacher_fld_list ="";	
        if(isset($_POST['study_level_fld_list']))
			$study_level_fld_list = $_POST['study_level_fld_list'];
		else
			$study_level_fld_list ="";
        if(isset($_POST['student_fld_list']))
			$student_fld_list = $_POST['student_fld_list'];
		else
			$student_fld_list ="";
        if(isset($_POST['selected_students_list']))
			$selected_students_list = $_POST['selected_students_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_all_students_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld_list'=>$term_fld_list,
			'grade_fld_list'=>$grade_fld_list,
            'teacher_fld_list'=>$teacher_fld_list,
            'study_level_fld_list'=>$study_level_fld_list,
            'student_fld_list'=>$student_fld_list,
            'selected_students_list'=>$selected_students_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_selected_students_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['selected_students_list']))
			$selected_students_list = $_POST['selected_students_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_selected_students_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'selected_students_list'=>$selected_students_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_all_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['subject_fld']))
			$subject_fld = $_POST['subject_fld'];
		else
			$subject_fld ="";
		if(isset($_POST['personnel_fld']))
			$personnel_fld = $_POST['personnel_fld'];
		else
			$personnel_fld ="";
        if(isset($_POST['competence_level_fld']))
			$competence_level_fld = $_POST['competence_level_fld'];
		else
			$competence_level_fld ="";	
        if(isset($_POST['individual_fld']))
			$individual_fld = $_POST['individual_fld'];
		else
			$individual_fld ="";
        if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['selected_courses_list']))
			$selected_courses_list = $_POST['selected_courses_list'];
		else
			$selected_courses_list ="";
        $cUrl = $this->get_service_api().'view_all_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'subject_fld'=>$subject_fld,
			'personnel_fld'=>$personnel_fld,
            'competence_level_fld'=>$competence_level_fld,
            'individual_fld'=>$individual_fld,
            'del_fld'=>$del_fld,
            'selected_courses_list'=>$selected_courses_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_all_selected_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['selected_courses_list']))
			$selected_courses_list = $_POST['selected_courses_list'];
		else
			$selected_courses_list ="";
        $cUrl = $this->get_service_api().'view_all_selected_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'selected_courses_list'=>$selected_courses_list,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_final_students_courses() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['student_course_status_fld']))
			$student_course_status_fld = $_POST['student_course_status_fld'];
		else
			$student_course_status_fld ="";
        if(isset($_POST['selected_student_courses_list']))
			$selected_student_courses_list = $_POST['selected_student_courses_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_final_students_courses';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'student_course_status_fld'=>$student_course_status_fld,
            'selected_student_courses_list'=>$selected_student_courses_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}     
	function add_students_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_students_courses';
        $student_course_status_fld = $this->input->post('student_course_status_fld');
        $selected_student_courses_list = $this->input->post('selected_student_courses_list');
        $post_data = array(
            'student_course_status_fld'=>$student_course_status_fld,
            'lang_id'=>$user_det['lang_id'],
            'selected_student_courses_list'=>$selected_student_courses_list
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_students_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_students_courses';
        $id = $this->input->post('token_id');    
        $course_id = $this->input->post('course_id');
        $course_status_id = $this->input->post('course_status_id');
        $post_data = array(
            'id'=>$id,
            'course_id'=>$course_id,
            'lang_id'=>$user_det['lang_id'],
            'course_status_id'=>$course_status_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_students_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_students_courses';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }    
    
    function get_courses(){        
		$cUrl = $this->get_service_api().'get_courses';
        $reqhdrs = array('Accept: application/json');    
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id']
          ); 
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_student_course_status(){        
		$cUrl = $this->get_service_api().'get_student_course_status';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function import_students_courses(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_students_courses';
        $label_details = $this->get_labels();
		$path = $_FILES["import_students_courses_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[130]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $ter=$label_details[222]['name']." *";
        $stu=$label_details[223]['name']." *";
        if($col1!=$ter||$col2!=$stu)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[129]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                {
                    $term=trim($sheets[$i][0]);
                    if($term!="")
                    {
                        $cond="select id from terms where name='".$term."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $term_id=$cu_details[0]['id'];
                        else
                            $term_id="";
                    }                    
                }
                else
                    $term="";
                if(isset($sheets[$i][1]))
                {
                    $student_name=trim($sheets[$i][1]);
                    if($student_name!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $student=$users['first_name']." ".$users['last_name'];
                            if($student==$student_name)
                            {
                                $student_id=$users['id'];
                                break;
                            }
                            else
                                $student_id="";
                        }                        
                    }                   
                }
                else
                    $student_name="";
                if(isset($sheets[$i][2]))
                {
                    $course=trim($sheets[$i][2]);
                    if($course!="")
                    {
                        $cond="select id from courses where name='".$course."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $course_id=$cu_details[0]['id'];
                        else
                            $course_id="";
                    }                    
                }
                else
                    $course="";
                if(isset($sheets[$i][3]))
                {
                    $course_status=trim($sheets[$i][3]);
                    if($course_status!="")
                    {
                        $cond="select id from student_course_statuses where name='".$course_status."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $course_status_id=$cu_details[0]['id'];
                        else
                            $course_status_id="";                        
                    }                   
                }
                else
                    $course_status="";
                if($term!=""||$student_name!=""||$course!=""||$course_status!="")
                {
                    $page_details[]=array(
                        "term"=>$term,
                        "term_id"=>$term_id,
                        "student_name"=>$student_name,
                        "student_id"=>$student_id,
                        "course"=>$course,
                        "course_id"=>$course_id,
                        "course_status"=>$course_status,
                        "course_status_id"=>$course_status_id              
                    );	
                }	
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[130]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
    function duplicate_student_courses(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'duplicate_student_courses';
        $source_term_id = $this->input->post('source_term_id');
        $destination_term_id = $this->input->post('destination_term_id');
        $post_data = array(
            'source_term_id'=>$source_term_id,
            'lang_id'=>$user_det['lang_id'],
            'destination_term_id'=>$destination_term_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
