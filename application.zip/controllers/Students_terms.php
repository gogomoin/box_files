<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Students_terms extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function students_terms() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'students_terms', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_students_terms() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld']))
			$term_fld = $_POST['term_fld'];
		else
			$term_fld ="";
		if(isset($_POST['grade_fld']))
			$grade_fld = $_POST['grade_fld'];
		else
			$grade_fld ="";
        if(isset($_POST['teacher_fld']))
			$teacher_fld = $_POST['teacher_fld'];
		else
			$teacher_fld ="";	
        if(isset($_POST['study_level_fld']))
			$study_level_fld = $_POST['study_level_fld'];
		else
			$study_level_fld ="";
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";
        $cUrl = $this->get_service_api().'view_students_terms';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld'=>$term_fld,
			'grade_fld'=>$grade_fld,
            'teacher_fld'=>$teacher_fld,
            'study_level_fld'=>$study_level_fld,
            'student_fld'=>$student_fld,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_all_students_terms() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_fld_list']))
			$term_fld_list = $_POST['term_fld_list'];
		else
			$term_fld_list ="";
		if(isset($_POST['grade_fld_list']))
			$grade_fld_list = $_POST['grade_fld_list'];
		else
			$grade_fld_list ="";
        if(isset($_POST['teacher_fld_list']))
			$teacher_fld_list = $_POST['teacher_fld_list'];
		else
			$teacher_fld_list ="";	
        if(isset($_POST['study_level_fld_list']))
			$study_level_fld_list = $_POST['study_level_fld_list'];
		else
			$study_level_fld_list ="";
        if(isset($_POST['assigned_fld_list']))
			$assigned_fld_list = $_POST['assigned_fld_list'];
		else
			$assigned_fld_list ="";
        if(isset($_POST['status_fld']))
			$status_fld_list = $_POST['status_fld_list'];
		else
			$status_fld_list ="";
        if(isset($_POST['selected_students_list']))
			$selected_students_list = $_POST['selected_students_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_all_students_terms';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'term_fld_list'=>$term_fld_list,
			'grade_fld_list'=>$grade_fld_list,
            'teacher_fld_list'=>$teacher_fld_list,
            'study_level_fld_list'=>$study_level_fld_list,
            'assigned_fld_list'=>$assigned_fld_list,
            'status_fld_list'=>$status_fld_list,
            'selected_students_list'=>$selected_students_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_selected_students_terms() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['selected_students_list']))
			$selected_students_list = $_POST['selected_students_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_selected_students_terms';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'selected_students_list'=>$selected_students_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	} 
    function view_final_students_terms() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        if(isset($_POST['term_id']))
			$term_id = $_POST['term_id'];
		else
			$term_id ="";
		if(isset($_POST['grade_id']))
			$grade_id = $_POST['grade_id'];
		else
			$grade_id ="";
        if(isset($_POST['teacher_id']))
			$teacher_id = $_POST['teacher_id'];
		else
			$teacher_id ="";	
        if(isset($_POST['study_level_id']))
			$study_level_id = $_POST['study_level_id'];
		else
			$study_level_id ="";
        if(isset($_POST['term']))
			$term = $_POST['term'];
		else
			$term ="";
		if(isset($_POST['grade']))
			$grade = $_POST['grade'];
		else
			$grade ="";
        if(isset($_POST['teacher']))
			$teacher = $_POST['teacher'];
		else
			$teacher ="";	
        if(isset($_POST['study_level']))
			$study_level = $_POST['study_level'];
		else
			$study_level ="";
        if(isset($_POST['selected_students_list']))
			$selected_students_list = $_POST['selected_students_list'];
		else
			$selected_students_list ="";
        $cUrl = $this->get_service_api().'view_final_students_terms';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'term_id'=>$term_id,
            'grade_id'=>$grade_id,
            'teacher_id'=>$teacher_id,
            'study_level_id'=>$study_level_id,
            'term'=>$term,
            'grade'=>$grade,
            'teacher'=>$teacher,
            'study_level'=>$study_level,
			'selected_students_list'=>$selected_students_list,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}     
	function add_students_terms(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_students_terms';
        $term_id = $this->input->post('term_id');
        $selected_students_list = $this->input->post('selected_students_list');
        $grade_id = $this->input->post('grade_id');
        $teacher_id = $this->input->post('teacher_id');
        $study_level_id = $this->input->post('study_level_id');
        $post_data = array(
            'term_id'=>$term_id,
            'selected_students_list'=>$selected_students_list,
            'grade_id'=>$grade_id,
            'teacher_id'=>$teacher_id,
            'lang_id'=>$user_det['lang_id'],
            'study_level_id'=>$study_level_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_students_terms(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_students_terms';
        $id = $this->input->post('token_id');    
        $class_id = $this->input->post('grade_id');
        $main_level_id = $this->input->post('study_level_id');
        $coach_id = $this->input->post('teacher_id');
        $post_data = array(
            'id'=>$id,
            'class_id'=>$class_id,
            'main_level_id'=>$main_level_id,
            'lang_id'=>$user_det['lang_id'],
            'coach_id'=>$coach_id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_students_terms(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_students_terms';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }    
    function get_students(){        
		$cUrl = $this->get_service_api().'get_students';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_active_terms(){        
		$cUrl = $this->get_service_api().'get_active_terms';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function import_students_terms(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_students_terms';
        $label_details = $this->get_labels();
		$path = $_FILES["import_students_terms_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";$col3="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if(isset($sheet_data[0][0][2]))
            $col3=$sheet_data[0][0][2];
        else
            $col3="";
        if($col1==""&&$col2==""&&$col3=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[140]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $ter=$label_details[214]['name']." *";
        $stu=$label_details[215]['name']." *";
        $gra=$label_details[216]['name']." *";
        if($col1!=$ter||$col2!=$stu||$col3!=$gra)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[139]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                $term_id="";
                if(isset($sheets[$i][0]))
                {
                    $term=trim($sheets[$i][0]);
                    if($term!="")
                    {
                        $cond="select id from terms where name='".$term."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $term_id=$cu_details[0]['id'];
                        else
                            $term_id="";
                    }                    
                }
                else
                    $term="";
                $student_id="";
                if(isset($sheets[$i][1]))
                {
                    $student_name=trim($sheets[$i][1]);
                    if($student_name!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $student=$users['first_name']." ".$users['last_name'];
                            if($student==$student_name)
                            {
                                $student_id=$users['id'];
                                break;
                            }
                            else
                                $student_id="";
                        }                        
                    }                   
                }
                else
                    $student_name="";
                $grade_id="";
                if(isset($sheets[$i][2]))
                {
                    $grade=trim($sheets[$i][2]);
                    if($grade!="")
                    {
                        $cond="select id from classes where name='".$grade."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $grade_id=$cu_details[0]['id'];
                        else
                            $grade_id="";
                    }                    
                }
                else
                    $grade="";
                $tutor_id="";
                if(isset($sheets[$i][3]))
                {
                    $tutor=trim($sheets[$i][3]);
                    if($tutor!="")
                    {
                        $cond="select id,first_name,last_name from users";
                        $cu_details = $this->users_model->special_fetch($cond);
                        foreach($cu_details as $users)
                        {
                            $tutor_name=$users['first_name']." ".$users['last_name'];
                            if($tutor_name==$tutor)
                            {
                                $tutor_id=$users['id'];
                                break;
                            }
                            else
                                $tutor_id="";
                        }                        
                    }                   
                }
                else
                    $tutor="";
                $study_level_id="";
                if(isset($sheets[$i][4]))
                {
                    $study_level=trim($sheets[$i][4]);
                    if($study_level!="")
                    {
                        $cond="select id from main_levels where name='".$study_level."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $study_level_id=$cu_details[0]['id'];
                        else
                            $study_level_id="";
                    }                    
                }
                else
                    $study_level="";
                if($term!=""||$student_name!=""||$grade!=""||$tutor!=""||$study_level!="")
                {
                    $page_details[]=array(
                        "term"=>$term,
                        "term_id"=>$term_id,
                        "student_name"=>$student_name,
                        "student_id"=>$student_id,
                        "grade"=>$grade,
                        "grade_id"=>$grade_id,
                        "tutor"=>$tutor,
                        "tutor_id"=>$tutor_id,
                        "study_level"=>$study_level,
                        "study_level_id"=>$study_level_id                 
                    );	
                }	
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[140]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
    function duplicate_student_terms(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'duplicate_student_terms';
        $source_term_id = $this->input->post('source_term_id');
        $destination_term_id = $this->input->post('destination_term_id');
        $post_data = array(
            'source_term_id'=>$source_term_id,
            'lang_id'=>$user_det['lang_id'],
            'destination_term_id'=>$destination_term_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
