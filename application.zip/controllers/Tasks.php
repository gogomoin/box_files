<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class tasks extends MY_Controller
{
    
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
        $this->load->library('pdf');
        $this->load->library('concatpdf');
        $this->load->library('word_convertor');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function tasks() 
	{
		
	}
    
	function view_tasks() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $dossier_id = $_POST['dos_id'];
        $current_date = $_POST['current_date'];
        if(isset($_POST['task_category_fld']))
			$task_category_fld = $_POST['task_category_fld'];
		else
			$task_category_fld ="";
		if(isset($_POST['from_date_fld']))
			$from_date_fld = $_POST['from_date_fld'];
		else
			$from_date_fld ="";
		if(isset($_POST['to_date_fld']))
			$to_date_fld = $_POST['to_date_fld'];
		else
			$to_date_fld ="";
        if(isset($_POST['is_published_fld']))
			$is_published_fld = $_POST['is_published_fld'];
		else
			$is_published_fld ="";
        if(isset($_POST['is_locked_fld']))
			$is_locked_fld = $_POST['is_locked_fld'];
		else
			$is_locked_fld ="";
		if(isset($_POST['is_del_fld']))
			$is_del_fld = $_POST['is_del_fld'];
		else
			$is_del_fld ="";			
		$cUrl = $this->get_service_api().'view_tasks';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'dossier_id'=>$dossier_id,
            'group_id'=>$user_det['group_id'],
            'user_id'=>$user_det['id'],
            'task_category_fld'=>$task_category_fld,
			'from_date_fld'=>$from_date_fld,
            'to_date_fld'=>$to_date_fld,
            'is_published_fld'=>$is_published_fld,
            'is_locked_fld'=>$is_locked_fld,
            'is_del_fld'=>$is_del_fld,
            'current_date'=>$current_date,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        //var_dump($json);die();
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}    
    function view_students_task() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $task_id = $_POST['task_id'];
        $cUrl = $this->get_service_api().'view_students_task';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'task_id'=>$task_id,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        //var_dump($json);die();
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}    
    function view_task_logs() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $task_id = $_POST['task_id'];
        $cUrl = $this->get_service_api().'view_task_logs';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'task_id'=>$task_id,
            'lang_id'=>$user_det['lang_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        //var_dump($json);die();
        $result = json_decode($json, true);        
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_tasks(){        
		$cUrl = $this->get_service_api().'add_tasks';
        $id = $this->input->post('task_token_id');
        $task_dup = $this->input->post('task_dup');
        $title = trim($this->input->post('task_title'));
        $task_category_id = $this->input->post('task_category_id');
        $from_date = $this->input->post('from_date');
        $to_date = $this->input->post('to_date');
        $description = $this->input->post('description');
        $description = str_replace('&nbsp;', ' ', $description);
        $document_files = $this->input->post('document_files');
        $files_order = $this->input->post('files_order');
        $dossier_id = $this->input->post('dos_id');
        $is_published = $this->input->post('is_published');
        $user_det = $this->session->userdata('user_det');
        $task_document="";
        $pdf_flag=false;
        if($document_files!="")
        {
            $task_document=$this->get_task_name($title,$task_category_id,$dossier_id);
            $files_order_arr=explode(",",$files_order);
            $document_files_arr=explode(",",$document_files);
            $files_arr=array();
            foreach($files_order_arr as $fil)
            {  
                if($fil !='')     
                    $files_arr[]= $document_files_arr[$fil];
            }
            $document_files=implode(",",$files_arr);
        }   
        $error_msg="";
        if($document_files!="")
        {            
            $doc_details=explode(",",$document_files);
            foreach($doc_details as $doc)
            {
                $cond="select document_unique_name,document_name from documents where id=".$doc;
                $document_details = $this->users_model->special_fetch($cond);
                if(count($document_details)>0)
                {
                    $document_name=$document_details[0]['document_unique_name'];
                    $document_org_name=$document_details[0]['document_name'];
                    $ext = strtolower(pathinfo($document_name, PATHINFO_EXTENSION));
                    if($ext=="pdf")
                    {
                        if($this->checkPDF($document_name))
                        {
                            if($error_msg=="")
                                $error_msg=$document_org_name;
                            else
                                $error_msg=$error_msg.", ".$document_org_name;
                            $pdf_flag=true;
                        }
                    }                    
                }
            }
        }
        if($pdf_flag)
        {
            $error_msg=$error_msg." are Copywrite Protected PDF files.  Please Unlock them before uploading or remove from the list";
            $out = array('statuscode'=>'201','statusdescription'=>$error_msg);
            echo json_encode($out);
        }
        else
        {  
            $post_data = array(
                'id'=>$id,
                'title'=>$title,
                'task_category_id'=>$task_category_id,
                'from_date'=>$from_date,
                'to_date'=>$to_date,
                'description'=>$description,
                'document_files'=>$document_files,
                'task_document'=>$task_document,
                'dossier_id'=>$dossier_id,
                'task_dup'=>$task_dup,
                'is_published'=>$is_published,
                'lang_id'=>$user_det['lang_id'],
                'user_id'=>$user_det['id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            set_time_limit(0);
            ob_end_clean();
            header("Connection: close");
            ob_start();
            echo $result;
            $size = ob_get_length();
            header("Content-Length: $size");
            ob_end_flush(); // Strange behaviour, will not work
            flush();            // Unless both are called !
            session_write_close(); // Added a line suggested in the comment */
            // Do processing here
            if($document_files!="")
            {
                $this->generate_pdf($document_files,$task_document); 
                $pdf_post_data = array(
                    'task_document'=>$task_document
                );
                $cUrl = $this->get_service_api().'update_task_pdf_status';
                $reqhdrs = array('Accept: application/json');       
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pdf_post_data));
                curl_setopt($ch, CURLOPT_VERBOSE, 1);
                $result1 = curl_exec($ch);
                curl_close($ch);
            }
            die();    
        }        
    }
	function generate_pdf($document_files,$task_file_name)
    {
        $con_pdf =new Concatpdf();
        $path=getcwd();
        $server_path=$path."/assets/uploads/pdf_files";
        $file_server_path=$path."/assets/uploads/user_files";
        $doc_details=explode(",",$document_files);
        foreach($doc_details as $doc)
        {
            $cond="select document_unique_name from documents where id=".$doc;
            $document_details = $this->users_model->special_fetch($cond);
            if(count($document_details)>0)
            {
                $ext = strtolower(pathinfo($document_details[0]['document_unique_name'], PATHINFO_EXTENSION));
                $filePath = $file_server_path."/".$document_details[0]['document_unique_name'];
                if($ext=='pptx'||$ext=='ppt'||$ext=='jpg'||$ext=='jpeg'||$ext=='png'||$ext=='gif'||$ext=='docx'||$ext=='doc'||$ext=='xlsx'||$ext=='xls'||$ext=='rtf'||$ext=='bmp')
                {       
                    if($ext=='gif'||$ext=='bmp')
                    {
                        if (file_exists($filePath)) 
                        {       
                            $con_pdf->addImage_to_pdf($filePath,"");
                        }
                    }
                    else
                    {
                        if (file_exists($filePath)) 
                        {       
                            $file_name="temp_doc_".time().".pdf";
                            $this->word_convertor->convert_to_pdf($file_server_path,$filePath,$file_name);
                            $target_server_path=$path."/assets/uploads/user_files/".$file_name;
                            $con_pdf->addPdf_to_pdf($target_server_path,"");
                            unlink($target_server_path);
                        }
                    }
                }
                else if($ext=='pdf')
                {
                    if (file_exists($filePath)) 
                    {
                        try {
                            $con_pdf->addPdf_to_pdf($filePath,"");

                        } catch (Exception $e) {
                            // Catch the exception and handle the error message
                            $errorMessage = $e->getMessage();
                            // Inform the user about the error
                            echo "An error occurred while processing the PDF: " . $errorMessage;
                        }                        
                    }
                }
            }
        }
        $final_pdf = $server_path."/".$task_file_name.".pdf";
        $con_pdf->Output($final_pdf, 'F');        
    }
    function checkPDF($document_file)
    {
        $check_con_pdf =new Concatpdf();
        $path=getcwd();
        $file_server_path=$path."/assets/uploads/user_files";
        $filePath = $file_server_path."/".$document_file;
        if(file_exists($filePath)) 
        {
            try {
                $check_con_pdf->addPdf_to_pdf($filePath,"");
            } catch (Exception $e) {
                return true;
            }                        
        }
        return false;
    }
    function gen_pdf()
    {
        echo $this->checkPDF("1662349218661_123.pdf");
        //$this->generate_pdf("3796","NOS-TAS-EXE-20230601143556"); 
    }
    function get_task_name($task_name,$task_category_id,$dossier_id)
    {
        $task_category="CAT";
        $lesson_name="LES";
        $cond="select name from task_categories where id=".$task_category_id;
        $task_category_details = $this->users_model->special_fetch($cond);
        if(count($task_category_details)>0)
            $task_category=$task_category_details[0]['name'];
        $cond="select name from dossiers where id=".$dossier_id;
        $dos_details = $this->users_model->special_fetch($cond);
        if(count($dos_details)>0)
            $lesson_name=$dos_details[0]['name'];
        $current_date = date("YmdHis");
        $file_name = strtoupper(substr(preg_replace('/\s+/', '', $lesson_name), 0, 3)) . "-" . strtoupper(substr(preg_replace('/\s+/', '', $task_name), 0, 3)) . "-" . strtoupper(substr(preg_replace('/\s+/', '', $task_category), 0, 3)) . "-" . $current_date;
        return $file_name;
    }
	function change_tasks_status()
    {
    	$cUrl = $this->get_service_api().'change_tasks_status';
        $ids = $this->input->post('ids');
        $status_type = $this->input->post('status_type');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'ids'=>$ids,
            'user_id'=>$user_det['id'],
            'lang_id'=>$user_det['lang_id'],
            'status_type'=>$status_type
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function get_task_categories(){        
		$cUrl = $this->get_service_api().'get_task_categories';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }  
    function check_task_user()
    {
    	$cUrl = $this->get_service_api().'check_task_user';
        $id = $this->input->post('id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function set_task_rating()
    {
    	$cUrl = $this->get_service_api().'set_task_rating';
        $rating = $this->input->post('rating');
        $st_id = $this->input->post('st_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'rating'=>$rating,
            'st_id'=>$st_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }  
    function set_task_comment()
    {
    	$cUrl = $this->get_service_api().'set_task_comment';
        $comments = $this->input->post('comments');
        $st_task_id = $this->input->post('st_task_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'comments'=>$comments,
            'lang_id'=>$user_det['lang_id'],
            'st_task_id'=>$st_task_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function set_annotations()
    {
    	$cUrl = $this->get_service_api().'set_annotations';
        $task_type = $this->input->post('task_type');
        $task_id = $this->input->post('task_id');
        $student_id = $this->input->post('student_id');
        $annotation_xml = $this->input->post('annotation_xml');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'task_type'=>$task_type,
            'task_id'=>$task_id,
            'student_id'=>$student_id,
            'annotation_xml'=>$annotation_xml,
            'lang_id'=>$user_det['lang_id'],
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_annotations()
    {
    	$cUrl = $this->get_service_api().'get_annotations';
        $task_type = $this->input->post('task_type');
        $task_id = $this->input->post('task_id');
        $student_id = $this->input->post('student_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'task_type'=>$task_type,
            'task_id'=>$task_id,
            'student_id'=>$student_id,
            'lang_id'=>$user_det['lang_id'],
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }    
    function get_view_annotations()
    {
    	$cUrl = $this->get_service_api().'get_view_annotations';
        $task_type = $this->input->post('task_type');
        $task_id = $this->input->post('task_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'task_type'=>$task_type,
            'task_id'=>$task_id,
            'user_id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    
    function check_annotation()
    {
    	$cUrl = $this->get_service_api().'check_annotation';
        $task_id = $this->input->post('id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'task_id'=>$task_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function check_task_dates()
    {
    	$cUrl = $this->get_service_api().'check_task_dates';
        $id = $this->input->post('id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
