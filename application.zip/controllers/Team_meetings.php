<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Team_meetings extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function team_meetings() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->get_file_manager();
            $this->load->view($this->view_dir . 'team_meetings', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}    
	function view_team_meetings() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['created_by_fld']))
			$created_by_fld = $_POST['created_by_fld'];
		else
			$created_by_fld ="";
        if(isset($_POST['personnel_fld']))
			$personnel_fld = $_POST['personnel_fld'];
		else
			$personnel_fld ="";	
        if(isset($_POST['student_fld']))
			$student_fld = $_POST['student_fld'];
		else
			$student_fld ="";
        if(isset($_POST['groups_fld']))
			$groups_fld = $_POST['groups_fld'];
		else
			$groups_fld ="";
        if(isset($_POST['date_created_fld']))
			$date_created_fld = $_POST['date_created_fld'];
		else
			$date_created_fld ="";
        if(isset($_POST['deadline_fld']))
			$deadline_fld = $_POST['deadline_fld'];
		else
			$deadline_fld ="";
        if(isset($_POST['meeting_status_fld']))
			$meeting_status_fld = $_POST['meeting_status_fld'];
		else
			$meeting_status_fld ="";
        $cUrl = $this->get_service_api().'view_team_meetings';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'created_by_fld'=>$created_by_fld,
            'personnel_fld'=>$personnel_fld,
            'student_fld'=>$student_fld,
            'groups_fld'=>$groups_fld,
            'date_created_fld'=>$date_created_fld,
            'deadline_fld'=>$deadline_fld,
            'meeting_status_fld'=>$meeting_status_fld,
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id'],
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch); 
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_team_meetings(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_team_meetings'; 
        $user_det = $this->session->userdata('user_det');
        $user_id = $user_det['id']; 
        $id = $this->input->post('token_id');  
        $title = $this->input->post('title');
        $category_id = $this->input->post('category_id');
        $created_by = $this->input->post('created_by');
        $deadline_date = $this->input->post('deadline_date');
        $group_id = $this->input->post('group_id');
        $mid = $this->input->post('mid');
        if(isset($group_id))
            $group_id=implode(",",$group_id);
        else
            $group_id="";
        $student_id = $this->input->post('student_id');
        if(isset($student_id))
            $student_id=implode(",",$student_id);
        else
            $student_id="";
        $personnel_id = $this->input->post('personnel_id'); 
        if(isset($personnel_id))  
            $personnel_id=implode(",",$personnel_id);    
        else
            $personnel_id=""; 
        if(isset($mid))
            $mid=1;
        else
            $mid=0;
        $priority = $this->input->post('priority');
        $meeting_status = $this->input->post('meeting_status');
        $opinion = $this->input->post('opinion');
        $decision = $this->input->post('decision');
        $fail = $this->input->post('fail');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
            'user_id'=>$user_id,
            'title'=>$title,
            'category_id'=>$category_id,
            'created_by'=>$created_by,
            'deadline_date'=>$deadline_date,
            'group_id'=>$group_id,
            'student_id'=>$student_id,
            'personnel_id'=>$personnel_id,
            'mid'=>$mid,
            'opinion'=>$opinion,
            'decision'=>$decision,
            'priority'=>$priority,
            'meeting_status'=>$meeting_status,
            'fail'=>$fail,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function add_team_notifications(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_team_notifications';
        $user_det = $this->session->userdata('user_det');
        $token_id = $this->input->post('team_token_id');
        $student_rbtn = $this->input->post('student_rbtn');
        $personnel_rbtn = $this->input->post('personnel_rbtn');
        $parent_rbtn = $this->input->post('parent_rbtn');
        $personnel_id = $this->input->post('personnel_team_id');
        $student_course_id = $this->input->post('student_course_id');
        $student_id = $this->input->post('student_id');
        $parent_course_id = $this->input->post('parent_course_id');
        $parent_id = $this->input->post('parent_id');
        $reply_enabled = $this->input->post('reply_enabled');
        if(!isset($parent_id))
            $parent_id=array();
        if(!isset($student_id))
            $student_id=array();
        if(!isset($personnel_id))
            $personnel_id=array();
        if(!isset($student_course_id))
            $student_course_id=array();
        if(!isset($parent_course_id))
            $parent_course_id=array();
        if(isset($reply_enabled))
            $reply_enabled=1;
        else
            $reply_enabled=0;
        $post_data = array(
            'id'=>$user_det['id'],
            'token_id'=>$token_id,
            'student_rbtn'=>$student_rbtn,
            'personnel_rbtn'=>$personnel_rbtn,
            'parent_rbtn'=>$parent_rbtn,
            'personnel_id'=>$personnel_id,
            'student_course_id'=>$student_course_id,
            'student_id'=>$student_id,
            'parent_course_id'=>$parent_course_id,
            'parent_id'=>$parent_id,
            'lang_id'=>$user_det['lang_id'],
            'reply_enabled'=>$reply_enabled
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_team_meetings(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_team_meetings';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_team_meetings(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_team_meetings';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_meeting_categories(){        
		$cUrl = $this->get_service_api().'get_meeting_categories';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_personnel(){        
		$cUrl = $this->get_service_api().'get_personnel';
        $reqhdrs = array('Accept: application/json');    
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'id'=>$user_det['id'],
            'group_id'=>$user_det['group_id']
          ); 
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    
}
