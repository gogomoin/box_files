<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Timeline extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function timeline() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
            $cond="select s.value from system_settings s where s.key='mark-evaluation-type'";
			$settings_details = $this->users_model->special_fetch($cond);
            if(count($settings_details)>0)
                $this->data['number_system'] = $settings_details[0]['value'];
            else
                $this->data['number_system'] = 'number';
            $lang_code="en";
            $cond="select s.code from languages s where s.id=".$user_det['lang_id'];
            $lang_code_details = $this->users_model->special_fetch($cond);
            if(count($lang_code_details)>0){
                    $lang_code = $lang_code_details[0]['code'];
            }
            $this->data['lang_code'] = $lang_code;
			$this->get_include();
            $this->load->view($this->view_dir . 'timeline', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
    function view_timeline(){
        
		$cUrl = $this->get_service_api().'view_timeline';
        $weekday_fld = strtolower($this->input->post('weekday_fld'));
        $course_date = $this->input->post('course_date');
        $cur_student_id = $this->input->post('cur_student_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'weekday_fld'=>$weekday_fld,
            'course_date'=>$course_date,
            'cur_student_id'=>$cur_student_id,
            'id'=>$user_det['id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function view_timeline_student_details() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
        if(isset($_POST['student_details']))
            $student_details = $_POST['student_details'];
        else
            $student_details=array();
        $course_id = $_POST['course_id'];
        $cUrl = $this->get_service_api().'view_timeline_student_details';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'searchValue'=>$searchValue,
			'student_details'=>$student_details,
            'course_id'=>$course_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_timeline_student_files(){
        
		$cUrl = $this->get_service_api().'view_timeline_student_files';
        $id = $this->input->post('id');
        $student_id = $this->input->post('student_id');
        $post_data = array(
            'id'=>$id,
			'student_id'=>$student_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function view_timeline_teacher_details() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $course_id = $_POST['course_id'];
        $columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $cUrl = $this->get_service_api().'view_timeline_teacher_details';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'id'=>$user_det['id'],
            'course_id'=>$course_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function view_timeline_student_file_details() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $course_id = $_POST['course_id'];
        $columnIndex = $_POST['order'][0]['column'];
        $columnName = "";$columnSortOrder ="";
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
        $cUrl = $this->get_service_api().'view_timeline_student_file_details';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
            'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'id'=>$user_det['id'],
            'course_id'=>$course_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_timeline_absence(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_timeline_absence';
        $label_details = $this->get_labels();
        $total_students = $this->input->post('total_students');
        $user_det = $this->session->userdata('user_det');
        $absences=array();
        for($i=0;$i<$total_students;$i++)
        {
            $student_term_id_val="student_term_id_".$i;
            $from_time_val="from_time_".$i;
            $to_time_val="to_time_".$i;
            $eval_date_val="eval_date_".$i;
            $is_missing_val="is_missing_".$i;
            $is_excusable_val="is_excusable_".$i;
            $is_excused_val="is_excused_".$i;
            $absence_category_id_val="absence_category_id_".$i;
            $excusable=$this->input->post($is_excusable_val);
            $excused=$this->input->post($is_excused_val);
            $missing=$this->input->post($is_missing_val);
            if(isset($excusable))
                $excusable=1;
            else
                $excusable=0;
            if(isset($excused))
                $excused=1;
            else
                $excused=0;
            if(isset($missing))
            {
                $absences[] = array(
                    'student_term_id'=>$this->input->post($student_term_id_val),
                    'from_time'=>$this->input->post($from_time_val),
                    'to_time'=>$this->input->post($to_time_val),
                    'eval_date'=>$this->input->post($eval_date_val),
                    'is_excusable'=>$excusable,
                    'is_excused'=>$excused,
                    'absence_category_id'=>$this->input->post($absence_category_id_val),
                    'id'=>$user_det['id']
                );
            }
        }
        if(count($absences)<=0)
        {
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[125]['name']);
            echo json_encode($out);
        }
        else
        {
            $post_data = array(
                'absences'=>$absences,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;  
        }              
    }
    function add_timeline_disciplinary(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_timeline_disciplinary';
        $label_details = $this->get_labels();
        $total_students = $this->input->post('total_students');
        $disciplinary=array();
        for($i=0;$i<$total_students;$i++)
        {
            $student_id_val="student_id_".$i;
            $is_remark_val="is_remark_".$i;
            $parental_check_val="parental_check_".$i;
            $disciplinary_category_id_val="disciplinary_category_id_".$i;
            $description_id_val="description_".$i;
            $parental_check=$this->input->post($parental_check_val);
            $remark=$this->input->post($is_remark_val);
            if(isset($parental_check))
                $parental_check=1;
            else
                $parental_check=0;
            if(isset($remark))
            {
                $disciplinary[] = array(
                    'student_id'=>$this->input->post($student_id_val),
                    'description'=>$this->input->post($description_id_val),
                    'parental_check'=>$parental_check,
                    'disciplinary_category_id'=>$this->input->post($disciplinary_category_id_val),
                    'id'=>$user_det['id']
                );
            }
        }
        if(count($disciplinary)<=0)
        {
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[126]['name']);
            echo json_encode($out);
        }
        else
        {
            $post_data = array(
                'disciplinary'=>$disciplinary,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;  
        }              
    }
    function add_timeline_marks(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_timeline_marks';
        $course_id = $this->input->post('course_id');
        $mark_category_id = $this->input->post('mark_category_id');
        $remark = $this->input->post('remark');
        $evaluation_date = $this->input->post('evaluation_date');
        $dossier_id = $this->input->post('dossier_id');
        $mark_counts = $this->input->post('mark_counts');
        $total_students = $this->input->post('total_students');
        $marks_assignment = $this->input->post('marks_assignment');
        $min_mark = $this->input->post('min_mark');
        $max_mark = $this->input->post('max_mark');
        $medium_mark = $this->input->post('medium_mark');
        $min_points = $this->input->post('min_points');
        $max_points = $this->input->post('max_points');
        $medium_points = $this->input->post('medium_points');
        if($marks_assignment==1)
        {
            $mark_type="predefined";
            $mark_schema=array("min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==2)
        {
            $mark_type="max_points_custom_mark";
            $mark_schema=array("max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        else if($marks_assignment==3)
        {
            $mark_type="complex_points_custom_mark";
            $mark_schema=array("min_points"=>$min_points,"medium_points"=>$medium_points,"max_points"=>$max_points,"min_mark"=>$min_mark,"medium_mark"=>$medium_mark,"max_mark"=>$max_mark);
        }
        if(isset($mark_counts))
            $mark_counts=1;
        else
            $mark_counts=0;
        $students=array();
        $marks=array();
        for($i=0;$i<$total_students;$i++)
        {
            $stu_id_val="student_id_".$i;
            $mark_id_val="mark_points_".$i;
            $mark_val=$this->input->post($mark_id_val);
            if($mark_val!="")
            {
                $students[]=$this->input->post($stu_id_val);
                $marks[]=$this->input->post($mark_id_val);
            }
        }
        $post_data = array(
            'course_id'=>$course_id,
            'mark_category_id'=>$mark_category_id,
            'remark'=>$remark,
            'evaluation_date'=>$evaluation_date,
            'dossier_id'=>$dossier_id,
            'mark_schema'=>$mark_schema,
            'mark_type'=>$mark_type,
            'mark_counts'=>$mark_counts,
            'students'=>$students,
            'lang_id'=>$user_det['lang_id'],
            'marks'=>$marks
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;  
    }
    function add_timeline_teacher_uploads()
	{
        if ($_FILES["attachment"]["error"] == UPLOAD_ERR_OK)
		{
            $user_det = $this->session->userdata('user_det');
            $name = $this->input->post('unqfilename');
            $allow_uploads = $this->input->post('allow_uploads');
            $course_id = $this->input->post('course_id');
            $description = $this->input->post('description');
            $fileorgName = $this->input->post('fileorgName');
            $lastModified = $this->input->post('lastModified');
            $tmp_name = $_FILES["attachment"]["tmp_name"];
            $cond="SELECT * FROM course_uploads c,course_upload_settings cu WHERE c.course_upload_setting_id=cu.id and cu.course_id=".$course_id." and c.uploaded_by=".$user_det['id']." and c.updated_at='".$lastModified."' and c.original_file_name='".$fileorgName."'";
		    $course_details = $this->users_model->special_fetch($cond);
            if(count($course_details)>0)
            {
                echo json_encode(array('status' => '201'));
            }
            else
            {
                $uploads_dir = 'assets/uploads/user_files';
                move_uploaded_file($tmp_name, "$uploads_dir/$name");
                $cUrl = $this->get_service_api().'add_timeline_teacher_uploads';
                $post_data = array(
                    'id'=>$user_det['id'],
                    'course_id'=>$course_id,
                    'allow_uploads'=>$allow_uploads,
                    'description'=>$description,
                    'fileorgName'=>$fileorgName,
                    'lastModified'=>$lastModified,
                    'lang_id'=>$user_det['lang_id'],
                    'unqfilename'=>$name
                );
                $reqhdrs = array('Accept: application/json');       
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
                curl_setopt($ch, CURLOPT_VERBOSE, 1);
                $result = curl_exec($ch);
                curl_close($ch);
                echo json_encode(array('status' => '200'));
            }
		}
		else
		{
			echo json_encode(array('status' => '201'));
		}
     }
    function add_timeline_student_uploads()
	{
        if ($_FILES["attachment"]["error"] == UPLOAD_ERR_OK)
		{
            $user_det = $this->session->userdata('user_det');
            $name = $this->input->post('unqfilename');
            $course_attendant_id = $this->input->post('course_attendant_id');
            $course_id = $this->input->post('course_id');
            $description = $this->input->post('description');
            $fileorgName = $this->input->post('fileorgName');
            $lastModified = $this->input->post('lastModified');
            $tmp_name = $_FILES["attachment"]["tmp_name"];
            $cond="SELECT * FROM course_uploads c,course_upload_settings cu WHERE c.course_upload_setting_id=cu.id and cu.course_id=".$course_id." and c.uploaded_by=".$user_det['id']." and c.updated_at='".$lastModified."' and c.original_file_name='".$fileorgName."'";
		    $course_details = $this->users_model->special_fetch($cond);
            if(count($course_details)>0)
            {
                echo json_encode(array('status' => '201'));
            }
            else
            {
                $uploads_dir = 'assets/uploads/user_files';
                move_uploaded_file($tmp_name, "$uploads_dir/$name");
                $cUrl = $this->get_service_api().'add_timeline_student_uploads';
                $post_data = array(
                    'id'=>$user_det['id'],
                    'course_id'=>$course_id,
                    'course_attendant_id'=>$course_attendant_id,
                    'description'=>$description,
                    'fileorgName'=>$fileorgName,
                    'lastModified'=>$lastModified,
                    'lang_id'=>$user_det['lang_id'],
                    'unqfilename'=>$name
                );
                $reqhdrs = array('Accept: application/json');       
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $cUrl);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
                curl_setopt($ch, CURLOPT_VERBOSE, 1);
                $result = curl_exec($ch);
                curl_close($ch);
                echo json_encode(array('status' => '200'));
            }
		}
		else
		{
			echo json_encode(array('status' => '201'));
		}
     }
     function update_course_upload_settings(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'update_course_upload_settings';
        $id = $this->input->post('id');
		$allow_uploads = $this->input->post('allow_uploads');
        $post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
			'allow_uploads'=>$allow_uploads
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function update_course_uploads(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'update_course_uploads';
        $id = $this->input->post('id');
		$teacher_checked = $this->input->post('teacher_checked');
        $post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
			'teacher_checked'=>$teacher_checked
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function update_student_course_uploads(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'update_student_course_uploads';
        $id = $this->input->post('id');
		$homework_completed = $this->input->post('homework_completed');
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
            'student_id'=>$user_det['id'],
			'homework_completed'=>$homework_completed
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_course_uploads(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_course_uploads';
        $id = $this->input->post('id');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'id'=>$id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function get_dossier_by_id(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'get_dossier_by_id';
        $id = $this->input->post('id');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'id'=>$id
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_students_for_timeline(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'get_students_for_timeline';
        $post_data = array(
            'group_id'=>$user_det['group_id'],
            'id'=>$user_det['id']
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_upload_count(){
        
		$cUrl = $this->get_service_api().'get_upload_count';
        $course_id = $this->input->post('course_id');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'course_id'=>$course_id,
            'id'=>$user_det['id']
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
}
