<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Timetable extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//timetable	
	
	function timetable() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'timetable', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_daily_timetable() 
	{
        $weekday_fld = $this->input->post('weekday_fld');
        $term_fld = $this->input->post('term_fld');
        $teacher_fld = $this->input->post('teacher_fld');
		$cUrl = $this->get_service_api().'view_daily_timetable';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'weekday_fld'=>$weekday_fld,
			'term_fld'=>$term_fld,
			'teacher_fld'=>$teacher_fld
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        curl_close($ch);
        echo $json;
	}
    function view_weekly_timetable() 
	{
        $term_fld = $this->input->post('term_fld');
        $cUrl = $this->get_service_api().'view_weekly_timetable';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
        	'term_fld'=>$term_fld
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        curl_close($ch);
        echo $json;
	}
	function add_timetable(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_timetable';
        $time_table_id = $this->input->post('time_table_id');
        $course_id  = $this->input->post('course_id');
        $post_data = array(
            'time_table_id'=>$time_table_id,
            'lang_id'=>$user_det['lang_id'],
            'course_id'=>$course_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function edit_timetable(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_timetable';
        $time_table_id = $this->input->post('time_table_id');
        $course_id  = $this->input->post('course_id');
        $post_data = array(
            'time_table_id'=>$time_table_id,
            'lang_id'=>$user_det['lang_id'],
            'course_id'=>$course_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function delete_timetable(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_timetable';
        $time_table_id = $this->input->post('time_table_id');
        $post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'time_table_id'=>$time_table_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function duplicate_timetable(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'duplicate_timetable';
        $source_term_id = $this->input->post('source_term_id');
        $destination_term_id = $this->input->post('destination_term_id');
        $teacher_fld = $this->input->post('teacher_fld');
        $post_data = array(
            'source_term_id'=>$source_term_id,
            'lang_id'=>$user_det['lang_id'],
            'destination_term_id'=>$destination_term_id
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function clear_timetable(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'clear_timetable';
        $term_fld = $this->input->post('term_fld');
        $weekday_fld = $this->input->post('weekday_fld');
        $teacher_fld = $this->input->post('teacher_fld');
        $post_data = array(
            'term_fld'=>$term_fld,
            'lang_id'=>$user_det['lang_id'],
            'weekday_fld'=>$weekday_fld,
            'teacher_fld'=>$teacher_fld
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	
    function get_weekdays(){        
		$cUrl = $this->get_service_api().'get_weekdays';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
	function import_timetable(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_timetable';
        $label_details = $this->get_labels();
		$path = $_FILES["import_timetable_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[46]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $ter=$label_details[80]['name']." *";
        $wday=$label_details[81]['name']." *";
        if($col1!=$ter||$col2!=$wday)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[45]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                $term_id="";
                if(isset($sheets[$i][0]))
                {
                    $term=trim($sheets[$i][0]);
                    if($term!="")
                    {
                        $cond="select id from terms where name='".$term."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $term_id=$cu_details[0]['id'];
                        else
                            $term_id="";
                    }                    
                }
                else
                    $term=""; 
                $weekday_id="";
                if(isset($sheets[$i][1]))
                {
                    $weekday=trim($sheets[$i][1]);
                    if($weekday!="")
                    {
                        $cond="select id from weekdays where name='".$weekday."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $weekday_id=$cu_details[0]['id'];
                        else
                            $weekday_id="";
                    }                    
                }
                else
                    $weekday="";
                $lesson_number_id="";
                if(isset($sheets[$i][2]))
                {
                    $lesson_number=trim($sheets[$i][2]);
                    if($lesson_number!="")
                    {
                        $cond="select id from lesson_numbers where lesson_number='".$lesson_number."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $lesson_number_id=$cu_details[0]['id'];
                        else
                            $lesson_number_id="";
                    }                    
                }
                else
                    $lesson_number="";
                $room_id="";
                if(isset($sheets[$i][3]))
                {
                    $room=trim($sheets[$i][3]);
                    if($room!="")
                    {
                        $cond="select id from rooms where name='".$room."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $room_id=$cu_details[0]['id'];
                        else
                            $room_id="";
                    }                    
                }
                else
                    $room="";
                $course_id="";
                if(isset($sheets[$i][4]))
                {
                    $course=trim($sheets[$i][4]);
                    if($course!="")
                    {
                        $cond="select id from courses where name='".$course."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $course_id=$cu_details[0]['id'];
                        else
                            $course_id="";
                    }                    
                }
                else
                    $course="";
                if($term!=""||$weekday!=""||$lesson_number!=""||$room!=""||$course!="")
                {                             
                    $page_details[]=array(
                        "term"=>$term,
                        "term_id"=>$term_id,
                        "weekday"=>$weekday,
                        "weekday_id"=>$weekday_id,
                        "lesson_number"=>$lesson_number,
                        "lesson_number_id"=>$lesson_number_id,
                        "room"=>$room,
                        "room_id"=>$room_id,
                        "course"=>$course,
                        "course_id"=>$course_id
                    );
                }				
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[46]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}	
}
