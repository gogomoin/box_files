<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Timetable_weekly extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//timetable_weekly	
	
	function timetable_weekly() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'timetable_weekly', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	
    function get_weekly_timetable() 
	{
        $personnel_fld = $this->input->post('personnel_fld');
        $cUrl = $this->get_service_api().'get_weekly_timetable';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
        	'personnel_fld'=>$personnel_fld,
            'id'=>$user_det['id']
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
        curl_close($ch);
        echo $json;
	}	
    function get_student_teacher(){        
        $cUrl = $this->get_service_api().'get_student_teacher';
        $reqhdrs = array('Accept: application/json');    
        $search_term = $this->input->post('searchTerm');
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'search_term'=>$search_term,
            'id'=>$user_det['id']
        );  
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
}
