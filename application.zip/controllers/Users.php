<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Users extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
        $this->load->library('excel_creator');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function users() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
            $this->data['page_details'] = $page_details;
            $this->session->set_userdata('page_layout',$page_layout);
            $user_det = $this->session->userdata('user_det');
            $lang_id = $user_det['lang_id'];
            $cond="select name from labels where page_id=34 and lang_id=".$lang_id;
            $label_details = $this->users_model->special_fetch($cond);
            //$label_details = $this->get_labels();
            $pgn_details = $this->get_paginate_numbers();
            $this->data['label_details'] = $label_details;
            $this->data['pgn_details'] = $pgn_details;
            $this->data['role_details'] = $this->get_role_details();
			$this->get_include();
            $this->load->view($this->view_dir . 'users', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	} 
    function get_user_labels()
    { 
        $user_det = $this->session->userdata('user_det');    
		$cond="select name from labels where page_id=34 and lang_id=".$user_det['id'];
		$label_details = $this->users_model->special_fetch($cond);
		return $label_details;
    }   
	function view_users() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['function_fld']))
			$function_fld = $_POST['function_fld'];
		else
			$function_fld ="";
        if(isset($_POST['teacher_fld']))
			$teacher_fld = $_POST['teacher_fld'];
		else
			$teacher_fld ="";	
        if(isset($_POST['admin_fld']))
			$admin_fld = $_POST['admin_fld'];
		else
			$admin_fld ="";
        if(isset($_POST['sysadmin_fld']))
			$sysadmin_fld = $_POST['sysadmin_fld'];
		else
			$sysadmin_fld ="";		
		$cUrl = $this->get_service_api().'view_users';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'function_fld'=>$function_fld,
            'teacher_fld'=>$teacher_fld,
            'admin_fld'=>$admin_fld,
            'sysadmin_fld'=>$sysadmin_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);     
        $result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
    function randomPassword($num) {
        $alphabet = '1234567890';
        $pass = array(); //remember to declare $pass as an array
        $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
        for ($i = 0; $i < $num; $i++) {
            $n = rand(0, $alphaLength);
            $pass[] = $alphabet[$n];
        }
        return implode($pass); //turn the array into a string
    }
	function add_users(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'add_users';    
        $id = $this->input->post('add_token_id');    
        $last_name = $this->input->post('last_name');
        $first_name = $this->input->post('first_name');
        $email = trim($this->input->post('email'));
        $username = trim($this->input->post('email'));
        $pwd=$this->randomPassword(6);
        $password=md5($pwd);
        $personnel_function_id  = $this->input->post('personnel_function_id');
        $gender_id = $this->input->post('gender_id');
        $country = $this->input->post('country_id');
        $city = $this->input->post('city');
        $address = $this->input->post('address');
        $address2 = $this->input->post('address2');        
        $zip = $this->input->post('zip');
        $mobile_phone = $this->input->post('mobile_phone');
        $fixed_phone = $this->input->post('fixed_phone');
        $birth_date = $this->input->post('birth_date');
        $admission = $this->input->post('admission');        
        $emission = $this->input->post('emission');
        $diploma = $this->input->post('diploma');
        $status = $this->input->post('status');
        $no_email = $this->input->post('no_email');
        $teacher = $this->input->post('teachers');
        $admin = $this->input->post('admin');
        $sysadmin = $this->input->post('sysadmin');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($no_email))
            $no_email=1;
        else
            $no_email=0;
        if(isset($teacher))
            $teacher=2;
        if(isset($admin))
            $admin=1;
        if(isset($sysadmin))
            $sysadmin=3;
        $post_data = array(
            'id'=>$id,
            'last_name'=>$last_name,
            'first_name'=>$first_name,
            'email'=>$email,
            'salt'=>$pwd,
            'password'=>$password,
            'personnel_function_id'=>$personnel_function_id,
            'gender_id'=>$gender_id,
            'country'=>$country,
            'city'=>$city,
            'address'=>$address,
            'address2'=>$address2,
            'zip'=>$zip,
            'mobile_phone'=>$mobile_phone,
            'fixed_phone'=>$fixed_phone,
            'birth_date'=>$birth_date,
            'admission'=>$admission,
            'emission'=>$emission,
            'diploma'=>$diploma,
            'no_email'=>$no_email,
            'teacher'=>$teacher,
            'admin'=>$admin,
            'sysadmin'=>$sysadmin,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_users(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'edit_users';
        
        $id = $this->input->post('token_id');
		$last_name = $this->input->post('last_name');
        $first_name = $this->input->post('first_name');
        $email = trim($this->input->post('email'));
        $username = trim($this->input->post('email'));
        $pwd=$this->randomPassword(6);
        $password=md5($pwd);
        $personnel_function_id  = $this->input->post('personnel_function_id');
        $gender_id = $this->input->post('gender_id');
        $country = $this->input->post('country_id');
        $city = $this->input->post('city');
        $address = $this->input->post('address');
        $address2 = $this->input->post('address2');        
        $zip = $this->input->post('zip');
        $mobile_phone = $this->input->post('mobile_phone');
        $fixed_phone = $this->input->post('fixed_phone');
        $birth_date = $this->input->post('birth_date');
        $admission = $this->input->post('admission');        
        $emission = $this->input->post('emission');
        $diploma = $this->input->post('diploma');
        $no_email = $this->input->post('no_email');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        if(isset($no_email))
            $no_email=1;
        else
            $no_email=0;
        $teacher = $this->input->post('teachers');
        $admin = $this->input->post('admin');
        $sysadmin = $this->input->post('sysadmin');
        if(isset($teacher))
            $teacher=2;
        else
            $teacher="";
        if(isset($admin))
            $admin=1;
        else
            $admin="";
        if(isset($sysadmin))
            $sysadmin=3;
        else
            $sysadmin="";
        $post_data = array(
            'id'=>$id,
			'last_name'=>$last_name,
            'first_name'=>$first_name,
            'email'=>$email,
            'username'=>$email,
            'salt'=>$pwd,
            'password'=>$password,
            'personnel_function_id'=>$personnel_function_id,
            'gender_id'=>$gender_id,
            'country'=>$country,
            'city'=>$city,
            'address'=>$address,
            'address2'=>$address2,
            'zip'=>$zip,
            'mobile_phone'=>$mobile_phone,
            'fixed_phone'=>$fixed_phone,
            'birth_date'=>$birth_date,
            'admission'=>$admission,
            'emission'=>$emission,
            'diploma'=>$diploma,
            'no_email'=>$no_email,
            'teacher'=>$teacher,
            'admin'=>$admin,
            'sysadmin'=>$sysadmin,
            'lang_id'=>$user_det['lang_id'],
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_users(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'delete_users';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_users(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'restore_users';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_users(){
        $user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'set_status_users';
        $ids = $this->input->post('ids');
		$post_data = array(
            'lang_id'=>$user_det['lang_id'],
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_personnel_functions(){        
		$cUrl = $this->get_service_api().'get_personnel_functions';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_gender(){        
		$cUrl = $this->get_service_api().'get_gender';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function import_users(){
		$user_det = $this->session->userdata('user_det');
		$cUrl = $this->get_service_api().'import_users';
        $label_details = $this->get_labels();
		$path = $_FILES["import_users_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$sheet_data=$this->excel_creator->read_file($target_file);
		$page_details = array();
        $error_flag=false;
        $col1="";$col2="";
        $col1=$sheet_data[0][0][0];
        if(isset($sheet_data[0][0][1]))
            $col2=$sheet_data[0][0][1];
        else
            $col2="";
        if($col1==""&&$col2=="")
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[155]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
            return;
        }
        $nam=$label_details[271]['name']." *";
        $fir=$label_details[272]['name']." *";
        if($col1!=$nam||$col2!=$fir)
            $error_flag=true;
        if($error_flag)
        {
            $error_rows=array();
            $out = array('statuscode'=>'201','statusdescription'=>$label_details[154]['name'],'error_rows'=>$error_rows);
            echo json_encode($out);
            return;
        }
		foreach($sheet_data as $sheets)
		{
			for($i=1;$i<count($sheets);$i++)
			{
                if(isset($sheets[$i][0]))
                    $name=trim($sheets[$i][0]);
                else
                    $name="";
                if(isset($sheets[$i][1]))
                    $first_name=trim($sheets[$i][1]);
                else
                    $first_name="";
                if(isset($sheets[$i][2]))
                    $email =trim($sheets[$i][2]);
                else
                    $email ="";
                $personnel_function_id="";
                if(isset($sheets[$i][3]))
                {
                    $personnel=trim($sheets[$i][3]);
                    if($personnel!="")
                    {
                        $cond="select id from personnel_functions where name='".$personnel."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $personnel_function_id=$cu_details[0]['id'];
                        else
                            $personnel_function_id="";
                    }                    
                }
                else
                    $personnel=""; 
                $gender_id="";
                if(isset($sheets[$i][4]))
                {
                    $gender=trim($sheets[$i][4]);
                    if($gender!="")
                    {
                        $cond="select id from genders where name='".$gender."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $gender_id=$cu_details[0]['id'];
                        else
                            $gender_id="";
                    }                    
                }
                else
                    $gender="";
                if(isset($sheets[$i][5]))
                {
                    $admission=trim($sheets[$i][5]);
                    $admission=str_replace("/","-",$admission);
                }
                else
                    $admission="";
                $country_id="";
                if(isset($sheets[$i][6]))
                {
                    $country=trim($sheets[$i][6]);
                    if($country!="")
                    {
                        $cond="select id from countries where name='".$country."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $country_id=$cu_details[0]['id'];
                        else
                            $country_id="";
                    }                    
                }
                else
                    $country="";
                if(isset($sheets[$i][7]))
                    $teacher=trim($sheets[$i][7]);
                else
                    $teacher="";
                if(isset($sheets[$i][8]))
                    $admin=trim($sheets[$i][8]);
                else
                    $admin="";
                if(isset($sheets[$i][9]))
                    $sysadmin=trim($sheets[$i][9]);
                else
                    $sysadmin="";
                if(isset($sheets[$i][10]))
                {
                    $birth_date=trim($sheets[$i][10]);
                    $birth_date=str_replace("/","-",$birth_date);
                }
                else
                    $birth_date="";
                if(isset($sheets[$i][11]))
                {
                    $emission=trim($sheets[$i][11]);
                    $emission=str_replace("/","-",$emission);
                }
                else
                    $emission="";
                if(isset($sheets[$i][12]))
                    $diploma=trim($sheets[$i][12]);
                else
                    $diploma="";
                if(isset($sheets[$i][13]))
                    $city=trim($sheets[$i][13]);
                else
                    $city="";
                if(isset($sheets[$i][14]))
                    $address=trim($sheets[$i][14]);
                else
                    $address="";
                if(isset($sheets[$i][15]))
                    $zip=trim($sheets[$i][15]);
                else
                    $zip="";
                if(isset($sheets[$i][16]))
                    $address2=trim($sheets[$i][16]);
                else
                    $address2="";
                if(isset($sheets[$i][17]))
                    $mobile_phone=trim($sheets[$i][17]);
                else
                    $mobile_phone="";  
                if(isset($sheets[$i][18]))
                    $fixed_phone=trim($sheets[$i][18]);
                else
                    $fixed_phone="";               
                if(isset($sheets[$i][19]))
                    $status=trim($sheets[$i][19]);
                else
                    $status="";
                if($name!=""||$first_name!=""||$email!=""||$personnel!=""||$gender!=""||$country!=""||$teacher!=""||$admin!=""||$sysadmin!=""||$birth_date!=""||$emission!=""||$diploma!=""||$city!=""||$address!=""||$zip!=""||$address2!=""||$mobile_phone!=""||$fixed_phone!=""||$status!="")
                {
                    $pwd=$this->randomPassword(6);
                    $password=md5($pwd);          
                    $page_details[]=array(
                        "name"=>$name,
                        "first_name"=>$first_name,
                        "email"=>$email,
                        "salt"=>$pwd,
                        "password"=>$email,
                        "personnel"=>$password,
                        "personnel_function_id"=>$personnel_function_id,
                        "gender"=>$gender,
                        "gender_id"=>$gender_id,
                        "country"=>$country,
                        "country_id"=>$country_id,
                        "teacher"=>$teacher,
                        "admin"=>$admin,
                        "sysadmin"=>$sysadmin,
                        "birth_date"=>$birth_date,
                        "admission"=>$admission,
                        "emission"=>$emission,
                        "diploma"=>$diploma,
                        "city"=>$city,
                        "address"=>$address,
                        "zip"=>$zip,
                        "address2"=>$address2,
                        "mobile_phone"=>$mobile_phone,
                        "fixed_phone"=>$fixed_phone,                        
                        "status"=>$status                 
                    );		
                }		
			}
		}
        if(count($page_details)>0)
        {
            $post_data = array(
                'page_details'=>$page_details,'lang_id'=>$user_det['lang_id']
            );
            $reqhdrs = array('Accept: application/json');       
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $cUrl);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
            curl_setopt($ch, CURLOPT_VERBOSE, 1);
            $result = curl_exec($ch);
            curl_close($ch);
            echo $result;
        }
        else
        {
            $error_rows=array();
            $out = array(
                'statuscode' => "201",
                'statusdescription'=>$label_details[155]['name'],
                'error_rows'=>$error_rows
            );
            $result = json_encode($out);
            echo $result;
        }
	}
    function test_array()
    {
        if(is_numeric("a")) {
            echo 'Found';
        }
        else
        {
            echo "Not Found";
        }
    }
    function get_trans(){
		echo $this->tran("de","Hello");
		
	}
	function tran($code,$text)
	{
		$url = 'https://www.googleapis.com/language/translate/v2?key='. APIKEY.'&q='.rawurlencode($text).'&source=en&target='.$code;
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($handle); 
		$responseDecoded = json_decode($response, true);
		curl_close($handle);
        if (array_key_exists("error",$responseDecoded))
        {
            echo "Language Code Error!";
        }
        else
        {
		    $res_text=$responseDecoded['data']['translations'][0]['translatedText'];
		    return $res_text;
        }
	}
    function document_convert_dates()
    {
        $cond="select id,created_at,document_unique_name from documents";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
			$timestamp = strtotime($pro['created_at']);
			$uploads_dir = 'assets/uploads/user_files';
			$file_path=$uploads_dir.'/'.$pro['document_unique_name'];
			$file_bytes=filesize($file_path);
			$file_size=$this->formatSizeUnits($file_bytes);
			$input = array(
				'created_at'=>$timestamp,
				'file_size'=>$file_size
			);
			$this->file_manager_model->edit($input,$pro['id']);
		}
		echo "Done";
    }
    function document_update_folders()
    {
        $cond="select id,dossier_key,personnel_id from dossiers where id<>1";
		$pro_details = $this->users_model->special_fetch($cond);
		foreach($pro_details as $pro)
		{
            $cond="select id from folders where folder='".$pro['dossier_key']."' and user_id=".$pro['personnel_id'];
		    $dos_key_details = $this->users_model->special_fetch($cond);
            if(count($dos_key_details)>0)
            {
                if($dos_key_details[0]['id']!="")
                {
                    $cond="select id from folders where folder='Learning Materials' and user_id=".$pro['personnel_id']." and parent_folder=".$dos_key_details[0]['id'];
                    $dos_fol_rel_details = $this->users_model->special_fetch($cond);
                    if(count($dos_fol_rel_details)>0)
                    {
                        $cond="select dossier_file_id from dossiers_related_files where dossier_id=".$pro['id'];
                        $dos_rel_details = $this->users_model->special_fetch($cond);
                        foreach($dos_rel_details as $rel)
                        {
                            if($rel['dossier_file_id']!="")
                            {
                                $cond="select document_unique_name from documents where id=".$rel['dossier_file_id'];
                                $doc_details = $this->users_model->special_fetch($cond);
                                if(count($doc_details)>0)
                                {
                                    $uploads_dir = 'assets/uploads/user_files';
                                    $file_path=$uploads_dir.'/'.$doc_details[0]['document_unique_name'];
                                    $file_bytes=filesize($file_path);
                                    $file_size=$this->formatSizeUnits($file_bytes);
                                    $input = array(
                                        'folder_id'=>$dos_fol_rel_details[0]['id'],
                                        'file_size'=>$file_size
                                    );
                                    $this->file_manager_model->edit($input,$rel['dossier_file_id']);
                                }
                            }
                        }
                    }
                    $cond="select id from folders where folder='Solutions' and user_id=".$pro['personnel_id']." and parent_folder=".$dos_key_details[0]['id'];
                    $dos_fol_sol_details = $this->users_model->special_fetch($cond);
                    if(count($dos_fol_sol_details)>0)
                    {
                        $cond="select dossier_file_id from dossiers_solutions where dossier_id=".$pro['id'];
                        $dos_rel_details = $this->users_model->special_fetch($cond);
                        foreach($dos_rel_details as $rel)
                        {
                            if($rel['dossier_file_id']!="")
                            {
                                $cond="select document_unique_name from documents where id=".$rel['dossier_file_id'];
                                $doc_details = $this->users_model->special_fetch($cond);
                                if(count($doc_details)>0)
                                {
                                    $uploads_dir = 'assets/uploads/user_files';
                                    $file_path=$uploads_dir.'/'.$doc_details[0]['document_unique_name'];
                                    $file_bytes=filesize($file_path);
                                    $file_size=$this->formatSizeUnits($file_bytes);
                                    $input = array(
                                        'folder_id'=>$dos_fol_sol_details[0]['id'],
                                        'file_size'=>$file_size
                                    );
                                    $this->file_manager_model->edit($input,$rel['dossier_file_id']);
                                }
                            }
                        }
                    }
                    $cond="select id from folders where folder='Evaluations' and user_id=".$pro['personnel_id']." and parent_folder=".$dos_key_details[0]['id'];
                    $dos_fol_eva_details = $this->users_model->special_fetch($cond);
                    if(count($dos_fol_eva_details)>0)
                    {
                        $cond="select dossier_file_id from dossiers_evaluations where dossier_id=".$pro['id'];
                        $dos_rel_details = $this->users_model->special_fetch($cond);
                        foreach($dos_rel_details as $rel)
                        {
                            if($rel['dossier_file_id']!="")
                            {
                                $cond="select document_unique_name from documents where id=".$rel['dossier_file_id'];
                                $doc_details = $this->users_model->special_fetch($cond);
                                if(count($doc_details)>0)
                                {
                                    $uploads_dir = 'assets/uploads/user_files';
                                    $file_path=$uploads_dir.'/'.$doc_details[0]['document_unique_name'];
                                    $file_bytes=filesize($file_path);
                                    $file_size=$this->formatSizeUnits($file_bytes);
                                    $input = array(
                                        'folder_id'=>$dos_fol_eva_details[0]['id'],
                                        'file_size'=>$file_size
                                    );
                                    $this->file_manager_model->edit($input,$rel['dossier_file_id']);
                                }
                            }
                        }
                    }
                }
            }
        }
		echo "Done";
    }
    
	function formatSizeUnits($bytes)
    {
        if ($bytes >= 1073741824)
        {
            $bytes = number_format($bytes / 1073741824, 2) . ' GB';
        }
        elseif ($bytes >= 1048576)
        {
            $bytes = number_format($bytes / 1048576, 2) . ' MB';
        }
        elseif ($bytes >= 1024)
        {
            $bytes = number_format($bytes / 1024, 2) . ' KB';
        }
        elseif ($bytes > 1)
        {
            $bytes = $bytes . ' bytes';
        }
        elseif ($bytes == 1)
        {
            $bytes = $bytes . ' byte';
        }
        else
        {
            $bytes = '0 bytes';
        }

        return $bytes;
	}
    function get_filepath()
    {
        $path=getcwd();
        echo $server_path=$path."/assets/uploads/pdf_files";
    }
    function admin_reset_password(){
        $cUrl = $this->get_service_api().'admin_reset_password';
        $new_password = $this->input->post('new_password');
        $id = $this->input->post('token_id');
        $user_det = $this->session->userdata('user_det');
        $post_data = array(
            'id'=>$id,
            'lang_id'=>$user_det['lang_id'],
            'new_password'=>$new_password
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
}
