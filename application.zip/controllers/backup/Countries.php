<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Countries extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//Career Goals	
	
	function countries() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$this->get_include();
            $this->load->view($this->view_dir . 'countries', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_countries() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = SERVICE_BASEURL.'view_countries';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_countries(){
        
		$cUrl = SERVICE_BASEURL.'add_countries';
        $name = $this->input->post('name');
        $iso = $this->input->post('iso');
        $iso3 = $this->input->post('iso3');
        $num_code = $this->input->post('num_code');
        $phone_code = $this->input->post('phone_code');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'name'=>$name,
            'iso'=>$iso,
            'iso3'=>$iso3,
            'num_code'=>$num_code,
            'phone_code'=>$phone_code,
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_countries(){
        
		$cUrl = SERVICE_BASEURL.'edit_countries';
        $id = $this->input->post('token_id');
		$name = $this->input->post('name');
        $iso = $this->input->post('iso');
        $iso3 = $this->input->post('iso3');
        $num_code = $this->input->post('num_code');
        $phone_code = $this->input->post('phone_code');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
			'name'=>$name,
            'iso'=>$iso,
            'iso3'=>$iso3,
            'num_code'=>$num_code,
            'phone_code'=>$phone_code,
            'status'=>$status
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_countries(){
        
		$cUrl = SERVICE_BASEURL.'delete_countries';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_countries(){
        
		$cUrl = SERVICE_BASEURL.'restore_countries';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_countries(){
        
		$cUrl = SERVICE_BASEURL.'set_status_countries';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
	function import_countries(){
		
		$cUrl = SERVICE_BASEURL.'import_countries';
		$path = $_FILES["import_countries_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$page_details = array();
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
                if(isset($sheet['cells'][$r][1]))
                    $name=trim($sheet['cells'][$r][1]);
                else
                    $name="";
                if(isset($sheet['cells'][$r][2]))
                    $iso=trim($sheet['cells'][$r][2]);
                else
                    $iso="";
                if(isset($sheet['cells'][$r][3]))
                    $iso3=trim($sheet['cells'][$r][3]);
                else
                    $iso3="";
                if(isset($sheet['cells'][$r][4]))
                    $num_code=trim($sheet['cells'][$r][4]);
                else
                    $num_code="";
                if(isset($sheet['cells'][$r][5]))
                    $phone_code=trim($sheet['cells'][$r][5]);
                else
                    $phone_code="";
                if(isset($sheet['cells'][$r][6]))
                    $status=trim($sheet['cells'][$r][6]);
                else
                    $status="";
                if($status=="Active")
                    $status_val=1;
                else
                    $status_val=0;
                $page_details[]=array(
                    "name"=>$name,
                    "iso"=>$iso,
                    "iso3"=>$iso3,
                    "num_code"=>$num_code,
                    "status"=>$status,
                    "status_val"=>$status_val,
                    "phone_code"=>$phone_code
                );				
			}
		}
		$post_data = array(
            'page_details'=>$page_details
		);
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
	}    	
}
