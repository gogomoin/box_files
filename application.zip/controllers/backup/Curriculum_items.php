<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Curriculum_items extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		
	} 
	
	//curriculum_items	
	
	function curriculum_items() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$this->get_include();
            $this->load->view($this->view_dir . 'curriculum_items', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function view_curriculum_items() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){                       
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";
        if(isset($_POST['curriculum_fld']))
			$curriculum_fld = $_POST['curriculum_fld'];
		else
			$curriculum_fld ="";
        if(isset($_POST['subject_fld']))
			$subject_fld = $_POST['subject_fld'];
		else
			$subject_fld ="";
        if(isset($_POST['curriculum_item_type_fld']))
			$curriculum_item_type_fld = $_POST['curriculum_item_type_fld'];
		else
			$curriculum_item_type_fld ="";
        if(isset($_POST['curriculum_item_cycle_fld']))
			$curriculum_item_cycle_fld = $_POST['curriculum_item_cycle_fld'];
		else
			$curriculum_item_cycle_fld ="";
        if(isset($_POST['competence_level_fld']))
			$competence_level_fld = $_POST['competence_level_fld'];
		else
			$competence_level_fld ="";			
		$cUrl = SERVICE_BASEURL.'view_curriculum_items';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
            'curriculum_fld'=>$curriculum_fld,
			'subject_fld'=>$subject_fld,
            'curriculum_item_type_fld'=>$curriculum_item_type_fld,
			'curriculum_item_cycle_fld'=>$curriculum_item_cycle_fld,
            'competence_level_fld'=>$competence_level_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );  
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
        curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_curriculum_items(){
        
		$cUrl = SERVICE_BASEURL.'add_curriculum_items';
        $title = $this->input->post('title');
        $curriculum_id = $this->input->post('curriculum_id');
        $curriculum_item_type_id = $this->input->post('curriculum_item_type_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $curriculum_item_cycle_id  = $this->input->post('curriculum_item_cycle_id');
        $subject_id  = $this->input->post('subject_id');
        $description = $this->input->post('description');
        $example = $this->input->post('example');
        $additional_category = $this->input->post('additional_category');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'title'=>$title,
            'curriculum_id'=>$curriculum_id,
            'curriculum_item_type_id'=>$curriculum_item_type_id,
            'competence_level_id'=>$competence_level_id,
            'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
            'subject_id'=>$subject_id,
            'description'=>$description,
            'example'=>$example,
            'status'=>$status,
            'additional_category'=>$additional_category
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_curriculum_items(){
        
		$cUrl = SERVICE_BASEURL.'edit_curriculum_items';
        $id = $this->input->post('token_id');
		$title = $this->input->post('title');
        $curriculum_id = $this->input->post('curriculum_id');
        $curriculum_item_type_id = $this->input->post('curriculum_item_type_id');
        $competence_level_id  = $this->input->post('competence_level_id');
        $curriculum_item_cycle_id  = $this->input->post('curriculum_item_cycle_id');
        $subject_id  = $this->input->post('subject_id');
        $description = $this->input->post('description');
        $example = $this->input->post('example');
        $additional_category = $this->input->post('additional_category');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
        $post_data = array(
            'id'=>$id,
			'title'=>$title,
            'curriculum_id'=>$curriculum_id,
            'curriculum_item_type_id'=>$curriculum_item_type_id,
            'competence_level_id'=>$competence_level_id,
            'curriculum_item_cycle_id'=>$curriculum_item_cycle_id,
            'subject_id'=>$subject_id,
            'description'=>$description,
            'example'=>$example,
            'status'=>$status,
            'additional_category'=>$additional_category
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_curriculum_items(){
        
		$cUrl = SERVICE_BASEURL.'delete_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function restore_curriculum_items(){
        
		$cUrl = SERVICE_BASEURL.'restore_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_curriculum_items(){
        
		$cUrl = SERVICE_BASEURL.'set_status_curriculum_items';
        $ids = $this->input->post('ids');
		$post_data = array(
            'ids'=>$ids
        );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculums(){        
		$cUrl = SERVICE_BASEURL.'get_curriculums';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }	
    function get_subjects(){        
		$cUrl = SERVICE_BASEURL.'get_subjects';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculum_item_types(){        
		$cUrl = SERVICE_BASEURL.'get_curriculum_item_types';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_competence_levels(){        
		$cUrl = SERVICE_BASEURL.'get_competence_levels';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
    function get_curriculum_item_cycles(){        
		$cUrl = SERVICE_BASEURL.'get_curriculum_item_cycles';
        $reqhdrs = array('Accept: application/json');    
        $post_data="";   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_curriculum_items(){
		
		$cUrl = SERVICE_BASEURL.'import_curriculum_items';
		$path = $_FILES["import_curriculum_items_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$page_details = array();
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
                if(isset($sheet['cells'][$r][1]))
                    $title=trim($sheet['cells'][$r][1]);
                else
                    $title="";
                if(isset($sheet['cells'][$r][2]))
                {
                    $curriculum=trim($sheet['cells'][$r][2]);
                    if($curriculum!="")
                    {
                        $cond="select id from curriculums where name='".$curriculum."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_id=$cu_details[0]['id'];
                        else
                            $curriculum_id="";
                    }                    
                }
                else
                    $curriculum="";
                if(isset($sheet['cells'][$r][3]))
                {
                    $subject=trim($sheet['cells'][$r][3]);
                    if($subject!="")
                    {
                        $cond="select id from subjects where name='".$subject."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $subject_id=$cu_details[0]['id'];
                        else
                            $subject_id="";
                    }                    
                }
                else
                    $subject="";  
                if(isset($sheet['cells'][$r][4]))
                {
                    $curriculum_item_type=trim($sheet['cells'][$r][4]);
                    if($curriculum_item_type!="")
                    {
                        $cond="select id from curriculum_item_types where name='".$curriculum_item_type."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_item_type_id=$cu_details[0]['id'];
                        else
                            $curriculum_item_type_id="";
                    }                    
                }
                else
                    $curriculum_item_type="";  
                if(isset($sheet['cells'][$r][5]))
                {
                    $curriculum_item_cycle=trim($sheet['cells'][$r][5]);
                    if($curriculum_item_cycle!="")
                    {
                        $cond="select id from curriculum_item_cycles where name='".$curriculum_item_cycle."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $curriculum_item_cycle_id=$cu_details[0]['id'];
                        else
                            $curriculum_item_cycle_id="";
                    }                    
                }
                else
                    $curriculum_item_cycle="";
                if(isset($sheet['cells'][$r][6]))
                {
                    $competence_level=trim($sheet['cells'][$r][6]);
                    if($competence_level!="")
                    {
                        $cond="select id from competence_levels where name='".$competence_level."'";
                        $cu_details = $this->users_model->special_fetch($cond);
                        if(count($cu_details)>0)
                            $competence_level_id=$cu_details[0]['id'];
                        else
                            $competence_level_id="";
                    }                    
                }
                else
                    $competence_level="";    
                if(isset($sheet['cells'][$r][7]))
                    $description=trim($sheet['cells'][$r][7]);
                else
                    $description="";
                if(isset($sheet['cells'][$r][8]))
                    $example=trim($sheet['cells'][$r][8]);
                else
                    $example="";
                if(isset($sheet['cells'][$r][9]))
                    $additional_category=trim($sheet['cells'][$r][9]);
                else
                    $additional_category="";  
                if(isset($sheet['cells'][$r][10]))
                    $status=trim($sheet['cells'][$r][10]);
                else
                    $status="";
                if($status=="Active")
                    $status_val=1;
                else
                    $status_val=0;   
                $page_details[]=array(
                    "title"=>$title,
                    "curriculum"=>$curriculum,
                    "curriculum_id"=>$curriculum_id,
                    "subject"=>$subject,
                    "subject_id"=>$subject_id,
                    "curriculum_item_type"=>$curriculum_item_type,
                    "curriculum_item_type_id"=>$curriculum_item_type_id,
                    "curriculum_item_cycle"=>$curriculum_item_cycle,
                    "curriculum_item_cycle_id"=>$curriculum_item_cycle_id,
                    "competence_level"=>$competence_level,
                    "competence_level_id"=>$competence_level_id,
                    "description"=>$description,
                    "example"=>$example,
                    "status"=>$status,
                    "status_val"=>$status_val,
                    "additional_category"=>$additional_category
                );				
			}
		}
		$post_data = array(
            'page_details'=>$page_details
		);
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
	}	
}
