<?php

if (!defined('BASEPATH'))

    exit('No direct script access allowed');

class Home extends MY_Controller
{
    function __construct() 
	{
        parent::__construct();           
        $this->load->helper('url');
        $this->load->library('session');
		$this->load->library('excel_reader');
    }    
    
	function index() 
	{		
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
			
		    $user_det = $this->session->userdata('user_det');
			$this->get_include();
			$this->load->view($this->view_dir . 'dashboard', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	} 
	//Login and Logout
    function login(){
		$username = $this->input->post('username');
		$password = md5($this->input->post('password'));
		$data_arr=array(
				'username'=>$username,
				'password'=>$password
			);
		$admin_details = $this->users_model->get_records($data_arr);
		if(count($admin_details)>0){
			$data_arr=array(
				'username'=>$username,
				'is_active'=>0
			);
			$adm_details = $this->users_model->get_records($data_arr);
			if(count($adm_details)>0)
			{
				$user_det = array('id'=>$admin_details[0]['id'],'username'=>$username,'name'=>'Admin');
				$this->session->set_userdata('user_det',$user_det);
				redirect('/');
			}
			else
			{
				$this->data['error_message'] = 'Account Deactivated - Please Contact Administrator';
				$this->data['username'] = $username;
				$this->load->view($this->view_dir . 'login', $this->data);
			}
		}
		else{
				$this->data['error_message'] = 'Invalid Username/Password';
				$this->data['username'] = $username;
				$this->load->view($this->view_dir . 'login', $this->data);
		}            
    }
    
    function logout(){
         $this->session->sess_destroy();
         $this->data['error_message'] = 'Successfully Logged Out';
         $this->data['username'] = "";
         $this->load->view($this->view_dir . 'login', $this->data); 
    }  
	//Single Column Layout	
	
	function single_column_layout() 
	{
		if($this->session->userdata('user_det') != '' 
           && $this->session->userdata('user_det') != 'undefined'
           && $this->session->userdata('user_det') != null){
		    $user_det = $this->session->userdata('user_det');
			$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
			$link_array = explode('/',$actual_link);
    		$page_layout = end($link_array);
			$cond="select * from pages where page_layout='".$page_layout."'";
        	$page_details = $this->users_model->special_fetch($cond);
			$this->data['page_details'] = $page_details;
			$this->data['page_layout'] = $page_layout;
			$this->get_include();
            $this->load->view($this->view_dir . 'single_column_layout', $this->data);
        }
        else{
            $this->data['error_message'] = '';
            $this->data['username'] = '';
            $this->load->view($this->view_dir . 'login', $this->data);
        }
	}
	function get_single_column_page() 
	{
		$draw = $_POST['draw'];
		$start = $_POST['start'];
        $rowperpage = $_POST['length'];
        $searchValue = $_POST['search']['value'];
		$page_layout = $_POST['page_layout'];
		$columnIndex = $_POST['order'][0]['column'];
		if($_POST['columns'][$columnIndex]['orderable'] != 'false'){
           
            $columnName = $_POST['columns'][$columnIndex]['data'];
            $columnSortOrder = $_POST['order'][0]['dir'];
        }
		if(isset($_POST['search_fld']))
			$search_fld = $_POST['search_fld'];
		else
			$search_fld ="";
		if(isset($_POST['status_fld']))
			$status_fld = $_POST['status_fld'];
		else
			$status_fld ="";
		if(isset($_POST['del_fld']))
			$del_fld = $_POST['del_fld'];
		else
			$del_fld ="";			
		$cUrl = SERVICE_BASEURL.'get_single_column_page';
        $user_det = $this->session->userdata('user_det');
		$post_data = array(
            'page_layout'=>$page_layout,
			'start'=>$start,
			'rowperpage'=>$rowperpage,
			'status_fld'=>$status_fld,
			'del_fld'=>$del_fld,
			'columnName'=>$columnName,
			'columnSortOrder'=>$columnSortOrder,
			'searchValue'=>$searchValue
          );
          
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $json = curl_exec($ch);
		$result = json_decode($json, true);
		curl_close($ch);		
		$response = array(
			"draw" => intval($draw),
			"iTotalRecords" => $result['totalRecord'],
			"iTotalDisplayRecords" => $result['totalRecordwithFilter'],
			"aaData" => $result['page_details']
		  );
		echo json_encode($response);
	}
	function add_single_column_page(){
        
		$cUrl = SERVICE_BASEURL.'add_single_column_page';
        $name = $this->input->post('name');
        $page_layout = $this->input->post('page_layout');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
		$post_data = array(
            'name'=>$name,
            'status'=>$status,
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function edit_single_column_page(){
        
		$cUrl = SERVICE_BASEURL.'edit_single_column_page';
        $id = $this->input->post('token_id');
		$name = $this->input->post('name');
        $page_layout = $this->input->post('page_layout');
        $status = $this->input->post('status');
        if(isset($status))
            $status=1;
        else
            $status=0;
		$post_data = array(
            'id'=>$id,
			'name'=>$name,
            'status'=>$status,
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function delete_single_column_page(){
        
		$cUrl = SERVICE_BASEURL.'delete_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function restore_single_column_page(){
        
		$cUrl = SERVICE_BASEURL.'restore_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function set_status_single_column_page(){
        
		$cUrl = SERVICE_BASEURL.'set_status_single_column_page';
        $ids = $this->input->post('ids');
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'ids'=>$ids,
			'page_layout'=>$page_layout
          );
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;                
    }
	function import_single_column_page(){
		
		$cUrl = SERVICE_BASEURL.'import_single_column_page';
		$path = $_FILES["import_single_column_page_file"]["tmp_name"];
		$target_dir = "./assets/uploads/imports/";
		$target_file = $target_dir . time().'.xls';
		move_uploaded_file($path, $target_file);
		$excel = new Excel_Reader();
		$excel->read($target_file);
		$page_details = array();
		foreach($excel->sheets as $sheet)
		{
			for($r=2;$r<=$sheet['numRows'];$r++)
			{
				if(isset($sheet['cells'][$r][1]))
                    $name=trim($sheet['cells'][$r][1]);
                else
                    $name="";
                if(isset($sheet['cells'][$r][2]))
                    $status=trim($sheet['cells'][$r][2]);
                else
                    $status="";
                if($status=="Active")
                    $status_val=1;
                else
                    $status_val=0;
                $page_details[]=array(
                    "name"=>$name,
                    "status"=>$status,
                    "status_val"=>$status_val                    
                );
			}
		}
		$page_layout = $this->input->post('page_layout');
		$post_data = array(
            'page_details'=>$page_details,
			'page_layout'=>$page_layout
		);
        $reqhdrs = array('Accept: application/json');       
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $cUrl);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLINFO_HEADER_OUT, true);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $reqhdrs);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        $result = curl_exec($ch);
        curl_close($ch);
        echo $result;
	}
}
