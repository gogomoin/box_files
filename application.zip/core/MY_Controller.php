<?php



class MY_Controller extends CI_Controller {



    public $view_dir = 'frontend/';
    public $header = '';
    public $banner = '';
    public $footer = '';
	public $user_id = '';
    public $data = array();
    function __construct() {
        parent::__construct();
		
		$this->load->model(array('users_model','admin_model','school_model','file_manager_model','folder_manager_model','dossiers_model','document_text_model'));

        $this->data['controller_name'] = $this->uri->segment(1);
        $this->data['method_name'] = $this->uri->segment('2') ? $this->uri->segment('2') : 'index';
		$host=$this->get_host();
        $ip=exec("hostname -I");
        $admin_details=array();
        if($host==$ip)
        {
            $cond="select * from admin";
            $admin_details = $this->users_model->special_fetch($cond);
        }
        else
        {
            $cond="select * from admin where domain like '%localhost%'";
            $admin_details = $this->users_model->special_fetch($cond);
        }
        $admin_details = $this->users_model->special_fetch($cond);
        $this->data['admin_details'] = $admin_details[0];
        $this->load_database('ps_test');
        $cond="select max(build_no) as build_no from builds where is_live=1";
        $build_no_details = $this->users_model->special_fetch($cond);
        if($build_no_details[0]['build_no']!="")
            $this->data['footer_build_no'] = $build_no_details[0]['build_no'];
        else 
            $this->data['footer_build_no'] = "1000";
        $this->load_database($admin_details[0]['domain_id']);
		$this->data['header_logo_image'] = $admin_details[0]['logo'];
        $this->data['base_url'] = $this->config->item('base_url');
        //Assets Path
        $this->data['assets_path'] = $this->config->item('base_url') . 'assets/';
        //JS Path
        $this->data['js_path'] = $this->config->item('base_url') . 'assets/js/';
        //Images Path
        $this->data['media_path'] = $this->config->item('base_url') . 'assets/media/';
        //CSS Path
        $this->data['css_path'] = $this->config->item('base_url') . 'assets/css/';
		//Plugins
        $this->data['plugins_path'] = $this->config->item('base_url') . 'assets/plugins/';
        $this->data['plugins_global_path'] = $this->config->item('base_url') . 'assets/plugins/global/';
        $this->data['plugins_custom_path'] = $this->config->item('base_url') . 'assets/plugins/custom/';
    }    
    function get_service_api()
    {
        $host=$this->get_host();
        $service_api='http://'.$host."/proscola_pdf/api/";
        return $service_api;
    }
    function get_host()
    {
        $host = $_SERVER['HTTP_HOST'];
		$host = str_replace("www.","",$host);
        return $host;
    }
    function get_labels()
    {     
        $page_layout = $this->session->userdata('page_layout');
        $user_det = $this->session->userdata('user_det');
        $lang_id = $user_det['lang_id'];
        if($lang_id=='')
            $lang_id=1;
        if($page_layout=="")
            $page_layout='dashboard';
        if($page_layout=="parents")
            $page_layout='users';
        $cond="select id from inner_pages where name='".$page_layout."'";
        $pg_details = $this->users_model->special_fetch($cond);
        $cond="select name,label_id from labels where page_id=".$pg_details[0]['id']." and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
        return $label_details;
    }
    function get_paginate_numbers()
    {
        $user_det = $this->session->userdata('user_det');
        $lang_id = $user_det['lang_id'];
        $cond="select number from paginate_numbers where lang_id=".$lang_id;
        $pgn_details = $this->users_model->special_fetch($cond);
        return $pgn_details;
    }
    function get_role_details()
    {
        $group_ids=array();
        if($this->session->userdata('user_det') != '' 
        && $this->session->userdata('user_det') != 'undefined'
        && $this->session->userdata('user_det') != null){
             $user_det = $this->session->userdata('user_det');
             $cond="select role_id from group_roles where group_id in(".$user_det['group_id'].")";
             $group_details = $this->users_model->special_fetch($cond);
             $group_ids=array();
             foreach($group_details as $group)
             {
                 $group_ids[]=$group['role_id'];
             }
             $group_ids = array_unique($group_ids);
        }
        return $group_ids;
    }
    function get_groups_details()
    {
        $group_ids=array();
        if($this->session->userdata('user_det') != '' 
        && $this->session->userdata('user_det') != 'undefined'
        && $this->session->userdata('user_det') != null){
             $user_det = $this->session->userdata('user_det');
             $group_ids=explode(",",$user_det['group_id']);
             $this->data['group_id_details'] = $group_ids;
        }
        return $group_ids;
    }
    function get_menu_details($group_id)
    {
        $cond="SELECT group_concat(distinct page_id) as page_id from roles r,group_roles g where r.id=g.role_id and g.group_id in(".$group_id.")";
        $rol_details = $this->users_model->special_fetch($cond);
        $menu_ids=explode(",",$rol_details[0]['page_id']);
        return $menu_ids;
    }
    function get_include() {
        $user_det = $this->session->userdata('user_det');
        $lang_id = $user_det['lang_id'];
        $group_id = $user_det['group_id'];
        $cond="select s.value from system_settings s where s.key='admin-items-per-page'";
        $table_number = $this->users_model->special_fetch($cond);
        $this->data['item_per_page'] = $table_number[0]['value'];
        $cond="select name,label_id from labels where page_id=57 and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
        $this->data['menu_details'] = $label_details;
        $cond="select name,label_id from labels where page_id=54 and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }        
        
        $this->data['all_page_label_details'] = $label_details;
        $cond="select id,name from languages where is_deleted=0";
        $this->data['lang_details'] = $this->users_model->special_fetch($cond);
        $this->data['menu_id_details'] = $this->get_menu_details($group_id);
        $this->data['group_id_details'] = $this->get_groups_details();
        $cond="select name,label_id from labels where page_id=55 and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
        $this->data['dash_label_details'] = $label_details;
        
        //$this->data['role_details'] = $this->get_role_details();
        $this->data['bulk_label_modal'] = $this->load->view($this->view_dir . 'bulk_label_modal', $this->data, true);
        $this->data['video_modal'] = $this->load->view($this->view_dir . 'common/video_modal', $this->data, true);
        $this->data['header'] = $this->load->view($this->view_dir . 'common/header', $this->data, true);
        $this->data['sideheader'] = $this->load->view($this->view_dir . 'common/sideheader', $this->data, true);
        $this->data['footer'] = $this->load->view($this->view_dir . 'common/footer', $this->data, true);
    }
    function get_file_manager() {
        $user_det = $this->session->userdata('user_det');
        $lang_id = $user_det['lang_id'];
        $cond="select name,label_id from labels where page_id=60 and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
        $this->data['file_manager_label_details'] = $label_details;
        $this->data['role_details'] = $this->get_role_details();
        $this->data['file_manager'] = $this->load->view($this->view_dir . 'common/file_manager', $this->data, true);
    }
    function get_notifications_modals() {
        $user_det = $this->session->userdata('user_det');
        $lang_id = $user_det['lang_id'];
        $cond="select name,label_id from labels where page_id=49 and lang_id=".$lang_id." order by label_id asc";
        $lbl_details = $this->users_model->special_fetch($cond);
        $label_details=array();
        foreach($lbl_details as $pg)
        {
            $label_id=$pg['label_id'];
            $label_details[$label_id]['name']=$pg['name'];
        }
        $this->data['label_details'] = $label_details;
        $this->data['notifications_modals'] = $this->load->view($this->view_dir . 'notifications_modals', $this->data, true);
    }
    function translate_lang($code,$text)
	{
		$url = 'https://www.googleapis.com/language/translate/v2?key='. APIKEY.'&q='.rawurlencode($text).'&source=en&target='.$code;
		$handle = curl_init($url);
		curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($handle); 
		$responseDecoded = json_decode($response, true);
		curl_close($handle);
        if (array_key_exists("error",$responseDecoded))
        {
            return "";
        }
        else
        {
		    $res_text=$responseDecoded['data']['translations'][0]['translatedText'];
		    return $res_text;
        }
	}
    function load_database($domain){
        $db_name = 'live';
        if($domain=='proscola_school_live')
        {
            $db_name = 'proscola_school_live';
        }
        else if($domain=='ps_test')
        {
            $db_name = 'ps_test';
        }
        else
        {
            for($i=1;$i<100;$i++)
            {
                if($domain == '1'){
                    $db_name = 'school';
                    break;
                }
                else if($domain == $i){
                    $db_name = $i;
                    break;
                }    
            }   
        }
        $str_db_name = (string)$db_name; 
        $this->db = $this->load->database($str_db_name, TRUE);
    }

}

