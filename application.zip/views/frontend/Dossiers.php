<?php echo $header; ?>
<?php echo $sideheader; ?>
<script type="text/javascript" src="<?php echo $js_path;?>Webviewer/lib/webviewer.min.js"></script>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>


#cc-table td:nth-child(13) {
  text-align:center;
}
#cc-table td:nth-child(12) {
    text-align:center;
}
#cc-table td:nth-child(11) {
    text-align:center;
}

#task_table td:nth-child(9) {
    text-align:center;
}
#task_table td:nth-child(8) {
    text-align:center;
}
#task_table td:nth-child(11) {
    text-align:center;
}
#task_table td:nth-child(10) {
    text-align:center;
}

#task_view_table td:nth-child(4) {
    text-align:center;
}
#task_view_table td:nth-child(5) {
    text-align:center;
}
#task_view_table td:nth-child(6) {
    text-align:center;
}
#task_view_table td:nth-child(11) {
    text-align:center;
}
#preview_task_table td:nth-child(9) {
    text-align:center;
}
#preview_task_table td:nth-child(7) {
    text-align:center;
}
#preview_task_table td:nth-child(8) {
    text-align:center;
}
#preview_task_table td:nth-child(10) {
    text-align:center;
}
#preview_task_table td:nth-child(11) {
    text-align:center;
}
#preview_task_table td:nth-child(12) {
    text-align:center;
}
.draggable_btn_sec {
  list-style: none;
  padding: 0;
  margin: 0 0 0px 0;
}
.draggable_btn_sec_up {
  list-style: none;
  padding: 0 0 0 0px;
  margin: 0 0 0px 0;
}
.draggable_btn_sec_task {
  list-style: none;
  padding: 0;
  margin: 0 0 0px 0;
}
.task_draggable_btn_sec {
  list-style: none;
  padding: 0;
  margin: 0 0 0px 0;
}
.text-wrap{
    overflow-wrap: anywhere;
    white-space: pre-wrap;
}
.draggable_btn_sec_dup {
  list-style: none;
  padding: 0 0 0 0px;
  margin: 0 0 0px 0;
}
.col.draggable.draggable_btns a {
    display: block;
    width: auto;
    height: auto;
    padding: 5px 10px;
    text-align: left;
    margin-right: 50px;
    height: 40px;
}
li.col.draggable.draggable_btns .btn.btn-link {
    display: block;
    position: absolute;
    top: 13px;
    left: 15px;
}
li.col.draggable.draggable_btns button.btn.btn-link {
    font-size: 15px;
}
.cls_btn {
    float: right;
    position: absolute;
    right: 15px;
    top: 15px;
    margin-top: 0px !important;
    font-size: 12px !important;
}
.col.draggable.draggable_btns {
    display: block;
    min-width: 100px;
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 5px 8px;
    margin-bottom: 10px;
    background-color: #a2e0ff;
    position: relative;
}
.qrsection {
    width: 50%;
    float: left;
}

.logosection {
    width: 50%;
    float: left;
}

.schooldetails {
    display: inline-block;
    padding-top: 10px;
}

.schoolimg {
    display: inline-block;
    float: right;
}

span#pr_teaser_text {
    padding: 15px;
    display: block;
    text-align: right;
}

.pr_date_details {
    float: left;
    padding: 15px;
    padding-left: 60%;
}
/* Change the background color of the button */
.webviewer-ui .FreeTextToolGroupButton {
  background-color: yellow !important;
}

/* Change the color of the icon */
.webviewer-ui .FreeTextToolGroupButton .svg-icon {
  fill: black !important;
}

@media (max-width:768px)
{
    .pr_date_details {
        padding-left: 15px;
    }
    .qrsection {
        width: 100%;
    }

    .logosection {
        width: 100%;
    }
}
</style>
<link href="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $css_path; ?>dossier_style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">
<link href="<?php echo $css_path; ?>ewsRatingStars.jquery.css" rel="stylesheet" type="text/css" />
<!-- <link href="<?php echo $assets_path; ?>pdf/css/lightbox.css" rel="stylesheet" type="text/css" /> -->
<link href="<?php echo $assets_path; ?>pdf/css/font-awesome.min.css" rel="stylesheet" type="text/css" />


 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <a name="dossiers_table_id"></a>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(341,$role_details)) { ?>
        <div class="card mb-7 border">
            
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[2]['name']; ?></h3>
                    <button type="button" id="label_40_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
                            
                             <!--begin::Col-->
                             <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[3]['name']; ?></label>
                                <div>
                                    <span><input type="radio" checked id="local" name="local" value="1"></span><span>
                                    <label for="local"> <?php echo $label_details[4]['name']; ?></label></span>
                                    <?php if($global_share_flag) { ?>
                                    <span><input type="radio" id="global" name="local" value="2"></span><span>
                                        <label for="global"> <?php echo $label_details[5]['name']; ?></label></span>
                                    <?php } ?>
                                </div>
                            </div>
                            <!--end::Col-->
						    <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px" id="term_fld_filter">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[6]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="term_fld" name="term_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px" id="teacher_fld_filter">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[7]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="teacher_fld" name="teacher_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px" id="course_fld_filter">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[8]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="course_fld" name="course_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                           
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[9]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="type_fld" name="type_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px" id="del_fld_filter">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[10]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="del_fld" name="del_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all"><?php echo $label_details[11]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[12]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[13]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                             <!--begin::Col-->
                             <div class="col-lg-3 w-md-400px" id="search_fld_filter">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[378]['name']; ?></label>
                                <input type="text" id="search_fld" name="search_fld" class="form-control" aria-describedby="basic-addon1">
                            </div>
                            <!--end::Col-->
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="dossiers_filter" name="dossiers_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[14]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="dossiers_reset" name="dossiers_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[15]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[16]['name']; ?></h3>
                                    <button type="button" id="label_40_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(253,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_dossiers_btn"><?php echo $label_details[17]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <!-- <button type="button" id="manage_task_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2">TASKS <i class="las la-plus fs-3"></i></button> -->
                            <?php if(in_array(259,$role_details)) { ?>
                            <!-- <button type="button" id="send_task_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"><?php echo $label_details[18]['name']; ?> <i class="las la-excuse-alt fs-3"></i></button> -->
                            <?php } ?>
                            <?php if(in_array(255,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_dossiers" data-toggle="modal"><?php echo $label_details[19]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(255,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_dossiers" data-toggle="modal"><?php echo $label_details[20]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[21]['name']; ?> </th>
                                    <th data-priority="6" class="fw-bolder"> <?php echo $label_details[341]['name']; ?> </th>
                                    <th data-priority="2" class="fw-bolder" > <?php echo $label_details[22]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[23]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[256]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[257]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[579]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[258]['name']; ?> </th>
                                    <th class="fw-bolder"> <?php echo $label_details[259]['name']; ?> </th>
                                    <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[376]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[24]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[25]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_create_id" style="display:none;">
                <form name="add_dossiers_form" id="add_dossiers_form" class="add_dossiers_form">
                    
                    <a name="dossiers_table_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[324]['name']; ?> <?php echo $label_details[382]['name']; ?>
                            </h3>
                            <button type="button" id="label_40_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[86]['name']; ?></button>
                            <button type="button" id="add_dossiers_new_con_sub" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[87]['name']; ?></button>
                            <button type="button" id="add_dossiers_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[88]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="alert alert-dismissible bg-light-danger border border-danger d-flex flex-column flex-sm-row w-100 p-5 pt-2 pb-2 mb-10 info_dos_cls">
                            <!--begin::Icon-->
                            <!--begin::Svg Icon | path: icons/duotune/communication/com003.svg-->
                            <span class="svg-icon svg-icon-5tx svg-icon-danger">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                    <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                    <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                            <!--end::Icon-->
                            <!--begin::Content-->
                            <div class="d-flex flex-column pe-0 pe-sm-10">
                                <h5 class="mb-1"><?php echo $label_details[390]['name']; ?></h5>
                            </div>
                            <!--end::Content-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_assignment_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg id="Group_2" data-name="Group 2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="19.246" height="24" viewBox="0 0 19.246 24">
                                        <defs>
                                            <clipPath id="clip-path">
                                            <rect id="Rectangle_1" data-name="Rectangle 1" width="19.246" height="24" fill="none"/>
                                            </clipPath>
                                        </defs>
                                        <g id="Group_1" data-name="Group 1" clip-path="url(#clip-path)">
                                            <path id="Path_4" data-name="Path 4" d="M18.876,16a1.642,1.642,0,0,1,.317,1.107c0,.683-.05,1.369.008,2.047a3.016,3.016,0,0,1-1.728,3.035,13.952,13.952,0,0,1-5.265,1.6,18.027,18.027,0,0,1-4.59.1c-2.153-.262-4.376-.544-6.2-1.894a2.925,2.925,0,0,1-1.39-2.443c.021-.877,0-1.755.006-2.633,0-.286-.04-.589.28-.826,2.154,2.249,5.008,2.694,7.914,2.9a17.45,17.45,0,0,0,8.432-1.277A5.24,5.24,0,0,0,18.876,16M.1,14.317a1.736,1.736,0,0,0,.348.714A5.2,5.2,0,0,0,3.313,16.9a19.365,19.365,0,0,0,10.242.653A11.453,11.453,0,0,0,17.588,16.1c.631-.393,1.311-.853,1.444-1.584a10.251,10.251,0,0,0-.049-4.4c-.007-.028-.073-.041-.145-.079a6.431,6.431,0,0,1-3.46,2.171,20.227,20.227,0,0,1-10.693.253A7.332,7.332,0,0,1,.151,9.774,23.816,23.816,0,0,0,.1,14.317M.018,7.236a2.965,2.965,0,0,0,2.094,3.259C7.541,12.62,12.9,13.007,18.1,9.742a2.056,2.056,0,0,0,1.085-1.758c.032-.95.011-1.9,0-2.852a1.2,1.2,0,0,0-.235-.869,4.345,4.345,0,0,1-2.813,1.925,21.746,21.746,0,0,1-7.882.861c-2.878-.16-5.736-.468-8.22-2.636C.032,5.5.1,6.373.018,7.236M11.325.1c-.29-.031-.579-.08-.869-.09A34.383,34.383,0,0,0,6.121.3,14.8,14.8,0,0,0,1.307,1.584a1.535,1.535,0,0,0-.184,2.8A8.145,8.145,0,0,0,3.669,5.465a24.841,24.841,0,0,0,9.3.493,11.864,11.864,0,0,0,4.94-1.467c1.4-.872,1.4-1.949-.008-2.8A11.8,11.8,0,0,0,11.776.2c-.164.026-.338.1-.451-.1" transform="translate(0 0.001)" fill="#58585a"/>
                                        </g>
                                        </svg></span> <?php echo $label_details[30]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_assignment_fields">
                                <!--begin::Compact form-->
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[31]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="term_id" name="term_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[32]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="subject_id" name="subject_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[33]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="language_id" name="language_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <?php if($curriculum_flag) { ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[34]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_id" name="curriculum_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[35]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_cycle_id" name="curriculum_cycle_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[36]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="course_id" name="course_id">
                                                    <option value=""><?php echo $label_details[263]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if($curriculum_flag) { ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[38]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_item_id" name="curriculum_item_id">
                                                    <option value=""><?php echo $label_details[39]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="help-block"><i class="fa fa-info-circle"></i><strong> <?php echo $label_details[40]['name']; ?>:: </strong><i><?php echo $label_details[41]['name']; ?></i></div>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="row">
                                    <div class="separator border-secondary my-10"></div>
                                </div> 
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[42]['name']; ?></label>
                                            <button type="button" id="file_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><?php echo $label_details[43]['name']; ?><i class="las la-file-image fs-3"></i></button> 
                                            <input type="hidden" id="school_mng" />
                                        </div>
                                        <div class="py-5">
                                            <div id="logo_image_block">
                                                <div class="rounded border input-group fit_content p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="logo_image" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                        <!--begin::Edit-->
                                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        </button>
                                                        <!--end::Edit-->
                                                        <!--begin::Remove-->
                                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file" data-bs-original-title="Remove Logo">
                                                        <i class="bi bi-x fs-2"></i>
                                                        </a>
                                                        <input type="hidden" id="school_logo_file_name" name="school_logo_file_name" />
                                                        <!--end::Remove-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[44]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="teaser_text" name="teaser_text" rows="7"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[45]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="start_date" name="start_date" />
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[46]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="end_date" name="end_date" />
                                            </div>
                                        </div>
                                        <?php if($learning_flag) { ?>
                                        <div class="mb-4" id="learning_type">
                                            <label for="" class="form-label mb-4"><?php echo $label_details[47]['name']; ?>:</label>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="group_chk" name="group_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[48]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="individual_chk" name="individual_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[49]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="remote_chk" name="remote_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[50]['name']; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                        <label for="" class="form-label"><?php echo $label_details[51]['name']; ?>:</label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" value="" id="published" name="published" />
                                        </div>
                                        </div>
                                        <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[52]['name']; ?></b>:: <i><?php echo $label_details[53]['name']; ?></i></label>
                                        <div class="card-rounded bg-primary bg-opacity-5 mb-15" id="sharingOptionsContainer">
                                            <div class="row p-2">
                                                <div class="ribbon ribbon-left ribbon-color-success uppercase  ribbon-shadow">
                                                    <i class="fa fa-share"></i> <?php echo $label_details[54]['name']; ?>
                                                </div>
                                            </div>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[55]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[56]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_visible" name="local_visible"  />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[57]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_duplication" name="local_duplication" />
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($global_share_flag) { ?>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[58]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[59]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_visible" name="global_visible" />
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[60]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_duplication" name="global_duplication" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[61]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="title" name="title" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[62]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="estimated_time" name="estimated_time" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[63]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="goals" name="goals" rows="5"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[64]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="path_to_success" name="path_to_success" rows="5"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="input-group mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[65]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="task" name="task" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <!--begin::Input group-->
                                    <div class="input-group keywords">
                                        <span class="input-group-text"><?php echo $label_details[66]['name']; ?> *</span>
                                        <input class="form-control" data-kt-repeater="tagify" value="" id="keywords" name="keywords" />
                                    </div>
                                    <!--end::Input group-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="selected_students_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.762" height="23.999" viewBox="0 0 18.762 23.999">
                                    <path id="Documents" d="M.476,24A1.091,1.091,0,0,1,0,22.971Q.015,13.137.008,3.3c0-.823.228-1.049,1.056-1.05H2.258v.541q0,8.759,0,17.517c0,1.059.379,1.442,1.43,1.442H16.535c-.179.786.365,1.693-.59,2.25ZM4.55,0c-.524,0-.791.313-.791.889q0,9.232,0,18.464c0,.62.267.89.878.891q6.56,0,13.12,0c.7,0,1-.308,1-.992q0-6.818,0-13.637c0-.118.05-.249-.088-.391H13.877V0C10.732,0,7.641,0,4.55,0M6.017,8.652H16.48V10.1H6.017Zm.007,2.994H16.486v1.46H6.025Zm-.007,3.006H16.48V16.1H6.017Zm9.4-10.926h3.319L15.414.012Z" transform="translate(0 0)" fill="#58585a"/>
                                    </svg></span> <?php echo $label_details[67]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="selected_students">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[68]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="useful_links" name="useful_links" rows="5"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[69]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1 les_desc">
                                                        <textarea id="description" name="description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <div>
                                                <div id="display_document_block" style="display:none;">
                                                    <div class="card">
                                                        <div id="document_list"></div>
                                                        <ul class="draggable_btn_sec" id="columns_list">
                                                            <div id="document_list_drag" class="draggable-zone">

                                                            </div>
                                                        </ul>
                                                    </div> 
                                                </div>
                                                <div class="input-group mb-5">
                                                    <button type="button" id="doc_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="las la-upload fs-3"></i> <?php echo $label_details[70]['name']; ?></button>
                                                </div>
                                                <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[71]['name']; ?></b>:: <i><?php echo $label_details[72]['name']; ?></i></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[86]['name']; ?></button>
                            <button type="button" id="add_dossiers_new_con_sub_bott" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[87]['name']; ?></button>
                            <button type="button" id="add_dossiers_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[88]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_edit_id" style="display:none;">
                <form name="edit_dossiers_form" id="edit_dossiers_form" class="edit_dossiers_form">
                    <a name="dossiers_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[89]['name']; ?> <?php echo $label_details[90]['name']; ?></h3>
                                <button type="button" id="label_40_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[91]['name']; ?></button>
                            <button type="button" id="edit_dossiers_update_sub"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[92]['name']; ?></button>
                            <button type="button" id="edit_dossiers_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[93]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="alert alert-dismissible bg-light-danger border border-danger d-flex flex-column flex-sm-row w-100 p-5 pt-2 pb-2 mb-10 info_dos_cls">
                            <!--begin::Icon-->
                            <!--begin::Svg Icon | path: icons/duotune/communication/com003.svg-->
                            <span class="svg-icon svg-icon-5tx svg-icon-danger">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                    <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                    <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                            <!--end::Icon-->
                            <!--begin::Content-->
                            <div class="d-flex flex-column pe-0 pe-sm-10">
                                <h5 class="mb-1"><?php echo $label_details[391]['name']; ?></h5>
                            </div>
                            <!--end::Content-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_assignment_container_up">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg id="Group_2" data-name="Group 2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="19.246" height="24" viewBox="0 0 19.246 24">
                                    <defs>
                                        <clipPath id="clip-path">
                                        <rect id="Rectangle_1" data-name="Rectangle 1" width="19.246" height="24" fill="none"/>
                                        </clipPath>
                                    </defs>
                                    <g id="Group_1" data-name="Group 1" clip-path="url(#clip-path)">
                                        <path id="Path_4" data-name="Path 4" d="M18.876,16a1.642,1.642,0,0,1,.317,1.107c0,.683-.05,1.369.008,2.047a3.016,3.016,0,0,1-1.728,3.035,13.952,13.952,0,0,1-5.265,1.6,18.027,18.027,0,0,1-4.59.1c-2.153-.262-4.376-.544-6.2-1.894a2.925,2.925,0,0,1-1.39-2.443c.021-.877,0-1.755.006-2.633,0-.286-.04-.589.28-.826,2.154,2.249,5.008,2.694,7.914,2.9a17.45,17.45,0,0,0,8.432-1.277A5.24,5.24,0,0,0,18.876,16M.1,14.317a1.736,1.736,0,0,0,.348.714A5.2,5.2,0,0,0,3.313,16.9a19.365,19.365,0,0,0,10.242.653A11.453,11.453,0,0,0,17.588,16.1c.631-.393,1.311-.853,1.444-1.584a10.251,10.251,0,0,0-.049-4.4c-.007-.028-.073-.041-.145-.079a6.431,6.431,0,0,1-3.46,2.171,20.227,20.227,0,0,1-10.693.253A7.332,7.332,0,0,1,.151,9.774,23.816,23.816,0,0,0,.1,14.317M.018,7.236a2.965,2.965,0,0,0,2.094,3.259C7.541,12.62,12.9,13.007,18.1,9.742a2.056,2.056,0,0,0,1.085-1.758c.032-.95.011-1.9,0-2.852a1.2,1.2,0,0,0-.235-.869,4.345,4.345,0,0,1-2.813,1.925,21.746,21.746,0,0,1-7.882.861c-2.878-.16-5.736-.468-8.22-2.636C.032,5.5.1,6.373.018,7.236M11.325.1c-.29-.031-.579-.08-.869-.09A34.383,34.383,0,0,0,6.121.3,14.8,14.8,0,0,0,1.307,1.584a1.535,1.535,0,0,0-.184,2.8A8.145,8.145,0,0,0,3.669,5.465a24.841,24.841,0,0,0,9.3.493,11.864,11.864,0,0,0,4.94-1.467c1.4-.872,1.4-1.949-.008-2.8A11.8,11.8,0,0,0,11.776.2c-.164.026-.338.1-.451-.1" transform="translate(0 0.001)" fill="#58585a"/>
                                    </g>
                                    </svg></span> <?php echo $label_details[94]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_assignment_fields_up">
                                <!--begin::Compact form-->
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[95]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="term_id_up" name="term_id">
                                                </select>
                                                <input type="hidden" id="token_id" name="token_id" />
                                                <input type="hidden" id="qr_code_up" name="qr_code_up" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[96]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="subject_id_up" name="subject_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[97]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="language_id_up" name="language_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <?php if($curriculum_flag) { ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[98]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_id_up" name="curriculum_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[99]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_cycle_id_up" name="curriculum_cycle_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[100]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="course_id_up" name="course_id">
                                                    <option value=""><?php echo $label_details[101]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if($curriculum_flag) { ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[102]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_item_id_up" name="curriculum_item_id">
                                                <option value=""><?php echo $label_details[103]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="help-block"><i class="fa fa-info-circle"></i><strong><?php echo $label_details[104]['name']; ?>:: </strong><i><?php echo $label_details[105]['name']; ?></i></div>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="row">
                                    <div class="separator border-secondary my-10"></div>
                                </div> 
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[106]['name']; ?></label>
                                        </div>
                                        <div class="py-5">
                                            <div id="logo_image_block_up">
                                                <div class="rounded border input-group fit_content p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="logo_image_up" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                        <!--begin::Edit-->
                                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit_up" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        </button>
                                                        <!--end::Edit-->
                                                        <!--begin::Remove-->
                                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file_up" data-bs-original-title="Remove Logo">
                                                        <i class="bi bi-x fs-2"></i>
                                                        </a>
                                                        <input type="hidden" id="school_logo_file_name_up" name="school_logo_file_name" />
                                                        <!--end::Remove-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[107]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="teaser_text_up" name="teaser_text" rows="7"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[108]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="start_date_up" name="start_date" />
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[109]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="end_date_up" name="end_date" />
                                            </div>
                                        </div>
                                        <?php if($learning_flag) { ?>
                                        <div class="mb-4" id="learning_type">
                                            <label for="" class="form-label mb-4"><?php echo $label_details[110]['name']; ?>:</label>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="group_chk_up" name="group_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[111]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="individual_chk_up" name="individual_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[112]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="remote_chk_up" name="remote_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[113]['name']; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                        <label for="" class="form-label"><?php echo $label_details[114]['name']; ?>:</label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" value="" id="published_up" name="published" />
                                        </div>
                                        </div>
                                        <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[115]['name']; ?></b>:: <i><?php echo $label_details[116]['name']; ?></i></label>
                                        <div class="card-rounded bg-primary bg-opacity-5 mb-15" id="sharingOptionsContainer_up">
                                            <div class="row p-2">
                                                <div class="ribbon ribbon-left ribbon-color-success uppercase  ribbon-shadow">
                                                    <i class="fa fa-share"></i> <?php echo $label_details[117]['name']; ?>
                                                </div>
                                            </div>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[118]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[119]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_visible_up" name="local_visible" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[120]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_duplication_up" name="local_duplication" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($global_share_flag) { ?>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[121]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[122]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_visible_up" name="global_visible" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[123]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_duplication_up" name="global_duplication" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[124]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="title_up" name="title" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[125]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="estimated_time_up" name="estimated_time" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[126]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="goals_up" name="goals" rows="5" style="white-space: pre-wrap;"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[127]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="path_to_success_up" name="path_to_success" rows="5"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="input-group mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[128]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="task_up" name="task" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <!--begin::Input group-->
                                    <div class="input-group keywords">
                                        <span class="input-group-text"><?php echo $label_details[129]['name']; ?> *</span>
                                        <input class="form-control" data-kt-repeater="tagify" value="" id="keywords_up" name="keywords" />
                                    </div>
                                    <!--end::Input group-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="selected_students_container_up">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.762" height="23.999" viewBox="0 0 18.762 23.999">
                                    <path id="Documents" d="M.476,24A1.091,1.091,0,0,1,0,22.971Q.015,13.137.008,3.3c0-.823.228-1.049,1.056-1.05H2.258v.541q0,8.759,0,17.517c0,1.059.379,1.442,1.43,1.442H16.535c-.179.786.365,1.693-.59,2.25ZM4.55,0c-.524,0-.791.313-.791.889q0,9.232,0,18.464c0,.62.267.89.878.891q6.56,0,13.12,0c.7,0,1-.308,1-.992q0-6.818,0-13.637c0-.118.05-.249-.088-.391H13.877V0C10.732,0,7.641,0,4.55,0M6.017,8.652H16.48V10.1H6.017Zm.007,2.994H16.486v1.46H6.025Zm-.007,3.006H16.48V16.1H6.017Zm9.4-10.926h3.319L15.414.012Z" transform="translate(0 0)" fill="#58585a"/>
                                    </svg></span> <?php echo $label_details[130]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="selected_students_up">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[131]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="useful_links_up" name="useful_links" rows="5"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[132]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1 les_desc">
                                                        <textarea id="description_up" name="description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <div>
                                                <div id="display_document_block_up" style="display:none;">
                                                    <div class="card">
                                                        <ul class="draggable_btn_sec_up">
                                                            <div id="document_list_up" class="draggable-zone">

                                                            </div>
                                                        </ul>
                                                    </div> 
                                                </div>
                                                <div class="input-group mb-5">
                                                    <button type="button" id="doc_manager_btn_id_up" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="las la-upload fs-3"></i> <?php echo $label_details[133]['name']; ?></button>
                                                </div>
                                                <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[134]['name']; ?></b>:: <i><?php echo $label_details[135]['name']; ?></i></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->                            
                        </div>
                        <!-- Manage Task Module -->
                        <?php
                            $grouparr = explode(",", $user_det['group_id']);
                            if ((in_array(1, $grouparr))||(in_array(2, $grouparr))||(in_array(3, $grouparr))) {
                        ?>
                            <?php echo $task_module; ?>
                        <?php } ?>
                        
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[91]['name']; ?></button>
                            <button type="button" id="edit_dossiers_update_sub_bott"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[92]['name']; ?></button>
                            <button type="button" id="edit_dossiers_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[93]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>
            <?php
                $grouparr = explode(",", $user_det['group_id']);
                if ((in_array(4, $grouparr))||(in_array(5, $grouparr))) {
            ?>
                <?php echo $task_module; ?>
            <?php } ?>
            <!-- Create TasK Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="task_create_id" style="display:none;">
                <form name="add_task_form" id="add_task_form" class="add_task_form">
                    <a name="task_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <span id="task_page_title"></span> <?php echo $label_details[431]['name']; ?>
                            </h3>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="tsk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="tsk_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[432]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="task_title" name="task_title" class="form-control" aria-describedby="basic-addon1">
                                <input type="hidden" id="task_token_id" name="task_token_id" />
                                <input type="hidden" id="task_dup" name="task_dup" />
                            </div>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[433]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="task_category_id" name="task_category_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row mb-5">
                            <div class="col-lg-6">
                                <div class="input-group mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[434]['name']; ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                        <input class="form-control" id="from_date" name="from_date" />
                                    </div>                                        
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="input-group mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[435]['name']; ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                        <input type="text" id="to_date" name="to_date" class="form-control" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[436]['name']; ?></label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <textarea id="task_description" name="task_description" rows="10"></textarea>
                                </div>
                            </div>
                        </div>
                        <div>
                            
                            <div id="task_document_block" style="display:none;">
                                <div class="card">
                                    <ul class="draggable_btn_sec_task" >
                                        <div id="tasks_list" class="draggable-zone">

                                        </div>
                                    </ul>
                                </div> 
                            </div>
                            <div class="input-group mb-5">
                                <button type="button" id="task_doc_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="las la-upload fs-3"></i> <?php echo $label_details[437]['name']; ?></button>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_task_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><span id="task_save"></span></button>
                            <span id="save_and_new_btn"><button type="button" id="add_task_new_sub" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><span id="task_save_new"></button></span>
                            <button type="button" id="add_task_publish_sub" class="btn btn-sm btn-success my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><span id="task_save_publish"></button>
                            <button type="button" id="add_task_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[440]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            

            <!-- Create TasK Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="teacher_log_create_id" style="display:none;">
                    <a name="teacher_log_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[456]['name']; ?>
                            </h3>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="mt-3">
                            <!--begin::Add customer-->
                            <div class="task_cls_style">
                                <div><b><?php echo $label_details[457]['name']; ?>:</b> <span id="task_log_title"></span>(<span id="task_log_type"></span>)</div>
                                <div><b><?php echo $label_details[458]['name']; ?>:</b> <span id="task_log_lesson"></span>(<span id="task_log_course"></span>)</div>
                                <div><span id="task_log_date"></span></div>
                                <span>&nbsp;</span>
                            </div>
                            <!--end::Add customer-->
                        </div>
                        <div class="clearfix"></div>
                        <div class="">
                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="task_log_table">
                                <!--begin::Table head-->
                                <thead >
                                    <tr>
                                        <th></th>
                                        <th data-priority="2" class="fw-bolder"> <?php echo $label_details[459]['name']; ?> </th>
                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[460]['name']; ?> </th>
                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[461]['name']; ?> </th>
                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[462]['name']; ?> </th>
                                    </tr>
                                </thead>
                                <!--end::Table head-->
                                <!--begin::Table body-->
                                <tbody class=" text-gray-800 task_actionBtns_table">
                                </tbody>
                                <!--end::Table body-->
                            </table>
                        </div>
                        <div class="card-box px-8">
                            <div class="">&nbsp;</div>
                                                <!--begin::Toolbar-->
                            <div class="card-toolbar float-xxl-end">
                                <button type="button" id="add_task_log_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[463]['name']; ?></button>
                            </div>
                            <!--end::Toolbar-->
                        </div>
                        <!--end::Card body-->
                    </div>
            </div>
           
            
            <!-- Duplicate Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_duplicate_id" style="display:none;">
                <form name="duplicate_dossiers_form" id="duplicate_dossiers_form" class="duplicate_dossiers_form">
                    <a name="dossiers_duplicate_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[152]['name']; ?> <?php echo $label_details[383]['name']; ?></h3>
                                <button type="button" id="label_40_17" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="duplicate_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-copy fs-4"></i><?php echo $label_details[153]['name']; ?></button>
                            <button type="button" id="duplicate_dossiers_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[154]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="dup_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="dup_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="alert alert-dismissible bg-light-danger border border-danger d-flex flex-column flex-sm-row w-100 p-5 pt-2 pb-2 mb-10 info_dos_cls">
                            <!--begin::Icon-->
                            <!--begin::Svg Icon | path: icons/duotune/communication/com003.svg-->
                            <span class="svg-icon svg-icon-5tx svg-icon-danger">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="10" fill="black"></rect>
                                    <rect x="11" y="14" width="7" height="2" rx="1" transform="rotate(-90 11 14)" fill="black"></rect>
                                    <rect x="11" y="17" width="2" height="2" rx="1" transform="rotate(-90 11 17)" fill="black"></rect>
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                            <!--end::Icon-->
                            <!--begin::Content-->
                            <div class="d-flex flex-column pe-0 pe-sm-10">
                                <h5 class="mb-1"><?php echo $label_details[392]['name']; ?></h5>
                            </div>
                            <!--end::Content-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_assignment_container_dup">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg id="Group_2" data-name="Group 2" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="19.246" height="24" viewBox="0 0 19.246 24">
                                    <defs>
                                        <clipPath id="clip-path">
                                        <rect id="Rectangle_1" data-name="Rectangle 1" width="19.246" height="24" fill="none"/>
                                        </clipPath>
                                    </defs>
                                    <g id="Group_1" data-name="Group 1" clip-path="url(#clip-path)">
                                        <path id="Path_4" data-name="Path 4" d="M18.876,16a1.642,1.642,0,0,1,.317,1.107c0,.683-.05,1.369.008,2.047a3.016,3.016,0,0,1-1.728,3.035,13.952,13.952,0,0,1-5.265,1.6,18.027,18.027,0,0,1-4.59.1c-2.153-.262-4.376-.544-6.2-1.894a2.925,2.925,0,0,1-1.39-2.443c.021-.877,0-1.755.006-2.633,0-.286-.04-.589.28-.826,2.154,2.249,5.008,2.694,7.914,2.9a17.45,17.45,0,0,0,8.432-1.277A5.24,5.24,0,0,0,18.876,16M.1,14.317a1.736,1.736,0,0,0,.348.714A5.2,5.2,0,0,0,3.313,16.9a19.365,19.365,0,0,0,10.242.653A11.453,11.453,0,0,0,17.588,16.1c.631-.393,1.311-.853,1.444-1.584a10.251,10.251,0,0,0-.049-4.4c-.007-.028-.073-.041-.145-.079a6.431,6.431,0,0,1-3.46,2.171,20.227,20.227,0,0,1-10.693.253A7.332,7.332,0,0,1,.151,9.774,23.816,23.816,0,0,0,.1,14.317M.018,7.236a2.965,2.965,0,0,0,2.094,3.259C7.541,12.62,12.9,13.007,18.1,9.742a2.056,2.056,0,0,0,1.085-1.758c.032-.95.011-1.9,0-2.852a1.2,1.2,0,0,0-.235-.869,4.345,4.345,0,0,1-2.813,1.925,21.746,21.746,0,0,1-7.882.861c-2.878-.16-5.736-.468-8.22-2.636C.032,5.5.1,6.373.018,7.236M11.325.1c-.29-.031-.579-.08-.869-.09A34.383,34.383,0,0,0,6.121.3,14.8,14.8,0,0,0,1.307,1.584a1.535,1.535,0,0,0-.184,2.8A8.145,8.145,0,0,0,3.669,5.465a24.841,24.841,0,0,0,9.3.493,11.864,11.864,0,0,0,4.94-1.467c1.4-.872,1.4-1.949-.008-2.8A11.8,11.8,0,0,0,11.776.2c-.164.026-.338.1-.451-.1" transform="translate(0 0.001)" fill="#58585a"/>
                                    </g>
                                    </svg></span> <?php echo $label_details[155]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_assignment_fields_dup">
                                <!--begin::Compact form-->
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[156]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="term_id_dup" name="term_id">
                                                </select>
                                                <input type="hidden" id="token_id_dup" name="token_id" />
                                                <input type="hidden" id="dom_id" name="dom_id" />
                                                <input type="hidden" id="local_global" name="local_global" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[157]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="subject_id_dup" name="subject_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[158]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="language_id_dup" name="language_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <?php if($curriculum_flag) { ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[159]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_id_dup" name="curriculum_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[160]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_cycle_id_dup" name="curriculum_cycle_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <?php } ?>
                                    <div class="col-lg-4">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[161]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="course_id_dup" name="course_id">
                                                    <option value=""><?php echo $label_details[162]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php if($curriculum_flag) { ?>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[163]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="curriculum_item_id_dup" name="curriculum_item_id">
                                                <option value=""><?php echo $label_details[164]['name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="help-block"><i class="fa fa-info-circle"></i><strong><?php echo $label_details[165]['name']; ?>:: </strong><i><?php echo $label_details[166]['name']; ?></i></div>
                                    </div>
                                </div>
                                <?php } ?>
                                <div class="row">
                                    <div class="separator border-secondary my-10"></div>
                                </div> 
                                <div class="row mb-5">
                                    <div class="col-lg-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[167]['name']; ?></label>
                                        </div>
                                        <div class="py-5">
                                            <div id="logo_image_block_dup">
                                                <div class="rounded border input-group fit_content p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="logo_image_dup" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                        <!--begin::duplicate-->
                                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_duplicate_up" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        </button>
                                                        <!--end::duplicate-->
                                                        <!--begin::Remove-->
                                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file_dup" data-bs-original-title="Remove Logo">
                                                        <i class="bi bi-x fs-2"></i>
                                                        </a>
                                                        <input type="hidden" id="school_logo_file_name_dup" name="school_logo_file_name" />
                                                        <!--end::Remove-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[168]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="teaser_text_dup" name="teaser_text" rows="7"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[169]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="start_date_dup" name="start_date" />
                                            </div>
                                        </div>
                                        <div class="mb-4">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[170]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" id="end_date_dup" name="end_date" />
                                            </div>
                                        </div>
                                        <?php if($learning_flag) { ?>
                                        <div class="mb-4" id="learning_type">
                                            <label for="" class="form-label mb-4"><?php echo $label_details[171]['name']; ?>:</label>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="group_chk_dup" name="group_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[172]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="individual_chk_dup" name="individual_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[173]['name']; ?>
                                                </label>
                                            </div>
                                            <div class="form-check form-check-custom form-check-solid mb-5">
                                                <input class="form-check-input" type="checkbox" value="" id="remote_chk_dup" name="remote_chk" />
                                                <label class="form-check-label" for="flexCheckDefault">
                                                    <?php echo $label_details[174]['name']; ?>
                                                </label>
                                            </div>
                                        </div>
                                        <?php } ?>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="mb-4">
                                        <label for="" class="form-label"><?php echo $label_details[175]['name']; ?>:</label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" value="" id="published_dup" name="published" />
                                        </div>
                                        </div>
                                        <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[176]['name']; ?></b>:: <i><?php echo $label_details[177]['name']; ?></i></label>
                                        <div class="card-rounded bg-primary bg-opacity-5 mb-15" id="sharingOptionsContainer_dup">
                                            <div class="row p-2">
                                                <div class="ribbon ribbon-left ribbon-color-success uppercase  ribbon-shadow">
                                                    <i class="fa fa-share"></i> <?php echo $label_details[178]['name']; ?>
                                                </div>
                                            </div>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[179]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[180]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_visible_dup" name="local_visible" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[181]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="local_duplication_dup" name="local_duplication" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php if($global_share_flag) { ?>
                                            <div class="row p-4 sharingOptions">
                                                <blockquote><small><label><?php echo $label_details[182]['name']; ?>:</label></small></blockquote>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[183]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_visible_dup" name="global_visible" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-6">
                                                    <div class="form-group">
                                                        <label class="fw-bolder mb-3"><?php echo $label_details[184]['name']; ?>:</label>
                                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                                            <input class="form-check-input" type="checkbox" value="" id="global_duplication_dup" name="global_duplication" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[185]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="title_dup" name="title" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[186]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="estimated_time_dup" name="estimated_time" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[187]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="goals_dup" name="goals" rows="5"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[188]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="path_to_success_dup" name="path_to_success" rows="5"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <div class="input-group mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[189]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="task_dup" name="task" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row mb-5">
                                    <!--begin::Input group-->
                                    <div class="input-group">
                                        <span class="input-group-text"><?php echo $label_details[190]['name']; ?> *</span>
                                        <input class="form-control" data-kt-repeater="tagify" value="" id="keywords_dup" name="keywords" />
                                    </div>
                                    <!--end::Input group-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="selected_students_container_up">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.762" height="23.999" viewBox="0 0 18.762 23.999">
                                    <path id="Documents" d="M.476,24A1.091,1.091,0,0,1,0,22.971Q.015,13.137.008,3.3c0-.823.228-1.049,1.056-1.05H2.258v.541q0,8.759,0,17.517c0,1.059.379,1.442,1.43,1.442H16.535c-.179.786.365,1.693-.59,2.25ZM4.55,0c-.524,0-.791.313-.791.889q0,9.232,0,18.464c0,.62.267.89.878.891q6.56,0,13.12,0c.7,0,1-.308,1-.992q0-6.818,0-13.637c0-.118.05-.249-.088-.391H13.877V0C10.732,0,7.641,0,4.55,0M6.017,8.652H16.48V10.1H6.017Zm.007,2.994H16.486v1.46H6.025Zm-.007,3.006H16.48V16.1H6.017Zm9.4-10.926h3.319L15.414.012Z" transform="translate(0 0)" fill="#58585a"/>
                                    </svg></span> <?php echo $label_details[191]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="selected_students_up">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <div class="row mb-5">
                                        <div class="col-lg-12">
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[192]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="useful_links_dup" name="useful_links" rows="5"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <!--begin::Input group-->
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[193]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1 les_desc">
                                                        <textarea id="description_dup" name="description"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Input group-->
                                            <div>
                                                <div id="display_document_block_dup" style="display:none;">
                                                    <div class="card">
                                                        <ul class="draggable_btn_sec_dup" >
                                                            <div id="document_list_dup" class="draggable-zone">

                                                            </div>
                                                        </ul>
                                                    </div> 
                                                </div>
                                                <div class="input-group mb-5">
                                                    <button type="button" id="doc_manager_btn_id_dup" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="las la-upload fs-3"></i> <?php echo $label_details[194]['name']; ?></button>
                                                </div>
                                                <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b><?php echo $label_details[195]['name']; ?></b>:: <i><?php echo $label_details[196]['name']; ?></i></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="duplicate_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-copy fs-4"></i><?php echo $label_details[153]['name']; ?></button>
                            <button type="button" id="duplicate_dossiers_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[154]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            
            <!-- Preview Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_preview_id" style="display:none;">
                <form name="preview_dossiers_form" id="preview_dossiers_form" class="preview_dossiers_form">
                    <a name="dossiers_preview_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[212]['name']; ?> <?php echo $label_details[384]['name']; ?></h3>
                                <button type="button" id="label_40_16" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <?php if(in_array(260,$role_details)) { ?>
                            <button type="button" id="preview_download_pdf_dossiers_sub"  class="btn btn-sm btn-success my-1 me-3 px-2 fs-8">
                                <i class="las la-download fs-4"></i><?php echo $label_details[213]['name']; ?></button>
                            <?php } ?>
                            <?php if(in_array(261,$role_details)) { ?>
                            <button type="button" id="preview_print_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-eye fs-4"></i><?php echo $label_details[214]['name']; ?></button>
                            <?php } ?>
                            
                            <button type="button" id="preview_dossiers_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[215]['name']; ?></button>
                            
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9" id="print_preview_body">
                        <div class="portlet-body my-10">
                            <div class="dossier-preview-container p-0">
                                <!-- print pdf page1 start -->
                                <div>
                                    <!-- <table style="width: 100%;">
                                        <tbody>
                                            <tr>
                                                <td valign="top" style="width: 190px;"><img id="school_logo_preview" alt="" style="padding: 15px; max-width: 100%;" /></td>
                                                <td valign="top"><strong><span id="school_name"></span><br></strong><span id="school_gen_email"></span><br><span id="school_address"></span><br><span id="school_phoneno"></span></td>
                                                <td valign="top" style="width: 140px;text-align:right;"><strong><?php echo $label_details[216]['name']; ?>: </strong><span id="pr_start_date"></span><br><strong><?php echo $label_details[217]['name']; ?>: </strong><span id="pr_end_date"></span><br><strong><?php echo $label_details[218]['name']; ?>: </strong><span id="pr_term"></span></td>
                                                <td valign="top" style="width: 100px;" align="center"><img id="pr_qr_code" alt="" style="padding: 0px 5px; max-width: 100%;" /><span id="pr_dossier_key"></span></td>
                                            </tr>
                                        </tbody>
                                        <tbody>
                                            <tr>
                                                <td colspan="2" valign="top">
                                                    <ul style="list-style: none; padding-left: 15px;">
                                                        <li>
                                                            <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[219]['name']; ?>:</strong> <span id="pr_name"></span></h1>
                                                        </li>
                                                        <li>
                                                            <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[220]['name']; ?>:</strong> <span id="pr_course"></span></h1>
                                                        </li>
                                                        <li>
                                                            <h3 style="font-weight: normal; color: #578ebe ;"><strong><?php echo $label_details[221]['name']; ?>:</strong> <span id="pr_teacher"></span></h3>
                                                        </li>
                                                        <li>
                                                            <h3 style="font-weight: normal;"><strong><?php echo $label_details[222]['name']; ?>:</strong> <span id="pr_language"></span></h3>
                                                        </li>
                                                        <li>
                                                            <h3 style="font-weight: normal;"><strong><?php echo $label_details[223]['name']; ?>:</strong> <span id="pr_preparation_time"></span></h3>
                                                        </li>
                                                        
                                                    </ul>
                                                </td>
                                                <td colspan="2" align="right" style="width: 500px;"><img id="pr_teaser_image" alt="" style="padding: 5px; max-width: 300px;  max-height: 200px;" />
                                                <div class="clearfix"></div>
                                                <span id="pr_teaser_text"></span></td>
                                            </tr>
                                        </tbody>
                                    </table> -->
                                    <div style="width: 100%;">
                                        <div style="border: 1px solid #ddd; padding: 15px 0;">
                                            <div class="logosection">
                                                <div style="width: 190px; float: left;"><img id="school_logo_preview" alt="" style="padding: 15px; max-width: 100%;" /></div>
                                                <div style="float: left; padding: 15px;">
                                                    <div><strong><span id="school_name"></span></strong></div>
                                                    <div><span id="school_gen_email"></span></div>
                                                    <div><span id="school_address"></span></div>
                                                    <div><span id="school_phoneno"></span></div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="qrsection">
                                                <div class="pr_date_details">
                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[216]['name']; ?>: </strong><span id="pr_start_date"></span></div>
                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[217]['name']; ?>: </strong><span id="pr_end_date"></span></div>
                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[218]['name']; ?>: </strong><span id="pr_term"></span></div>
                                                </div>
                                                <div style="float: right;">        
                                                <div style="width: 100px;" align="center"><img id="pr_qr_code" alt="" style="padding: 5px; max-width: 100%;" /><span id="pr_dossier_key"></span></div> 
                                                </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        <div style="border: 1px solid #ddd;">
                                            <div class="schooldetails">
                                                <ul style="list-style: none; padding-left: 15px;">
                                                    <li>
                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[219]['name']; ?> : </strong> <span id="pr_name"></span></h1>
                                                    </li>
                                                    <li>
                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[220]['name']; ?>: </strong> <span id="pr_course"></span></h1>
                                                    </li>
                                                    <li>
                                                        <h3 style="font-weight: normal; color: #578ebe ;"><strong><?php echo $label_details[221]['name']; ?>: </strong> <span id="pr_teacher"></span></h3>
                                                    </li>
                                                    <li>
                                                        <h4 style="font-weight: normal;"><strong><?php echo $label_details[222]['name']; ?>: </strong> <span id="pr_language"></span></h4>
                                                    </li>
                                                    <li>
                                                        <h4 style="font-weight: normal;"><strong><?php echo $label_details[223]['name']; ?>: </strong> <span id="pr_preparation_time"></span></h4>
                                                    </li>
                                                    <li>
                                                        <a class="btn btn-xs btn-success btn-edit datatable-edit-button preview_teach_lesson_fld px-1 me-1"><i class="fas fa-chalkboard-teacher fs-8"></i> TEACH</a>
                                                    </li>
                                                    
                                                </ul>
                                            </div>
                                            <div class="schoolimg">
                                                <div class="sImg-size"><img id="pr_teaser_image" alt="" style="padding: 15px;width: 250px;" /><span id="pr_teaser_text"></span></div>
                                            </div>
                                            <div style="clear:both"></div>
                                        </div>
                                    </div>
                                    <br />
                                    <div id="pr_goals_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[224]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_goals"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_path_to_success_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[225]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_path_to_success"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_task_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[226]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_task"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_useful_links_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[228]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_useful_links"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_media_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;">Media</h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_media"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_description_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[227]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_description"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_learning_materials_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[229]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_learning_materials"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_solutions_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[230]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_solutions"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div id="pr_evaluations_table">
                                        <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr>
                                                    <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[231]['name']; ?></h2></th>
                                                </tr>
                                            </tbody>
                                            <tbody style="">
                                                <tr>
                                                    <td style="padding: 15px;">
                                                        <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                            <tbody>
                                                                <tr>
                                                                    <td>
                                                                        <span id="pr_evaluations"></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <br />
                                    </div>
                                    <div class="card mb-5 mb-lg-10 border pb-4" id="preview_task_manage_id" style="display: none;">
                                        <div class="card-header hd-col-2" id="preview_tasks_container">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.762" height="23.999" viewBox="0 0 18.762 23.999">
                                                <path id="Tasks" d="M.476,24A1.091,1.091,0,0,1,0,22.971Q.015,13.137.008,3.3c0-.823.228-1.049,1.056-1.05H2.258v.541q0,8.759,0,17.517c0,1.059.379,1.442,1.43,1.442H16.535c-.179.786.365,1.693-.59,2.25ZM4.55,0c-.524,0-.791.313-.791.889q0,9.232,0,18.464c0,.62.267.89.878.891q6.56,0,13.12,0c.7,0,1-.308,1-.992q0-6.818,0-13.637c0-.118.05-.249-.088-.391H13.877V0C10.732,0,7.641,0,4.55,0M6.017,8.652H16.48V10.1H6.017Zm.007,2.994H16.486v1.46H6.025Zm-.007,3.006H16.48V16.1H6.017Zm9.4-10.926h3.319L15.414.012Z" transform="translate(0 0)" fill="#58585a"/>
                                                </svg></span> <?php echo $label_details[393]['name']; ?></h4>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <div class="card-body pt-0" id="preview_add_container">
                                            <!--begin::Table-->
                                            <div class="">
                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="preview_task_table">
                                                    <!--begin::Table head-->
                                                    <thead >
                                                        <tr>
                                                            <th class="no-print"></th>
                                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[419]['name']; ?> </th>
                                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[420]['name']; ?> </th>
                                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[421]['name']; ?> </th>
                                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[422]['name']; ?> </th>
                                                            <th class="fw-bolder"> <?php echo $label_details[423]['name']; ?> </th>
                                                            <th class="fw-bolder"> <?php echo $label_details[424]['name']; ?> </th>
                                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[425]['name']; ?> </th>
                                                            <th class="fw-bolder" data-priority="8"> <?php echo $label_details[426]['name']; ?> </th>
                                                            <th data-priority="9" class="fw-bolder"> <?php echo $label_details[427]['name']; ?> </th>
                                                            <th data-priority="10" class="fw-bolder"> <?php echo $label_details[428]['name']; ?> </th>
                                                            <th data-priority="3" class="w-md-200px fw-bolder no-print" style="text-align: center;"> <?php echo $label_details[429]['name']; ?> </th>
                                                        </tr>
                                                    </thead>
                                                    <!--end::Table head-->
                                                    <!--begin::Table body-->
                                                    <tbody class=" text-gray-800 preview_task_actionBtns_table">
                                                    </tbody>
                                                    <!--end::Table body-->
                                                </table>
                                            </div>
                                            <!--end::Table-->
                                        </div>                            
                                    </div>

                                    <!-- 
                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                        <tbody>
                                            <tr>
                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[227]['name']; ?></h2></th>
                                            </tr>
                                            <tr>
                                                <td style="padding: 5px 15px;"><span id="pr_description"></span></td>
                                            </tr>
                                        </tbody>
                                        <tbody style="">
                                            <tr>
                                                <td style="padding: 15px;">
                                                    <table style="background-color: #fff;" width="100%" cellspacing="0" cellpadding="0" id="mytable">
                                                        <tbody>
                                                            <tr>
                                                                <td colspan="3" style="padding: 10px 15px; border-bottom: 1px solid #ddd;"><h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;"><?php echo $label_details[228]['name']; ?></h2></td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <span id="pr_useful_links"></span>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td colspan="3" style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                    <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                        <?php echo $label_details[229]['name']; ?>
                                                                    </h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                <ul style="list-style: none;padding-top: 15px;">
                                                                    <span id="pr_learning_materials"></span>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                    <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                        <?php echo $label_details[230]['name']; ?>
                                                                    </h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <ul style="list-style: none;padding-top: 15px;">
                                                                        <span id="pr_solutions"></span>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                    <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                        <?php echo $label_details[231]['name']; ?>
                                                                    </h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td>
                                                                    <ul style="list-style: none;padding-top: 15px;">
                                                                        <span id="pr_evaluations"></span>
                                                                    </ul>
                                                                </td>
                                                            </tr>
                                                            
                                                        </tbody>
                                                    </table>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <?php if(in_array(260,$role_details)) { ?>
                            <button type="button" id="preview_download_pdf_dossiers_sub_bott"  class="btn btn-sm btn-success my-1 me-3 px-2 fs-8">
                                <i class="las la-download fs-4"></i><?php echo $label_details[213]['name']; ?></button>
                            <?php } ?>
                            <?php if(in_array(261,$role_details)) { ?>
                            <button type="button" id="preview_print_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-eye fs-4"></i><?php echo $label_details[214]['name']; ?></button>
                            <?php } ?>
                            <button type="button" id="preview_dossiers_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[215]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Create TasK Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="teacher_view_create_id" style="display:none;">
                    <a name="teacher_view_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[441]['name']; ?>
                            </h3>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="mt-3">
                            <!--begin::Add customer-->
                            <div class="task_cls_style">
                                <div><b><?php echo $label_details[442]['name']; ?>:</b> <span id="task_view_title"></span>(<span id="task_view_type"></span>)</div>
                                <div><b><?php echo $label_details[443]['name']; ?>:</b> <span id="task_view_lesson"></span>(<span id="task_view_course"></span>)</div>
                                <div><span id="task_view_date"></span></div>
                                <span>&nbsp;</span>
                            </div>
                            <!--begin::Toolbar-->
                            <div class="card-toolbar task_btn_style">
                                <?php if(in_array(726,$role_details)) { ?>
                                <button type="button" id="lock_teacher_view_btn_id" class="btn btn-sm btn-info px-2"><?php echo $label_details[444]['name']; ?> <i class="las la-lock"></i></button>
                                <?php } ?>
                                <?php if(in_array(727,$role_details)) { ?>
                                <button type="button" id="grade_teacher_view_btn_id" class="btn btn-sm btn-success px-2"><?php echo $label_details[445]['name']; ?> <i class="fas fa-graduation-cap"></i></button>
                                <?php } ?>                       
                            </div>
                            <!--end::Toolbar-->
                            <!--end::Add customer-->
                        </div>
                        <div class="clearfix"></div>
                        <div class="">
                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="task_view_table">
                                <!--begin::Table head-->
                                <thead >
                                    <tr>
                                        <th></th>
                                        <th style="text-align: center;" data-priority="1" width="20px" rowspan="1" colspan="1">
                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                <input type="checkbox" id="task_view_table_check_all" class="group-checkable" name="task_view_table_check_all" >
                                                <span></span>
                                            </label>
                                        </th>
                                        <th data-priority="2" class="fw-bolder"> <?php echo $label_details[446]['name']; ?> </th>
                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[447]['name']; ?> </th>
                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[448]['name']; ?> </th>
                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[450]['name']; ?> </th>
                                        <th data-priority="7" class="fw-bolder"> <?php echo $label_details[449]['name']; ?> </th>
                                        <th data-priority="8" class="fw-bolder"> <?php echo $label_details[451]['name']; ?> </th>
                                        <th class="fw-bolder"> <?php echo $label_details[452]['name']; ?> </th>
                                        <th class="fw-bolder"> <?php echo $label_details[453]['name']; ?> </th>
                                        <th data-priority="3" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[454]['name']; ?> </th>
                                    </tr>
                                </thead>
                                <!--end::Table head-->
                                <!--begin::Table body-->
                                <tbody class=" text-gray-800 task_actionBtns_table">
                                </tbody>
                                <!--end::Table body-->
                            </table>
                        </div>
                        <div class="card-box px-8">
                            <div class="">&nbsp;</div>
                                                <!--begin::Toolbar-->
                            <div class="card-toolbar float-xxl-end">
                                <button type="button" id="add_student_task_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[455]['name']; ?></button>
                            </div>
                            <!--end::Toolbar-->
                        </div>
                        <!--end::Card body-->
                    </div>
            </div>


            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_dossiers" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[235]['name']; ?> <?php echo $label_details[385]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_dossiers_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[236]['name']; ?> <?php echo $label_details[385]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_dossiers_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[237]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[238]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->
            
             <!--begin::Modal - Restore Module-->
             <div class="modal fade" id="restore_dossiers" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[239]['name']; ?> <?php echo $label_details[386]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_dossiers_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[240]['name']; ?> <?php echo $label_details[386]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_dossiers_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[241]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[242]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->

            <!--begin::Modal - Send Task Module-->
            <div class="modal fade" id="send_task_dossiers" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[371]['name']; ?> <?php echo $label_details[287]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_18" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="st_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="st_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="send_task_dossiers_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[373]['name']; ?> <?php echo $label_details[387]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="send_task_dossiers_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[372]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_st_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[388]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - send_task Module-->

            <!--begin::Modal - Task Modals-->
            <div class="modal fade task_modal_cls" id="task_modals" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><span id="modal_header_title"></span></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                    <div class="tool_tip">
                                        <span class="tool_tip_text">Edit Labels</span>
                                        <i class="las la-edit fs-1"></i>
                                    </div>
                                    <!--end::Svg Icon-->
                                </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="tskmod_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="tskmod_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="task_modals_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><span id="modal_alert_title"></span></label>
                                        <label class="fs-6"><span id="modal_task_title"></span>?</label>   
                                        <input type="hidden" id="student_submit_id" />                                     
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="modal_tasks_sub" class="btn btn-primary"><span id="modal_alert_icon"></span><span id="modal_task_btn_text"></span>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_tskmod_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[468]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>

            <!--begin::Modal - Task Comments Modals-->
            <div class="modal fade" id="task_comments_modals" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[464]['name']; ?></span></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text">Edit Labels</span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="tskcom_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="tskcom_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="task_comments_modals_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="row mb-5">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[465]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="task_comments" name="task_comments" rows="5"></textarea>
                                                    <input type="hidden" id="st_task_id" name="st_task_id" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="modal_task_comments_sub" class="btn btn-primary"><i class="fas fa-comment fs-8"></i><?php echo $label_details[466]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_tskcom_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[467]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->
            
            <!--begin::Modal - PDF Ediotr Module-->
            <div class="modal fade task_modal_cls" id="teach_pdf_view_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-fullscreen">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="pdf_close_cls">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <div class="close_pdf_div">
                                    <span><i class="fa fa-arrow-left"></i></span>
                                    <span class="close_pdf">
                                        <?php echo $label_details[580]['name']; ?>
                                    </span>
                                </div>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y">
                            <div id="pdftron_viewer"></div>
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - PDF Tools Module-->
            <?php echo $video_modal; ?>
            <?php echo $file_manager; ?>
            <!--end::Modals-->
            
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $plugins_path; ?>ckeditor/ckeditor.js" type="text/javascript"></script>
<script src="<?php echo $plugins_path; ?>ckeditor/adapters/jquery.js" type="text/javascript"></script>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<script src="<?php echo $js_path;?>moment.js"></script>
<script src="<?php echo $plugins_path;?>custom/draggable/draggable.bundle.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/draggable/cards.js"></script>
<!--<script src="<?php echo $js_path;?>custom/documentation/forms/tagify.js"></script>-->
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/forms/tagify.js"></script>
<script src="<?php echo $js_path;?>ewsRatingStars.jquery.js"></script>
		<!--end::Page Custom Javascript-->
        <!--begin::PDF Viewer -->
<script type="text/javascript">
      window.PDFJS_LOCALE = {
        pdfJsWorker: '<?php echo $assets_path;?>pdf/js/pdf.worker.js',
        pdfJsCMapUrl: '<?php echo $assets_path;?>pdf/cmaps'
      };
</script>
<script src="<?php echo $assets_path;?>pdf/js/libs/html2canvas.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/three.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/pdf.min.js"></script>

<script src="<?php echo $assets_path;?>pdf/js/dist/3dflipbook.js"></script>
<script src="<?php echo $js_path;?>pdfeditor/pspdfkit.js"></script>

<!-- <script src="<?php echo $assets_path;?>pdf/js/lightbox.js"></script> -->
		<!--end::PDF Viewer-->
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>dossiers.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,student_table,selected=[],id="<?php  echo $user_det['id'];?>",term_fld="",teacher_fld="",course_fld="",type_fld="",del_fld="",local_fld="1",term_details=[],subject_details=[],dossier_language_details=[],curriculum_details=[],curriculum_cycle_details=[],curriculum_item_details=[],curriculum_item_cycle_details=[],student_details=[],course_details=[],study_level_details=[],flag=false,selected_students=[],tree_details=[],folder_id=1,inner_folder_id=1,attachmentCount = 0,uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],selected_folder_id="",file_details=[],file_doc_details=[],document_files=[],solution_files=[],evaluation_files=[],document_files_up=[],solution_files_up=[],evaluation_files_up=[],selected_folder=[],change_tree=true,folder_table,folder_tree=false,mark_categories_details=[],eva_count=0,eva_total_count=[],document_files_dup=[],solution_files_dup=[],evaluation_files_dup=[],school_details=[],rating=0,label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,preview_role=false,duplicate_role=false,download_role=false,download_att_role=false,file_manager_label_details=<?php echo json_encode($file_manager_label_details); ?>,move_id=1,group_id="<?php  echo $user_det['group_id'];?>",search_fld="",role_details=[],pdf_file_name="",arrayBuffer=[],curriculum_flag="<?php  echo $curriculum_flag;?>",learning_flag="<?php  echo $learning_flag;?>",global_share_flag="<?php  echo $global_share_flag;?>",all_document_files=[],task_file_doc_details=[],task_document_files=[],task_file_doc_details=[],task_table,from_date_fld="",to_date_fld="",is_published_fld="",is_locked_fld="",is_del_fld="",task_selected=[],task_category_fld="",task_category_details=[],task_view_table,task_view_selected=[],task_log_table,dos_id='',task_files_order=[],task_file_doc_details=[],load_tasks=0,lang_code="<?php  echo $lang_code;?>",preview_dos_id,preview_dos_key,preview_task_table;

$(document).ready(function() {
    CKEDITOR.env.isCompatible = true;
    $.map(ro_details, function(value, index){
        role_details.push(value);
    });
    var input1 = document.querySelector("#keywords_up");
    new Tagify(input1);
    var input2 = document.querySelector("#keywords_dup");
    new Tagify(input2);   
    
    $("#start_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#start_date_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#start_date_dup").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#end_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#end_date_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#end_date_dup").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#from_date").flatpickr({
        enableTime: true,
        dateFormat: "d-m-Y h:i K",
        time_24hr: false
    });
    $("#to_date").flatpickr({
        enableTime: true,
        dateFormat: "d-m-Y h:i K",
        time_24hr: false
    });
    $("#from_date_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#to_date_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    $('#task_description').ckeditor();  
    CKEDITOR.instances.task_description.on( 'save', function( evt ) {
        return false; //Prevents Page Refresh
    });
    file_manager_details();
    dossiers_details();
});
</script>  
