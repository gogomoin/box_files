<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(4) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(3) {
    text-align: center;
}
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[2]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[3]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
       
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[4]['name']; ?></h3>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th class="fw-bolder"> <?php echo $label_details[5]['name']; ?> </th>
								<th class="fw-bolder"> <?php echo $label_details[6]['name']; ?> </th>
								<th class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[7]['name']; ?> </th>
                                <th class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[8]['name']; ?> </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
           

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="acl_groups_edit_id" style="display:none;">
                <form name="edit_acl_groups_form" id="edit_acl_groups_form" class="edit_acl_groups_form">
                    <a name="acl_groups_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[9]['name']; ?></h3>
                        </div>
                        <div class="card-box px-8">
                            <div class="">&nbsp;</div>
                                                <!--begin::Toolbar-->
                            <div class="card-toolbar float-xxl-end">
                                <button type="button" id="edit_acl_groups_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                    <i class="las la-edit fs-4"></i><?php echo $label_details[10]['name']; ?></button>
                                <button type="button" id="edit_acl_groups_update_sub"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[11]['name']; ?></button>
                                <button type="button" id="edit_acl_groups_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[12]['name']; ?></button>
                            </div>
                            <!--end::Toolbar-->
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success" data-bs-toggle="tab" href="#kt_tab_pane_1_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[13]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info" data-bs-toggle="tab" href="#kt_tab_pane_2_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[14]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent_up">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1_up" role="tabpanel">
                                <!-- <div class="mb-10">
                                    <label class="fs-6 form-label text-dark"><?php echo $label_details[15]['name']; ?></label>
                                    <div class="form-check form-switch form-check-custom form-check-solid">
                                        <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                                    </div>
                                </div> -->
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[16]['name']; ?> *</label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                        <input type="text" id="group_name" name="group_name" class="form-control" aria-describedby="basic-addon1">
                                        <input type="hidden" id="token_id" name="token_id" />
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[17]['name']; ?> *</label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                        <input type="text" disabled="disabled" id="group_key" name="group_key" class="form-control" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2_up" role="tabpanel">
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[18]['name']; ?> *</label>
                                </div>
                                <div id="custom_rights"></div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[19]['name']; ?> *</label>
                                </div>
                                <div id="role_list"></div>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_acl_groups_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[10]['name']; ?></button>
                            <button type="button" id="edit_acl_groups_update_sub_bott"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                            <i class="las la-edit fs-4"></i><?php echo $label_details[11]['name']; ?></button>
                            <button type="button" id="edit_acl_groups_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[12]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>acl_groups.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,selected=[],page_details=[],group_role_details=[],role_details=[],custom_details=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>";

$(document).ready(function() {  
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("335", role_details) != -1)
    {
        edit_role=true;
    }  
	acl_groups_details();
});
</script>  
