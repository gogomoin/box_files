<?php
    $user_det = $this->session->userdata('user_det');
 ?>
</div>
    
    <!-- All Jquery -->
    <!-- ============================================================== -->
    <script src="<?php echo $admin_libs_path; ?>jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo $admin_libs_path; ?>popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo $admin_libs_path; ?>bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- apps -->
    <script src="<?php echo $admin_js_path; ?>app.min.js"></script>
    <script src="<?php echo $admin_js_path; ?>app.init.iconbar.js"></script>
    <script src="<?php echo $admin_js_path; ?>app-style-switcher.js"></script>
    <!-- slimscrollbar scrollbar JavaScript -->
    <script src="<?php echo $admin_libs_path; ?>perfect-scrollbar/dist/perfect-scrollbar.jquery.min.js"></script>
    <script src="<?php echo $admin_extra_libs_path; ?>sparkline/sparkline.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo $admin_js_path; ?>waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo $admin_js_path; ?>sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo $admin_js_path; ?>custom.min.js"></script>
	<script src="<?php echo $admin_extra_libs_path; ?>DataTables/datatables.min.js"></script>
	
    
<script type="application/javascript">
    var resizefunc = [],user_pristine_pwd=false;
$('#reset_pwd_btn').on('click', function(e){
    $('.errYxt').hide();
    $(".chng_pwd_form")[0].reset();
    user_pristine = false;
    $('#password,#n_password').css('border','1px solid #ccc');
    $(".chng_pwd_form").show();
    $('.chng_pwd_loader').hide();
});
    
$('#reset_pwd_sub').click(function(){
    
    user_pristine_pwd = true;
    if(valid_chng_pwd()){
     $(".chng_pwd_form").hide();
     $('.chng_pwd_loader').show();
     var pdata = {
         'password':$('#password').val(),
         'listing_owner_id':'<?php echo $user_det["id"];?>'
     };
        
     $.ajax({
        type : 'POST',
        url : baseurl+'listing_owner/change_password',
        data :JSON.stringify(pdata),
        success: function(r) {
            if(r.statuscode == '200'){
                $("#pwd_succ_msg span").html(r.statusdescription);
                $("#pwd_succ_msg").show();
                setTimeout(function(){
                    $('#close_pwd_btn').trigger('click');
                } , 2500);
            }
            else{
                $("#pwd_err_msg span").html(r.statusdescription);
                $("#pwd_err_msg").show();
            }
            $('.chng_pwd_loader').hide();
        },
        error: function() {
               $("#pwd_err_msg span").html('Failed To Reset Password – Please Try Again');
               $("#pwd_err_msg").show();
               $('.chng_pwd_loader').hide();
            }
        });
    }
    
});
   
$('#password,#n_password').on('keyup change', function(e){
    if(user_pristine_pwd)
        valid_chng_pwd();
});
    
function valid_chng_pwd(){
    var valid = true,
        pwd = $('#password').val(),
        n_pwd =  $('#n_password').val(),
        errMsg='';
    if(pwd == ''){
       $('#password').css('border','1px solid red');
        valid = false;
    }
    else{
        $('#password').css('border','1px solid #ccc');
    }
    if(n_pwd == ''){
       $('#n_password').css('border','1px solid red');
        valid = false;
    }
    else{
        $('#n_password').css('border','1px solid #ccc');
    }
    if(!valid){
        errMsg += 'Please Fill All Required Fields';
    }
    if(pwd != '' && n_pwd != ''){
        if(n_pwd != pwd){
           $('#password').css('border','1px solid red');
            if(errMsg != ''){
                errMsg += '<br/>';
            }
            errMsg += 'Confirm Password Did not match';
            valid = false;
            
        }
        else{
            $('#password').css('border','1px solid #ccc');
        }
    }
    if(!valid){
        $("#pwd_err_msg span").html(errMsg);
        $("#pwd_err_msg").show();
    }
    else{
        $("#pwd_err_msg span").html('');
        $("#pwd_err_msg").hide();
    }
    return valid;
}
    
</script>
</body>
</html>
