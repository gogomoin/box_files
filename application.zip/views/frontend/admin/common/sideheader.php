<?php
$user_det = $this->session->userdata('user_det');
?>
 <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        <li class="sidebar-item">
                            <a class="sidebar-link" href="<?php echo $base_url."admin"; ?>">
                                <i class=" mdi mdi-home-outline"></i>
                                <span class="hide-menu">Dashboard </span></a>                            
                        </li>
						<?php if($roles['smart_box']==0||$roles['sm_view']==0) {?>
							<li class="sidebar-item">
								<a class="sidebar-link" href="<?php echo $base_url."smart_box"; ?>">
									<i class=" icon fa fa-briefcase"></i>
									<span class="hide-menu">Smart Box </span></a>
							</li>
						<?php } ?>
						<?php if($roles['components']==0||$roles['com_view']==0) {?>
							<li class="sidebar-item">
								<a class="sidebar-link" href="<?php echo $base_url."components"; ?>">
									<i class=" icon fa fa-briefcase"></i>
									<span class="hide-menu">Components </span></a>
							</li>
						<?php } ?>
						<?php if($roles['sub_admin']==0||$roles['ad_view']==0) {?>
							<li class="sidebar-item">
								<a class="sidebar-link" href="<?php echo $base_url."sub_admin"; ?>">
									<i class=" icon fa fa-briefcase"></i>
									<span class="hide-menu">Admin </span></a>
							</li>
						<?php } ?>
						<?php if($roles['user']==0||$roles['u_view']==0) {?>
							<li class="sidebar-item">
								<a class="sidebar-link" href="<?php echo $base_url."user"; ?>">
									<i class=" icon fa fa-briefcase"></i>
									<span class="hide-menu">User </span></a>
							</li>
						<?php } ?>
						<?php if($roles['roles']==0||$roles['ro_view']==0) {?>
							<li class="sidebar-item">
								<a class="sidebar-link" href="<?php echo $base_url."admin/roles"; ?>">
									<i class=" icon fa fa-male"></i>
									<span class="hide-menu">Roles </span></a>
							</li>
						<?php } ?>
						<li class="sidebar-item">
                            <a class="sidebar-link has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false">
                                <i class=" icon fa fa-cog"></i>
                                <span class="hide-menu">Settings</span></a>
                            <ul aria-expanded="false" class="collapse  first-level">
							<?php if($roles['address_fields']==0||$roles['s_af_view']==0) {?>
                                <li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."admin/address_fields"; ?>"><i class="icon fa fa-address-card"></i><span
                                      class="hide-menu">Address Fields </span></a>
								</li>
								<?php } ?>
								<?php if($roles['address']==0||$roles['s_a_view']==0) {?>
								<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."admin/address"; ?>"><i class="fa fa-address-book"></i><span
                                      class="hide-menu">Address </span></a>
								</li>
								<?php } ?>
								<?php if($roles['company']==0||$roles['s_com_view']==0) {?>
									<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."company"; ?>"><i class="icon fa fa-building"></i><span
													class="hide-menu">Company </span></a>
									</li>
								<?php } ?>
								<?php if($roles['id_proof']==0||$roles['s_id_view']==0) {?>
									<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."id_proof"; ?>"><i class="icon fa fa-id-card"></i><span
													class="hide-menu">ID Proof </span></a>
									</li>
								<?php } ?>
								<?php if($roles['category']==0||$roles['cat_view']==0) {?>
									<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."category"; ?>"><i class="icon fa fa-list-alt"></i><span
													class="hide-menu">Category </span></a>
									</li>
								<?php } ?>								
								<?php if($roles['sub_category']==0||$roles['sub_cat_view']==0) {?>
									<li class="sidebar-item"> <a class="sidebar-link" href="<?php echo $base_url."sub_category"; ?>"><i class="icon fa fa-list-ul"></i><span
													class="hide-menu">Sub Category </span></a>
									</li>
								<?php } ?>
                            </ul>
                        </li>
					</ul>
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
       

