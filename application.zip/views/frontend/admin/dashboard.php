<?php 
echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>

<div class="page-wrapper">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="card gredient-info-bg m-t-0 m-b-0">
                <div class="card-body">
                    <h4 class="card-title text-white">Welcome <?php echo $user_det['username'];?></h4>
                    <h5 class="card-subtitle text-white op-5">Dashboard </h5>
                    <div class="row m-t-30 m-b-20">
                        <!-- col -->
                        <div class="col-sm-12 col-lg-3">
                            <div class="temp d-flex align-items-center flex-row">
                                <div class="display-5 text-white"><i class="mdi mdi-playlist-check"></i> <span>500</span>
                                </div>
                                <div class="m-l-10">
                                    <h3 class="m-b-0 text-white">Smart Boxes</h3>
                                </div>
                            </div>
                        </div>
                        <!-- col -->
                        <div class="col-sm-12 col-lg-9">
                            <div class="row">
                                <!-- col -->
                                <div class="col-sm-12 col-md-3">
                                    <div class="info d-flex align-items-center">
                                        <div class="m-r-10">
                                            <i class="mdi mdi-view-list text-white display-5 op-5"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-white m-b-0">56000</h3>
                                            <span class="text-white op-5">Active Users</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- col -->
                                <!-- col -->
                                <div class="col-sm-12 col-md-3">
                                    <div class="info d-flex align-items-center">
                                        <div class="m-r-10">
                                            <i class="mdi mdi mdi-eye text-white display-5 op-5"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-white m-b-0">653200</h3>
                                            <span class="text-white op-5">Programmes</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- col -->
                                <!-- col -->
                                <div class="col-sm-12 col-md-3">
                                    <div class="info d-flex align-items-center">
                                        <div class="m-r-10">
                                            <i class="mdi mdi-clock-in text-white display-5 op-5"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-white m-b-0">200763</h3>
                                            <span class="text-white op-5">Villages</span>
                                        </div>
                                    </div>
                                </div>
								<div class="col-sm-12 col-md-3">
                                    <div class="info d-flex align-items-center">
                                        <div class="m-r-10">
                                            <i class="mdi mdi-calendar-check text-white display-5 op-5"></i>
                                        </div>
                                        <div>
                                            <h3 class="text-white m-b-0">56</h3>
                                            <span class="text-white op-5">Events</span>
                                        </div>
                                    </div>
                                </div>
                                <!-- col -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            
			 
            <!-- ============================================================== -->
            <!-- End Container fluid  -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            <!-- ============================================================== -->
            <!-- End footer -->
            <!-- ============================================================== -->
        </div>
        
<?php echo $footer; ?>
<!--This page JavaScript --> 
  

<!--This page plugins -->
<script type="text/javascript">

var baseurl="<?php  echo $base_url;  ?>", userPristine=false,marker_id='';
$(document).ready(function(){	
    var url = window.location.href.split('#')[1];
	 if(url != undefined)
	 	window.location.href = '#';
});
</script>

<!-- edit by deva -->
