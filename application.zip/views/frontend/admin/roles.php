<?php echo $header; 
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<style>
	a:hover,a:focus{
		text-decoration: none;
		outline: none;
	}
	#accordion .panel{
		border: none;
		border-radius: 0;
		box-shadow: none;
		margin: 0 0 10px;
		overflow: hidden;
		position: relative;
	}
	#accordion .panel-heading{
		padding: 0;
		border: none;
		border-radius: 0;
		margin-bottom: 10px;
		z-index: 1;
		position: relative;
	}
	#accordion .panel-heading:before,
	#accordion .panel-heading:after{
		content: "";
		width: 50%;
		height: 20%;
		box-shadow: 0 15px 5px rgba(0, 0, 0, 0.4);
		position: absolute;
		bottom: 15px;
		left: 10px;
		transform: rotate(-3deg);
		z-index: -1;
	}
	#accordion .panel-heading:after{
		left: auto;
		right: 10px;
		transform: rotate(3deg);
	}
	#accordion .panel-title a{
		display: block;
		padding: 15px 70px 5px 70px;
		margin: 0;
		background: #fff;
		font-size: 18px;
		font-weight: 500;
		letter-spacing: 1px;
		color: #4c32e9;
		border-radius: 0;
		box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1), 0 0 40px rgba(0, 0, 0, 0.1) inset;
		position: relative;
	}
	#accordion .panel-title a:before,
	#accordion .panel-title a.collapsed:before{
		content: "\f106";
		font-family: "Font Awesome 5 Free";
		font-weight: 900;
		width: 55px;
		height: 100%;
		text-align: center;
		line-height: 50px;
		border-left: 1px solid blue;
		position: absolute;
		top: 0;
		right: 0;
	}
	#accordion .panel-title a.collapsed:before{ content: "\f107"; }
	#accordion .panel-title a .icon{
		display: inline-block;
		width: 55px;
		height: 100%;
		border-right: 2px blue;
		font-size: 20px;
		color: rgba(0,0,0,0.7);
		line-height: 50px;
		text-align: center;
		position: absolute;
		top: 0;
		left: 0;
	}
	#accordion .panel-body{
		padding: 5px 10px;
		margin: 0 0 0px;
		border-top: none;
		background: #fff;
		font-size: 15px;
		color: #333;
		line-height: 27px;
	}
	input#chk_sub_admin {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_user {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_components {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_smart_box {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_roles {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_settings {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_address_fields {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_address {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_company {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_id_proof {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_category {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_sub_category_fields {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_sub_category {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_sub_admin_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_user_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_components_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_smart_box_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_roles_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_settings_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_address_fields_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_address_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_company_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_id_proof_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_category_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_sub_category_fields_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
	input#chk_sub_category_up {
		position: absolute;
		z-index: 999;
		top: 18px;
		left: 50px;
	}
</style>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Roles</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Roles</li>
						</ol>
					</nav>
				</div>
			</div>
			<?php if($roles['ro_add']==0) {?>
			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<div class="button-group">
						<button type="button" class="btn waves-effect waves-light btn-primary" id="add_role_btn" data-toggle="modal" data-target="#add_role">Add Role</button>
					</div>
				</div>
			</div>
			<?php } ?>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">					
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
								<tr class="bg-light">
									<th>S.No.</th>
									<th>Role Name</th>
									<th>Admin</th>
									<th>Created On</th>
									<th>Actions</th>
								</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Roles Modal -->
	<div id="add_role" class="modal fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Role</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>				
				</div>
				<div class="modal-body">    
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_role_form" id="add_role_form" tion="#" class="add_role_form">
					<div class="row">
						<div class="form-group col-sm-6">
							<div class="add_user_frm">
								<input type="text" class="form-control" id="role_name" name="role_name" placeholder="Role Name *">
							</div>
						</div>
					</div>

						<div class="container">
							<div class="row">
								<div class="col-md-12">
									<h4 class="card-title"><input type="checkbox" id="chk_all" name="chk_all" value=""> Select All</h4>
									<div id="chk_all_id">
										<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingsmart_box">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_smart_box" value="" name="chk_smart_box">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsesmart_box" aria-expanded="false" aria-controls="collapsesmart_box">
															<i class="icon fa fa-briefcase"></i>
															Smart Box
														</a>
													</h4>
												</div>
												<div id="collapsesmart_box" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsmart_box">
													<div class="panel-body">
														<div id="chk_smart_box_id">
															<fieldset class="checkbox">
																<label class="col-2">
																	<input type="checkbox" value="sm_add" id="chk_add_smart_box" name="grp_smart_box[]"> Add
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_edit" id="chk_edit_smart_box" name="grp_smart_box[]"> Edit
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_delete" id="chk_del_smart_box" name="grp_smart_box[]"> Delete
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_status" id="chk_status_smart_box" name="grp_smart_box[]"> Status
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_components" id="chk_components_smart_box" name="grp_smart_box[]"> Components
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_cmp_allocate" id="chk_allocate_components_smart_box" name="grp_smart_box[]"> Allocate Components
																</label>
																<label class="col-2">
																	<input type="checkbox" value="sm_admin" id="chk_admin_smart_box" name="grp_smart_box[]"> Allocate Admin
																</label>					
																<label class="col-2">
																	<input type="checkbox" value="sm_view" id="chk_view_smart_box" name="grp_smart_box[]"> View
																</label>
															</fieldset>
														</div>
													</div>
												</div>
											</div>
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingcomponents">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_components" value="" name="chk_components">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsecomponents" aria-expanded="false" aria-controls="collapsecomponents">
															<i class="icon fa fa-briefcase"></i>
															Components
														</a>
													</h4>
												</div>
												<div id="collapsecomponents" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingcomponents">
													<div class="panel-body">
														<div id="chk_components_id">
															<fieldset class="checkbox">
																<label class="col-2">
																	<input type="checkbox" value="cmp_add" id="chk_add_components" name="grp_components[]"> Add
																</label>
																<label class="col-2">
																	<input type="checkbox" value="cmp_edit" id="chk_edit_components" name="grp_components[]"> Edit
																</label>
																<label class="col-2">
																	<input type="checkbox" value="cmp_delete" id="chk_del_components" name="grp_components[]"> Delete
																</label>
																<label class="col-2">
																	<input type="checkbox" value="cmp_status" id="chk_status_components" name="grp_components[]"> Status
																</label>
																<label class="col-2">
																	<input type="checkbox" value="cmp_import" id="chk_import_components" name="grp_components[]"> Import
																</label>
																<label class="col-2">
																	<input type="checkbox" value="cmp_export" id="chk_export_components" name="grp_components[]"> Export
																</label>					
																<label class="col-2">
																	<input type="checkbox" value="cmp_view" id="chk_view_components" name="grp_components[]"> View
																</label>
															</fieldset>
														</div>
													</div>
												</div>
											</div>
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingTwo">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_sub_admin" value="" name="chk_sub_admin">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">

															<i class="icon fa fa-briefcase"></i>
															Admin
														</a>
													</h4>
												</div>
												<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
													<div class="panel-body">
														<div id="chk_sub_admin_id">
															<fieldset class="checkbox">
																<label class="col-2">
																	<input type="checkbox" value="ad_add" id="chk_add_sub_admin" name="grp_sub_admin[]"> Add
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ad_edit" id="chk_edit_sub_admin" name="grp_sub_admin[]"> Edit
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ad_delete" id="chk_del_sub_admin" name="grp_sub_admin[]"> Delete
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ad_status" id="chk_status_sub_admin" name="grp_sub_admin[]"> Status
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ad_view" id="chk_view_sub_admin" name="grp_sub_admin[]"> View
																</label>
															</fieldset>
														</div>
													</div>
												</div>
											</div>
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingUser">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_user" value="" name="chk_user">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseUser" aria-expanded="false" aria-controls="collapseUser">
															<i class="icon fa fa-briefcase"></i>
															User
														</a>
													</h4>
												</div>
												<div id="collapseUser" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingUser">
													<div class="panel-body">
														<div id="chk_user_id">
															<fieldset class="checkbox">
																<label class="col-2">
																	<input type="checkbox" value="u_add" id="chk_add_user" name="grp_user[]"> Add
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_edit" id="chk_edit_user" name="grp_user[]"> Edit
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_delete" id="chk_del_user" name="grp_user[]"> Delete
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_status" id="chk_status_user" name="grp_user[]"> Status
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_import" id="chk_import_user" name="grp_user[]"> Import
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_export" id="chk_export_user" name="grp_user[]"> Export
																</label>
																<label class="col-2">
																	<input type="checkbox" value="u_view" id="chk_view_user" name="grp_user[]"> View
																</label>
															</fieldset>
														</div>
													</div>
												</div>
											</div>
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingThree">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_roles" value="" name="chk_roles">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
															<i class="icon fa fa-male"></i>
															Roles
														</a>
													</h4>
												</div>
												<div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
													<div class="panel-body">
														<div id="chk_roles_id">
															<fieldset class="checkbox">
																<label class="col-2">
																	<input type="checkbox" value="ro_add" id="chk_add_role" name="grp_role[]"> Add
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ro_edit" id="chk_edit_role" name="grp_role[]"> Edit
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ro_delete" id="chk_del_role" name="grp_role[]"> Delete
																</label>
																<label class="col-2">
																	<input type="checkbox" value="ro_view" id="chk_view_role" name="grp_role[]"> View
																</label>
															</fieldset>
														</div>
													</div>
												</div>
											</div>
											<div class="panel panel-default">
												<div class="panel-heading" role="tab" id="headingFour">
													<h4 class="panel-title">
														<input type="checkbox" id="chk_settings" name="chk_settings" value="">
														<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
															<i class="icon fa fa-cog"></i>
															Settings
														</a>
													</h4>
												</div>
												<div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
													<div class="panel-body">
														<div id="chk_settings_id">
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="headingFive">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_address_fields" name="chk_address_fields" value="">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">

																			<i class="icon fa fa-address-card"></i>
																			Address Fields
																		</a>
																	</h4>
																</div>
																<div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
																	<div class="panel-body">
																		<div id="chk_address_fields_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="s_af_add" id="chk_add_address_fields" name="grp_address_fields[]">  Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_af_edit" id="chk_edit_address_fields" name="grp_address_fields[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_af_del" id="chk_del_address_fields" name="grp_address_fields[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_af_view" id="chk_view_address_fields" name="grp_address_fields[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="headingSix">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_address" name="chk_address" value="">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">

																			<i class="icon fa fa-address-book"></i>
																			Address
																		</a>
																	</h4>
																</div>
																<div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
																	<div class="panel-body">
																		<div id="chk_address_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="s_a_add" id="chk_add_address" name="grp_address[]"> Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_a_edit" id="chk_edit_address" name="grp_address[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_a_del" id="chk_del_address" name="grp_address[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_a_import" id="chk_imp_address" name="grp_address[]"> Import
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_a_export" id="chk_exp_address" name="grp_address[]"> Export
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_a_view" id="chk_view_address" name="grp_address[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="heading7">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_company" value="" name="chk_company">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse7" aria-expanded="false" aria-controls="collapse7">

																			<i class="icon fa fa-building"></i>
																			Company
																		</a>
																	</h4>
																</div>
																<div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">
																	<div class="panel-body">
																		<div id="chk_company_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="s_com_add" id="chk_add_company" name="grp_company[]"> Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_com_edit" id="chk_edit_company" name="grp_company[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_com_delete" id="chk_del_company" name="grp_company[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_com_view" id="chk_view_company" name="grp_company[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="heading8">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_id_proof" value="" name="chk_id_proof">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="false" aria-controls="collapse8">

																			<i class="icon fa fa-id-card"></i>
																			ID Proof
																		</a>
																	</h4>
																</div>
																<div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">
																	<div class="panel-body">
																		<div id="chk_id_proof_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="s_id_add" id="chk_add_id_proof" name="grp_id_proof[]"> Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_id_edit" id="chk_edit_id_proof" name="grp_id_proof[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_id_delete" id="chk_del_id_proof" name="grp_id_proof[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="s_id_view" id="chk_view_id_proof" name="grp_id_proof[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="heading9">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_category" value="" name="chk_category">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse9" aria-expanded="false" aria-controls="collapse9">

																			<i class="icon fa fa-list-alt"></i>
																			Category
																		</a>
																	</h4>
																</div>
																<div id="collapse9" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading9">
																	<div class="panel-body">
																		<div id="chk_category_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="cat_add" id="chk_add_category" name="grp_category[]"> Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="cat_edit" id="chk_edit_category" name="grp_category[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="cat_delete" id="chk_del_category" name="grp_category[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="cat_view" id="chk_view_category" name="grp_category[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>															
															<div class="panel panel-default">
																<div class="panel-heading" role="tab" id="heading11">
																	<h4 class="panel-title">
																		<input type="checkbox" id="chk_sub_category" name="chk_sub_category" value="">
																		<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse11" aria-expanded="false" aria-controls="collapse11">

																			<i class="icon fa fa-list-ul"></i>
																			Sub Category
																		</a>
																	</h4>
																</div>
																<div id="collapse11" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading11">
																	<div class="panel-body">
																		<div id="chk_sub_category_id">
																			<fieldset class="checkbox">
																				<label class="col-2">
																					<input type="checkbox" value="sub_cat_add" id="chk_add_sub_category" name="grp_sub_category[]">  Add
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="sub_cat_edit" id="chk_edit_sub_category" name="grp_sub_category[]"> Edit
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="sub_cat_delete" id="chk_del_sub_category" name="grp_sub_category[]"> Delete
																				</label>
																				<label class="col-2">
																					<input type="checkbox" value="sub_cat_view" id="chk_view_sub_category" name="grp_sub_category[]"> View
																				</label>
																			</fieldset>
																		</div>
																	</div>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_role_form">
					<button type="button" class="btn btn-primary" id="add_role_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Roles Modal-->
	<div id="edit_address" class="modal fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog modal-lg">
		<div class="modal-content">
		  <div class="modal-header">
		  <h4 class="modal-title">Edit Address</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>			
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<form name="edit_address_form" id="edit_address_form" action="#" class="edit_address_form">
				<div class="row">
					<div class="form-group col-sm-6">
						<div class="add_user_frm">
							<input type="text" class="form-control" id="role_name_up" name="role_name" placeholder="Role Name *">
							<input type="hidden" name="role_id" id="role_id" value="" />
						</div>
					</div>
				</div>
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h4 class="card-title"><input type="checkbox" id="chk_all_up" name="chk_all_up" value=""> Select All</h4>
							<div id="chk_all_id_up">
								<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="headingsmart_box_up">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_smart_box_up" value="" name="chk_smart_box_up">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsesmart_box_up" aria-expanded="false" aria-controls="collapsesmart_box_up">
													<i class="icon fa fa-briefcase"></i>
													Smart Box
												</a>
											</h4>
										</div>
										<div id="collapsesmart_box_up" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingsmart_box_up">
											<div class="panel-body">
												<div id="chk_smart_box_id_up">
													<fieldset class="checkbox">
														<label class="col-2">
															<input type="checkbox" value="sm_add" id="chk_add_smart_box_up" name="grp_smart_box_up[]"> Add
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_edit" id="chk_edit_smart_box_up" name="grp_smart_box_up[]"> Edit
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_delete" id="chk_del_smart_box_up" name="grp_smart_box_up[]"> Delete
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_status" id="chk_status_smart_box_up" name="grp_smart_box_up[]"> Status
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_components" id="chk_components_smart_box_up" name="grp_smart_box_up[]"> Components
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_cmp_allocate" id="chk_allocate_components_smart_box_up" name="grp_smart_box_up[]"> Allocate Components
														</label>
														<label class="col-2">
															<input type="checkbox" value="sm_admin" id="chk_admin_smart_box_up" name="grp_smart_box_up[]"> Allocate Admin
														</label>					
														<label class="col-2">
															<input type="checkbox" value="sm_view" id="chk_view_smart_box_up" name="grp_smart_box_up[]"> View
														</label>
													</fieldset>
												</div>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="headingcomponents_up">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_components_up" value="" name="chk_components">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapsecomponents_up" aria-expanded="false" aria-controls="collapsecomponents_up">
													<i class="icon fa fa-briefcase"></i>
													Components
												</a>
											</h4>
										</div>
										<div id="collapsecomponents_up" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingcomponents_up">
											<div class="panel-body">
												<div id="chk_components_id_up">
													<fieldset class="checkbox">
														<label class="col-2">
															<input type="checkbox" value="cmp_add" id="chk_add_components_up" name="grp_components_up[]"> Add
														</label>
														<label class="col-2">
															<input type="checkbox" value="cmp_edit" id="chk_edit_components_up" name="grp_components_up[]"> Edit
														</label>
														<label class="col-2">
															<input type="checkbox" value="cmp_delete" id="chk_del_components_up" name="grp_components_up[]"> Delete
														</label>
														<label class="col-2">
															<input type="checkbox" value="cmp_status" id="chk_status_components_up" name="grp_components_up[]"> Status
														</label>
														<label class="col-2">
															<input type="checkbox" value="cmp_import" id="chk_import_components_up" name="grp_components_up[]"> Import
														</label>
														<label class="col-2">
															<input type="checkbox" value="cmp_export" id="chk_export_components_up" name="grp_components_up[]"> Export
														</label>					
														<label class="col-2">
															<input type="checkbox" value="cmp_view" id="chk_view_components_up" name="grp_components_up[]"> View
														</label>
													</fieldset>
												</div>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="heading12">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_sub_admin_up" value="" name="chk_sub_admin_up">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse12" aria-expanded="false" aria-controls="collapse12">

													<i class="icon fa fa-briefcase"></i>
													Admin
												</a>
											</h4>
										</div>
										<div id="collapse12" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading12">
											<div class="panel-body">
												<div id="chk_sub_admin_id_up">
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ad_add" id="chk_add_sub_admin_up" name="grp_sub_admin_up[]"> Add
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ad_edit" id="chk_edit_sub_admin_up" name="grp_sub_admin_up[]"> Edit
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ad_delete" id="chk_del_sub_admin_up" name="grp_sub_admin_up[]"> Delete
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ad_status" id="chk_status_sub_admin_up" name="grp_sub_admin_up[]"> Status
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ad_view" id="chk_view_sub_admin_up" name="grp_sub_admin_up[]"> View
														</label>
													</fieldset>
												</div>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="headingUser_up">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_user_up" value="" name="chk_user_up">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseUser_up" aria-expanded="false" aria-controls="collapseUser_up">
													<i class="icon fa fa-briefcase"></i>
													User
												</a>
											</h4>
										</div>
										<div id="collapseUser_up" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingUser_up">
											<div class="panel-body">
												<div id="chk_user_id_up">
													<fieldset class="checkbox">
														<label class="col-2">
															<input type="checkbox" value="u_add" id="chk_add_user_up" name="grp_user_up[]"> Add
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_edit" id="chk_edit_user_up" name="grp_user_up[]"> Edit
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_delete" id="chk_del_user_up" name="grp_user_up[]"> Delete
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_status" id="chk_status_user_up" name="grp_user_up[]"> Status
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_import" id="chk_import_user_up" name="grp_user_up[]"> Import
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_export" id="chk_export_user_up" name="grp_user_up[]"> Export
														</label>
														<label class="col-2">
															<input type="checkbox" value="u_view" id="chk_view_user_up" name="grp_user_up[]"> View
														</label>
													</fieldset>
												</div>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="heading13">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_roles_up" value="" name="chk_roles_up">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse13" aria-expanded="false" aria-controls="collapse13">
													<i class="icon fa fa-male"></i>
													Roles
												</a>
											</h4>
										</div>
										<div id="collapse13" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading13">
											<div class="panel-body">
												<div id="chk_roles_id_up">
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ro_add" id="chk_add_role_up" name="grp_role_up[]"> Add
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ro_edit" id="chk_edit_role_up" name="grp_role_up[]"> Edit
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ro_delete" id="chk_del_role_up" name="grp_role_up[]"> Delete
														</label>
													</fieldset>
													<fieldset class="checkbox">
														<label>
															<input type="checkbox" value="ro_view" id="chk_view_role_up" name="grp_role_up[]"> View
														</label>
													</fieldset>
												</div>
											</div>
										</div>
									</div>
									<div class="panel panel-default">
										<div class="panel-heading" role="tab" id="heading14">
											<h4 class="panel-title">
												<input type="checkbox" id="chk_settings_up" name="chk_settings_up" value="">
												<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse14" aria-expanded="false" aria-controls="collapse14">
													<i class="icon fa fa-cog"></i>
													Settings
												</a>
											</h4>
										</div>
										<div id="collapse14" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading14">
											<div class="panel-body">
												<div id="chk_settings_id_up">
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading15">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_address_fields_up" name="chk_address_fields_up" value="">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse15" aria-expanded="false" aria-controls="collapse15">

																	<i class="icon fa fa-address-card"></i>
																	Address Fields
																</a>
															</h4>
														</div>
														<div id="collapse15" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading15">
															<div class="panel-body">
																<div id="chk_address_fields_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_af_add" id="chk_add_address_fields_up" name="grp_address_fields_up[]">  Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_af_edit" id="chk_edit_address_fields_up" name="grp_address_fields_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_af_del" id="chk_del_address_fields_up" name="grp_address_fields_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_af_view" id="chk_view_address_fields_up" name="grp_address_fields_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading16">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_address_up" name="chk_address_up" value="">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse16" aria-expanded="false" aria-controls="collapse16">

																	<i class="icon fa fa-address-book"></i>
																	Address
																</a>
															</h4>
														</div>
														<div id="collapse16" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading16">
															<div class="panel-body">
																<div id="chk_address_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_add" id="chk_add_address_up" name="grp_address_up[]"> Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_edit" id="chk_edit_address_up" name="grp_address_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_del" id="chk_del_address_up" name="grp_address_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_import" id="chk_imp_address_up" name="grp_address_up[]"> Import
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_export" id="chk_exp_address_up" name="grp_address_up[]"> Export
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_a_view" id="chk_view_address_up" name="grp_address_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading17">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_company_up" value="" name="chk_company_up">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse17" aria-expanded="false" aria-controls="collapse17">

																	<i class="icon fa fa-building"></i>
																	Company
																</a>
															</h4>
														</div>
														<div id="collapse17" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading17">
															<div class="panel-body">
																<div id="chk_company_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_com_add" id="chk_add_company_up" name="grp_company_up[]"> Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_com_edit" id="chk_edit_company_up" name="grp_company_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_com_delete" id="chk_del_company_up" name="grp_company_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_com_view" id="chk_view_company_up" name="grp_company_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading18">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_id_proof_up" value="" name="chk_id_proof_up">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse18" aria-expanded="false" aria-controls="collapse18">

																	<i class="icon fa fa-id-card"></i>
																	ID Proof
																</a>
															</h4>
														</div>
														<div id="collapse18" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading18">
															<div class="panel-body">
																<div id="chk_id_proof_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_id_add" id="chk_add_id_proof_up" name="grp_id_proof_up[]"> Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_id_edit" id="chk_edit_id_proof_up" name="grp_id_proof_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_id_delete" id="chk_del_id_proof_up" name="grp_id_proof_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="s_id_view" id="chk_view_id_proof_up" name="grp_id_proof_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading19">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_category_up" value="" name="chk_category_up">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse19" aria-expanded="false" aria-controls="collapse19">

																	<i class="icon fa fa-list-alt"></i>
																	Category
																</a>
															</h4>
														</div>
														<div id="collapse19" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading19">
															<div class="panel-body">
																<div id="chk_category_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="cat_add" id="chk_add_category_up" name="grp_category_up[]"> Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="cat_edit" id="chk_edit_category_up" name="grp_category_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="cat_delete" id="chk_del_category_up" name="grp_category_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="cat_view" id="chk_view_category_up" name="grp_category_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>													
													<div class="panel panel-default">
														<div class="panel-heading" role="tab" id="heading21">
															<h4 class="panel-title">
																<input type="checkbox" id="chk_sub_category_up" name="chk_sub_category_up" value="">
																<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse21" aria-expanded="false" aria-controls="collapse21">

																	<i class="icon fa fa-list-ul"></i>
																	Sub Category
																</a>
															</h4>
														</div>
														<div id="collapse21" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading21">
															<div class="panel-body">
																<div id="chk_sub_category_id_up">
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="sub_cat_add" id="chk_add_sub_category_up" name="grp_sub_category_up[]">  Add
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="sub_cat_edit" id="chk_edit_sub_category_up" name="grp_sub_category_up[]"> Edit
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="sub_cat_delete" id="chk_del_sub_category_up" name="grp_sub_category_up[]"> Delete
																		</label>
																	</fieldset>
																	<fieldset class="checkbox">
																		<label>
																			<input type="checkbox" value="sub_cat_view" id="chk_view_sub_category_up" name="grp_sub_category_up[]"> View
																		</label>
																	</fieldset>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
			<div class="text-center edit_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer edit_address_form">
			<button type="button" class="btn btn-primary" id="edit_address_sub">Update</button>
			<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>
	  </div>
	</div>

	<!-- delete Address -->
	<div id="delete_address" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
	  <div class="modal-dialog">
		<div class="modal-content">
		  <div class="modal-header">
			<h4 class="modal-title">Delete Address</h4>
			<button type="button" class="close" data-dismiss="modal">&times;</button>
		  </div>
		  <div class="modal-body">
		
			<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
			<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
			<div class="delete_address_form">
			  <div class="form-group">
				<p>If You Delete Address, Related Information Will Be Removed</p>
				<p>Are You Sure You Want To Delete Address?</p>
			  </div>
			</div>
			<div class="text-center delete_col_loader" style="display:none">
				<div class="loader"></div>
			</div>
		  </div>
		  <div class="modal-footer delete_address_form">
			<button type="button" class="btn btn-primary" id="delete_address_sub">Delete</button>
			<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
		  </div>
		</div>

	  </div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>roles.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,role=[],id="<?php  echo $user_det['id'];?>";
var edit_role = "<?php echo $roles['ro_edit']; ?>";
var del_role = "<?php echo $roles['ro_delete']; ?>";
var sta_role = "<?php echo $roles['ro_status']; ?>";
$(document).ready(function() {    
	role_details();
});

</script>
