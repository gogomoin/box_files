<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<link href="<?php echo $css_path;?>jquery-ui.css"" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.0.45/css/materialdesignicons.min.css">
<script src="<?php echo $js_path;?>jquery.min.js"></script>
<script src="<?php echo $js_path;?>jquery-ui.min.js"></script>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Smart Box</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Smart Box</li>
						</ol>
					</nav>
				</div>
			</div>
			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['sm_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_smart_box_btn" data-toggle="modal" data-target="#add_smart_box">Add Smart Box</button>
						</div>
					<?php } ?>					
				</div>				
			</div>			
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Box No.</th>
								<th>Address</th>
								<th>Country</th>
								<th>Photo</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Status</th>
								<th>Admin</th>
								<th>Components</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Smart Box Modal -->
	<div id="add_smart_box" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Smart Box</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="com_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="com_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_smart_box_form" id="add_smart_box_form" action="#" class="add_smart_box_form">
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Smart Box No</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="box_no" name="box_no" placeholder="Box No *">
								</div>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Smart Box Photo</label>
								<div class="custom-file">
									<input type="file" name="smart_box_photo_file" id="smart_box_photo_file" class="custom-file-input" accept="image/*">
									<label class="custom-file-label" for="customFile" id="smart_box_photo_label">Choose Photo (Images only)</label>
									<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="smart_box_photo_preview">
									<a class="" style="cursor:pointer" id="remove_smart_box_photo_file"><span>Remove</span></a>
								</div>
							</div>
						</div>
						<div class="row"><div class="form-group col-sm-12"></div></div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Country</label>
								<select class="form-control" id="country_id" name="country_id" placeholder="Select Country">
								</select>
							</div>
						</div>
						<div id="address_fields"></div>
					</form>
					<div class="text-center com_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_smart_box_form">
					<button type="button" class="btn btn-primary" id="add_smart_box_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_com_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit smart_box Modal -->
	<div id="edit_smart_box" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Smart Box</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_smart_box_form" id="edit_smart_box_form" action="#" class="edit_smart_box_form">
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Smart Box No</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="box_no_up" name="box_no" placeholder="Box No *">
									<input type="hidden" id="smart_box_id" name="smart_box_id">
								</div>
							</div>
						</div>
						<div class="form-group col-sm-12">
							<label for="email">Smart Box Photo</label>
							<div class="custom-file">
								<input type="file" name="smart_box_photo_file" id="smart_box_photo_file_up" class="custom-file-input" accept="image/*">
								<label class="custom-file-label" for="customFile" id="smart_box_photo_label_up">Choose Photo (Images only)</label>
								<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="smart_box_photo_preview_up">
								<a class="" style="cursor:pointer" id="remove_smart_box_photo_file_up"><span>Remove</span></a>
								<input type="hidden" id="smart_box_photo_file_name" name="smart_box_photo_file_name">
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Country</label>
								<select class="form-control" id="country_id_up" name="country_id" placeholder="Select Country">
								</select>
							</div>
						</div>
						<div id="address_fields_up"></div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_smart_box_form">
					<button type="button" class="btn btn-primary" id="edit_smart_box_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_com_edit_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete smart_box Modal -->
	<div id="delete_smart_box" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Smart Box</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_smart_box_form">
						<div class="form-group">
							<p>If You Delete Smart Box, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Smart Box?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_smart_box_form">
					<button type="button" class="btn btn-primary" id="delete_smart_box_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_com_del_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
	<!-- smart_box status -->
	<div id="status_smart_box" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Smart Box Status</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sts_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sts_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="status_smart_box_form">
						<div class="form-group">
							<p>Are You Sure You Want To <strong class="st_chng"></strong> Smart Box?</p>
						</div>
					</div>
					<div class="text-center status_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer status_smart_box_form">
					<button type="button" class="btn btn-primary" id="status_mark_sub">Yes</button>
					<button type="button" class="btn btn-danger" id="close_mrk_st_btn" data-dismiss="modal">No</button>
				</div>
			</div>
		</div>
	</div>	
	<!-- smart_box admin -->
	<div id="admin_smart_box" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Smart Box Admin</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sm_adm_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sm_adm_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="admin_smart_box_form" id="admin_smart_box_form" action="#" class="admin_smart_box_form">
						<div class="row">
							<div class="col-sm-12">
								<div class="card">
									<div class="card-body">
										<div class="table-responsive m-t-20">
											<table id="admin-table" class="table table-bordered m-b-20" data-page-length='10'>
												<thead>
												<tr class="bg-light">
													<th></th>
													<th>Name</th>
													<th>Role</th>
												</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<input type="hidden" id="smart_box_id_admin" name="smart_box_id" />
					</form>
					<div class="text-center admin_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer admin_smart_box_form">
					<button type="button" class="btn btn-primary" id="admin_mark_sub">Allocate</button>
					<button type="button" class="btn btn-danger" id="close_mrk_sm_adm_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>	
</div>
<?php echo $footer; ?>
<script src="<?php echo $js_path;?>smart_box.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,admin_table,category_list,category_list_up,country=[],categories=[],address_fields_arr=[],address_arr=[],selected=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['sm_edit']; ?>";
	var del_add_role = "<?php echo $roles['sm_delete']; ?>";
	var status_add_role = "<?php echo $roles['sm_status']; ?>";
	var admin_add_role = "<?php echo $roles['sm_admin']; ?>";
	var components_add_role = "<?php echo $roles['sm_components']; ?>";
	$(document).ready(function() {
		smart_box_details();
	});
</script>
