<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<link href="<?php echo $css_path;?>jquery-ui.css"" rel="stylesheet" type="text/css"/>
<script src="<?php echo $js_path;?>jquery.min.js"></script>
<script src="<?php echo $js_path;?>jquery-ui.min.js"></script>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Smart Box Components</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item"><a href="<?php echo $base_url."smart_box"; ?>">Smart Box</a></li>
							<li class="breadcrumb-item active" aria-current="page">Components</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['sm_cmp_allocate']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="allocate_components_btn" data-toggle="modal" data-target="#allocate_components">Allocate Components </button>
						</div>
					<?php } ?>					
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Serial No</th>
								<th>Name</th>								
								<th>Photo</th>
								<th>Quantity</th>
								<th>Specifications</th>
								<th>Price</th>
								<th>Date of Purchase</th>
								<th>Date of Expiry</th>
								<th>Notes</th>
								<th>Status</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- smart_box Allocate Components -->
	<div id="allocate_components" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Smart Box Components</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sm_adm_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sm_adm_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="smart_box_component_form" id="smart_box_component_form" action="#" class="smart_box_component_form">
						<div class="row">
							<div class="col-sm-12">
								<div class="card">
									<div class="card-body">
										<div class="table-responsive m-t-20">
											<table id="comp-table" class="table table-bordered m-b-20" data-page-length='10'>
												<thead>
												<tr class="bg-light">
													<th></th>
													<th>Serial No</th>
													<th>Name</th>
												</tr>
												</thead>
												<tbody>
												</tbody>
											</table>
										</div>
									</div>
								</div>
							</div>
						</div>
						<input type="hidden" id="smart_box_id" name="smart_box_id" value="<?php echo $smart_box_id; ?>" />
					</form>
					<div class="text-center smart_box_component_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer smart_box_component_form">
					<button type="button" class="btn btn-primary" id="smart_box_component_mark_sub">Allocate</button>
					<button type="button" class="btn btn-danger" id="close_mrk_sm_adm_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>smart_box_components.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,comp_table,country=[],company=[],roles=[],id_proofs=[],id="<?php  echo $user_det['id'];?>",smart_box_id="<?php  echo $smart_box_id;?>",selected=[];
	$(document).ready(function() {
		smart_box_components_details();
	});
</script>
