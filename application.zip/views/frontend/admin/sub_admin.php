<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<link href="<?php echo $css_path;?>jquery-ui.css"" rel="stylesheet" type="text/css"/>
<script src="<?php echo $js_path;?>jquery.min.js"></script>
<script src="<?php echo $js_path;?>jquery-ui.min.js"></script>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Admin</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Admin</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['ad_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_sub_admin_btn" data-toggle="modal" data-target="#add_sub_admin">Add Admin </button>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Username</th>
								<th>Name</th>
								<th>Mobile No</th>
								<th>Photo</th>
								<th>Company Name</th>
								<th>Role Name</th>
								<th>ID Proof</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Status</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new Sub Admin Modal -->
	<div id="add_sub_admin" class="modal fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Admin</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="com_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="com_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_sub_admin_form" id="add_sub_admin_form" action="#" class="add_sub_admin_form">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">Admin Info</span></a> </li>
							<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Profile</span></a> </li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="home" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>

								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Username *</label>
										<input type="text" class="form-control" id="username" name="username" placeholder="Username *">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Name *</label>
										<input type="text" class="form-control" id="name" name="name" placeholder="Name *">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Role Name</label>
										<select class="form-control" id="role_name" name="role_name" placeholder="Select Role Name">
										</select>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Country</label>
										<select class="form-control" id="country" name="country" placeholder="Select Country">
										</select>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">ID Proof Name</label>
										<select class="form-control" id="id_proof_name" name="id_proof_name">
											<option>Select ID Proof Name</option>
										</select>
										<small class="text-muted">* Select Country To View ID Proof Names </small>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">ID Proof File</label>
										<div class="custom-file">
											<input type="file" name="id_proof_file" id="id_proof_file" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="id_proof_label">Choose ID Proof (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="ID Proof" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="id_proof_preview">
											<a class="" style="cursor:pointer" id="remove_id_proof_file"><span>Remove</span></a>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Department Name</label>
										<input type="text" class="form-control" id="dept_name" name="dept_name" placeholder="Department Name">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Designation</label>
										<input type="text" class="form-control" id="designation" name="designation" placeholder="Designation">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Company Name</label>
										<select class="form-control" id="com_name" name="com_name" placeholder="Select Company">
										</select>
									</div>
								</div>
								<div class="row company_details" style="display: none">
									<div class="form-group col-sm-6">
										<small class="text-muted">Email address </small>
										<h6><span id="com_email"></span></h6> <small class="text-muted p-t-30 db">Phone</small>
										<h6><span id="com_conact_no"></span></h6> <small class="text-muted p-t-30 db">Address</small>
										<h6><span id="com_address"></span></h6>
									</div>
									<div class="form-group col-sm-6">
										<small class="text-muted">Contact Person Name </small>
										<h6><span id="contact_person_name"></span></h6> <small class="text-muted p-t-30 db">Company Logo</small>
										<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Logo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="com_logo_preview">
									</div>
								</div>
							</div>
							<div class="tab-pane  p-20" id="profile" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>

								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Phone No</label>
										<input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone No">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Email</label>
										<input type="text" class="form-control" id="email" name="email" placeholder="Email">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="radio1">Gender: </label>
										<fieldset class="radio">
											<label for="radio1">
												<input type="radio" id="male" name="gender" value="Male"> Male
											</label>
											<label>
												<input type="radio" id="female" name="gender" value="Female" > Female
											</label>
										</fieldset>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Date Of Birth</label>
										<input type="text" class="form-control" id="date_of_birth" name="date_of_birth" placeholder="Date Of Birth" autocomplete="off">
									</div>
									<script type="text/javascript">
										$('#date_of_birth').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
											changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
									</script>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<div class="add_user_frm">
											<label for="email">Address</label>
											<textarea type="text" class="form-control" id="address" name="address" placeholder="Address"></textarea>
										</div>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Photo</label>
										<div class="custom-file">
											<input type="file" name="photo_file" id="photo_file" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="photo_label">Choose Photo (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="photo_preview">
											<a class="" style="cursor:pointer" id="remove_photo_file"><span>Remove</span></a>
										</div>
									</div>
								</div>
							</div>

						</div>
					</form>
					<div class="text-center com_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_sub_admin_form">
					<button type="button" class="btn btn-primary" id="add_sub_admin_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_com_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit Admin Modal -->
	<div id="edit_sub_admin" class="modal fade fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Admin</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_sub_admin_form" id="edit_sub_admin_form" action="#" class="edit_sub_admin_form">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home_up" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">Admin Info</span></a> </li>
							<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#profile_up" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Profile</span></a> </li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="home_up" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>

								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Username *</label>
										<input type="text" class="form-control" id="username_up" name="username" placeholder="Username *">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Name *</label>
										<input type="text" class="form-control" id="name_up" name="name" placeholder="Name *">
									</div>
									<input type="hidden" id="admin_id" name="admin_id">
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Role Name</label>
										<select class="form-control" id="role_name_up" name="role_name" placeholder="Select Role Name">
										</select>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Country</label>
										<select class="form-control" id="country_up" name="country" placeholder="Select Country">
										</select>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">ID Proof Name</label>
										<select class="form-control" id="id_proof_name_up" name="id_proof_name">
											<option>Select ID Proof Name</option>
										</select>
										<small class="text-muted">* Select Country To View ID Proof Names </small>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">ID Proof File</label>
										<div class="custom-file">
											<input type="file" name="id_proof_file" id="id_proof_file_up" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="id_proof_label_up">Choose ID Proof (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="ID Proof" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="id_proof_preview_up">
											<a class="" style="cursor:pointer" id="remove_id_proof_file_up"><span>Remove</span></a>
											<input type="hidden" id="id_proof_file_name" name="id_proof_file_name">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Department Name</label>
										<input type="text" class="form-control" id="dept_name_up" name="dept_name" placeholder="Department Name">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Designation</label>
										<input type="text" class="form-control" id="designation_up" name="designation" placeholder="Designation">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Company Name</label>
										<select class="form-control" id="com_name_up" name="com_name" placeholder="Select Company">
										</select>
									</div>
								</div>
								<div class="row company_details_up" style="display: none">
									<div class="form-group col-sm-6">
										<small class="text-muted">Email address </small>
										<h6><span id="com_email_up"></span></h6> <small class="text-muted p-t-30 db">Phone</small>
										<h6><span id="com_conact_no_up"></span></h6> <small class="text-muted p-t-30 db">Address</small>
										<h6><span id="com_address_up"></span></h6>
									</div>
									<div class="form-group col-sm-6">
										<small class="text-muted">Contact Person Name </small>
										<h6><span id="contact_person_name_up"></h6> <small class="text-muted p-t-30 db">Company Logo</small>
										<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Logo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="com_logo_preview_up">
									</div>
								</div>
							</div>
							<div class="tab-pane  p-20" id="profile_up" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>

								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Phone No</label>
										<input type="text" class="form-control" id="phone_no_up" name="phone_no" placeholder="Phone No">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Email</label>
										<input type="text" class="form-control" id="email_up" name="email" placeholder="Email">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="radio1">Gender: </label>
										<fieldset class="radio">
											<label for="radio1">
												<input type="radio" id="male_up" name="gender" value="Male"> Male
											</label>
											<label>
												<input type="radio" id="female_up" name="gender" value="Female" > Female
											</label>
										</fieldset>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Date Of Birth</label>
										<input type="text" class="form-control" id="date_of_birth_up" name="date_of_birth" placeholder="Date Of Birth" autocomplete="off">
									</div>
									<script type="text/javascript">
										$('#date_of_birth_up').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
											changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
									</script>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Address</label>
										<div class="add_user_frm">
											<textarea type="text" class="form-control" id="address_up" name="address" placeholder="Address"></textarea>
										</div>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Photo</label>
										<div class="custom-file">
											<input type="file" name="photo_file" id="photo_file_up" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="photo_label_up" name="photo_label">Choose Photo (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="photo_preview_up">
											<a class="" style="cursor:pointer" id="remove_photo_file_up"><span>Remove</span></a>
											<input type="hidden" id="photo_file_name" name="photo_file_name">
										</div>
									</div>
								</div>
							</div>

						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_sub_admin_form">
					<button type="button" class="btn btn-primary" id="edit_sub_admin_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_com_edit_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete Admin Modal -->
	<div id="delete_sub_admin" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Admin</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_sub_admin_form">
						<div class="form-group">
							<p>If You Delete Admin, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Admin?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_sub_admin_form">
					<button type="button" class="btn btn-primary" id="delete_sub_admin_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_com_del_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
	<!-- Admin status -->
	<div id="status_sub_admin" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Admin Status</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sts_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sts_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="status_sub_admin_form">
						<div class="form-group">
							<p>Are You Sure You Want To <strong class="st_chng"></strong> Admin?</p>
						</div>
					</div>
					<div class="text-center status_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer status_sub_admin_form">
					<button type="button" class="btn btn-primary" id="status_mark_sub">Yes</button>
					<button type="button" class="btn btn-danger" id="close_mrk_st_btn" data-dismiss="modal">No</button>
				</div>
			</div>
		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>sub_admin.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],company=[],roles=[],id_proofs=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['ad_edit']; ?>";
	var del_add_role = "<?php echo $roles['ad_delete']; ?>";
	var status_add_role = "<?php echo $roles['ad_status']; ?>";
	$(document).ready(function() {
		sub_admin_details();
	});

</script>
