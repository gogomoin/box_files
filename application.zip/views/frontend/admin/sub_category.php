<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">Sub Category</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">Sub Category</li>
						</ol>
					</nav>
				</div>
			</div>

			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['sub_cat_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_sub_category_btn" data-toggle="modal" data-target="#add_sub_category">Add Sub Category </button>
						</div>
					<?php } ?>
					<?php if($roles['sub_cat_import']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="import_sub_category_btn" data-toggle="modal" data-target="#import_sub_category">Import Sub Category </button>
						</div>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Country</th>
								<th>Parent Category</th>
								<th>Sub Category</th>
								<th>Admin</th>
								<th>Created On</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new sub_category -->
	<div id="add_sub_category" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add Sub Category</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_sub_category_form" id="add_sub_category_form" action="#" class="add_sub_category_form">
						<div class="form-group pst_relt">
							<label for="email">Country *</label>
							<div class="add_user_frm">
								<select class="form-control" name="country_id" id="country_id">
									<option value="">Country *</option>
								</select>
							</div>
						</div>
						<div class="form-group pst_relt">
							<label for="email">Parent Category *</label>
							<div class="add_user_frm">
								<select class="form-control" name="category_id" id="category_id">
									<option value="">Parent Category *</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Sub Category Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="sub_category_name" name="sub_category_name" placeholder="Sub Category Name *">
								</div>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_sub_category_form">
					<button type="button" class="btn btn-primary" id="add_sub_category_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_collec_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit sub_category Fields -->
	<div id="edit_sub_category" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit Sub Category</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_sub_category_form" id="edit_sub_category_form" action="#" class="edit_sub_category_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Country *</label>
								<select class="form-control" name="country_id" id="country_id_up">
									<option value="">Country *</option>
								</select>
								<input type="hidden" name="category_id" id="edt_category_id" value="" />
							</div>
						</div>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<label for="email">Parent Category *</label>
								<select class="form-control" name="category_id_up" id="category_id_up">
									<option value="">Parent Category *</option>
								</select>
							</div>
						</div>
						<div class="row">
							<div class="form-group col-sm-12">
								<label for="email">Sub Category Name *</label>
								<div class="add_user_frm">
									<input type="text" class="form-control" id="sub_category_name_up" name="sub_category_name_up" placeholder="Sub Category Name *">
								</div>
							</div>
						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_sub_category_form">
					<button type="button" class="btn btn-primary" id="edit_sub_category_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_collecu_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete sub_category -->
	<div id="delete_sub_category" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete Sub Category</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_sub_category_form">
						<div class="form-group">
							<p>If You Delete Sub Category, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete Sub Category?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_sub_category_form">
					<button type="button" class="btn btn-primary" id="delete_sub_category_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_collecd_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
	<!-- Import Sub Category -->
	<div id="import_sub_category" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Import Sub Category</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="import_sub_category_form" id="import_sub_category_form" action="#" class="import_sub_category_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<select class="form-control" name="country_id_imp" id="country_id_imp">
									<option value="">Select Country *</option>
								</select>
							</div>
						</div>
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<div class="custom-file">
									<input type="file" name="import_sub_category_file" id="import_sub_category_file" class="custom-file-input" accept=".xls">
									<label class="custom-file-label" for="customFile" id="import_label">Choose file (.xls only)</label>
									<input class="gui-input" id="import_uploader" style="display:none" type="text">
								</div>
							</div>
						</div>
						<div class="form-group pst_relt pull-right">
							<div class="add_user_frm">
								<a class="" style="cursor:pointer" id="sample_excel"><i class="fa fa-download"></i> <span>Download Sample Excel Format To Upload Sub Category</span></a>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_sub_category_form">
					<button type="button" class="btn btn-primary" id="import_sub_category_sub">Import</button>
					<button type="button" class="btn btn-danger" id="close_import_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

</div>

<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>sub_category.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],category=[],sub_category_fields=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['sub_cat_edit']; ?>";
	var del_add_role = "<?php echo $roles['sub_cat_delete']; ?>";
	var import_add_fld_role = "<?php echo $roles['sub_cat_import']; ?>";
	$(document).ready(function() {
		sub_category_details();
	});

</script>
