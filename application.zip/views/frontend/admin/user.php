<?php echo $header;
$user_det = $this->session->userdata('user_det');
?>
<?php echo $sideheader;?>
<link href="<?php echo $css_path;?>jquery-ui.css"" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://cdn.materialdesignicons.com/5.0.45/css/materialdesignicons.min.css">
<script src="<?php echo $js_path;?>jquery.min.js"></script>
<script src="<?php echo $js_path;?>jquery-ui.min.js"></script>
<style>
	/*!
 * jQuery ComboTree Plugin 
 * Author:  Erhan FIRAT
 * Mail:    erhanfirat@gmail.com
 * Licensed under the MIT license
 * Version: 1.2.1
 */


:root {
    --ct-bg: #fff;
    --ct-btn-hover: #e8e8e8;
    --ct-btn-active: #ddd;
    --ct-btn-color: #555;
    --ct-border-color: #e1e1e1;
    --ct-border-radius: 5px;
    --ct-tree-hover: #efefef;
    --ct-selection: #418EFF;
    --ct-padding: 8px;
}


.comboTreeWrapper{
	position: relative;
	text-align: left !important;
}

.comboTreeInputWrapper{
	position: relative;
}

.comboTreeArrowBtn {
	position: absolute;
    right: 0px;
    bottom: 0px;
    top: 0px;
    box-sizing: border-box;
    border: 1px solid var(--ct-border-color);
    border-radius: 0 var(--ct-border-radius) var(--ct-border-radius) 0;
    background: var(--ct-border-color);
    cursor: pointer;
    -webkit-user-select: none; /* Safari */
    -moz-user-select: none; /* Firefox */
    -ms-user-select: none; /* IE10+/Edge */
    user-select: none; /* Standard */
}
.comboTreeArrowBtn:hover {
    background: var(--ct-btn-hover);
}
.comboTreeArrowBtn:active {
    background: var(--ct-btn-active);
}
.comboTreeInputBox:focus + .comboTreeArrowBtn {
    color: var(--ct-btn-color);
    border-top: 1px solid var(--ct-selection);
    border-right: 1px solid var(--ct-selection);
    border-bottom: 1px solid var(--ct-selection);
}

.comboTreeArrowBtnImg{
    font-size: 1.25rem;
}

.comboTreeDropDownContainer {
	display: none;
	background: var(--ct-bg);
	border: 1px solid var(--ct-border-color);
	position: absolute;
  width: 100%;
  box-sizing: border-box;
  z-index: 999;
	max-height: 250px;
	overflow-y: auto;
}

.comboTreeDropDownContainer ul{
	padding: 0px;
	margin: 0;
}

.comboTreeDropDownContainer li{
	list-style-type: none;
	padding-left: 15px;
}

.comboTreeDropDownContainer li .selectable{
	cursor: pointer;
}

.comboTreeDropDownContainer li .not-selectable{
	cursor: not-allowed;
}


.comboTreeDropDownContainer li:hover{
	background-color: var(--ct-tree-hover);}
.comboTreeDropDownContainer li:hover ul{
	background-color: var(--ct-bg)}
.comboTreeDropDownContainer li span.comboTreeItemTitle.comboTreeItemHover{
	background-color: var(--ct-selection);
	color: var(--ct-bg);
    border-radius: 2px;
}

span.comboTreeItemTitle{
	display: block;
    padding: 3px var(--ct-padding);
}
.comboTreeDropDownContainer label{
    cursor: pointer;
	width: 100%;
    display: block;
}
.comboTreeDropDownContainer .comboTreeItemTitle input {
	position: relative;
    top: 2px;
	margin: 0px 4px 0px 0px;
}
.comboTreeParentPlus{
    position: relative;
    left: -12px;
    top: 4px;
    width: 4px;
    float: left;
		cursor: pointer;
}


.comboTreeInputBox {
	padding: var(--ct-padding);
    border-radius: var(--ct-border-radius);
    border: 1px solid var(--ct-border-color);
    width: 100%;
    box-sizing: border-box;
    padding-right: 24px;
}
.comboTreeInputBox:focus {
    border: 1px solid var(--ct-selection);
    outline-width: 0;
}


.multiplesFilter{
	width: 100%;
	padding: 5px;
	box-sizing: border-box;
	border-top: none;
	border-left: none;
	border-right: none;
	border-bottom: 1px solid var(--ct-border-color);
}
</style>
<div class="page-wrapper">
	<div class="page-breadcrumb">
		<div class="row">
			<div class="col-5 align-self-center">
				<h4 class="page-title">User</h4>
				<div class="d-flex align-items-center">
					<nav aria-label="breadcrumb">
						<ol class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo $base_url."admin"; ?>">Home</a></li>
							<li class="breadcrumb-item active" aria-current="page">User</li>
						</ol>
					</nav>
				</div>
			</div>
			<div class="col-7 align-self-center">
				<div class="d-flex no-block justify-content-end align-items-center">
					<?php if($roles['u_add']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="add_user_btn" data-toggle="modal" data-target="#add_user">Add User</button>
						</div>
					<?php } ?>
					<?php if($roles['u_import']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="import_user_imp" data-toggle="modal" data-target="#import_user">Import User</button>
						</div>
					<?php } ?>
					<?php if($roles['u_export']==0) {?>
						<div class="button-group">
							<button type="button" class="btn waves-effect waves-light btn-primary" id="export_user_exp" data-toggle="modal" data-target="#export_user">Export User</button>
						</div>
					<?php } ?>
				</div>				
			</div>			
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12">
			<div class="card">
				<div class="card-body">
					<div class="table-responsive m-t-20">
						<table id="cc-table" class="table table-bordered m-b-20" data-page-length='100'>
							<thead>
							<tr class="bg-light">
								<th>S.No.</th>
								<th>Name</th>
								<th>Mobile No</th>
								<th>Photo</th>
								<th>Address</th>
								<th>Category</th>
								<th>Created By</th>
								<th>Created On</th>
								<th>Status</th>
								<th>Actions</th>
							</tr>
							</thead>
							<tbody>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- add new User Modal -->
	<div id="add_user" class="modal fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Add User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="com_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="com_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="add_user_form" id="add_user_form" action="#" class="add_user_form">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#profile" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">User Profile</span></a> </li>
							<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#loc" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Location & Skills</span></a> </li>							
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="profile" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Name *</label>
										<input type="text" class="form-control" id="name" name="name" placeholder="Name *">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Phone No *</label>
										<input type="text" class="form-control" id="phone_no" name="phone_no" placeholder="Phone No *">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="radio1">Gender: </label>
										<fieldset class="radio">
											<label for="radio1">
												<input type="radio" id="male" name="gender" value="Male"> Male
											</label>
											<label>
												<input type="radio" id="female" name="gender" value="Female" > Female
											</label>
										</fieldset>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Date Of Birth</label>
										<input type="text" class="form-control" id="date_of_birth" name="date_of_birth" placeholder="Date Of Birth" autocomplete="off">
									</div>
									<script type="text/javascript">
										$('#date_of_birth').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
											changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
									</script>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Email</label>
										<input type="text" class="form-control" id="email" name="email" placeholder="Email">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Nationality</label>
										<select class="form-control" id="nationality" name="nationality" placeholder="Select Nationality">
										</select>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">House No</label>
										<input type="text" class="form-control" id="house_no" name="house_no" placeholder="House No">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Street Name</label>
										<input type="text" class="form-control" id="street_name" name="street_name" placeholder="Street Name">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Pin Code</label>
										<input type="text" class="form-control" id="pin_code" name="pin_code" placeholder="Pin Code">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">User Photo</label>
										<div class="custom-file">
											<input type="file" name="user_photo_file" id="user_photo_file" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="user_photo_label">Choose Photo (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="user_photo_preview">
											<a class="" style="cursor:pointer" id="remove_user_photo_file"><span>Remove</span></a>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
							</div>
							<div class="tab-pane  p-20" id="loc" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Country</label>
										<select class="form-control" id="country_id" name="country_id" placeholder="Select Country">
										</select>
									</div>
								</div>
								<div class="row">
									<div id="skills" style="display:none">
										<label for="email">Select Skills</label>
										<input type="text" id="multi_category" name="skills" placeholder="Select Skills" autocomplete="off" />
									</div>
								</div>
								<div id="address_fields"></div>
						 	</div>							
						</div>
					</form>
					<div class="text-center com_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_user_form">
					<button type="button" class="btn btn-primary" id="add_user_sub">Add</button>
					<button type="button" class="btn btn-danger" id="close_com_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- edit User Modal -->
	<div id="edit_user" class="modal fade fade bs-example-modal-lg" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Edit User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="edit_user_form" id="edit_user_form" action="#" class="edit_user_form">
						<!-- Nav tabs -->
						<ul class="nav nav-tabs customtab" role="tablist">
							<li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#profile_up" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">User Profile</span></a> </li>
							<li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#loc_up" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Location & Skills</span></a> </li>							
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="profile_up" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Name *</label>
										<input type="text" class="form-control" id="name_up" name="name" placeholder="Name *">
										<input type="hidden" id="user_id" name="user_id">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Phone No *</label>
										<input type="text" class="form-control" id="phone_no_up" name="phone_no" placeholder="Phone No *">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="radio1">Gender: </label>
										<fieldset class="radio">
											<label for="radio1">
												<input type="radio" id="male_up" name="gender" value="Male"> Male
											</label>
											<label>
												<input type="radio" id="female_up" name="gender" value="Female" > Female
											</label>
										</fieldset>
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Date Of Birth</label>
										<input type="text" class="form-control" id="date_of_birth_up" name="date_of_birth" placeholder="Date Of Birth" autocomplete="off">
									</div>
									<script type="text/javascript">
										$('#date_of_birth_up').datepicker({dateFormat: 'dd-mm-yy',changeMonth: true,
											changeYear: true,yearRange: '1930:'+(new Date).getFullYear(),maxDate: 0});
									</script>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Email</label>
										<input type="text" class="form-control" id="email_up" name="email" placeholder="Email">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Nationality</label>
										<select class="form-control" id="nationality_up" name="nationality" placeholder="Select Nationality">
										</select>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">House No</label>
										<input type="text" class="form-control" id="house_no_up" name="house_no" placeholder="House No">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">Street Name</label>
										<input type="text" class="form-control" id="street_name_up" name="street_name" placeholder="Street Name">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Pin Code</label>
										<input type="text" class="form-control" id="pin_code_up" name="pin_code" placeholder="Pin Code">
									</div>
									<div class="form-group col-sm-6">
										<label for="email">User Photo</label>
										<div class="custom-file">
											<input type="file" name="user_photo_file" id="user_photo_file_up" class="custom-file-input" accept="image/*">
											<label class="custom-file-label" for="customFile" id="user_photo_label_up">Choose Photo (Images only)</label>
											<img src="<?php echo $base_url?>assets/images/no_image.png" alt="Photo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="user_photo_preview_up">
											<a class="" style="cursor:pointer" id="remove_user_photo_file_up"><span>Remove</span></a>
											<input type="hidden" id="user_photo_file_name" name="user_photo_file_name">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
							</div>
							<div class="tab-pane  p-20" id="loc_up" role="tabpanel">
								<div class="row">
									<div class="form-group col-sm-6">
									</div>
									<div class="form-group col-sm-6">
									</div>
								</div>
								<div class="row">
									<div class="form-group col-sm-6">
										<label for="email">Country</label>
										<select class="form-control" id="country_id_up" name="country_id" placeholder="Select Country">
										</select>
									</div>
								</div>
								<div class="row">
									<div id="skills_up" style="display:none">
										<label for="email">Select Skills</label>
										<input type="text" id="multi_category_up" name="skills" placeholder="Select Skills" autocomplete="off" />
									</div>
								</div>
								<div id="address_fields_up"></div>
						 	</div>							
						</div>
					</form>
					<div class="text-center edit_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer edit_user_form">
					<button type="button" class="btn btn-primary" id="edit_user_sub">Update</button>
					<button type="button" class="btn btn-danger" id="close_com_edit_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>

	<!-- delete User Modal -->
	<div id="delete_user" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Delete User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">

					<div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="delete_user_form">
						<div class="form-group">
							<p>If You Delete User, Related Information Will Be Removed</p>
							<p>Are You Sure You Want To Delete User?</p>
						</div>
					</div>
					<div class="text-center delete_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer delete_user_form">
					<button type="button" class="btn btn-primary" id="delete_user_sub">Delete</button>
					<button type="button" class="btn btn-danger" id="close_com_del_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>

		</div>
	</div>
	<!-- User status -->
	<div id="status_user" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">User Status</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="sts_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="sts_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<div class="status_user_form">
						<div class="form-group">
							<p>Are You Sure You Want To <strong class="st_chng"></strong> User?</p>
						</div>
					</div>
					<div class="text-center status_mrk_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer status_user_form">
					<button type="button" class="btn btn-primary" id="status_mark_sub">Yes</button>
					<button type="button" class="btn btn-danger" id="close_mrk_st_btn" data-dismiss="modal">No</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Import User -->
	<div id="import_user" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Import User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="import_user_form" id="import_user_form" action="#" class="import_user_form">
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<select class="form-control" name="country_id_imp" id="country_id_imp">
									<option value="">Select Country *</option>
								</select>
							</div>
						</div>
						 
						<div class="form-group pst_relt">
							<div class="add_user_frm">
								<div class="custom-file">
									<input type="file" name="import_user_file" id="import_user_file" class="custom-file-input" accept=".xls">
									<label class="custom-file-label" for="customFile" id="import_label">Choose file (.xls only)</label>
									<input class="gui-input" id="import_uploader" style="display:none" type="text">
								</div>
							</div>
						</div>
						<div class="form-group pst_relt pull-right">
							<div class="add_user_frm">
								<a class="" style="cursor:pointer" id="sample_excel"><i class="fa fa-download"></i> <span>Download Sample Excel Format To Upload User</span></a>
							</div>
						</div>
					</form>
					<div class="text-center add_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_user_form">
					<button type="button" class="btn btn-primary" id="import_user_sub">Import</button>
					<button type="button" class="btn btn-danger" id="close_import_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
	<!-- Export User -->
	<div id="export_user" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">Export User</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body">
					<div class="alert alert-danger errYxt" id="exp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
					<div class="alert alert-success errYxt" id="exp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
					<form name="export_user_form" id="export_user_form" action="#" class="export_user_form">
						<div class="form-group pst_relt">
						<label for="email">Select Country *</label>
							<div class="add_user_frm">
								<select class="form-control" name="country_id" id="country_id_exp">
									<option value="">Select Country *</option>
								</select>
							</div>
						</div>
						<div class="form-group pst_relt">
							<label for="email">Category</label>
							<div class="add_user_frm">
								<select class="form-control" name="category_id" id="category_id_exp">
									<option value="">Category *</option>
								</select>
							</div>
						</div>
						<div id="address_fields_exp"></div>
					</form>
					<div class="text-center exp_col_loader" style="display:none">
						<div class="loader"></div>
					</div>
				</div>
				<div class="modal-footer add_user_form">
					<button type="button" class="btn btn-primary" id="export_user_btn">Export</button>
					<button type="button" class="btn btn-danger" id="close_exp_btn" data-dismiss="modal">Cancel</button>
				</div>
			</div>
		</div>
	</div>
</div>

<?php echo $footer; ?>
<script src="<?php echo $js_path;?>comboTreePlugin.js"></script>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>user.js"></script>
<script type="text/javascript">
	var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,category_list,category_list_up,country=[],categories=[],categories_exp=[],address_fields_arr=[],address_arr=[],address_fields_arr_exp=[],address_arr_exp=[],nationality=[],id="<?php  echo $user_det['id'];?>";
	var edit_add_role = "<?php echo $roles['u_edit']; ?>";
	var del_add_role = "<?php echo $roles['u_delete']; ?>";
	var status_add_role = "<?php echo $roles['u_status']; ?>";
	$(document).ready(function() {
		user_details();
	});

</script>
