<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(8) {
    text-align: center;
}
</style>
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3">BOX BUILDS</h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary">DASHBOARD</a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">SYSTEM ADMINISTRATION</li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">BOX BUILDS</li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                </svg></span> BOX BUILDS
                            </h3>   
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <!-- <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_builds_box_btn">CREATE <i class="las la-plus fs-5"></i></button>
                        <span>&nbsp;</span> -->
                        <!--begin::Toolbar-->
                        <!-- <div class="card-toolbar">
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_builds_box" data-toggle="modal">DELETE <i class="las la-trash-alt fs-3"></i></button>
                        </div> -->
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th></th>
                                <th data-priority="2" class="fw-bolder"> Build No </th>
								<th data-priority="4" class="fw-bolder"> Item No </th>
								<th data-priority="5" class="fw-bolder"> Build Date </th>
                                <th class="fw-bolder"> Description </th>
                                <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> Actions </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
           
            
            <!--end::Modals-->
        </div>
        <!--end::Post-->    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>builds_box.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,selected=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",term_fld="",start_date_fld="",end_date_fld="",role_details=[];
$(document).ready(function() {
	builds_box_details();
});
</script>  
