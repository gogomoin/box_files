<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(8) {
    text-align: center;
}

</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3">BUILDS</h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary">DASHBOARD</a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">SYSTEM ADMINISTRATION</li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">BUILDS</li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                </svg></span> BUILDS
                            </h3>   
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th></th>
                                <th data-priority="2" class="fw-bolder"> Build No </th>
								<th data-priority="4" class="fw-bolder"> Item No </th>
								<th data-priority="5" class="fw-bolder"> Build Date </th>
                                <th data-priority="6" class="fw-bolder"> Release Date </th>
                                <th class="fw-bolder"> Description </th>
                                <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> Actions </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            
            <!--begin::Modals-->
            <div class="modal fade" id="deploy_builds_ps" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder">Deploy Build</h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="deploy_builds_ps_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <input type="hidden" id="deploy_token_id" name="deploy_token_id" />
                                        <label class="fs-6">Are You Sure You Want To Deploy Build To PS Test Environment?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="deploy_builds_ps_sub" class="btn btn-primary"><i class="las la-rocket fs-5"></i>DEPLOY
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i>CANCEL</button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>

            <div class="modal fade" id="deploy_live_builds_ps" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder">Deploy Build Live</h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_live_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_live_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="deploy_live_builds_ps_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <input type="hidden" id="deploy_live_token_id" name="deploy_live_token_id" />
                                        <label class="fs-6">Are You Sure You Want To Deploy Build To Live Instances?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="deploy_live_builds_ps_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i>DEPLOY LIVE
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_live_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i>CANCEL</button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            
            <!--end::Modals-->
        </div>
        <!--end::Post-->    
    <!--end::Post-->
<?php echo $footer; ?>
<script src="<?php echo $js_path;?>builds_ps.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,selected=[],status_fld="",del_fld="",term_fld="",start_date_fld="",end_date_fld="",role_details=[];

$(document).ready(function() { 
    builds_ps_details();
});
</script>  
