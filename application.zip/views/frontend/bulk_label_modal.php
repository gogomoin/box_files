       <style>
           #system_bulk_label_table tr th:nth-child(3) {
                min-width: 250px;
            }
            #system_bulk_label_table tr th:nth-child(5) {
                min-width: 250px;
            }
           </style>
       
       <!--begin::Modal - New Message Module-->
        <div class="modal fade" id="bulk_label_edit_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $all_page_label_details[0]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-7 border" id="system_bulk_label_container">
                            <a name="system_bulk_label_tag"></a>
                            <form name="system_bulk_label_form" id="system_bulk_label_form" class="system_bulk_label_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.06 24"><path d="M8,5.6c.11-1.09,0-2.15.06-3.23C8,2,6.69,2,6.28,1.85c-.1,1.75.16.62.57,1.57-.32.91-.57-.11-.48,1.59L6.7,5v6.71H5.52V5l.32,0c.1-1.75-.17-.66-.47-1.6.47-1,.64.21.56-1.65L4.62,1.5v0C7.2,1,9.78.32,12.36,0c2.48.54,5,.91,7.47,1.53l-3.41.65v3.3c0,.08,0,.14.1.18.71.34.45,1.57-.14,1.92-.28,0-.32.27-.4.48a7.7,7.7,0,0,1-1.5,2.44,1.32,1.32,0,0,0-.21,1c-.34,1-1.66,1.12-2.56,1-2.28-.62-.94-1.1-1.81-2.15a6.54,6.54,0,0,1-1.48-2.5.32.32,0,0,0-.25-.25c-.8-.2-1.09-1.87-.13-2M6.83,16.18A1,1,0,0,0,5.7,17a.76.76,0,0,0,0,.3q.52,2.85,1.06,5.7a1,1,0,0,0,1,.84c10.88-.53,9.05,2.57,10.57-6.42a1,1,0,0,0-1.09-1.27H6.83M21,16c-.94-2.15-3.49-3.07-5.54-3.87-.22,1-.47,1.9-.73,2.83,4.13.08,5.53-.54,4.37,4.37a2.53,2.53,0,0,0,2-3A1.89,1.89,0,0,0,21,16M9.66,15c-.28-.93-.52-1.87-.74-2.83-2.83.8-8.8,4.58-4.06,7.09-1.38-5.19.9-4,4.8-4.26m2.43-2.08c-1.48.31-1.44,1.91,0,2.13,1.7-.1,1.5-1.93,0-2.13" transform="translate(-3.09 0.02)" style="fill:#1b1819"/></svg></span> <?php echo $all_page_label_details[159]['name']; ?></h4>
                                </div>
                                <!--end::Heading-->
                                
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="system_bulk_label_filter">
                                <div class="alert alert-danger errYxt" id="system_bulk_label_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="system_bulk_label_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <input type="hidden" id="system_bulk_label_id" />
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class="cct-scrool mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="system_bulk_label_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="system_bulk_label_table_check_all" class="group-checkable" name="system_bulk_label_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $all_page_label_details[18]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $all_page_label_details[19]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $all_page_label_details[16]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $all_page_label_details[17]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $all_page_label_details[20]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="system_bulk_label_sub_btn"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $all_page_label_details[21]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - New Message Module-->
<script>
    var all_page_labels=<?php echo json_encode($all_page_label_details); ?>;
</script>
      

        

        