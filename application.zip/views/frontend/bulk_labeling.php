<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>

 <style>
     .actionBtns_table tr td:nth-child(3) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(4) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(5) {
    text-align: center;
}
#section_1_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_1_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_2_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_2_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_3_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_3_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_4_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_4_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_5_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_5_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_6_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_6_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_7_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_7_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_8_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_8_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_9_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_9_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_10_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_10_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_11_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_11_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_12_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_12_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_13_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_13_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_14_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_14_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_15_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_15_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_16_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_16_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_17_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_17_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_18_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_18_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_19_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_19_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_20_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_20_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_21_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_21_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_22_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_22_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_23_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_23_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_24_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_24_table tr th:nth-child(5) {
    min-width: 250px;
}
#section_28_table tr th:nth-child(3) {
    min-width: 250px;
}
#section_28_table tr th:nth-child(5) {
    min-width: 250px;
}
.module_css tr td:nth-child(2) {
    text-align: center;
}
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[2]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(333,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="bulk_labeling_table_id"></a>
            <div class="card-header hd-col-2" id="section_0_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[3]['name']; ?></h3>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="section_0_filter">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="lang_fld" name="lang_fld" data-hide-search="true">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="bulk_labeling_filter" name="bulk_labeling_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[5]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="bulk_labeling_reset" name="bulk_labeling_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[6]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[7]['name']; ?></h3>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th class="fw-bolder"> <?php echo $label_details[8]['name']; ?> </th>
                                <th class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[10]['name']; ?> </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table module_css">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="edit_module_create_id" style="display:none;">
                
                    <a name="module_create_id"></a>
                    <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                    <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                        <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                    </div>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[11]['name']; ?> <span id="module_name"></span> <?php echo $label_details[12]['name']; ?>
                            </h3>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body px-8 pb-7 pt-2" id="edit_fields">
                        <!--begin::Compact form-->
                        <div class="d-flex align-items-center">
                            <!--begin::Col-->
                            <div class="col-xxl-12">
                                <!--begin::Row-->
                                <div class="row g-8">
                                    <!--begin::Col-->
                                    <div class="col-lg-3 w-md-200px">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                        <!--begin::Select-->
                                        <select class="form-select form-select-solid border" data-control="select2" id="lang_edit_fld" name="lang_fld" data-hide-search="true">
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <!--end::Col-->
                                    <div class="col-lg-4 mt-16 w-md-250px">
                                        <!--end::Input group-->
                                        <!--begin:Action-->
                                        <div class="fltl me-3">
                                            <button type="button" id="bulk_labeling_edit_filter" name="bulk_labeling_edit_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                <i class="las la-filter"></i>
                                                <!--end::Svg Icon--><?php echo $label_details[14]['name']; ?>
                                            </button>
                                        </div>
                                    </div>
                                    <!--end::Col-->
                                </div>
                                <!--end::Row-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Input group-->

                            <!--end:Action-->
                        </div>
                        <!--end::Compact form-->
                    </div>
                    <!--end::Card body-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="card mb-7 border" id="section_1_container">
                            <a name="section_1_tag"></a>
                            <form name="section_1_form" id="section_1_form" class="section_1_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[15]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                                
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_1_filter">
                                <div class="alert alert-danger errYxt" id="section_1_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_1_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_1_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_1_table_check_all" class="group-checkable" name="section_1_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[18]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[19]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[16]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[17]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[20]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_1"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[21]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_2_container">
                            <a name="section_2_tag"></a>
                            <form name="section_2_form" id="section_2_form" class="section_2_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="23.991" height="24" viewBox="0 0 23.991 24">
                                    <path id="Path_19" data-name="Path 19" d="M23.962,2.419A2.725,2.725,0,0,0,21.441.027C21.228-.052,2.956.07,2.74.02A2.733,2.733,0,0,0,.053,2.283c-.117.408,0,18.53-.039,18.981a2.726,2.726,0,0,0,2.3,2.692c.386.094,18.523,0,18.946.033a2.733,2.733,0,0,0,2.694-2.311,2.821,2.821,0,0,0,.031-.416c-.041-.387.054-18.467-.02-18.844M16.506,6.033h5.971V10.5H16.506Zm0,5.974h5.951v4.479H16.505ZM1.52,6.023H7.487v4.483H1.52Zm5.962,10.47H1.544V12.02H7.482Zm.01,6H5.5c-1.325-.112-3.764.561-3.974-1.33-.044-1.042-.012-2.086-.012-3.152H7.492Zm7.486-.016H9.008V18.031h5.97Zm.011-5.984H9.008V12.009h5.98Zm0-6h-6V6.037h6Zm7.463,10.771a1.385,1.385,0,0,1-1.35,1.212c-1.522.025-3.045.008-4.616.008V18.032h5.983c0,1.06.046,2.154-.017,3.242" transform="translate(0 0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[22]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_2_filter">
                                <div class="alert alert-danger errYxt" id="section_2_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_2_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_2_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_2_table_check_all" class="group-checkable" name="section_2_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[25]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[26]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[23]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[24]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[27]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_2"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[28]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_3_container">
                            <a name="section_3_tag"></a>
                            <form name="section_3_form" id="section_3_form" class="section_3_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.466" height="24" viewBox="0 0 24.466 24">
                                    <path id="create_section" data-name="create section" d="M13.36,21.438H1.6c-1.126,0-1.595-.466-1.6-1.6Q0,12.049,0,4.255v-.38H21.671v8.888c-2.7-1.068-5.2-.759-7.248,1.376s-2.248,4.618-1.062,7.3m.062-2.987a5.521,5.521,0,1,0,5.551-5.482,5.556,5.556,0,0,0-5.551,5.482m5.151-2.938h.717v2.566H21.9v.752H19.323v2.61H18.58V18.858H16.017a2.8,2.8,0,0,1-.049-.758h2.605Zm3.12-13.988A1.347,1.347,0,0,0,20.151,0H5.18C3.919,0,2.657,0,1.4,0A1.243,1.243,0,0,0,.028,1.179c-.052.581-.01,1.17-.01,1.775H21.694c0-.5,0-.964,0-1.429M3.6,1.489A.744.744,0,0,1,4.325.752a.783.783,0,0,1,.75.769.75.75,0,0,1-.762.7A.709.709,0,0,1,3.6,1.489M1.256,1.5a.772.772,0,0,1,.721-.75.758.758,0,0,1,.743.765.706.706,0,0,1-.737.708A.72.72,0,0,1,1.256,1.5" transform="translate(0 0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[29]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                                
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_3_filter">
                                <div class="alert alert-danger errYxt" id="section_3_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_3_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_3_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_3_table_check_all" class="group-checkable" name="section_3_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[32]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[33]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[30]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[31]['name']; ?> </th>
                                                       
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[34]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_3"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[35]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_4_container">
                            <a name="section_4_tag"></a>
                            <form name="section_4_form" id="section_4_form" class="section_4_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.445" height="24" viewBox="0 0 24.445 24">
                                    <path id="edit_section" data-name="edit section" d="M13,20.853H1.553C.458,20.854,0,20.4,0,19.3Q0,11.721,0,4.14V3.77H21.08v8.645a6,6,0,0,0-7.05,1.339c-1.983,2.067-2.187,4.492-1.033,7.1M21.1,1.483A1.311,1.311,0,0,0,19.6,0H5.039C3.812,0,2.586,0,1.359,0A1.209,1.209,0,0,0,.028,1.147c-.05.565-.01,1.139-.01,1.726H21.1c0-.486,0-.938,0-1.39M1.931,2.163a.7.7,0,0,1-.708-.7.75.75,0,0,1,.7-.73.736.736,0,0,1,.723.743.685.685,0,0,1-.716.688m2.265,0a.691.691,0,0,1-.7-.712A.724.724,0,0,1,4.208.732a.76.76,0,0,1,.73.748.73.73,0,0,1-.741.682M24.445,18.494a5.515,5.515,0,1,1-5.487-5.522,5.517,5.517,0,0,1,5.487,5.522m-3.581-.686-1.246-1.24a.235.235,0,0,0-.052.031l-3.552,3.55c-.037.037-.082.071-.082.127,0,.4,0,.794,0,1.2.376,0,.723-.005,1.071,0a.387.387,0,0,0,.31-.129q.992-1,1.994-2,.777-.775,1.557-1.549m.382-.377c.186-.191.38-.384.567-.583a.324.324,0,0,0,.008-.491q-.376-.392-.768-.768a.309.309,0,0,0-.458-.013c-.213.192-.415.4-.621.6l1.272,1.257" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[36]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                                
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_4_filter">
                                <div class="alert alert-danger errYxt" id="section_4_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_4_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_4_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_4_table_check_all" class="group-checkable" name="section_4_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[39]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[40]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[37]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[38]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[41]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_4"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[42]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_5_container">
                            <a name="section_5_tag"></a>
                            <form name="section_5_form" id="section_5_form" class="section_5_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.51" height="24" viewBox="0 0 24.51 24">
                                    <path id="delete_section" data-name="delete section" d="M13.372,21.455H1.6c-1.126,0-1.6-.466-1.6-1.6q0-7.8,0-15.6v-.38H21.689v8.9c-2.705-1.069-5.2-.759-7.254,1.378s-2.25,4.621-1.063,7.3m8.34-19.929A1.349,1.349,0,0,0,20.167,0H5.185C3.923,0,2.661,0,1.4,0A1.244,1.244,0,0,0,.029,1.18c-.052.581-.01,1.172-.01,1.776H21.712c0-.5,0-.965,0-1.43m-19.725.7A.72.72,0,0,1,1.258,1.5.772.772,0,0,1,1.981.752a.757.757,0,0,1,.743.765.705.705,0,0,1-.737.708m2.331,0A.711.711,0,0,1,3.6,1.492.745.745,0,0,1,4.329.753a.783.783,0,0,1,.751.77.751.751,0,0,1-.762.7M24.511,18.575a5.44,5.44,0,1,1-5.441-5.456,5.455,5.455,0,0,1,5.441,5.456m-5.463.613c.081.072.138.12.191.172.421.42.84.841,1.261,1.26.255.253.532.282.724.08s.155-.457-.092-.7c-.4-.4-.806-.8-1.2-1.21-.073-.074-.18-.125-.2-.266.463-.46.932-.925,1.4-1.391.257-.255.29-.528.09-.723s-.463-.155-.723.1c-.314.313-.626.629-.942.94a3.726,3.726,0,0,1-.5.473c-.245-.25-.482-.5-.724-.738-.266-.266-.527-.538-.807-.79a.427.427,0,0,0-.61.03.45.45,0,0,0,0,.6c.064.077.139.145.21.216l1.367,1.355a3.713,3.713,0,0,0-.322.251c-.406.4-.81.8-1.207,1.208a.439.439,0,0,0,.076.736.468.468,0,0,0,.568-.13c.475-.484.952-.964,1.449-1.467" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[43]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_5_filter">
                                <div class="alert alert-danger errYxt" id="section_5_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_5_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_5_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_5_table_check_all" class="group-checkable" name="section_5_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[46]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[47]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[44]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[45]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[48]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_5"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[49]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_6_container">
                            <a name="section_6_tag"></a>
                            <form name="section_6_form" id="section_6_form" class="section_6_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="20.13" height="24" viewBox="0 0 20.13 24">
                                    <path id="status_section" data-name="status section" d="M18.971,7.555c-.7-.1-1.4-.215-2.094-.32a.089.089,0,0,1-.084-.074,6.843,6.843,0,0,0-.444-1.056.108.108,0,0,1,.014-.136c.2-.262.406-.526.608-.789s.411-.53.611-.8a.449.449,0,0,0,0-.583q-.07-.095-.145-.186a17.126,17.126,0,0,0-1.348-1.392c-.157-.15-.315-.3-.477-.445A.443.443,0,0,0,15,1.755c-.551.417-1.1.832-1.655,1.25a.1.1,0,0,1-.128.014,6.685,6.685,0,0,0-.96-.394.1.1,0,0,1-.08-.092c-.108-.719-.218-1.438-.326-2.157a.4.4,0,0,0-.356-.364A1.037,1.037,0,0,0,11.332,0H9.139C9,0,8.867,0,8.731,0a.415.415,0,0,0-.455.365,11.969,11.969,0,0,0-.216,1.22c-.047.337-.089.675-.134,1.013a7.2,7.2,0,0,0-1.1.462l-1-.778c-.231-.179-.462-.359-.7-.536a.41.41,0,0,0-.519-.021c-.09.061-.181.121-.265.188a12.854,12.854,0,0,0-1.11,1.054,7.875,7.875,0,0,0-.723.823.42.42,0,0,0,.016.618c.426.518.843,1.042,1.234,1.586a.1.1,0,0,1,.01.127,5.551,5.551,0,0,0-.419.988.1.1,0,0,1-.093.078L1.161,7.5a.454.454,0,0,0-.421.487c0,.351,0,.7,0,1.051q0,.789,0,1.577a.435.435,0,0,0,.371.472l.51.074,1.621.239c.043.006.074.014.09.068a5.705,5.705,0,0,0,.453,1.091.082.082,0,0,1-.009.1c-.113.145-.222.294-.334.439-.3.39-.613.77-.9,1.17a.459.459,0,0,0,.009.593c.1.129.2.256.312.377A22.94,22.94,0,0,0,4.52,16.868a.444.444,0,0,0,.628.026q.824-.629,1.651-1.255a.076.076,0,0,1,.1-.016,6.984,6.984,0,0,0,.992.409.082.082,0,0,1,.065.074c.107.713.218,1.426.324,2.139a.425.425,0,0,0,.455.4H11.4a.406.406,0,0,0,.446-.35,19.369,19.369,0,0,0,.34-2.163.113.113,0,0,1,.089-.113,5.814,5.814,0,0,0,.933-.388.141.141,0,0,1,.181.019q.774.613,1.554,1.218a.459.459,0,0,0,.613.031,1.625,1.625,0,0,0,.177-.126,13.579,13.579,0,0,0,1.923-1.965.4.4,0,0,0,.036-.458.82.82,0,0,0-.094-.133c-.419-.519-.839-1.037-1.228-1.58-.025-.034-.048-.061-.021-.111a6.908,6.908,0,0,0,.426-1,.093.093,0,0,1,.088-.072c.126-.015.251-.036.376-.055.573-.087,1.145-.177,1.718-.26a.452.452,0,0,0,.428-.479q0-1.319,0-2.638a.441.441,0,0,0-.418-.476m-4.6,2.374L12.8,8.27l.715-.2a3.844,3.844,0,0,0-2.139-2.329,3.921,3.921,0,1,0,1.936,5.34c.024-.047.044-.1.067-.144.11-.24.292-.362.542-.245s.265.332.157.572a4.641,4.641,0,0,1-1.261,1.666,4.7,4.7,0,1,1,1.328-5.372c.044.108.092.214.143.334l.739-.168-.65,2.209M10.045,24H.8c-.625,0-.8-.173-.8-.8,0-.459-.006-.918,0-1.377a.582.582,0,0,1,.633-.633c.164-.006.328,0,.492,0q9.079,0,18.159-.006c.518,0,.891.239.837.834-.037.412-.006.83-.007,1.245,0,.532-.2.733-.731.733H10.045m-5.567-.795h2.71V21.977H4.478ZM10.8,21.99H8.089v1.227H10.8Zm-7.214-.005H.867V23.21H3.585Z" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[50]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                              
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_6_filter">
                                <div class="alert alert-danger errYxt" id="section_6_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_6_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_6_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_6_table_check_all" class="group-checkable" name="section_6_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[53]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[54]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[51]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[52]['name']; ?> </th>
                                                       
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[55]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_6"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[56]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_7_container">
                            <a name="section_7_tag"></a>
                            <form name="section_7_form" id="section_7_form" class="section_7_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="22.898" height="24" viewBox="0 0 22.898 24">
                                    <path id="Import_Section" data-name="Import Section" d="M7.8,7.815v2.224H4.5l6.828,7.51,7.074-7.487H15.146V7.811H15.6a5.075,5.075,0,0,1,.483-1.547,2.072,2.072,0,0,1,2.029-1.246c1.041.03,2.084.005,3.125.007A1.579,1.579,0,0,1,22.9,6.689q0,5.26,0,10.519c0,1.19-.007,2.381-.012,3.571A3.157,3.157,0,0,1,19.677,24Q11.444,24,3.211,24A3.152,3.152,0,0,1,0,20.781Q0,15.94,0,11.1A3.164,3.164,0,0,1,3.286,7.815c1.5,0,2.993,0,4.517,0m6.209.222c0-2.25,0-1.152,0-3.4A2.269,2.269,0,0,1,16.886,2.3a2.493,2.493,0,0,1,1.456,1.059.241.241,0,0,0-.016-.229,4.579,4.579,0,0,0-1-1.623,4.784,4.784,0,0,0-5.3-1.148,4.806,4.806,0,0,0-3.1,4.481c0,3.1,0,2.844,0,5.94a.828.828,0,0,1-.038.4H7.046l4.3,4.731,4.481-4.746H14.012c0-1.062,0-2.093,0-3.124" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[125]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_7_filter">
                                <div class="alert alert-danger errYxt" id="section_7_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_7_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_7_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_7_table_check_all" class="group-checkable" name="section_7_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[121]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[122]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[119]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[120]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[123]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_7"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[124]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_8_container">
                            <a name="section_8_tag"></a>
                            <form name="section_8_form" id="section_8_form" class="section_8_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.284" height="24" viewBox="0 0 24.284 24">
                                    <path id="Restore_section" data-name="Restore section" d="M22.555,0H5.8C4.386,0,2.978,0,1.566,0A1.392,1.392,0,0,0,.035,1.321C-.026,1.972.022,2.632.022,3.305H24.284v-1.6A1.509,1.509,0,0,0,22.555,0M2.222,2.487a.8.8,0,0,1-.814-.805.862.862,0,0,1,.809-.84.85.85,0,0,1,.831.853.786.786,0,0,1-.827.792m2.609,0a.791.791,0,0,1-.8-.818A.835.835,0,0,1,4.844.842a.877.877,0,0,1,.84.862.839.839,0,0,1-.853.783M0,4.339V22.213C0,23.476.528,24,1.786,24h20.7c1.258,0,1.782-.524,1.782-1.786q.007-8.724,0-17.448V4.339ZM18.811,15.817A7.178,7.178,0,0,1,13.5,21.276,7.324,7.324,0,0,1,9.085,7.331,7.12,7.12,0,0,1,14.1,7.282a.2.2,0,0,0,.264-.075c.348-.44.7-.875,1.056-1.315.066-.084.128-.18.255-.145A.308.308,0,0,1,15.89,6c.141.5.277,1,.422,1.5l.95,3.326a.476.476,0,0,1-.515.651c-1.192-.075-2.389-.158-3.585-.233-.484-.035-.972-.057-1.456-.088a.271.271,0,0,1-.268-.132c-.062-.119,0-.207.07-.3.4-.488.8-.985,1.21-1.491A5.07,5.07,0,1,0,16.752,14.2h2.239a6.24,6.24,0,0,1-.18,1.619" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[57]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_8_filter">
                                <div class="alert alert-danger errYxt" id="section_8_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_8_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_8_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_8_table_check_all" class="group-checkable" name="section_8_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[60]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[61]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[58]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[59]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[62]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_8"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[63]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_9_container">
                            <a name="section_9_tag"></a>
                            <form name="section_9_form" id="section_9_form" class="section_9_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                    <path id="standard_section" data-name="standard section" d="M11.307,0h.533A1.42,1.42,0,0,1,12.8,1.309c.055.508.164,1.01.252,1.535a13.934,13.934,0,0,1,2.362.651l.841-1.181a1.313,1.313,0,0,1,2.118-.38q.815.55,1.607,1.136a1.109,1.109,0,0,1,.294,1.743c-.342.512-.7,1.016-1.046,1.527a11.7,11.7,0,0,1,1.279,2.073c.521-.089.994-.162,1.464-.25a1.2,1.2,0,0,1,1.61,1.123c.126.712.278,1.419.418,2.128v.533a1.481,1.481,0,0,1-1.33.876c-.508.046-1.008.176-1.507.268a12.258,12.258,0,0,1-.551,2.071.319.319,0,0,0,.16.469c.379.228.741.483,1.1.742a1.2,1.2,0,0,1,.325,1.8q-.6.879-1.219,1.742a1.156,1.156,0,0,1-1.823.333c-.5-.339-.988-.686-1.463-1.017-.34.221-.667.4-.959.632-.359.28-.993.293-1.11.715a3.42,3.42,0,0,0,.192,1.351c.181,1.015-.163,1.466-1.186,1.653A11.532,11.532,0,0,0,12.587,24h-.64a1.714,1.714,0,0,1-.737-1.039c-.061-.456-.18-.906-.213-1.362a.5.5,0,0,0-.493-.546,8.956,8.956,0,0,1-1.953-.544c-.323.455-.634.9-.956,1.344a1.2,1.2,0,0,1-1.8.324c-.6-.409-1.191-.828-1.78-1.252A1.105,1.105,0,0,1,3.7,19.2c.346-.511.7-1.014,1.055-1.523a12.1,12.1,0,0,1-1.271-2.1c-.526.092-1.014.17-1.5.263a1.193,1.193,0,0,1-1.564-1A5.433,5.433,0,0,0,0,13.333V12.16a1.293,1.293,0,0,1,1.281-.982c.421-.033.836-.143,1.256-.208.221-.034.316-.124.358-.367a7.658,7.658,0,0,1,.479-1.788c.107-.244,0-.346-.178-.468-.4-.265-.79-.539-1.171-.827a1.079,1.079,0,0,1-.3-1.584c.45-.678.917-1.347,1.407-2A1.075,1.075,0,0,1,4.721,3.7c.529.352,1.049.717,1.585,1.085A10.457,10.457,0,0,1,8.4,3.524c-.088-.494-.166-.963-.256-1.43C7.948,1.091,8.306.6,9.317.415A9.554,9.554,0,0,0,11.307,0M4.616,11.963A7.383,7.383,0,1,0,11.93,4.619a7.42,7.42,0,0,0-7.314,7.344m5.01-1.743c-.214-.207-.4-.25-.628-.008-.412.441-.838.868-1.261,1.3a.4.4,0,0,0-.021.644q1.589,1.573,3.175,3.15a.418.418,0,0,0,.682.017q2.328-2.3,4.665-4.6a.493.493,0,0,0,.015-.785q-.514-.54-1.035-1.073c-.478-.489-.545-.48-1.023-.015-.978.952-1.967,1.894-2.991,2.878-.5-.478-1.042-.99-1.577-1.509" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[64]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_9_filter">
                                <div class="alert alert-danger errYxt" id="section_9_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_9_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_9_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_9_table_check_all" class="group-checkable" name="section_9_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[67]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[68]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[65]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[66]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[69]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_9"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[70]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_10_container">
                            <a name="section_10_tag"></a>
                            <form name="section_10_form" id="section_10_form" class="section_10_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.001" height="24" viewBox="0 0 24.001 24">
                                    <path id="Individual_Section" data-name="Individual Section" d="M0,22.9V1.085A1.085,1.085,0,0,1,1.085,0H9.943a1.085,1.085,0,0,1,1.085,1.085V22.9a1.085,1.085,0,0,1-1.085,1.084H1.085A1.084,1.084,0,0,1,0,22.9M24,4.477V1.545A1.545,1.545,0,0,0,22.456,0H14.493a1.545,1.545,0,0,0-1.545,1.545V4.477a1.546,1.546,0,0,0,1.545,1.546h7.963A1.546,1.546,0,0,0,24,4.477m0,9V10.544A1.545,1.545,0,0,0,22.456,9H14.493a1.545,1.545,0,0,0-1.545,1.545v2.932a1.545,1.545,0,0,0,1.545,1.545h7.963A1.545,1.545,0,0,0,24,13.477m0,8.978V19.522a1.545,1.545,0,0,0-1.545-1.545H14.493a1.545,1.545,0,0,0-1.545,1.545v2.932A1.545,1.545,0,0,0,14.493,24h7.963A1.545,1.545,0,0,0,24,22.455" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[71]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_10_filter">
                                <div class="alert alert-danger errYxt" id="section_10_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_10_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_10_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_10_table_check_all" class="group-checkable" name="section_10_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[74]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[75]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[72]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[73]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[76]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_10"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[77]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_11_container">
                            <a name="section_11_tag"></a>
                            <form name="section_11_form" id="section_11_form" class="section_11_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="28.459" height="24" viewBox="0 0 28.459 24">
                                    <path id="Default_Section" data-name="Default Section" d="M12.2,10.632a3.7,3.7,0,1,0,3.731,3.688A3.718,3.718,0,0,0,12.2,10.632m2.155,3.057q-1.169,1.149-2.335,2.3a.21.21,0,0,1-.341-.008q-.794-.79-1.59-1.577a.2.2,0,0,1,.011-.323c.212-.215.426-.429.631-.65.114-.121.208-.1.314,0,.267.259.539.515.79.756.513-.494,1.008-.964,1.5-1.442.239-.232.273-.237.513.008q.26.267.517.536a.247.247,0,0,1-.007.393M12.2,10.632a3.7,3.7,0,1,0,3.731,3.688A3.718,3.718,0,0,0,12.2,10.632m2.155,3.057q-1.169,1.149-2.335,2.3a.21.21,0,0,1-.341-.008q-.794-.79-1.59-1.577a.2.2,0,0,1,.011-.323c.212-.215.426-.429.631-.65.114-.121.208-.1.314,0,.267.259.539.515.79.756.513-.494,1.008-.964,1.5-1.442.239-.232.273-.237.513.008q.26.267.517.536a.247.247,0,0,1-.007.393m9.387,5.934h0V17.86c0-.264,0-.472,0-.682q-.007-4.78,0-9.561a2.676,2.676,0,0,0-2.984-2.958H4.41v0h0c-.621,0-1.165-.008-1.708,0A2.639,2.639,0,0,0,.006,7.384q-.012,6.948,0,13.9A2.618,2.618,0,0,0,2.75,24q9.116.005,18.235,0a2.612,2.612,0,0,0,2.758-2.7c.013-.54,0-1.081,0-1.674m-5.5-5.324a.743.743,0,0,1-.666.439c-.253.023-.5.088-.754.134a6.1,6.1,0,0,1-.276,1.037.16.16,0,0,0,.08.235c.19.114.372.242.551.371a.6.6,0,0,1,.162.9q-.3.44-.61.872a.579.579,0,0,1-.913.167c-.249-.169-.494-.344-.732-.508-.17.11-.333.2-.48.316-.18.141-.5.147-.556.358a1.737,1.737,0,0,0,.1.677c.092.508-.081.734-.592.827a5.732,5.732,0,0,0-1.023.208h-.32a.862.862,0,0,1-.37-.521c-.031-.228-.089-.453-.106-.682a.253.253,0,0,0-.248-.273,4.47,4.47,0,0,1-.977-.272c-.162.228-.317.453-.479.672a.6.6,0,0,1-.9.163c-.3-.205-.6-.415-.892-.627a.554.554,0,0,1-.16-.866c.174-.256.352-.508.529-.763a6.067,6.067,0,0,1-.637-1.051c-.263.046-.507.084-.75.131a.6.6,0,0,1-.784-.5,2.685,2.685,0,0,0-.208-.751v-.588a.648.648,0,0,1,.641-.492c.211-.016.419-.072.629-.1.11-.016.158-.061.178-.183a3.869,3.869,0,0,1,.241-.9c.053-.122,0-.174-.09-.235-.2-.133-.4-.269-.585-.414a.539.539,0,0,1-.149-.792c.225-.34.459-.675.7-1a.537.537,0,0,1,.8-.122c.265.176.526.359.793.543a5.226,5.226,0,0,1,1.048-.629c-.045-.248-.083-.482-.128-.716-.1-.5.082-.746.588-.841a4.821,4.821,0,0,0,1-.208h.266a.709.709,0,0,1,.482.655c.028.255.082.506.127.768a7.163,7.163,0,0,1,1.183.326l.42-.591a.658.658,0,0,1,1.061-.19c.272.184.54.374.8.569a.555.555,0,0,1,.147.873c-.171.256-.348.508-.524.764a5.818,5.818,0,0,1,.641,1.037c.262-.043.5-.081.733-.124a.6.6,0,0,1,.8.562c.063.355.14.71.21,1.065ZM12.2,10.632a3.7,3.7,0,1,0,3.731,3.688A3.718,3.718,0,0,0,12.2,10.632m2.155,3.057q-1.169,1.149-2.335,2.3a.21.21,0,0,1-.341-.008q-.794-.79-1.59-1.577a.2.2,0,0,1,.011-.323c.212-.215.426-.429.631-.65.114-.121.208-.1.314,0,.267.259.539.515.79.756.513-.494,1.008-.964,1.5-1.442.239-.232.273-.237.513.008q.26.267.517.536a.247.247,0,0,1-.007.393m14.1,1.278h0V13.2c0-.264,0-.472,0-.682q-.007-4.78,0-9.561A2.676,2.676,0,0,0,25.468,0H9.12V0h0C8.5,0,7.952,0,7.408.005A2.639,2.639,0,0,0,4.717,2.727c0,.262,0,.524,0,.786l.889,0h0v0H21.957A2.676,2.676,0,0,1,24.94,6.472q.005,4.78,0,9.561c0,.21,0,.418,0,.682v1.765h0c0,.3,0,.584,0,.862h.747a2.612,2.612,0,0,0,2.758-2.7c.013-.54,0-1.081,0-1.674" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[78]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_11_filter">
                                <div class="alert alert-danger errYxt" id="section_11_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_11_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_11_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_11_table_check_all" class="group-checkable" name="section_11_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[81]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[82]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[79]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[80]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[83]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_11"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[84]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_12_container">
                            <a name="section_12_tag"></a>
                            <form name="section_12_form" id="section_12_form" class="section_12_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="22.118" height="24" viewBox="0 0 22.118 24">
                                    <path id="Clear_Daily_Timetable_" data-name="Clear Daily Timetable " d="M15.359,2.211c-.608,0-1.216,0-1.825,0a.761.761,0,0,0-.31.025V3.242a1.385,1.385,0,0,1-.18.695,1.46,1.46,0,0,1-1.685.682,1.4,1.4,0,0,1-1.046-1.375c0-.339,0-.676,0-1.019H7.21c0,.145,0,.275,0,.405a4.49,4.49,0,0,1-.044.957A1.441,1.441,0,0,1,5.6,4.663a1.387,1.387,0,0,1-1.29-1.3c-.023-.37,0-.744,0-1.147H3.568c-.469,0-.941.006-1.412,0A2.1,2.1,0,0,0,0,4.379q.012,6.586,0,13.17a2.069,2.069,0,0,0,2.16,2.162q3.82,0,7.636,0c-.023-.234-.035-.471-.035-.711a7.313,7.313,0,0,1,.05-.858q-3.969,0-7.938,0c-.415,0-.509-.093-.509-.5V6.691c0-.4.1-.5.494-.5H8.748v0h6.966c.329,0,.442.124.442.478v5.141a7.152,7.152,0,0,1,.848-.05q.254,0,.5.019,0-3.708,0-7.413a2.065,2.065,0,0,0-2.148-2.154M6.836,2.16c0,.346.006.692,0,1.039A1.047,1.047,0,0,1,5.722,4.277,1.048,1.048,0,0,1,4.663,3.183q0-1.039,0-2.078a1.086,1.086,0,1,1,2.173-.023c.007.359,0,.719,0,1.078Zm6-.016c0,.359,0,.719,0,1.078a1.085,1.085,0,0,1-2.17-.005q-.008-1.078,0-2.157a1.085,1.085,0,0,1,2.17,0c0,.359,0,.719,0,1.079Zm-6.682,9.2H2.8V7.985H6.153Zm4.282-.006H7.081V7.984h3.355Zm-4.28,4.915H2.8V12.9H6.156Zm8.56-4.914H11.358V7.988h3.358Zm-4.283,4.914H7.074V12.908h3.359ZM16.8,13.368a5.317,5.317,0,1,0,5.317,5.316A5.318,5.318,0,0,0,16.8,13.368m.713,8.517A7.817,7.817,0,0,1,15,20.809c.2-.36.393-.715.589-1.071a.265.265,0,0,1-.027-.019c-.294.283-.585.568-.876.852a4.758,4.758,0,0,1-.833-.81,5.743,5.743,0,0,0,1.807-1.784l2.5,1.445a4.461,4.461,0,0,0-.643,2.462m1.029-3.134c-.054.1-.109.194-.167.289a.252.252,0,0,1-.225.13.255.255,0,0,1-.128-.037q-1.023-.589-2.042-1.18a.252.252,0,0,1-.1-.357c.054-.1.107-.192.166-.285a.249.249,0,0,1,.357-.1c.682.391,1.362.786,2.042,1.178a.25.25,0,0,1,.1.36m.2-2.439c-.285.5-.572,1-.864,1.5l-.682-.395c.1-.176.2-.345.3-.515q.273-.472.546-.941a.257.257,0,0,1,.4-.107c.072.041.145.08.215.124a.245.245,0,0,1,.093.329m-.585-.353a2.338,2.338,0,0,0-.172.323c.07-.025.083-.077.107-.114.077-.116.151-.232.325-.17-.066-.126-.188-.143-.26-.039" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[85]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                              
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_12_filter">
                                <div class="alert alert-danger errYxt" id="section_12_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_12_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_12_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_12_table_check_all" class="group-checkable" name="section_12_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[88]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[89]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[86]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[87]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[90]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_12"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[91]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_13_container">
                            <a name="section_13_tag"></a>
                            <form name="section_13_form" id="section_13_form" class="section_13_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.06 24"><path d="M8,5.6c.11-1.09,0-2.15.06-3.23C8,2,6.69,2,6.28,1.85c-.1,1.75.16.62.57,1.57-.32.91-.57-.11-.48,1.59L6.7,5v6.71H5.52V5l.32,0c.1-1.75-.17-.66-.47-1.6.47-1,.64.21.56-1.65L4.62,1.5v0C7.2,1,9.78.32,12.36,0c2.48.54,5,.91,7.47,1.53l-3.41.65v3.3c0,.08,0,.14.1.18.71.34.45,1.57-.14,1.92-.28,0-.32.27-.4.48a7.7,7.7,0,0,1-1.5,2.44,1.32,1.32,0,0,0-.21,1c-.34,1-1.66,1.12-2.56,1-2.28-.62-.94-1.1-1.81-2.15a6.54,6.54,0,0,1-1.48-2.5.32.32,0,0,0-.25-.25c-.8-.2-1.09-1.87-.13-2M6.83,16.18A1,1,0,0,0,5.7,17a.76.76,0,0,0,0,.3q.52,2.85,1.06,5.7a1,1,0,0,0,1,.84c10.88-.53,9.05,2.57,10.57-6.42a1,1,0,0,0-1.09-1.27H6.83M21,16c-.94-2.15-3.49-3.07-5.54-3.87-.22,1-.47,1.9-.73,2.83,4.13.08,5.53-.54,4.37,4.37a2.53,2.53,0,0,0,2-3A1.89,1.89,0,0,0,21,16M9.66,15c-.28-.93-.52-1.87-.74-2.83-2.83.8-8.8,4.58-4.06,7.09-1.38-5.19.9-4,4.8-4.26m2.43-2.08c-1.48.31-1.44,1.91,0,2.13,1.7-.1,1.5-1.93,0-2.13" transform="translate(-3.09 0.02)" style="fill:#1b1819"/></svg></span> <?php echo $label_details[92]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                                
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_13_filter">
                                <div class="alert alert-danger errYxt" id="section_13_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_13_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_13_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_13_table_check_all" class="group-checkable" name="section_13_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[95]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[96]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[93]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[94]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[97]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_13"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[98]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_14_container">
                            <a name="section_14_tag"></a>
                            <form name="section_14_form" id="section_14_form" class="section_14_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.455" height="24" viewBox="0 0 18.455 24">
                                    <path id="Resigned_Section" data-name="Resigned Section" d="M14.671,13.625a4.738,4.738,0,0,0-1.069-.119,4.858,4.858,0,0,0-4.837,4.847,4.663,4.663,0,0,0,1.448,3.434,5.583,5.583,0,0,0,.735.6,4.618,4.618,0,0,0,2.686.811,4.847,4.847,0,0,0,1.037-9.576m-1.086,8.514a3.7,3.7,0,0,1-2.218-.735A3.789,3.789,0,0,1,13.5,14.569a3.683,3.683,0,0,1,.7.047,3.786,3.786,0,0,1-.622,7.523m2.128-2.456-.763.791-1.374-1.4-1.284,1.387-.785-.784,1.313-1.348-1.305-1.307.755-.74,1.313,1.336,1.365-1.373.766.767c-.416.442-.906.858-1.334,1.355l1.335,1.319m-.549-7.576c-.069-.016-.23.238-.454.682a5.487,5.487,0,0,0-1.238-.138,5.627,5.627,0,0,0-5.6,5.614,5.4,5.4,0,0,0,1.677,3.978,6.464,6.464,0,0,0,.851.7A4.648,4.648,0,0,1,9.869,24c-.038-.082-.109-.048-.17-.049H8.877c-.078.009-.17-.054-.228.049H7.893c-.023-.1-.105-.067-.166-.071a15.27,15.27,0,0,1-3.4-.689,8.679,8.679,0,0,1-2.94-1.53A3.455,3.455,0,0,1,.114,19.953a5.173,5.173,0,0,1,.012-2.172,9.031,9.031,0,0,1,1.313-3.469,9.443,9.443,0,0,1,2.41-2.568A10.426,10.426,0,0,1,6.2,10.5,5.7,5.7,0,0,1,9.288,0q.19,0,.378.013t.393.04a5.7,5.7,0,0,1,2.327,10.437,8.43,8.43,0,0,1,2.779,1.617" transform="translate(0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[99]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_14_filter">
                                <div class="alert alert-danger errYxt" id="section_14_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_14_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_14_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_14_table_check_all" class="group-checkable" name="section_14_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_14"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_15_container">
                            <a name="section_15_tag"></a>
                            <form name="section_15_form" id="section_15_form" class="section_15_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.013" height="24" viewBox="0 0 24.013 24">
                                    <path id="Timeline_Section" data-name="Timeline Section" d="M24.01,12.272A12.007,12.007,0,0,1,0,11.92,11.34,11.34,0,0,1,.461,8.752,12.1,12.1,0,0,1,1.735,5.817a11.157,11.157,0,0,1,1.9-2.407A12.75,12.75,0,0,1,6.152,1.534,11.995,11.995,0,0,1,24.01,12.272m-19.678.52c.121.112.206.188.289.266.222.21.436.432.668.631a.647.647,0,0,0,.895-.933c-.64-.685-1.3-1.353-1.981-1.993-.429-.4-.693-.4-1.122,0-.678.634-1.32,1.3-1.968,1.97a.637.637,0,0,0-.139.721.626.626,0,0,0,.621.4.678.678,0,0,0,.5-.228c.287-.269.571-.542.888-.843.038.274.07.5.1.73A9.245,9.245,0,1,0,14.916,3.323a8.834,8.834,0,0,0-2.582-.387c-.474,0-.741.227-.757.623s.238.655.722.695c.125.01.251.013.378.019A7.915,7.915,0,1,1,5.411,16.181a8.006,8.006,0,0,1-1.079-3.388M12.822,9.92q0-1.486,0-2.972a.687.687,0,0,0-.5-.659A.729.729,0,0,0,11.5,6.6a1.014,1.014,0,0,0-.079.5c0,1.72-.009,3.44,0,5.16a.633.633,0,0,1-.2.5q-1.309,1.307-2.6,2.634a.7.7,0,1,0,.978,1c1.05-.987,2.065-2.009,3.056-3.056a.621.621,0,0,0,.175-.462c-.007-.982,0-1.963,0-2.945m.072,8.558a.766.766,0,0,0-.778-.792.783.783,0,0,0-.789.812.771.771,0,0,0,.783.759.755.755,0,0,0,.784-.78M15.657,6.65a.781.781,0,0,0-.025,1.562.776.776,0,0,0,.815-.785.765.765,0,0,0-.79-.777m2.354,5.189a.783.783,0,0,0-.8-.779.769.769,0,0,0-.782.788.779.779,0,0,0,.79.784.8.8,0,0,0,.79-.793m-2.351,3.51a.785.785,0,0,0-.791.786.777.777,0,0,0,.785.79.788.788,0,1,0,.006-1.575" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[132]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_15_filter">
                                <div class="alert alert-danger errYxt" id="section_15_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_15_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_15_table">
                                                <!--begin::Table head-->
                                                <thead >
												<tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_15_table_check_all" class="group-checkable" name="section_15_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                   </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_15"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_16_container">
                            <a name="section_16_tag"></a>
                            <form name="section_16_form" id="section_16_form" class="section_16_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24.284" height="24" viewBox="0 0 24.284 24">
                                    <path id="preview_section" data-name="preview section" d="M22.555,0H5.8C4.386,0,2.978,0,1.566,0A1.392,1.392,0,0,0,.035,1.322C-.026,1.973.022,2.633.022,3.306H24.284v-1.6A1.509,1.509,0,0,0,22.555,0M2.222,2.488a.8.8,0,0,1-.814-.805.862.862,0,0,1,.809-.84.85.85,0,0,1,.831.853.786.786,0,0,1-.827.792m2.609,0a.791.791,0,0,1-.8-.818A.835.835,0,0,1,4.844.843a.877.877,0,0,1,.84.862.839.839,0,0,1-.853.783M11.9,9.8a3.845,3.845,0,1,0,3.858,3.836A3.841,3.841,0,0,0,11.9,9.8m.026,5.873a2.04,2.04,0,0,1-2.059-2.024,2.035,2.035,0,1,1,4.069,0,2.046,2.046,0,0,1-2.01,2.019M11.9,9.8a3.845,3.845,0,1,0,3.858,3.836A3.841,3.841,0,0,0,11.9,9.8m.026,5.873a2.04,2.04,0,0,1-2.059-2.024,2.035,2.035,0,1,1,4.069,0,2.046,2.046,0,0,1-2.01,2.019M0,4.34V22.214C0,23.477.528,24,1.786,24h20.7c1.258,0,1.782-.524,1.782-1.786q.007-8.724,0-17.448V4.34ZM14.438,18.955a8.148,8.148,0,0,1-6.383-.515A17.654,17.654,0,0,1,2.23,13.605c2.257-2.6,4.725-4.808,8.191-5.552a7.324,7.324,0,0,1,3.761.18,15.966,15.966,0,0,1,7.391,5.385,16.325,16.325,0,0,1-7.136,5.336M11.9,9.8a3.845,3.845,0,1,0,3.858,3.836A3.841,3.841,0,0,0,11.9,9.8m.026,5.873a2.04,2.04,0,0,1-2.059-2.024,2.035,2.035,0,1,1,4.069,0,2.046,2.046,0,0,1-2.01,2.019" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[133]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_16_filter">
                                <div class="alert alert-danger errYxt" id="section_16_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_16_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_16_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                   <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_16_table_check_all" class="group-checkable" name="section_16_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_16"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_17_container">
                            <a name="section_17_tag"></a>
                            <form name="section_17_form" id="section_17_form" class="section_17_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="27.411" height="23.116" viewBox="0 0 27.411 23.116">
                                    <path id="duplicate_sections" data-name="duplicate sections" d="M27.407,14.415h0v-1.7c0-.254,0-.454,0-.657q-.007-4.6,0-9.209A2.578,2.578,0,0,0,24.53,0H8.784V0h0c-.6,0-1.122-.008-1.645,0A2.541,2.541,0,0,0,4.543,2.626c0,.252,0,.505,0,.757l.857,0h0v0H21.148a2.578,2.578,0,0,1,2.874,2.849q.005,4.6,0,9.209c0,.2,0,.4,0,.657v1.7h0c0,.287,0,.563,0,.831h.72a2.516,2.516,0,0,0,2.657-2.6c.012-.52,0-1.041,0-1.613M22.87,18.9h0V17.2c0-.254,0-.454,0-.657q-.007-4.6,0-9.209a2.578,2.578,0,0,0-2.874-2.849H4.247v0h0c-.6,0-1.122-.008-1.645,0A2.541,2.541,0,0,0,.006,7.111q-.012,6.692,0,13.384a2.522,2.522,0,0,0,2.643,2.618q8.78.005,17.563,0a2.516,2.516,0,0,0,2.657-2.6c.012-.52,0-1.041,0-1.613m-7.124-3.017H11.986v3.761H9.555V15.883H5.794V13.451H9.555V9.691h2.431v3.761h3.761Z" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[134]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_17_filter">
                                <div class="alert alert-danger errYxt" id="section_17_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_17_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_17_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_17_table_check_all" class="group-checkable" name="section_17_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_17"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_18_container">
                            <a name="section_18_tag"></a>
                            <form name="section_18_form" id="section_18_form" class="section_18_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="20.472" height="23.564" viewBox="0 0 20.472 23.564">
                                    <path id="Send_Task_Section" data-name="Send Task Section" d="M4.026,4.64V1.7H5.311c0-.2,0-.387,0-.574A1.1,1.1,0,0,1,6.451,0C7.538,0,8.625,0,9.712,0a1.093,1.093,0,0,1,1.117,1.131c0,.177,0,.354,0,.558h1.248V4.64Zm4.049-1.08a1.127,1.127,0,0,0,1.2-1.212A1.2,1.2,0,0,0,8.055,1.143a1.209,1.209,0,0,0,.021,2.417m2.3,15.424a5.519,5.519,0,0,1,5.519-5.519c.083,0,.166,0,.248.006q0-4.987,0-9.974c0-.055,0-.11,0-.165A.729.729,0,0,0,15.4,2.64c-.275,0-.55,0-.825,0h-1.15V5.866H2.676V2.639H.865A.758.758,0,0,0,0,3.5Q0,6.4,0,9.293q0,4.526,0,9.053a.746.746,0,0,0,.779.822h9.6c0-.061,0-.122,0-.183M7.524,16.578c-.207.254-.205.256-.473.039-.643-.522-1.287-1.041-1.927-1.566Q3.89,14.04,2.659,13.024c-.214-.176-.225-.26-.054-.468.22-.269.44-.539.662-.807.141-.17.212-.188.392-.054.292.217.559.467.84.7.342.279.687.557,1.029.836.538.44,1.072.885,1.619,1.336l.908-1.11,3.376-4.132,1.15-1.406c.13-.158.214-.17.369-.046.281.225.557.457.839.681a.192.192,0,0,1,.036.312q-.679.829-1.357,1.658c-.34.416-.673.838-1.019,1.25-.314.374-.632.746-.934,1.128-.534.674-1.085,1.333-1.623,2-.452.562-.912,1.118-1.368,1.677m8.369-2.171a4.579,4.579,0,1,0,4.58,4.578,4.578,4.578,0,0,0-4.58-4.578m-.347,8.166c-.219-.758-.42-1.467-.627-2.177-.022-.082.022-.125.063-.175.319-.392,1.161-1.458,1.269-1.592-.136.108-1.2.948-1.592,1.268-.051.043-.093.088-.175.063-.709-.205-1.419-.407-2.177-.625l5.556-2.317c-.778,1.865-1.538,3.689-2.317,5.556" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[135]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_18_filter">
                                <div class="alert alert-danger errYxt" id="section_18_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_18_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_18_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_18_table_check_all" class="group-checkable" name="section_18_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_18"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_19_container">
                            <a name="section_19_tag"></a>
                            <form name="section_19_form" id="section_19_form" class="section_19_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="25.931" height="24.158" viewBox="0 0 25.931 24.158">
                                    <path id="print_section" data-name="print section" d="M0,10.257a2.616,2.616,0,0,1,2.692-2.2q10.261,0,20.523,0a2.617,2.617,0,0,1,2.712,2.57c0,.041,0,8.208,0,8.263a2.614,2.614,0,0,1-1.153,2.137,3.763,3.763,0,0,1-2.426.441V14.332H3.524v7.133c-.378,0-.738.017-1.1,0A2.587,2.587,0,0,1,.079,19.617C.033,19.47-.006,10.29,0,10.257m21.451,1.385a.834.834,0,0,0-.879-.906.85.85,0,0,0-.914.878.861.861,0,0,0,.9.919.839.839,0,0,0,.9-.891M4.441,1.778c-.008,1.769,0,3.538,0,5.308a.2.2,0,0,0,.015.054h16.99V6.968q0-2.581,0-5.162A1.76,1.76,0,0,0,19.787,0c-.062,0-.124.008-.186.008H6.4c-.1,0-.207,0-.31-.007a1.773,1.773,0,0,0-1.65,1.775M19.787,24.159c-.1,0-13.662,0-13.7,0a1.762,1.762,0,0,1-1.647-1.735c-.013-2.385,0-7.163,0-7.184H21.459c0,.209,0,4.767-.007,7.076a1.772,1.772,0,0,1-1.664,1.844m-.127-6.253H6.229v.885H19.66Zm0,2.691H6.23v.879H19.664Z" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[136]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_19_filter">
                                <div class="alert alert-danger errYxt" id="section_19_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_19_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_19_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_19_table_check_all" class="group-checkable" name="section_19_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_19"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_20_container">
                            <a name="section_20_tag"></a>
                            <form name="section_20_form" id="section_20_form" class="section_20_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="26.257" height="23.244" viewBox="0 0 26.257 23.244">
                                    <path id="Mark_As_Read_Section" data-name="Mark As Read Section" d="M.542,8.422C4.356,10.8,8.18,13.158,11.974,15.566a1.889,1.889,0,0,0,2.3.013c3.765-2.39,7.559-4.734,11.345-7.09a1.37,1.37,0,0,1,.6-.3c.016.169.039.3.039.435,0,4.058.011,8.117,0,12.175a2.321,2.321,0,0,1-2.509,2.442q-10.581,0-21.162,0A2.354,2.354,0,0,1,.007,20.653Q0,14.72.008,8.786a.927.927,0,0,1,.1-.621c.145.086.291.168.433.256m25.5-.451L20.129,4.284Q16.823,2.222,13.518.157c-.226-.142-.4-.24-.685-.061Q6.644,3.98.439,7.838a1.82,1.82,0,0,0-.159.133Z" transform="translate(0 0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[137]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_20_filter">
                                <div class="alert alert-danger errYxt" id="section_20_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_20_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_20_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_20_table_check_all" class="group-checkable" name="section_20_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_20"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_21_container">
                            <a name="section_21_tag"></a>
                            <form name="section_21_form" id="section_21_form" class="section_21_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="32.769" height="23.017" viewBox="0 0 32.769 23.017">
                                    <path id="mark_as_unread_section" data-name="mark as unread section" d="M30.47,0q-7.1,7.1-14.084,14.088h0Q9.381,7.082,2.3,0Zm2.3,2.668a2.091,2.091,0,0,0-.231-1.139,5.837,5.837,0,0,1-.4.506Q24.912,9.271,17.681,16.5a1.606,1.606,0,0,1-2.592,0Q7.858,9.271.631,2.035a5.863,5.863,0,0,1-.4-.506A2.091,2.091,0,0,0,0,2.667q0,8.909,0,17.82A2.279,2.279,0,0,0,2.54,23.015q6.924,0,13.845,0t13.845,0a2.279,2.279,0,0,0,2.537-2.527q.006-8.911,0-17.82" transform="translate(0 0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[138]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_21_filter">
                                <div class="alert alert-danger errYxt" id="section_21_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_21_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_21_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_21_table_check_all" class="group-checkable" name="section_21_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_21"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_22_container">
                            <a name="section_22_tag"></a>
                            <form name="section_22_form" id="section_22_form" class="section_22_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="23.997" height="24" viewBox="0 0 23.997 24">
                                    <path id="Archive_Section" data-name="Archive Section" d="M12.018,24h9.119a2.673,2.673,0,0,0,2.855-2.843q0-8.154,0-16.306a2.982,2.982,0,0,0-.711-2.009C22.716,2.165,22.158,1.478,21.6.8A2.074,2.074,0,0,0,19.91,0Q11.993,0,4.076,0A2.045,2.045,0,0,0,2.417.782Q1.534,1.856.649,2.925A2.742,2.742,0,0,0,0,4.735Q0,13,0,21.26A2.656,2.656,0,0,0,2.742,24Q7.38,24,12.018,24M9.339,12V9.352h5.335v2.656h4.561l-7.222,7.224L4.783,12Zm-6.5-9.341c.362-.444.7-.85,1.026-1.257.08-.1.189-.071.289-.071q7.773,0,15.546,0c.08,0,.17-.03.237.04.394.417.787.835,1.214,1.288Z" transform="translate(0 -0.001)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[139]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_22_filter">
                                <div class="alert alert-danger errYxt" id="section_22_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_22_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_22_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_22_table_check_all" class="group-checkable" name="section_22_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_22"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_23_container">
                            <a name="section_23_tag"></a>
                            <form name="section_23_form" id="section_23_form" class="section_23_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="37.525" height="24" viewBox="0 0 37.525 24">
                                    <path id="Dashboard_Section" data-name="Dashboard Section" d="M.327,15.747a18.768,18.768,0,0,1,36.908-.753,17.12,17.12,0,0,1,.276,3.989,2.054,2.054,0,0,1-1.756,1.928c-3.634.031-7.269.013-10.982.013.752-.962,1.5-1.913,2.24-2.87,1.719-2.222,3.47-4.421,5.14-6.68a3.389,3.389,0,0,0-1.687-5.242,3.5,3.5,0,0,0-3.643.807q-4.023,3.888-8.014,7.81a2.732,2.732,0,0,1-1.259.739,5.911,5.911,0,0,0-4.615,5.527c-1.343,0-2.669.006-4,0C7.075,21,5.294,20.99,3.346,20.99c-1.485,0-2.969-.216-3.306-1.75a15.922,15.922,0,0,1,.286-3.493m16.984-8.9h3.078V2.209H17.311ZM9.585,13.622,4.9,13.007a20.859,20.859,0,0,0-.32,3.008c1.568.2,3.059.5,4.608.57a19.135,19.135,0,0,0,.4-2.963M13.05,8.741,9.774,5.449l-1.9,1.9,3.2,3.235L13.05,8.741m8.567,12.974a4.184,4.184,0,0,1,1.011-2.128c.322-.383.623-.782.932-1.176,1.663-2.122,3.33-4.241,4.982-6.371a1.2,1.2,0,0,0-.006-1.73,1.232,1.232,0,0,0-1.738.08c-.215.175-.417.368-.615.563q-3.445,3.4-6.882,6.8a2.033,2.033,0,0,1-1.053.588,2.833,2.833,0,0,0-2.261,3.129,2.777,2.777,0,0,0,2.9,2.506,2.571,2.571,0,0,0,2.728-2.265" transform="translate(0 0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[140]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_23_filter">
                                <div class="alert alert-danger errYxt" id="section_23_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_23_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_23_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_23_table_check_all" class="group-checkable" name="section_23_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                       
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_23"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                        <div class="card mb-7 border" id="section_24_container">
                            <a name="section_24_tag"></a>
                            <form name="section_24_form" id="section_24_form" class="section_24_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="36.075" height="24" viewBox="0 0 36.075 24">
                                    <path id="message_menu_section" data-name="message menu section" d="M28.622,0h7.453V5.173H28.622Zm7.45,9.233H28.62v5.194h7.453Zm0,9.57H28.621V24h7.453ZM2.4,0Q9.8,7.4,17.084,14.69h0l9.434-9.438V0ZM18.436,17.211a1.675,1.675,0,0,1-2.7,0Q8.194,9.669.659,2.122A6.127,6.127,0,0,1,.244,1.6,2.18,2.18,0,0,0,0,2.782q0,9.29,0,18.582A2.377,2.377,0,0,0,2.649,24q7.219,0,14.436,0h9.436V9.119q-4.042,4.046-8.085,8.091" transform="translate(0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[141]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_24_filter">
                                <div class="alert alert-danger errYxt" id="section_24_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_24_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_24_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_24_table_check_all" class="group-checkable" name="section_24_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_24"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>

                        <div class="card mb-7 border" id="section_28_container">
                            <a name="section_28_tag"></a>
                            <form name="section_28_form" id="section_28_form" class="section_28_form">
                            <div class="card-header hd-col-2">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="36.075" height="24" viewBox="0 0 36.075 24">
                                    <path id="message_menu_section" data-name="message menu section" d="M28.622,0h7.453V5.173H28.622Zm7.45,9.233H28.62v5.194h7.453Zm0,9.57H28.621V24h7.453ZM2.4,0Q9.8,7.4,17.084,14.69h0l9.434-9.438V0ZM18.436,17.211a1.675,1.675,0,0,1-2.7,0Q8.194,9.669.659,2.122A6.127,6.127,0,0,1,.244,1.6,2.18,2.18,0,0,0,0,2.782q0,9.29,0,18.582A2.377,2.377,0,0,0,2.649,24q7.219,0,14.436,0h9.436V9.119q-4.042,4.046-8.085,8.091" transform="translate(0)" fill="#6c33a3"/>
                                    </svg></span> <?php echo $label_details[141]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                               
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="section_28_filter">
                                <div class="alert alert-danger errYxt" id="section_28_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="section_28_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class=" mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="section_28_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="section_28_table_check_all" class="group-checkable" name="section_28_table_check_all" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[102]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[103]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                                        
                                                        <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[104]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="update_section_28"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4 me-2"></i><?php echo $label_details[105]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                            </form>
                        </div>
                    </div>
                    <!--end::Card body-->
            </div>
            <!--end::Modals-->
            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="modules_edit_id" style="display:none;">
                <form name="edit_modules_form" id="edit_modules_form" class="edit_modules_form">
                    <a name="modules_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> Edit Modules</h3>
                                <button type="button" id="label_2_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                                <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                <div class="tool_tip">
                                    <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                                    <i class="las la-edit fs-1"></i>
                                </div>
                                <!--end::Svg Icon-->
                            </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-10">
                            <label class="fs-6 form-label text-dark me-5">Module Name *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="mod_name" name="mod_name" class="form-control"  aria-describedby="basic-addon1">
                                <input type="hidden" id="token_id" name="token_id" />
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_modules_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i>UDPATE</button>
                            <button type="button" id="edit_modules_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i>CANCEL</button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
		<!--end::Page Custom Javascript-->
<script src="<?php echo $js_path;?>bulk_labeling.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],address_fields=[],section_1_selected=[],section_2_selected=[],section_3_selected=[],section_4_selected=[],section_5_selected=[],section_6_selected=[],section_7_selected=[],section_8_selected=[],section_9_selected=[],section_10_selected=[],section_11_selected=[],section_12_selected=[],section_13_selected=[],section_14_selected=[],section_15_selected=[],section_16_selected=[],section_17_selected=[],section_18_selected=[],section_19_selected=[],section_20_selected=[],section_21_selected=[],section_22_selected=[],section_23_selected=[],section_24_selected=[],section_28_selected=[],id="<?php  echo $user_det['id'];?>",lang_fld="",module_id="",lang_edit_fld="",tree_details=[],label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() {  
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });  
    if ($.inArray("334", role_details) != -1)
    {
        edit_role=true;
    }
	bulk_labeling_details();
});
</script>  
