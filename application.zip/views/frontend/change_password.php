<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
?>

 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <?php echo $label_details[1]['name']; ?>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="change_password_edit_id">
                <form name="edit_change_password_form" id="edit_change_password_form" class="edit_change_password_form">
                    <a name="change_password_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[2]['name']; ?></h3>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[3]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="password" id="current_password" name="current_password" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[4]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="password" id="new_password" name="new_password" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[5]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="password" id="confirm_password" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_change_password_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[6]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>
        </div>
        <!--end::Post-->
       
    <!--end::Post-->
<?php echo $footer; ?>
<script src="<?php echo $js_path;?>change_password.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",label_details=<?php echo json_encode($label_details); ?>,group_id="<?php  echo $user_det['group_id'];?>";

$(document).ready(function() {
	change_password_details();
});
</script>  
