<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 
 <style>
     .actionBtns_table tr td:nth-child(9) {
    text-align: center;
}


</style>
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(283,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="coaching_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[2]['name']; ?></h3>
                    <button type="button" id="label_44_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
						    <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[3]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="term_fld" name="term_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="student_fld" name="student_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="tutor_fld" name="tutor_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[6]['name']; ?></label>
                                <div class="input-group">
                                    <input class="form-control" placeholder="<?php echo $label_details[182]['name']; ?>" id="deadline_fld" name="deadline_fld" />
                                </div>
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[7]['name']; ?></label>
                                <div class="input-group">
                                    <input class="form-control" placeholder="<?php echo $label_details[182]['name']; ?>" id="coaching_date_fld" name="coaching_date_fld" />
                                </div>
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[8]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="status_fld" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[9]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[10]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[11]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[12]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="del_fld" name="del_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all"><?php echo $label_details[13]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[14]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[15]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <div class="col-lg-4 mt-17 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="coaching_filter" name="coaching_filter" class="btn btn-primary pb-2 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[16]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="coaching_reset" name="coaching_reset" class="btn btn-danger me-5 pb-2 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[17]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[177]['name']; ?></h3>
                                    <button type="button" id="label_44_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(284,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_coaching_btn"><?php echo $label_details[19]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(286,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_coaching" data-toggle="modal"><?php echo $label_details[20]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(286,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_coaching" data-toggle="modal"><?php echo $label_details[21]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(287,$role_details)) { ?>
                            <button type="button" class="btn btn-sm btn-success my-1 px-2" data-toggle="modal" data-target="#import_coaching" id="import_coaching_btn"><?php echo $label_details[22]['name']; ?> <i class="las la-external-link-alt fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[23]['name']; ?> </th>
                                    <th data-priority="2" class="fw-bolder"> <?php echo $label_details[24]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder"> <?php echo $label_details[25]['name']; ?> </th>
                                    <th data-priority="6" class="fw-bolder"> <?php echo $label_details[26]['name']; ?> </th>
                                    <th data-priority="7" class="fw-bolder"> <?php echo $label_details[27]['name']; ?> </th>
                                    <th data-priority="8" class="fw-bolder"> <?php echo $label_details[28]['name']; ?> </th>
                                    <th data-priority="9" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[29]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[30]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="coaching_create_id" style="display:none;">
                <form name="add_coaching_form" id="add_coaching_form" class="add_coaching_form">
                    <a name="coaching_table_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[31]['name']; ?> <?php echo $label_details[252]['name']; ?>
                            </h3>
                            <button type="button" id="label_44_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_coaching_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[32]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <h3><?php echo $label_details[162]['name']; ?>:</h3>
                        <div class="col-xxl-12">
                            <!--begin::Row-->
                            <div class="row g-8">
                                <!--begin::Col-->
                                <div class="col-lg-3 w-md-200px">
                                    <label class="fs-7 form-label text-dark"><?php echo $label_details[33]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <div class="overflow-hidden flex-grow-1">
                                            <select class="form-select rounded-start-0" data-control="select2" id="term_fld_list" name="term_fld">
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 w-md-200px">
                                    <label class="fs-7 form-label text-dark"><?php echo $label_details[34]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <div class="overflow-hidden flex-grow-1">
                                            <select class="form-select rounded-start-0" data-control="select2" id="student_fld_list" name="student_fld">
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3 w-md-200px">
                                    <label class="fs-7 form-label text-dark"><?php echo $label_details[35]['name']; ?></label>
                                    <!--begin::Select-->
                                    <select id="status_fld_list" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                        <option value="all" selected="selected"><?php echo $label_details[36]['name']; ?></option>
                                        <option value="1"><?php echo $label_details[37]['name']; ?></option>
                                        <option value="0"><?php echo $label_details[38]['name']; ?></option>
                                    </select>
                                    <!--end::Select-->
                                </div>
                                <div class="col-lg-4 mt-16 w-md-250px">
                                    <!--end::Input group-->
                                    <!--begin:Action-->
                                    <div class="fltl me-3">
                                        <button type="button" id="coaching_filter_list" name="coaching_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                            <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                            <i class="las la-filter"></i>
                                            <!--end::Svg Icon--><?php echo $label_details[39]['name']; ?>
                                        </button>
                                    </div>
                                    <div class="fltl">
                                        <button type="button" id="coaching_reset_list" name="coaching_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[40]['name']; ?></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!--begin::Table-->
                        <div class="">
                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="all_assign_student_list">
                                <!--begin::Table head-->
                                <thead >
                                    <tr>
                                        <th></th>
                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[41]['name']; ?> </th>
                                        <th data-priority="1" class="fw-bolder"> <?php echo $label_details[42]['name']; ?> </th>
                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[43]['name']; ?> </th>
                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[44]['name']; ?> </th>
                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[45]['name']; ?> </th>
                                        <th data-priority="2" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[46]['name']; ?> </th>
                                    </tr>
                                </thead>
                                <!--end::Table head-->
                                <!--begin::Table body-->
                                <tbody class=" text-gray-800 actionBtns_table">
                                </tbody>
                                <!--end::Table body-->
                            </table>
                        </div>
                        <!--end::Table-->
                        <div class="row" id="student_add_protocol" style="display:none;">
                            <a name="coaching_create_id"></a>
                            <h3 class="py-4"><?php echo $label_details[47]['name']; ?></h3>
                            <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                                <li class="nav-item">
                                    <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1">
                                        <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                            </svg>
                                        </span>
                                        <!--end::Svg Icon-->
                                        <span class="d-flex flex-column align-items-start">
                                            <span class="fs-4 fw-bolder"><?php echo $label_details[48]['name']; ?></span>
                                        </span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_2">
                                        <span class="svg-icon svg-icon-2 svg-icon-primary">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                            </svg>
                                        </span>
                                        <!--end::Svg Icon-->
                                        <span class="d-flex flex-column align-items-start">
                                            <span class="fs-4 fw-bolder"><?php echo $label_details[49]['name']; ?></span>
                                        </span>
                                    </a>
                                </li>
                            </ul>
                            <div class="tab-content" id="myTabContent">
                                <div class="tab-pane fade show active" id="kt_tab_pane_1" role="tabpanel">
                                    <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                    <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                                        <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[50]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="coaching_category_id" name="coaching_category_id">
                                                </select>
                                                <input type="hidden" id="student_id" name="student_id" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[51]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="student_agenda" name="student_agenda" rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[52]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="personnel_agenda" name="personnel_agenda" rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[53]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="protocol" name="protocol" rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[54]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="arrangement" name="arrangement" rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[55]['name']; ?> *</label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                            <input class="form-control" placeholder="<?php echo $label_details[211]['name']; ?>" id="coaching_date" name="coaching_date" />
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[56]['name']; ?></label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                            <input class="form-control" placeholder="<?php echo $label_details[211]['name']; ?>" id="deadline_date" name="deadline_date" />
                                        </div>
                                    </div>
                                    <div class="mb-10">
                                        <label class="fs-6 form-label text-dark"><?php echo $label_details[57]['name']; ?></label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" id="is_fulfilled" name="is_fulfilled" checked="checked">
                                        </div>
                                    </div>
                                    <div class="mb-10">
                                        <label class="fs-6 form-label text-dark"><?php echo $label_details[58]['name']; ?></label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                                        </div>
                                    </div>
                                    <div class="card-box">
                                        <!--begin::Toolbar-->
                                        <div class="card-toolbar float-xxl-end">
                                            <button type="button" id="add_coaching_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[59]['name']; ?></button>
                                        </div>
                                        <div class="">&nbsp;</div>
                                        <!--end::Toolbar-->
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="kt_tab_pane_2" role="tabpanel">
                                    <div class="card-body p-0">
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="personal_data_container">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 20.53"><defs><style>.a{fill:#f46200;}</style></defs><path class="a" d="M1.73,22.25H0a8.23,8.23,0,0,1,5.28-7.76A6,6,0,0,1,2.58,9a5.78,5.78,0,0,1,2-4,6,6,0,0,1,8.27.22,5.8,5.8,0,0,1,1.7,4.87,5.94,5.94,0,0,1-2.67,4.38,8.42,8.42,0,0,1,5.32,7.77l-.17,0H15.39a6.56,6.56,0,0,0-2.83-5A6.87,6.87,0,0,0,7.93,16,6.68,6.68,0,0,0,1.73,22.25ZM4.22,9.44A4.28,4.28,0,1,0,8.51,5.16,4.27,4.27,0,0,0,4.22,9.44Zm9.8-6h7.12a1,1,0,0,1,1.14,1.13q0,7.42,0,14.84a1,1,0,0,1-1.12,1.13h-2c-.09,0-.2,0-.28,0v1.67c1.16,0,2.31,0,3.46,0A1.69,1.69,0,0,0,24,20.45V3.55a1.73,1.73,0,0,0-1.85-1.81H14c-.09,0-.18,0-.26,0V3.45Zm6.51,3.41V5.18H15.42V6.86Zm0,3.43V8.6H15.42v1.69Zm-5.1,3.42h5.1V12h-5.1Zm1.71,1.74v1.68h3.4V15.45Z" transform="translate(0 -1.73)"/></svg></span> <?php echo $label_details[60]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="collapse"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="personal_data_fields">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Table-->
                                                        <div class="cct-scrool">
                                                            <img id="pv_profile_pic" width="100px" height="100px" alt="" class="avatar-img mb-4">
                                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="personal_data_details">
                                                                <!--begin::Table body-->
                                                                <tbody class=" text-gray-800 actionBtns_table">
                                                                    <tr>
                                                                        <th class="left" width="20%"><?php echo $label_details[61]['name']; ?></th>
                                                                        <td><div id="pv_name"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[62]['name']; ?></th>
                                                                        <td><div id="pv_remarks"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[63]['name']; ?></th>
                                                                        <td><div id="pv_grade"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[64]['name']; ?></th>
                                                                        <td><div id="pv_personal_strengths"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[65]['name']; ?></th>
                                                                        <td><div id="pv_personal_weaknesses"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[66]['name']; ?></th>
                                                                        <td><div id="pv_career_goals"></div></td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[67]['name']; ?></th>
                                                                        <td> <div id="pv_permission_to_leave_school"></div>
                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th class="left"><?php echo $label_details[68]['name']; ?></th>
                                                                        <td> <div id="pv_permission_to_smoke"></div>
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                                <!--end::Table body-->
                                                            </table>
                                                        </div>
                                                        <!--end::Table-->
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->

                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="marks_block">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15.63 24"><path d="M9.21,3.94A.18.18,0,0,1,9,3.76V1.29A1.26,1.26,0,0,0,8.65.38,1.24,1.24,0,0,0,7.74,0,1.29,1.29,0,0,0,6.45,1.29V3.76a.18.18,0,0,1-.18.18H3.87V5.17a.59.59,0,0,0,.59.59H11a.58.58,0,0,0,.59-.59V3.94ZM7.71,1.77a.51.51,0,0,1,0-1,.51.51,0,0,1,0,1ZM13.55,7.9H2.09V7.1H13.55Zm0,2.11H2.09v-.8H13.55Zm0,2.1H2.09v-.8H13.55Zm-.24,3.26L8.47,20.21,6.82,21.87h0L3,18.11a.68.68,0,0,1,0-1l.7-.7a.69.69,0,0,1,1,0l2.11,2.11,4.84-4.84a.67.67,0,0,1,1,0l.7.7A.67.67,0,0,1,13.31,15.37Zm1-12.52H9.49v.63h4.84a.67.67,0,0,1,.67.66V22.7a.66.66,0,0,1-.67.66H1.3a.65.65,0,0,1-.66-.66V4.15a.66.66,0,0,1,.66-.66H6V2.85H1.3A1.3,1.3,0,0,0,0,4.15V22.7A1.3,1.3,0,0,0,1.3,24h13a1.3,1.3,0,0,0,1.3-1.3V4.15A1.3,1.3,0,0,0,14.33,2.85Z" style="fill:#2c9f5a"/></svg></span> <?php echo $label_details[69]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="expand"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="selected_students">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Table-->
                                                        <div class="cct-scrool">
                                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_marks">
                                                                <!--begin::Table head-->
                                                                <thead >
                                                                    <tr>
                                                                        <th class="fw-bolder"> <?php echo $label_details[70]['name']; ?> </th>
                                                                        <th class="fw-bolder"> <?php echo $label_details[71]['name']; ?> </th>
                                                                        <th class="fw-bolder"> <?php echo $label_details[72]['name']; ?> </th>
                                                                    </tr>
                                                                </thead>
                                                                <!--end::Table head-->
                                                                <!--begin::Table body-->
                                                                <tbody class=" text-gray-800 actionBtns_table">
                                                                </tbody>
                                                                <tfoot>
                                                                    <tr>
                                                                        <th colspan="3"></th> 
                                                                    </tr>
                                                                </tfoot>
                                                                <!--end::Table body-->
                                                            </table>
                                                        </div>
                                                        <!--end::Table-->
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->

                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="marks_evolution_block">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.91 24"><defs><style>.a{fill:#27393f;}</style></defs><path class="a" d="M0,2.93H3.49v1H13.64c.09-.31,0-.64.06-1h3.46v9c-2.53-.82-4.61-.29-6.05,2.06a4.42,4.42,0,0,0,.4,5.32c1.48,1.87,3.43,2.18,5.65,1.47v3.24H0Zm7.05,7.13H11.7A1.31,1.31,0,0,0,12,10a.43.43,0,0,0,.35-.48.45.45,0,0,0-.4-.44,1.48,1.48,0,0,0-.3,0H2.51a1.6,1.6,0,0,0-.38,0,.44.44,0,0,0-.39.45A.43.43,0,0,0,2.1,10a1.31,1.31,0,0,0,.34,0Zm-1.22,2H2.37c-.42,0-.64.17-.64.48S2,13,2.35,13H9.28c.4,0,.6-.16.61-.46s-.21-.48-.63-.48ZM5.26,16c1,0,1.93,0,2.89,0,.4,0,.64-.19.63-.49S8.55,15,8.16,15H2.34c-.38,0-.61.18-.61.47s.23.48.6.48C3.31,16,4.29,16,5.26,16Zm-.62,2H2.31c-.33,0-.54.14-.57.47s.2.49.54.49H7a.5.5,0,0,0,.57-.48c0-.29-.21-.48-.58-.48Zm13.65,1,2.43,2.34c.28.27.56.53.84.81a1.88,1.88,0,0,1,.27.36.57.57,0,0,1-.17.78.61.61,0,0,1-.82-.13l-1.55-1.93-1.48-1.85a3.84,3.84,0,0,1-5.06-5.76,3.85,3.85,0,0,1,5.05-.21C19.46,14.7,19.64,16.75,18.29,19Zm-3.22-1.79L13.88,16a.48.48,0,1,0-.7.65c.51.53,1,1.06,1.55,1.57a.45.45,0,0,0,.75-.05c.2-.24.4-.49.59-.74l1.57-2c.24-.3.23-.59,0-.76s-.52-.11-.72.14l-.26.33ZM12.89,1.64h-2.7C9.84.44,9.43,0,8.57.07a1.67,1.67,0,0,0-1,.34A1.61,1.61,0,0,0,7,1.71H4.33V3.14h8.56Z" transform="translate(0 -0.06)"/></svg></span> <?php echo $label_details[73]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="collapse"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="student_courses_fields">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Row-->
                                                        <div class="row g-8">
                                                            <!--begin::Col-->
                                                            <div class="input-group">
                                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[74]['name']; ?></label>
                                                                <!--begin::Select-->
                                                                <select class="form-select form-select-solid border" data-control="select2" id="subject_id" name="subject_id" multiple="multiple" data-allow-clear="true">
                                                                    <option></option>
                                                                </select>
                                                                <!--end::Select-->
                                                            </div>
                                                            <!--end::Col-->
                                                            <!--begin::Col-->
                                                            <div class="input-group">
                                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[75]['name']; ?></label>
                                                                <!--begin::Select-->
                                                                <select class="form-select form-select-solid border" data-control="select2" id="student_term_id" name="student_term_id" multiple="multiple" data-allow-clear="true">
                                                                </select>
                                                                <!--end::Select-->
                                                            </div>
                                                            <!--end::Col-->
                                                            <div class="col-lg-4 mt-4 w-md-250px">
                                                                <!--end::Input group-->
                                                                <!--begin:Action-->
                                                                <div class="fltl me-3">
                                                                    <button type="button" id="mark_evolution_filter" name="mark_evolution_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                                        <i class="las la-filter"></i>
                                                                        <!--end::Svg Icon--><?php echo $label_details[76]['name']; ?>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <!--end::Col-->
                                                        </div>
                                                        <!--end::Row-->
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="chart-container">
                                                                    <div class="bar-chart-container">
                                                                        <canvas id="bar-chart"></canvas>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->

                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="disciplinary_block">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0,13.36V10.64a1,1,0,0,1,1.09-.53c.43,0,.86,0,1.31,0A9.79,9.79,0,0,1,3.88,6.54c-.39-.39-.77-.76-1.15-1.15a.73.73,0,0,1,0-1.07c.53-.54,1.06-1.08,1.6-1.61a.74.74,0,0,1,.76-.17.82.82,0,0,1,.35.23l1.1,1.12A10.07,10.07,0,0,1,10.12,2.4V.83A.76.76,0,0,1,11,0H13a.77.77,0,0,1,.87.87V2.4a9.72,9.72,0,0,1,3.58,1.48c.36-.36.7-.71,1.05-1a.79.79,0,0,1,1.28,0l1.36,1.36a.81.81,0,0,1,0,1.34l-1,1a10.13,10.13,0,0,1,1.49,3.58h1.55A.76.76,0,0,1,24,11V13a.77.77,0,0,1-.87.86H21.6a9.72,9.72,0,0,1-1.48,3.58l1.1,1.09a.78.78,0,0,1,0,1.21l-1.42,1.42a.78.78,0,0,1-1.26,0l-1.07-1.07a10,10,0,0,1-3.58,1.48c0,.48,0,.94,0,1.4a.92.92,0,0,1-.58,1H10.64a1,1,0,0,1-.53-1.09c0-.43,0-.86,0-1.31a10,10,0,0,1-3.58-1.48c-.37.36-.72.73-1.08,1.08a.78.78,0,0,1-1.23,0L2.81,19.78a.79.79,0,0,1,0-1.26l1.07-1.06A9.52,9.52,0,0,1,3,15.74a10,10,0,0,1-.56-1.86H.79a.73.73,0,0,1-.59-.25C.13,13.55.07,13.45,0,13.36ZM12,4.22A7.78,7.78,0,1,0,19.78,12,7.78,7.78,0,0,0,12,4.22Z" transform="translate(0 0)" style="fill:#343434"/><path d="M8.68,11h.9V16.2h-.9Zm6.64.07h-.9v5.1h.9Zm-3.77,1.25h.9V7.8h-.9ZM10.3,10.67v-1H8v1Zm.54,3.05h2.32v-1H10.84Zm5.2-3v-1H13.71v1ZM11.55,16.2h.9V14.08h-.9Zm-2-6.9V7.81H8.67V9.3Zm5.75.06V7.8h-.91V9.36Z" transform="translate(0 0)" style="fill:#075a9c"/></svg></span> <?php echo $label_details[77]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="expand"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="student_selected_courses_fields">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Table-->
                                                        <div class="cct-scrool">
                                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_disciplinary">
                                                                <!--begin::Table head-->
                                                                <thead >
                                                                    <tr>
                                                                        <th class="fw-bolder"> <?php echo $label_details[78]['name']; ?> </th>
                                                                        <th class="fw-bolder"> <?php echo $label_details[79]['name']; ?> </th>
                                                                    </tr>
                                                                </thead>
                                                                <!--end::Table head-->
                                                                <!--begin::Table body-->
                                                                <tbody class=" text-gray-800 actionBtns_table">
                                                                </tbody>
                                                                <!--end::Table body-->
                                                            </table>
                                                        </div>
                                                        <!--end::Table-->
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->
                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="absences_block">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 23.98"><path d="M6,2V0H8V2h8V0h2V2H22.9A1,1,0,0,1,24,3.1V22.8a1.67,1.67,0,0,1-.05.5,1,1,0,0,1-1,.68H1.08A1,1,0,0,1,0,22.9V3.12A1,1,0,0,1,.76,2a1.71,1.71,0,0,1,.39,0H6ZM22,8H2V22H22ZM12,16.29,15.63,20,17,18.54l-3.63-3.62,3.32-3.39L15.26,10.1l-3.39,3.39L8.56,10.16,7.11,11.59,10.51,15,6.85,18.56,8.33,20Z" transform="translate(0 -0.01)" style="fill:#f7090a"/></svg></span> <?php echo $label_details[80]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="expand"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="student_final_fields">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Table-->
                                                        <div class="cct-scrool">
                                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_absences">
                                                                <!--begin::Table head-->
                                                                <thead >
                                                                    <tr>
                                                                        <th class="fw-bolder"> <?php echo $label_details[81]['name']; ?> </th>
                                                                        <th class="fw-bolder"> <?php echo $label_details[82]['name']; ?> </th>
                                                                    </tr>
                                                                </thead>
                                                                <!--end::Table head-->
                                                                <!--begin::Table body-->
                                                                <tbody class=" text-gray-800 actionBtns_table">
                                                                </tbody>
                                                                <!--end::Table body-->
                                                            </table>
                                                        </div>
                                                        <!--end::Table-->
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->
                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_coaching_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[83]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="coaching_edit_id" style="display:none;">
                <form name="edit_coaching_form" id="edit_coaching_form" class="edit_coaching_form">
                    <a name="coaching_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[84]['name']; ?> <?php echo $label_details[85]['name']; ?></h3>
                                <button type="button" id="label_44_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-box px-8">
                            <div class="">&nbsp;</div>
                                                <!--begin::Toolbar-->
                            <div class="card-toolbar float-xxl-end">
                                <button type="button" id="edit_coaching_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[86]['name']; ?></button>
                            </div>
                            <!--end::Toolbar-->
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <h3><?php echo $label_details[87]['name']; ?></h3>
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[88]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_2_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[89]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1_up" role="tabpanel">
                                <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                                    <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[90]['name']; ?> *</label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <select class="form-select rounded-start-0" data-control="select2" id="coaching_category_id_up" name="coaching_category_id">
                                            </select>
                                            <input type="hidden" id="token_id" name="token_id" />
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[91]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <textarea id="student_agenda_up" name="student_agenda" rows="8"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[92]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <textarea id="personnel_agenda_up" name="personnel_agenda" rows="8"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[93]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <textarea id="protocol_up" name="protocol" rows="8"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[94]['name']; ?></label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <textarea id="arrangement_up" name="arrangement" rows="8"></textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[95]['name']; ?> *</label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                        <input class="form-control" placeholder="<?php echo $label_details[253]['name']; ?>" id="coaching_date_up" name="coaching_date" />
                                    </div>
                                </div>
                                <div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[96]['name']; ?></label>
                                    <div class="input-group">
                                        <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                        <input class="form-control" placeholder="<?php echo $label_details[253]['name']; ?>" id="deadline_date_up" name="deadline_date" />
                                    </div>
                                </div>
                                <div class="mb-10">
                                    <label class="fs-6 form-label text-dark"><?php echo $label_details[97]['name']; ?></label>
                                    <div class="form-check form-switch form-check-custom form-check-solid">
                                        <input class="form-check-input" type="checkbox" id="is_fulfilled_up" name="is_fulfilled" checked="checked">
                                    </div>
                                </div>
                                <div class="mb-10">
                                    <label class="fs-6 form-label text-dark"><?php echo $label_details[98]['name']; ?></label>
                                    <div class="form-check form-switch form-check-custom form-check-solid">
                                        <input class="form-check-input" type="checkbox" id="status_up" name="status" checked="checked">
                                    </div>
                                </div>
                                <div class="card-box">
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="edit_coaching_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[99]['name']; ?></button>
                                    </div>
                                    <div class="">&nbsp;</div>
                                    <!--end::Toolbar-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2_up" role="tabpanel">
                                <div class="card-body p-0 px-9">
                                    <div class="card mb-7 border">
                                        <div class="card-header hd-col-2" id="personal_data_container_up">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 20.53"><defs><style>.a{fill:#f46200;}</style></defs><path class="a" d="M1.73,22.25H0a8.23,8.23,0,0,1,5.28-7.76A6,6,0,0,1,2.58,9a5.78,5.78,0,0,1,2-4,6,6,0,0,1,8.27.22,5.8,5.8,0,0,1,1.7,4.87,5.94,5.94,0,0,1-2.67,4.38,8.42,8.42,0,0,1,5.32,7.77l-.17,0H15.39a6.56,6.56,0,0,0-2.83-5A6.87,6.87,0,0,0,7.93,16,6.68,6.68,0,0,0,1.73,22.25ZM4.22,9.44A4.28,4.28,0,1,0,8.51,5.16,4.27,4.27,0,0,0,4.22,9.44Zm9.8-6h7.12a1,1,0,0,1,1.14,1.13q0,7.42,0,14.84a1,1,0,0,1-1.12,1.13h-2c-.09,0-.2,0-.28,0v1.67c1.16,0,2.31,0,3.46,0A1.69,1.69,0,0,0,24,20.45V3.55a1.73,1.73,0,0,0-1.85-1.81H14c-.09,0-.18,0-.26,0V3.45Zm6.51,3.41V5.18H15.42V6.86Zm0,3.43V8.6H15.42v1.69Zm-5.1,3.42h5.1V12h-5.1Zm1.71,1.74v1.68h3.4V15.45Z" transform="translate(0 -1.73)"/></svg></span> <?php echo $label_details[100]['name']; ?></h4>
                                                <div class="tools">
                                                    <a href="javascript:;" class="collapse"></a>
                                                </div>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <!--begin::Card body-->
                                        <div class="card-body px-8 pb-7 pt-2" id="personal_data_fields_up">
                                            <!--begin::Compact form-->
                                            <div class="align-items-center">
                                                <!--begin::Col-->
                                                <div class="col-xxl-12">
                                                    <!--begin::Table-->
                                                    <div class="cct-scrool">
                                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="personal_data_details_up">
                                                            <img id="pv_profile_pic_up" width="100px" height="100px" alt="" class="avatar-img mb-4">
                                                            <!--begin::Table body-->
                                                            <tbody class=" text-gray-800 actionBtns_table">
                                                                <tr>
                                                                    <th class="left" width="20%"><?php echo $label_details[101]['name']; ?></th>
                                                                    <td><div id="pv_name_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[102]['name']; ?></th>
                                                                    <td><div id="pv_remarks_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[103]['name']; ?></th>
                                                                    <td><div id="pv_grade_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[104]['name']; ?></th>
                                                                    <td><div id="pv_personal_strengths_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[105]['name']; ?></th>
                                                                    <td><div id="pv_personal_weaknesses_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[106]['name']; ?></th>
                                                                    <td><div id="pv_career_goals_up"></div></td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[107]['name']; ?></th>
                                                                    <td> <div id="pv_permission_to_leave_school_up"></div>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <th class="left"><?php echo $label_details[108]['name']; ?></th>
                                                                    <td> <div id="pv_permission_to_smoke_up"></div>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                            <!--end::Table body-->
                                                        </table>
                                                    </div>
                                                    <!--end::Table-->
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Input group-->

                                                <!--end:Action-->
                                            </div>
                                            <!--end::Compact form-->
                                        </div>
                                        <!--end::Card body-->
                                    </div>
                                    <div class="card mb-7 border">
                                        <div class="card-header hd-col-2" id="marks_block_up">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15.63 24"><path d="M9.21,3.94A.18.18,0,0,1,9,3.76V1.29A1.26,1.26,0,0,0,8.65.38,1.24,1.24,0,0,0,7.74,0,1.29,1.29,0,0,0,6.45,1.29V3.76a.18.18,0,0,1-.18.18H3.87V5.17a.59.59,0,0,0,.59.59H11a.58.58,0,0,0,.59-.59V3.94ZM7.71,1.77a.51.51,0,0,1,0-1,.51.51,0,0,1,0,1ZM13.55,7.9H2.09V7.1H13.55Zm0,2.11H2.09v-.8H13.55Zm0,2.1H2.09v-.8H13.55Zm-.24,3.26L8.47,20.21,6.82,21.87h0L3,18.11a.68.68,0,0,1,0-1l.7-.7a.69.69,0,0,1,1,0l2.11,2.11,4.84-4.84a.67.67,0,0,1,1,0l.7.7A.67.67,0,0,1,13.31,15.37Zm1-12.52H9.49v.63h4.84a.67.67,0,0,1,.67.66V22.7a.66.66,0,0,1-.67.66H1.3a.65.65,0,0,1-.66-.66V4.15a.66.66,0,0,1,.66-.66H6V2.85H1.3A1.3,1.3,0,0,0,0,4.15V22.7A1.3,1.3,0,0,0,1.3,24h13a1.3,1.3,0,0,0,1.3-1.3V4.15A1.3,1.3,0,0,0,14.33,2.85Z" style="fill:#2c9f5a"/></svg></span> <?php echo $label_details[109]['name']; ?></h4>
                                                <div class="tools">
                                                    <a href="javascript:;" class="expand"></a>
                                                </div>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <!--begin::Card body-->
                                        <div class="card-body px-8 pb-7 pt-2" id="selected_students_up">
                                            <!--begin::Compact form-->
                                            <div class="align-items-center">
                                                <!--begin::Col-->
                                                <div class="col-xxl-12">
                                                    <!--begin::Table-->
                                                    <div class="cct-scrool">
                                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_marks_up">
                                                            <!--begin::Table head-->
                                                            <thead >
                                                                <tr>
                                                                    <th class="fw-bolder"> <?php echo $label_details[110]['name']; ?> </th>
                                                                    <th class="fw-bolder"> <?php echo $label_details[111]['name']; ?> </th>
                                                                    <th class="fw-bolder"> <?php echo $label_details[112]['name']; ?> </th>
                                                                </tr>
                                                            </thead>
                                                            <!--end::Table head-->
                                                            <!--begin::Table body-->
                                                            <tbody class=" text-gray-800 actionBtns_table">
                                                            </tbody>
                                                            <tfoot>
                                                                <tr>
                                                                    <th colspan="3"></th> 
                                                                </tr>
                                                            </tfoot>
                                                            <!--end::Table body-->
                                                        </table>
                                                    </div>
                                                    <!--end::Table-->
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Input group-->

                                                <!--end:Action-->
                                            </div>
                                            <!--end::Compact form-->
                                        </div>
                                        <!--end::Card body-->
                                    </div>
                                    <div class="card mb-7 border">
                                        <div class="card-header hd-col-2" id="marks_evolution_block_up">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.91 24"><defs><style>.a{fill:#27393f;}</style></defs><path class="a" d="M0,2.93H3.49v1H13.64c.09-.31,0-.64.06-1h3.46v9c-2.53-.82-4.61-.29-6.05,2.06a4.42,4.42,0,0,0,.4,5.32c1.48,1.87,3.43,2.18,5.65,1.47v3.24H0Zm7.05,7.13H11.7A1.31,1.31,0,0,0,12,10a.43.43,0,0,0,.35-.48.45.45,0,0,0-.4-.44,1.48,1.48,0,0,0-.3,0H2.51a1.6,1.6,0,0,0-.38,0,.44.44,0,0,0-.39.45A.43.43,0,0,0,2.1,10a1.31,1.31,0,0,0,.34,0Zm-1.22,2H2.37c-.42,0-.64.17-.64.48S2,13,2.35,13H9.28c.4,0,.6-.16.61-.46s-.21-.48-.63-.48ZM5.26,16c1,0,1.93,0,2.89,0,.4,0,.64-.19.63-.49S8.55,15,8.16,15H2.34c-.38,0-.61.18-.61.47s.23.48.6.48C3.31,16,4.29,16,5.26,16Zm-.62,2H2.31c-.33,0-.54.14-.57.47s.2.49.54.49H7a.5.5,0,0,0,.57-.48c0-.29-.21-.48-.58-.48Zm13.65,1,2.43,2.34c.28.27.56.53.84.81a1.88,1.88,0,0,1,.27.36.57.57,0,0,1-.17.78.61.61,0,0,1-.82-.13l-1.55-1.93-1.48-1.85a3.84,3.84,0,0,1-5.06-5.76,3.85,3.85,0,0,1,5.05-.21C19.46,14.7,19.64,16.75,18.29,19Zm-3.22-1.79L13.88,16a.48.48,0,1,0-.7.65c.51.53,1,1.06,1.55,1.57a.45.45,0,0,0,.75-.05c.2-.24.4-.49.59-.74l1.57-2c.24-.3.23-.59,0-.76s-.52-.11-.72.14l-.26.33ZM12.89,1.64h-2.7C9.84.44,9.43,0,8.57.07a1.67,1.67,0,0,0-1,.34A1.61,1.61,0,0,0,7,1.71H4.33V3.14h8.56Z" transform="translate(0 -0.06)"/></svg></span> <?php echo $label_details[113]['name']; ?></h4>
                                                <div class="tools">
                                                    <a href="javascript:;" class="expand"></a>
                                                </div>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <!--begin::Card body-->
                                        <div class="card-body px-8 pb-7 pt-2" id="student_courses_fields_up">
                                            <!--begin::Compact form-->
                                            <div class="align-items-center">
                                                <!--begin::Col-->
                                                <div class="col-xxl-12">
                                                    <!--begin::Row-->
                                                    <div class="row g-8">
                                                        <!--begin::Col-->
                                                        <div class="input-group">
                                                            <label class="fs-7 form-label text-dark"><?php echo $label_details[114]['name']; ?></label>
                                                            <!--begin::Select-->
                                                            <select class="form-select form-select-solid border" data-control="select2" id="subject_id_up" name="subject_id" multiple>
                                                            </select>
                                                            <!--end::Select-->
                                                        </div>
                                                        <!--end::Col-->
                                                        <!--begin::Col-->
                                                        <div class="input-group">
                                                            <label class="fs-7 form-label text-dark"><?php echo $label_details[115]['name']; ?></label>
                                                            <!--begin::Select-->
                                                            <select class="form-select form-select-solid border" data-control="select2" id="student_term_id_up" name="student_term_id" multiple>
                                                            </select>
                                                            <!--end::Select-->
                                                        </div>
                                                        <!--end::Col-->
                                                        <div class="col-lg-4 mt-16 w-md-250px">
                                                            <!--end::Input group-->
                                                            <!--begin:Action-->
                                                            <div class="fltl me-3">
                                                                <button type="button" id="mark_evolution_filter_up" name="mark_evolution_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                                    <i class="las la-filter"></i>
                                                                    <!--end::Svg Icon--><?php echo $label_details[116]['name']; ?>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <!--end::Col-->
                                                    </div>
                                                    <!--end::Row-->
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <div class="chart-container">
                                                                <div class="bar-chart-container">
                                                                    <canvas id="bar-chart_up"></canvas>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Input group-->

                                                <!--end:Action-->
                                            </div>
                                            <!--end::Compact form-->
                                        </div>
                                        <!--end::Card body-->
                                    </div>
                                    <div class="card mb-7 border">
                                        <div class="card-header hd-col-2" id="disciplinary_block_up">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0,13.36V10.64a1,1,0,0,1,1.09-.53c.43,0,.86,0,1.31,0A9.79,9.79,0,0,1,3.88,6.54c-.39-.39-.77-.76-1.15-1.15a.73.73,0,0,1,0-1.07c.53-.54,1.06-1.08,1.6-1.61a.74.74,0,0,1,.76-.17.82.82,0,0,1,.35.23l1.1,1.12A10.07,10.07,0,0,1,10.12,2.4V.83A.76.76,0,0,1,11,0H13a.77.77,0,0,1,.87.87V2.4a9.72,9.72,0,0,1,3.58,1.48c.36-.36.7-.71,1.05-1a.79.79,0,0,1,1.28,0l1.36,1.36a.81.81,0,0,1,0,1.34l-1,1a10.13,10.13,0,0,1,1.49,3.58h1.55A.76.76,0,0,1,24,11V13a.77.77,0,0,1-.87.86H21.6a9.72,9.72,0,0,1-1.48,3.58l1.1,1.09a.78.78,0,0,1,0,1.21l-1.42,1.42a.78.78,0,0,1-1.26,0l-1.07-1.07a10,10,0,0,1-3.58,1.48c0,.48,0,.94,0,1.4a.92.92,0,0,1-.58,1H10.64a1,1,0,0,1-.53-1.09c0-.43,0-.86,0-1.31a10,10,0,0,1-3.58-1.48c-.37.36-.72.73-1.08,1.08a.78.78,0,0,1-1.23,0L2.81,19.78a.79.79,0,0,1,0-1.26l1.07-1.06A9.52,9.52,0,0,1,3,15.74a10,10,0,0,1-.56-1.86H.79a.73.73,0,0,1-.59-.25C.13,13.55.07,13.45,0,13.36ZM12,4.22A7.78,7.78,0,1,0,19.78,12,7.78,7.78,0,0,0,12,4.22Z" transform="translate(0 0)" style="fill:#343434"/><path d="M8.68,11h.9V16.2h-.9Zm6.64.07h-.9v5.1h.9Zm-3.77,1.25h.9V7.8h-.9ZM10.3,10.67v-1H8v1Zm.54,3.05h2.32v-1H10.84Zm5.2-3v-1H13.71v1ZM11.55,16.2h.9V14.08h-.9Zm-2-6.9V7.81H8.67V9.3Zm5.75.06V7.8h-.91V9.36Z" transform="translate(0 0)" style="fill:#075a9c"/></svg></span> <?php echo $label_details[117]['name']; ?></h4>
                                                <div class="tools">
                                                    <a href="javascript:;" class="expand"></a>
                                                </div>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <!--begin::Card body-->
                                        <div class="card-body px-8 pb-7 pt-2" id="student_selected_courses_fields_up">
                                            <!--begin::Compact form-->
                                            <div class="align-items-center">
                                                <!--begin::Col-->
                                                <div class="col-xxl-12">
                                                    <!--begin::Table-->
                                                    <div class="cct-scrool">
                                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_disciplinary_up">
                                                            <!--begin::Table head-->
                                                            <thead >
                                                                <tr>
                                                                    <th class="fw-bolder"> <?php echo $label_details[118]['name']; ?> </th>
                                                                    <th class="fw-bolder"> <?php echo $label_details[119]['name']; ?> </th>
                                                                </tr>
                                                            </thead>
                                                            <!--end::Table head-->
                                                            <!--begin::Table body-->
                                                            <tbody class=" text-gray-800 actionBtns_table">
                                                            </tbody>
                                                            <!--end::Table body-->
                                                        </table>
                                                    </div>
                                                    <!--end::Table-->
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Input group-->
                                                <!--end:Action-->
                                            </div>
                                            <!--end::Compact form-->
                                        </div>
                                        <!--end::Card body-->
                                    </div>
                                    <div class="card mb-7 border">
                                        <div class="card-header hd-col-2" id="absences_block_up">
                                            <!--begin::Heading-->
                                            <div class="card-title">
                                                <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 23.98"><path d="M6,2V0H8V2h8V0h2V2H22.9A1,1,0,0,1,24,3.1V22.8a1.67,1.67,0,0,1-.05.5,1,1,0,0,1-1,.68H1.08A1,1,0,0,1,0,22.9V3.12A1,1,0,0,1,.76,2a1.71,1.71,0,0,1,.39,0H6ZM22,8H2V22H22ZM12,16.29,15.63,20,17,18.54l-3.63-3.62,3.32-3.39L15.26,10.1l-3.39,3.39L8.56,10.16,7.11,11.59,10.51,15,6.85,18.56,8.33,20Z" transform="translate(0 -0.01)" style="fill:#f7090a"/></svg></span> <?php echo $label_details[120]['name']; ?></h4>
                                                <div class="tools">
                                                    <a href="javascript:;" class="expand"></a>
                                                </div>
                                            </div>
                                            <!--end::Heading-->
                                        </div>
                                        <!--begin::Card body-->
                                        <div class="card-body px-8 pb-7 pt-2" id="student_final_fields_up">
                                            <!--begin::Compact form-->
                                            <div class="align-items-center">
                                                <!--begin::Col-->
                                                <div class="col-xxl-12">
                                                    <!--begin::Table-->
                                                    <div class="cct-scrool">
                                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_absences_up">
                                                            <!--begin::Table head-->
                                                            <thead >
                                                                <tr>
                                                                    <th class="fw-bolder"> <?php echo $label_details[121]['name']; ?> </th>
                                                                    <th class="fw-bolder"> <?php echo $label_details[122]['name']; ?> </th>
                                                                </tr>
                                                            </thead>
                                                            <!--end::Table head-->
                                                            <!--begin::Table body-->
                                                            <tbody class=" text-gray-800 actionBtns_table">
                                                            </tbody>
                                                            <!--end::Table body-->
                                                        </table>
                                                    </div>
                                                    <!--end::Table-->
                                                </div>
                                                <!--end::Col-->
                                                <!--begin::Input group-->
                                                <!--end:Action-->
                                            </div>
                                            <!--end::Compact form-->
                                        </div>
                                        <!--end::Card body-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_coaching_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[123]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>


            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_coaching" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[124]['name']; ?> <?php echo $label_details[254]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_44_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_coaching_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[126]['name']; ?> <?php echo $label_details[254]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_coaching_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[128]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[129]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

             <!--begin::Modal - Restore Module-->
             <div class="modal fade" id="restore_coaching" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[130]['name']; ?> <?php echo $label_details[255]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_44_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_coaching_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[131]['name']; ?> <?php echo $label_details[255]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_coaching_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[132]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[133]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->

            <!--begin::Modal - Import Module-->
            <div class="modal fade" id="import_coaching" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[134]['name']; ?> <?php echo $label_details[256]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_44_7" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                    </svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <form name="import_coaching_form" id="import_coaching_form" action="#" class="import_coaching_form">

                                <!--begin::Input group-->
                                <div class="form-group pst_relt">
                                    <div class="add_coaching_frm imp_file_cls">
                                        <div class="custom-file mb-4">
                                        <span class="uploadFile"><?php echo $label_details[226]['name']; ?></span>
                                            <input type="file" name="import_coaching_file" id="import_coaching_file" class="custom-file-input" accept=".xls" title="<?php echo $label_details[234]['name']; ?>">
                                            <label class="custom-file-label" for="customFile" id="import_label"><?php echo $label_details[135]['name']; ?></label>
                                            <input class="gui-input" id="import_uploader" style="display:none" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pst_relt mb-4">
                                    <div class="add_coaching_frm">
                                        <button type="button" class="btn btn-link" id="import_download_sample" ><i class="fa fa-download"></i> <span><?php echo $label_details[136]['name']; ?> <?php echo $label_details[256]['name']; ?></span></button>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="import_coaching_sub" class="btn btn-primary"><i class="las la-external-link-alt fs-5"></i><?php echo $label_details[137]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_import_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[138]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Import Module-->

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>Chart.js"></script>
<script src="<?php echo $js_path;?>coaching.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,student_table,selected=[],id="<?php  echo $user_det['id'];?>",term_fld="",tutor_fld="",student_fld="",deadline_fld="",coaching_date_fld="",status_fld="",del_fld="",term_details=[],teacher_details=[],grade_details=[],student_details=[],study_level_details=[],flag=false,selected_students=[],assign_selected_students=[],term_fld_list="",assigned_fld_list="",grade_fld_list="",teacher_fld_list="",study_level_fld_list="",status_fld_list="",student_fld_list="",term_id="",grade_id="",teacher_id="",study_level_id="",student_id="",term="",grade="",teacher="",study_level="",student="",coaching_type_details=[],student_details=[],marks_table,disciplinary_table,absences_table,mark_student_id="",mark_term_id="",barChartData="",subject_details=[],max_mark="",myChart=null,label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];
$(document).ready(function() {
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("285", role_details) != -1)
    {
        edit_role=true;
    }
    $("#coaching_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#coaching_date_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#coaching_date_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#deadline_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#deadline_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#deadline_date_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    coaching_details();
});
</script>  
