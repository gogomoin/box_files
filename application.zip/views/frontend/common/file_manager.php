<!--begin::Modal - File Manager Module-->
<div class="modal fade" id="file_manager" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered file_body_css">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header p-3">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[0]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mb-7 grey-col-bg">
				<div class="d-flex flex-column flex-column-fluid container-fluid file_css">	
					<!--begin::Post-->
					<div class="content flex-column-fluid" id="kt_content">
						<!--begin::Inbox App - Messages -->
						<div class="d-flex flex-column flex-lg-row">
							<!--begin::Sidebar-->
							<div class="flex-column flex-lg-row-auto w-100 w-lg-250px mb-10 mb-lg-0">
								<!--begin::Sticky aside-->
								<div class="card card-flush mb-0" data-kt-sticky="false" data-kt-sticky-name="inbox-aside-sticky" data-kt-sticky-offset="{default: false, xl: '0px'}" data-kt-sticky-width="{lg: '275px'}" data-kt-sticky-left="auto" data-kt-sticky-top="150px" data-kt-sticky-animation="false" data-kt-sticky-zindex="95">
									<!--begin::Aside content-->
									<div class="card-body vh-80 p-4 tree_css">
										<div id="kt_docs_jstree_contextual"></div>
									</div>
									<!--end::Aside content-->
								</div>
								<!--end::Sticky aside-->
							</div>
							<!--end::Sidebar-->
							<!--begin::Content-->
							
								<div class="flex-lg-row-fluid ms-lg-7 ms-xl-5">
									<div id="manage_files">
										<!--begin::Card-->
										<div class="card card-flush">
											<!--begin::Card header-->
											<div class="card-header pt-4 px-2">
												<!--begin::Card toolbar-->
												
												<!--begin::Toolbar-->
												<div class="d-flex justify-content-end pt-1" data-kt-filemanager-table-toolbar="base">
													<!--begin::Export-->
													<button type="button" class="btn btn-light-primary me-3 px-2" id="kt_folder_manager">
													<!--begin::Svg Icon | path: icons/duotune/files/fil013.svg-->
													<span class="svg-icon svg-icon-2">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
															<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black" />
															<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.2C9.7 3 10.2 3.20001 10.4 3.60001ZM16 12H13V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V12H8C7.4 12 7 12.4 7 13C7 13.6 7.4 14 8 14H11V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V14H16C16.6 14 17 13.6 17 13C17 12.4 16.6 12 16 12Z" fill="black" />
															<path opacity="0.3" d="M11 14H8C7.4 14 7 13.6 7 13C7 12.4 7.4 12 8 12H11V14ZM16 12H13V14H16C16.6 14 17 13.6 17 13C17 12.4 16.6 12 16 12Z" fill="black" />
														</svg>
													</span>
													<!--end::Svg Icon--><?php echo $file_manager_label_details[1]['name']; ?></button>
													<!--end::Export-->
													<?php if(in_array(317,$role_details)) { ?>
													<!--begin::Add customer-->
													<button type="button" class="btn btn-primary me-3 px-2" id="kt_upload_files">
													<!--begin::Svg Icon | path: icons/duotune/files/fil018.svg-->
													<span class="svg-icon svg-icon-2">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
															<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black" />
															<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM16 11.6L12.7 8.29999C12.3 7.89999 11.7 7.89999 11.3 8.29999L8 11.6H11V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V11.6H16Z" fill="black" />
															<path opacity="0.3" d="M11 11.6V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V11.6H11Z" fill="black" />
														</svg>
													</span>
													<!--end::Svg Icon--><?php echo $file_manager_label_details[2]['name']; ?></button>
													<!--end::Add customer-->
													<?php } ?>
												</div>
												<!--end::Toolbar-->
												<!--end::Card toolbar-->
											</div>
											<div class="card-header fil_head_css pt-4 px-2">
												<!--begin::Card toolbar-->
												<div class="card-toolbar my-0">
													<button type="button" id="allocate_logo_file" class="btn btn-sm btn-primary me-3 px-2"><?php echo $file_manager_label_details[3]['name']; ?> <i class="las la-plus fs-3"></i></button>
													<button type="button" id="delete_file_btn_id" class="btn btn-sm btn-danger me-3 px-2" data-target="#delete_file" data-toggle="modal"><?php echo $file_manager_label_details[4]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
													<button type="button" id="move_to_folder_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#move_to_folder" data-toggle="modal"><?php echo $file_manager_label_details[5]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
												</div>
												<!--end::Card toolbar-->
											</div>
											<!--end::Card header-->
											<div class="card-body p-4">
												<div class="alert alert-danger errYxt" id="upl_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
												<div class="alert alert-success errYxt" id="upl_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
												<div class="card mb-5 mb-lg-10 border pb-4" id="upload_files_block" style="display:none;">
													<form method="POST" name="kt_modal_upload_form" id="kt_modal_upload_form" class="kt_modal_upload_form" enctype="multipart/form-data">
														<a name="upload_files_form_create_id"></a>
														<!--begin::Card header-->
														<div class="card-header mb-2  hd-col-3">
															<!--begin::Heading-->
															<div class="card-title">
																<h3>
																	<span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																	<path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
																	<rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
																	<rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
																	<rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
																	<path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
																	</svg></span> <?php echo $file_manager_label_details[6]['name']; ?>
																</h3>
															</div>
															<div class="card-box px-8">
																<div class="">&nbsp;</div>
																					<!--begin::Toolbar-->
																<div class="card-toolbar float-xxl-end">
																	<!-- <button type="button" id="upload_files_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $file_manager_label_details[7]['name']; ?></button> -->
																	<button type="button" id="upload_files_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $file_manager_label_details[8]['name']; ?></button>
																</div>
																<!--end::Toolbar-->
															</div>
															<!--end::Heading-->
														</div>
														<!--end::Card header-->
														<!--begin::Card body-->
														<div class="card-body p-0 px-9">
															<div class="form-group pst_relt">
																<div class="row">
																	<div class="input-group up-imgWrap mb-2">
																		<div class="file btn btn-lg btn-primary up-image me-3">
																		<?php echo $file_manager_label_details[9]['name']; ?>
																			<input type="file" name="upload_material" id="upload_material"  multiple="multiple">
																		</div>
																		<div class="file btn btn-lg btn-primary up-image">
																		<?php echo $file_manager_label_details[117]['name']; ?>
																			<input type="file" name="upload_material_folder" id="upload_material_folder" onchange="getfolder(event)" webkitdirectory mozdirectory msdirectory odirectory directory multiple />
																		</div>
																	</div>
																	<!-- <div class="col-md-8 add_user_frm">
																		<label for="upload_material" class="field prepend-icon file file-fw upload_material" style="border: 1px solid rgb(238, 238, 238);">
																				<span class="button btn-primary">Choose File</span>
																				<input class="gui-file" name="upload_material" id="upload_material" type="file" style="border: 1px solid rgb(238, 238, 238);">
																				<input class="gui-input" id="import_uploader" placeholder="Attach Files" type="text" style="width:70%;">
																		</label>
																	</div> -->
																	<div class="col-sm-12">
																		<div id="fileuploadMessage"></div>
																	</div>
																	<input type="hidden" name="material_original_name" id="attachFilenames1" value="" />
																	<input type="hidden" name="material_unique_name" id="attachFilenames" value="" />
																	<input type="hidden" name="folder_id" id="kt_folder_id" value="" />
																</div>
															</div>
														</div>
														<!--end::Card body-->
													</form>
												</div>
												<table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="file-manager-table">
													<!--begin::Table head-->
													<thead >
														<tr>
															<th width="20px" rowspan="1" colspan="1">
																<label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
																	<input type="checkbox" id="file_table_check_all" class="group-checkable" name="file_table_check_all" >
																	<span></span>
																</label>
															</th>
															<th class="fw-bolder"> <?php echo $file_manager_label_details[10]['name']; ?> </th>
															<th class="fw-bolder"> <?php echo $file_manager_label_details[11]['name']; ?> </th>
															<th class="fw-bolder"> <?php echo $file_manager_label_details[12]['name']; ?> </th>
															<th class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $file_manager_label_details[13]['name']; ?> </th>
														</tr>
													</thead>
													<!--end::Table head-->
													<!--begin::Table body-->
													<tbody class=" text-gray-800 actionBtns_table" id="fm_table_css">
													</tbody>
													<!--end::Table body-->
												</table>
											</div>
										</div>
										<!--end::Card-->
									</div>
									<div id="manage_folders">
										<div class="card card-flush">
											<!--begin::Card header-->
											<div class="card-header p-4">
												<!--begin::Card toolbar-->
												
												<!--begin::Toolbar-->
												<div class="d-flex justify-content-end pt-1" data-kt-filemanager-table-toolbar="base">
													
													<!--begin::Export-->
													<button type="button" class="btn btn-light-primary me-3 px-2" id="kt_view_files">
													<!--begin::Svg Icon | path: icons/duotune/files/fil013.svg-->
													<span class="svg-icon svg-icon-2">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
															<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black" />
															<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.2C9.7 3 10.2 3.20001 10.4 3.60001ZM16 12H13V9C13 8.4 12.6 8 12 8C11.4 8 11 8.4 11 9V12H8C7.4 12 7 12.4 7 13C7 13.6 7.4 14 8 14H11V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V14H16C16.6 14 17 13.6 17 13C17 12.4 16.6 12 16 12Z" fill="black" />
															<path opacity="0.3" d="M11 14H8C7.4 14 7 13.6 7 13C7 12.4 7.4 12 8 12H11V14ZM16 12H13V14H16C16.6 14 17 13.6 17 13C17 12.4 16.6 12 16 12Z" fill="black" />
														</svg>
													</span>
													<!--end::Svg Icon--><?php echo $file_manager_label_details[14]['name']; ?></button>
													<!--end::Export-->
													<!--begin::Add customer-->
													<button type="button" class="btn btn-primary me-3 px-2" id="kt_file_manager_new_folder">
													<!--begin::Svg Icon | path: icons/duotune/files/fil018.svg-->
													<span class="svg-icon svg-icon-2">
														<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
															<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black" />
															<path d="M10.4 3.60001L12 6H21C21.6 6 22 6.4 22 7V19C22 19.6 21.6 20 21 20H3C2.4 20 2 19.6 2 19V4C2 3.4 2.4 3 3 3H9.20001C9.70001 3 10.2 3.20001 10.4 3.60001ZM16 11.6L12.7 8.29999C12.3 7.89999 11.7 7.89999 11.3 8.29999L8 11.6H11V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V11.6H16Z" fill="black" />
															<path opacity="0.3" d="M11 11.6V17C11 17.6 11.4 18 12 18C12.6 18 13 17.6 13 17V11.6H11Z" fill="black" />
														</svg>
													</span>
													<!--end::Svg Icon--><?php echo $file_manager_label_details[15]['name']; ?></button>
													<!--end::Add customer-->
												</div>
												<!--end::Toolbar-->
												<div class="card-toolbar my-0">
													<button type="button" id="delete_folder_btn_id" class="btn btn-sm btn-danger me-3 px-2" data-target="#delete_folder" data-toggle="modal"><?php echo $file_manager_label_details[16]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
													<button type="button" id="move_to_other_folder_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#move_to_other_folder" data-toggle="modal"><?php echo $file_manager_label_details[17]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
													<button type="button" id="copy_folder_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#copy_folder" data-toggle="modal"><?php echo $file_manager_label_details[18]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
												</div>
												<!--end::Card toolbar-->
											</div>
											<!--end::Card header-->
											<div class="card-body p-4">
												<div class="alert alert-danger errYxt" id="fol_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
												<div class="alert alert-success errYxt" id="fol_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
												<div class="folder_css" id="new_folder">
													<div class="d-flex align-items-center">
														<!--begin::Folder icon-->
														
														<!--begin::Svg Icon | path: icons/duotune/files/fil012.svg-->
														<span class="svg-icon svg-icon-2x svg-icon-primary me-4">
															<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																<path opacity="0.3" d="M10 4H21C21.6 4 22 4.4 22 5V7H10V4Z" fill="black"></path>
																<path d="M9.2 3H3C2.4 3 2 3.4 2 4V19C2 19.6 2.4 20 3 20H21C21.6 20 22 19.6 22 19V7C22 6.4 21.6 6 21 6H12L10.4 3.60001C10.2 3.20001 9.7 3 9.2 3Z" fill="black"></path>
															</svg>
														</span>
														<!--end::Svg Icon-->
														<!--end::Folder icon-->
														<!--begin:Input-->
														<input type="text" name="new_folder_name" id="new_folder_name" placeholder="Enter the folder name" class="form-control mw-250px me-3">
														<!--end:Input-->
														<!--begin:Submit button-->
														<button class="btn btn-icon btn-light-primary me-3" id="kt_file_manager_add_folder">
															<span class="indicator-label">
																<!--begin::Svg Icon | path: icons/duotune/arrows/arr085.svg-->
																<span class="svg-icon svg-icon-1">
																	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																		<path d="M9.89557 13.4982L7.79487 11.2651C7.26967 10.7068 6.38251 10.7068 5.85731 11.2651C5.37559 11.7772 5.37559 12.5757 5.85731 13.0878L9.74989 17.2257C10.1448 17.6455 10.8118 17.6455 11.2066 17.2257L18.1427 9.85252C18.6244 9.34044 18.6244 8.54191 18.1427 8.02984C17.6175 7.47154 16.7303 7.47154 16.2051 8.02984L11.061 13.4982C10.7451 13.834 10.2115 13.834 9.89557 13.4982Z" fill="black"></path>
																	</svg>
																</span>
																<!--end::Svg Icon-->
															</span>
															<span class="indicator-progress">
																<span class="spinner-border spinner-border-sm align-middle"></span>
															</span>
														</button>
														<!--end:Submit button-->
														<!--begin:Cancel button-->
														<button class="btn btn-icon btn-light-danger" id="kt_file_manager_cancel_folder">
															<span class="indicator-label">
																<!--begin::Svg Icon | path: icons/duotune/arrows/arr088.svg-->
																<span class="svg-icon svg-icon-1">
																	<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
																		<rect opacity="0.5" x="7.05025" y="15.5356" width="12" height="2" rx="1" transform="rotate(-45 7.05025 15.5356)" fill="black"></rect>
																		<rect x="8.46447" y="7.05029" width="12" height="2" rx="1" transform="rotate(45 8.46447 7.05029)" fill="black"></rect>
																	</svg>
																</span>
																<!--end::Svg Icon-->
															</span>
															<span class="indicator-progress">
																<span class="spinner-border spinner-border-sm align-middle"></span>
															</span>
														</button>
														<!--end:Cancel button-->
													</div>
												</div>
												<table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="folder-manager-table">
													<!--begin::Table head-->
													<thead >
														<tr>
															<th width="10%" rowspan="1" colspan="1">
																<label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
																	<input type="checkbox" id="folder_table_check_all" class="group-checkable" name="folder_table_check_all" >
																	<span></span>
																</label>
															</th>
															<th class="fw-bolder"> <?php echo $file_manager_label_details[19]['name']; ?> </th>
															<th class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $file_manager_label_details[20]['name']; ?> </th>
														</tr>
													</thead>
													<!--end::Table head-->
													<!--begin::Table body-->
													<tbody class=" text-gray-800 actionBtns_table">
													</tbody>
													<!--end::Table body-->
												</table>
											</div>
										</div>
									</div>
								</div><!--begin::Manage Files Mark-->
							
							
							<!--end::Content-->
						</div>
						<!--end::Inbox App - Messages -->
					</div>
					<!--end::Post-->
				</div>
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - File Manager Module-->
<!--begin::Modal - File Delete Module-->
<div class="modal fade" id="delete_file" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[21]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="file_del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="file_del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="delete_file_form">
					<!--begin::Input group-->
					<div class="fv-row mb-10">
						<div class="me-5 fw-bold text-center">
							<label class="fs-6"><?php echo $file_manager_label_details[22]['name']; ?></label>
						</div>
					</div>
					<!--end::Input group-->
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="delete_file_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[23]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_file_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[24]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--begin::Modal - File Move To Folder Module-->
<div class="modal fade" id="move_to_folder" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[25]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="mov_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="mov_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="move_to_folder_file_form">
					<div id="folder_jstree"></div>
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="move_to_folder_file_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[26]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_move_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[27]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - move_to_folder Module-->
<!--begin::Modal - Rename Module-->
<div class="modal fade" id="rename_file" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[28]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="ren_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="ren_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="rename_file_form">
					<label class="fs-6"><?php echo $file_manager_label_details[29]['name']; ?></label>
					<input type="text" name="new_file_name" id="new_file_name" class="form-control mt-2 me-3 mb-4">
					<input type="hidden" name="token_id" id="token_id" />
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="rename_file_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[30]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_ren_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[31]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - rename Module-->

<!--begin:: Folder Manager Modals -->

<!--begin::Modal - Folder Delete Module-->
<div class="modal fade" id="delete_folder" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[32]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="fol_del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="fol_del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="delete_folder_form">
					<!--begin::Input group-->
					<div class="fv-row mb-10">
						<div class="me-5 fw-bold text-center">
							<label class="fs-6"><?php echo $file_manager_label_details[33]['name']; ?></label>
						</div>
					</div>
					<!--end::Input group-->
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="delete_folder_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[34]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_fol_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[35]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--begin::Modal - Folder Move To Folder Module-->
<div class="modal fade" id="move_to_other_folder" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[36]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="mov_oth_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="mov_oth_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="move_to_folder_form">
					<div id="folder_jstree_move"></div>
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="move_to_folder_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[37]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_move_oth_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[38]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - move_to_folder Module-->

<!--begin::Modal - Folder Move To Folder Module-->
<div class="modal fade" id="copy_folder" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[39]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="copy_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="copy_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="copy_folder_form">
					<div id="folder_jstree_copy"></div>
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="copy_folder_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[40]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_copy_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[41]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - move_to_folder Module-->

<!--begin::Modal - Rename Folder Module-->
<div class="modal fade" id="rename_folder" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $file_manager_label_details[42]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<div class="alert alert-danger errYxt" id="ren_fol_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
				<div class="alert alert-success errYxt" id="ren_fol_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
				<!--begin::Form-->
				<div class="rename_folder_form">
					<label class="fs-6"><?php echo $file_manager_label_details[43]['name']; ?></label>
					<input type="text" name="new_folder_name" id="new_other_folder_name" class="form-control mw-250px me-3 mb-4">
					<input type="hidden" name="folder_token_id" id="folder_token_id" />
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="rename_folder_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $file_manager_label_details[44]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_ren_oth_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $file_manager_label_details[45]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - rename Folder Module-->
<!--begin::Modal - Rename Folder Module-->
<div class="modal fade" id="pdf_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-fullscreen">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="pdf_close_cls">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
							<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
							<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
						</svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y">
				<div id="pdf_container"></div>
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - rename Folder Module-->
<?php echo $video_modal; ?>



