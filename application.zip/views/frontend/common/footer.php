<?php
    $user_det = $this->session->userdata('user_det');
 ?>
<!--begin::Modal - Dashboard Module-->
 <div class="modal fade" id="dashboard_breadcrumb" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
	<!--begin::Modal dialog-->
	<div class="modal-dialog modal-dialog-centered mw-650px">
		<!--begin::Modal content-->
		<div class="modal-content">
			<!--begin::Modal header-->
			<div class="modal-header">
				<!--begin::Modal title-->
				<h2 class="fw-bolder"><?php echo $dash_label_details[108]['name']; ?></h2>
				<!--end::Modal title-->
				<!--begin::Close-->
				<div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
					<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
					<span class="svg-icon svg-icon-1">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
					</span>
					<!--end::Svg Icon-->
				</div>
				<!--end::Close-->
			</div>
			<!--end::Modal header-->
			<!--begin::Modal body-->
			<div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
				<!--begin::Form-->
				<div class="dashboard_breadcrumb_form">
					<!--begin::Input group-->
					<div class="fv-row mb-10">
						<div class="me-5 fw-bold text-center">
							<label class="fs-6"><?php echo $dash_label_details[109]['name']; ?>?</label>
						</div>
					</div>
					<!--end::Input group-->
					<!--begin::Actions-->
					<div class="text-center">
						<button type="button" id="dashboard_breadcrumb_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $dash_label_details[110]['name']; ?>
						</button>
						<button type="button" class="btn btn-danger me-3" id="close_com_das_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $dash_label_details[111]['name']; ?></button>
					</div>
					<!--end::Actions-->
				</div>
				<!--end::Form-->
			</div>
			<!--end::Modal body-->
		</div>
		<!--end::Modal content-->
	</div>
	<!--end::Modal dialog-->
</div>
<!--end::Modal - Dashboard Module-->
 <!--begin::Footer-->
 <div class="footer py-4 d-flex flex-column flex-md-row flex-stack" id="kt_footer">
        <!--begin::Copyright-->
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-bold me-1">All Copyrights ProScola GmbH | ProScola - Build <?php echo $footer_build_no ?></span>
        </div>
        <!--end::Copyright-->
    </div>
    <!--end::Footer-->
</div>
<!--end::Container-->
</div>

					<!--end::Content wrapper-->
				</div>
				<!--end::Wrapper-->
			</div>
			<!--end::Page-->
		</div>
		<!--end::Root-->
		<!--begin::Drawers-->
		
		<!--begin::Chat drawer-->
		<div id="kt_drawer_chat" class="bg-body" data-kt-drawer="true" data-kt-drawer-name="chat" data-kt-drawer-activate="true" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'300px', 'md': '500px'}" data-kt-drawer-direction="end" data-kt-drawer-toggle="#kt_drawer_chat_toggle" data-kt-drawer-close="#kt_drawer_chat_close">
			<!--begin::Messenger-->
			<div class="card w-100 rounded-0 border-0" id="kt_drawer_chat_messenger">
				<!--begin::Card header-->
				<div class="card-header pe-5" id="kt_drawer_chat_messenger_header">
					<!--begin::Title-->
					<div class="card-title">
						<!--begin::User-->
						<div class="d-flex justify-content-center flex-column me-3">
							<a class="fs-4 fw-bolder text-gray-900 text-hover-primary me-1 mb-2 lh-1"><?php echo $menu_details[63]['name']; ?></a>
						</div>
						<!--end::User-->
					</div>
					<!--end::Title-->
					<!--begin::Card toolbar-->
					<div class="card-toolbar">
						<!--begin::Menu-->
						<div class="me-2">
							<a href="<?php echo $base_url; ?>notifications" class="btn btn-sm btn-flex btn-primary me-lg-4">
								<!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="14.3" viewBox="0 0 24 21.453">
										<path id="view_all" data-name="view all" d="M11.984,21.453a2.269,2.269,0,0,0-.363-.2L.143,15.391C.1,15.37.049,15.361.02,15.309c.776-.4,1.55-.79,2.323-1.188a.152.152,0,0,1,.158.017l2.738,1.4q3.339,1.7,6.678,3.41a.182.182,0,0,0,.19,0q4.7-2.4,9.394-4.8a.215.215,0,0,1,.224,0c.755.39,1.512.775,2.273,1.163-.017.047-.061.052-.093.068L12.4,21.256a2.534,2.534,0,0,0-.362.2ZM0,10.74c.053-.022.088.021.126.041Q6.02,13.788,11.912,16.8a.181.181,0,0,0,.189,0q5.908-3.022,11.819-6.039c.026-.014.065-.015.073-.061l-.118-.062c-.709-.363-1.42-.724-2.127-1.09a.26.26,0,0,0-.268,0q-4.68,2.4-9.362,4.786a.206.206,0,0,1-.214,0q-4.68-2.394-9.362-4.787a.258.258,0,0,0-.268,0Q1.2,10.108.115,10.655c-.034.017-.065.066-.115.035ZM23.9,6.053Q18.011,3.042,12.12.03a.216.216,0,0,0-.223,0Q6.3,2.9.691,5.758l-.684.351c.031.019.046.03.063.038Q6,9.173,11.92,12.2a.184.184,0,0,0,.191-.007q4.336-2.217,8.674-4.432L24,6.12a.19.19,0,0,0-.1-.067m-4.937.6q-3.421,1.749-6.841,3.5a.225.225,0,0,1-.234,0q-3.9-2-7.811-4l-.067-.035c.012-.049.058-.052.091-.069q3.911-2,7.821-4a.164.164,0,0,1,.17,0q3.91,2,7.822,4c.032.016.062.035.107.061l-1.058.541" transform="translate(0 0)" fill="#ffffff"/>
									</svg>
								<!--end::Svg Icon-->&nbsp;<?php echo $menu_details[64]['name']; ?>
							</a>
						</div>
						<!--end::Menu-->
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-light-primary" id="kt_drawer_chat_close">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-2">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Card toolbar-->
				</div>
				<!--end::Card header-->
				<!--begin::Card body-->
				<div class="card-body" id="kt_drawer_chat_messenger_body">
					<!--begin::Messages-->
					<div class="scroll-y me-n5 pe-5" data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_drawer_chat_messenger_header, #kt_drawer_chat_messenger_footer" data-kt-scroll-wrappers="#kt_drawer_chat_messenger_body" data-kt-scroll-offset="0px">
						<div id="drawer_msg_display"></div>
					</div>
					<!--end::Messages-->
				</div>
				<!--end::Card body-->
				<!--begin::Card footer-->
				
				<!--end::Card footer-->
			</div>
			<!--end::Messenger-->
		</div>
		<!--end::Chat drawer-->
		<!--end::Drawers-->
		<!--end::Main-->
		<!--begin::Engage drawers-->
		<!--begin::Demos drawer-->

		<!--end::Demos drawer-->
		<!--end::Engage drawers-->
		<!--begin::Engage toolbar-->

		<!--end::Engage toolbar-->
		<!--begin::Scrolltop-->
		<?php echo $bulk_label_modal; ?>
		<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">
			<!--begin::Svg Icon | path: icons/duotune/arrows/arr066.svg-->
			<span class="svg-icon">
				<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
					<rect opacity="0.5" x="13" y="6" width="13" height="2" rx="1" transform="rotate(90 13 6)" fill="black" />
					<path d="M12.5657 8.56569L16.75 12.75C17.1642 13.1642 17.8358 13.1642 18.25 12.75C18.6642 12.3358 18.6642 11.6642 18.25 11.25L12.7071 5.70711C12.3166 5.31658 11.6834 5.31658 11.2929 5.70711L5.75 11.25C5.33579 11.6642 5.33579 12.3358 5.75 12.75C6.16421 13.1642 6.83579 13.1642 7.25 12.75L11.4343 8.56569C11.7467 8.25327 12.2533 8.25327 12.5657 8.56569Z" fill="black" />
				</svg>
			</span>
			<!--end::Svg Icon-->
		</div>
	</div>
		<!--end::Scrolltop-->
		<!--begin::Javascript-->
		<script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="<?php echo $plugins_global_path; ?>plugins.bundle.js"></script>
		<script src="<?php echo $js_path; ?>scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Vendors Javascript(used by this page)-->
		<script src="<?php echo $plugins_custom_path; ?>fullcalendar/fullcalendar.bundle.js"></script>
		<script src="<?php echo $plugins_custom_path; ?>datatables/datatables.bundle.js"></script>
		<!--end::Page Vendors Javascript-->
		<!--begin::Page Custom Javascript(used by this page)-->
		<script src="<?php echo $js_path; ?>custom/widgets.js"></script>
		<script src="<?php echo $js_path; ?>custom/apps/chat/chat.js"></script>
		<script src="<?php echo $js_path; ?>custom/modals/create-app.js"></script>
		<script src="<?php echo $js_path; ?>custom/modals/users-search.js"></script>
		<script src="<?php echo $js_path;?>common.js"></script>
		<script src="<?php echo $js_path;?>header.js"></script>
		<script src="<?php echo $js_path; ?>datatables.min.js" type="text/javascript"></script>
		<script src="<?php echo $js_path;?>viewer.js"></script>
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>
<script>
	var  baseurl_fot="<?php  echo $base_url;?>",lang_details=<?php echo json_encode($lang_details); ?>,system_bulk_label_selected=[],item_per_page="<?php  echo $item_per_page;?>",item_arr=['10','25','50','100'],files_order=[];
	msg_block();
	lang_view();
</script>
