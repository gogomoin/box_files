<!DOCTYPE html>
<?php
    $user_det = $this->session->userdata('user_det');
	$title=strtolower($menu_details[54]['name']);
	$title=ucfirst($title);
 ?>
 <style>
	 html {
touch-action: manipulation;
}
	 </style>
 

<html lang="en">
	<!--begin::Head-->
	<head><base href="../">
		<title>ProScola <?php echo $title; ?></title>
		<meta charset="utf-8" />
		<meta HTTP-EQUIV="MSThemeCompatible" content="Yes" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
		<link rel="shortcut icon" href="<?php echo $media_path; ?>logos/favicon.ico" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Page Vendor Stylesheets(used by this page)-->
		<link href="<?php echo $plugins_custom_path; ?>fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $plugins_custom_path; ?>datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Page Vendor Stylesheets-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<link href="<?php echo $plugins_global_path; ?>plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>viewer.css" rel="stylesheet" type="text/css" />
		
		<!--end::Global Stylesheets Bundle-->
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
		<!--begin::Main-->
		<!--begin::Root-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Page-->
			<div class="page d-flex flex-row flex-column-fluid">
				<!--begin::Wrapper-->
				<div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
					<!--begin::Header-->
					<div id="kt_header" class="header">
						<!--begin::Container-->
						<div class="container-fluid d-flex flex-stack">
							<!--begin::Brand-->
							<div class="d-flex align-items-center me-5">
								<!--begin::Aside toggle-->
								<div class="d-lg-none btn btn-icon btn-active-color-white w-30px h-30px ms-n2 me-3" id="kt_aside_toggle">
									<!--begin::Svg Icon | path: icons/duotune/abstract/abs015.svg-->
									<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
										viewBox="0 0 20 11" style="enable-background:new 0 0 20 11;" xml:space="preserve">
									<style type="text/css">
										.st0{fill:#FFFFFF;}
									</style>
									<g>
										<rect class="st0" width="12" height="1"/>
									</g>
									<g>
										<rect y="3" class="st0" width="12" height="1"/>
									</g>
									<g>
										<rect y="6" class="st0" width="12" height="1"/>
									</g>
									</svg>
									<!--end::Svg Icon-->
								</div>
								<!--end::Aside  toggle-->
								<!--begin::Logo-->
								<a href="<?php echo $base_url; ?>" class="">
									<img alt="Logo" src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $header_logo_image; ?>" class="h-40px" />
								</a>
								<!--end::Logo-->
								<!--begin::Nav-->
								
								<!--end::Nav-->
							</div>
							<!--end::Brand-->
							<!--begin::Topbar-->
							<div class="d-flex align-items-center">
								<!--begin::Topbar-->
								<div class="d-flex align-items-center flex-shrink-0">
									
									<!--begin::Chat-->
									<div class="d-flex align-items-center ms-1">
										<!--begin::Menu wrapper-->
										<div class="btn btn-icon btn-color-white bg-hover-white bg-hover-opacity-10 w-30px h-30px h-40px w-40px position-relative" id="kt_drawer_chat_toggle">
											<!--begin::Svg Icon | path: icons/duotune/communication/com012.svg-->
											<span class="svg-icon svg-icon-2">
												<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
													<path opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="black" />
													<rect x="6" y="12" width="7" height="2" rx="1" fill="black" />
													<rect x="6" y="7" width="12" height="2" rx="1" fill="black" />
												</svg>
											</span>
											<!--end::Svg Icon-->
											<div id="blink"><span class="bullet bullet-dot bg-success h-6px w-6px position-absolute translate-middle top-0 start-50 animation-blink"></span></div>
										</div>
										<!--end::Menu wrapper-->
									</div>
									<!--end::Chat-->
									<!--begin::User-->
									<div class="d-flex align-items-center ms-1" id="kt_header_user_menu_toggle">
										<!--begin::User info-->
										<div class="btn btn-flex align-items-center bg-hover-white bg-hover-opacity-10 py-2 px-2 px-md-3" data-kt-menu-trigger="click" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">
											<!--begin::Name-->
											<div class="d-none d-md-flex flex-column align-items-end justify-content-center me-2 me-md-4">
												<span class="text-white fs-8 fw-bold lh-1 mb-1"> <?php echo $user_det['name']; ?> </span>
											</div>
											<!--end::Name-->
											<!--begin::Symbol-->
											<div class="symbol symbol-30px symbol-md-40px">
												<?php if($user_det['avatar']=='') { ?>
													<img src="<?php echo $media_path; ?>avatars/user.png" alt="image" />
												<?php } else { ?>
													<img src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $user_det['avatar']; ?>" alt="image" />
												<?php }  ?>
											</div>
											<!--end::Symbol-->
										</div>
										<!--end::User info-->
										<!--begin::Menu-->
										<div class="menu menu-sub menu-sub-dropdown menu-column menu-rounded menu-gray-800 menu-state-bg menu-state-primary fw-bold py-4 fs-6 w-275px" data-kt-menu="true">
											<!--begin::Menu item-->
											<div class="menu-item px-3">
												<div class="menu-content d-flex align-items-center px-3">
													<!--begin::Avatar-->
													<div class="symbol symbol-50px me-5">
													<?php if($user_det['avatar']=='') { ?>
														<img src="<?php echo $media_path; ?>avatars/user.png" alt="image" />
													<?php } else { ?>
														<img src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $user_det['avatar']; ?>" alt="image" />
													<?php }  ?>
													</div>
													<!--end::Avatar-->
													<!--begin::Username-->
													<div class="d-flex flex-column">
														<div class="fw-bolder d-flex align-items-center fs-5"><?php echo $user_det['name']; ?>
														</div>
														<a class="fw-bold text-muted text-hover-primary fs-7"><?php echo $user_det['email']; ?></a>
													</div>
													<!--end::Username-->
												</div>
											</div>
											<!--end::Menu item-->
											<!--begin::Menu separator-->
											<div class="separator my-2"></div>
											<!--end::Menu separator-->
											<!--begin::Menu item-->
											<div class="menu-item px-5">
												<a href="<?php echo $base_url; ?>timetable_weekly" class="menu-link px-5"><?php echo $menu_details[58]['name']; ?></a>
											</div>
											<!--end::Menu item-->
											<!--begin::Menu item-->
											<div class="menu-item px-5">
												<a href="<?php echo $base_url; ?>notifications" class="menu-link px-5">
													<span class="menu-text"><?php echo $menu_details[59]['name']; ?></span>
												</a>
											</div>
											<!--end::Menu item-->
											<!--begin::Menu separator-->
											<div class="separator my-2"></div>
											<!--end::Menu separator-->
											<!--begin::Menu item-->
											<div class="menu-item px-5" data-kt-menu-trigger="hover" data-kt-menu-placement="left-start">
												<a class="menu-link px-5">
													<span class="menu-title position-relative"><?php echo $menu_details[60]['name']; ?>
													<span class="fs-8 rounded bg-light px-3 py-2 position-absolute translate-middle-y top-50 end-0"><span id="default_lang"></span>
													</span></span>
												</a>
												<!--begin::Menu sub-->
												<div class="menu-sub menu-sub-dropdown w-175px py-4">
													<div id="display_lang"></div>
												</div>
												<!--end::Menu sub-->
											</div>
											<!--end::Menu item-->
											<!--begin::Menu item-->
											<div class="menu-item px-5 my-1">
												<a href="<?php echo $base_url; ?>change_password" class="menu-link px-5"><?php echo $menu_details[61]['name']; ?></a>
											</div>
											<!--end::Menu item-->
											<!--begin::Menu item-->
											<div class="menu-item px-5">
												<a href="<?php echo $base_url; ?>logout" class="menu-link px-5"><?php echo $menu_details[62]['name']; ?></a>
											</div>
											<!--end::Menu item-->
											<!--begin::Menu separator-->
											<div class="separator my-2"></div>
											<!--end::Menu separator-->
										</div>
										<!--end::Menu-->
									</div>
									<!--end::User -->
								</div>
								<!--end::Topbar-->
							</div>
							<!--end::Topbar-->
						</div>
						<!--end::Container-->
					</div>
					<!--end::Header-->
<script>
	var lang_head_id=<?php echo $user_det['lang_id']; ?>,no_msg_found='<?php echo $menu_details[65]['name']; ?>';
</script>