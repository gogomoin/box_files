<?php
$user_det = $this->session->userdata('user_det');
?>
<!--begin::Content wrapper-->
<div class="d-flex flex-column-fluid">
<!--begin::Aside-->
<div id="kt_aside" class="aside card border" data-kt-drawer="true" data-kt-drawer-name="aside" data-kt-drawer-activate="{default: true, lg: false}" data-kt-drawer-overlay="true" data-kt-drawer-width="{default:'200px', '300px': '250px'}" data-kt-drawer-direction="start" data-kt-drawer-toggle="#kt_aside_toggle">
    <!--begin::Aside menu-->
    <div class="aside-menu flex-column-fluid px-5">
        <!--begin::Aside Menu-->
        <div class="hover-scroll-overlay-y my-5 pe-4 me-n4" id="kt_aside_menu_wrapper" data-kt-scroll="true" data-kt-scroll-activate="{default: false, lg: true}" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_header, #kt_aside_footer" data-kt-scroll-wrappers="#kt_aside, #kt_aside_menu" data-kt-scroll-offset="{lg: '75px'}">
            <!--begin::Menu-->
            <div class="menu menu-column menu-rounded fw-bold fs-6" id="#kt_aside_menu" data-kt-menu="true">

                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='') echo "active"; ?>" href="<?php echo $base_url; ?>">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/general/gen025.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect x="2" y="2" width="9" height="9" rx="2" fill="black" />
                                    <rect opacity="0.3" x="13" y="2" width="9" height="9" rx="2" fill="black" />
                                    <rect opacity="0.3" x="13" y="13" width="9" height="9" rx="2" fill="black" />
                                    <rect opacity="0.3" x="2" y="13" width="9" height="9" rx="2" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">DASHBOARD</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='timeline') echo "active"; ?>" href="<?php echo $base_url; ?>timeline">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/ecommerce/ecm007.svg-->
                            <span class="svg-icon svg-icon-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path opacity="0.3" d="M20.9 12.9C20.3 12.9 19.9 12.5 19.9 11.9C19.9 11.3 20.3 10.9 20.9 10.9H21.8C21.3 6.2 17.6 2.4 12.9 2V2.9C12.9 3.5 12.5 3.9 11.9 3.9C11.3 3.9 10.9 3.5 10.9 2.9V2C6.19999 2.5 2.4 6.2 2 10.9H2.89999C3.49999 10.9 3.89999 11.3 3.89999 11.9C3.89999 12.5 3.49999 12.9 2.89999 12.9H2C2.5 17.6 6.19999 21.4 10.9 21.8V20.9C10.9 20.3 11.3 19.9 11.9 19.9C12.5 19.9 12.9 20.3 12.9 20.9V21.8C17.6 21.3 21.4 17.6 21.8 12.9H20.9Z" fill="black"/>
<path d="M16.9 10.9H13.6C13.4 10.6 13.2 10.4 12.9 10.2V5.90002C12.9 5.30002 12.5 4.90002 11.9 4.90002C11.3 4.90002 10.9 5.30002 10.9 5.90002V10.2C10.6 10.4 10.4 10.6 10.2 10.9H9.89999C9.29999 10.9 8.89999 11.3 8.89999 11.9C8.89999 12.5 9.29999 12.9 9.89999 12.9H10.2C10.4 13.2 10.6 13.4 10.9 13.6V13.9C10.9 14.5 11.3 14.9 11.9 14.9C12.5 14.9 12.9 14.5 12.9 13.9V13.6C13.2 13.4 13.4 13.2 13.6 12.9H16.9C17.5 12.9 17.9 12.5 17.9 11.9C17.9 11.3 17.5 10.9 16.9 10.9Z" fill="black"/>
</svg></span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">TIMELINE</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='timetable_weekly') echo "active"; ?>" href="<?php echo $base_url; ?>timetable_weekly">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/general/gen014.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21 22H3C2.4 22 2 21.6 2 21V5C2 4.4 2.4 4 3 4H21C21.6 4 22 4.4 22 5V21C22 21.6 21.6 22 21 22Z" fill="black" />
                                    <path d="M6 6C5.4 6 5 5.6 5 5V3C5 2.4 5.4 2 6 2C6.6 2 7 2.4 7 3V5C7 5.6 6.6 6 6 6ZM11 5V3C11 2.4 10.6 2 10 2C9.4 2 9 2.4 9 3V5C9 5.6 9.4 6 10 6C10.6 6 11 5.6 11 5ZM15 5V3C15 2.4 14.6 2 14 2C13.4 2 13 2.4 13 3V5C13 5.6 13.4 6 14 6C14.6 6 15 5.6 15 5ZM19 5V3C19 2.4 18.6 2 18 2C17.4 2 17 2.4 17 3V5C17 5.6 17.4 6 18 6C18.6 6 19 5.6 19 5Z" fill="black" />
                                    <path d="M8.8 13.1C9.2 13.1 9.5 13 9.7 12.8C9.9 12.6 10.1 12.3 10.1 11.9C10.1 11.6 10 11.3 9.8 11.1C9.6 10.9 9.3 10.8 9 10.8C8.8 10.8 8.59999 10.8 8.39999 10.9C8.19999 11 8.1 11.1 8 11.2C7.9 11.3 7.8 11.4 7.7 11.6C7.6 11.8 7.5 11.9 7.5 12.1C7.5 12.2 7.4 12.2 7.3 12.3C7.2 12.4 7.09999 12.4 6.89999 12.4C6.69999 12.4 6.6 12.3 6.5 12.2C6.4 12.1 6.3 11.9 6.3 11.7C6.3 11.5 6.4 11.3 6.5 11.1C6.6 10.9 6.8 10.7 7 10.5C7.2 10.3 7.49999 10.1 7.89999 10C8.29999 9.90003 8.60001 9.80003 9.10001 9.80003C9.50001 9.80003 9.80001 9.90003 10.1 10C10.4 10.1 10.7 10.3 10.9 10.4C11.1 10.5 11.3 10.8 11.4 11.1C11.5 11.4 11.6 11.6 11.6 11.9C11.6 12.3 11.5 12.6 11.3 12.9C11.1 13.2 10.9 13.5 10.6 13.7C10.9 13.9 11.2 14.1 11.4 14.3C11.6 14.5 11.8 14.7 11.9 15C12 15.3 12.1 15.5 12.1 15.8C12.1 16.2 12 16.5 11.9 16.8C11.8 17.1 11.5 17.4 11.3 17.7C11.1 18 10.7 18.2 10.3 18.3C9.9 18.4 9.5 18.5 9 18.5C8.5 18.5 8.1 18.4 7.7 18.2C7.3 18 7 17.8 6.8 17.6C6.6 17.4 6.4 17.1 6.3 16.8C6.2 16.5 6.10001 16.3 6.10001 16.1C6.10001 15.9 6.2 15.7 6.3 15.6C6.4 15.5 6.6 15.4 6.8 15.4C6.9 15.4 7.00001 15.4 7.10001 15.5C7.20001 15.6 7.3 15.6 7.3 15.7C7.5 16.2 7.7 16.6 8 16.9C8.3 17.2 8.6 17.3 9 17.3C9.2 17.3 9.5 17.2 9.7 17.1C9.9 17 10.1 16.8 10.3 16.6C10.5 16.4 10.5 16.1 10.5 15.8C10.5 15.3 10.4 15 10.1 14.7C9.80001 14.4 9.50001 14.3 9.10001 14.3C9.00001 14.3 8.9 14.3 8.7 14.3C8.5 14.3 8.39999 14.3 8.39999 14.3C8.19999 14.3 7.99999 14.2 7.89999 14.1C7.79999 14 7.7 13.8 7.7 13.7C7.7 13.5 7.79999 13.4 7.89999 13.2C7.99999 13 8.2 13 8.5 13H8.8V13.1ZM15.3 17.5V12.2C14.3 13 13.6 13.3 13.3 13.3C13.1 13.3 13 13.2 12.9 13.1C12.8 13 12.7 12.8 12.7 12.6C12.7 12.4 12.8 12.3 12.9 12.2C13 12.1 13.2 12 13.6 11.8C14.1 11.6 14.5 11.3 14.7 11.1C14.9 10.9 15.2 10.6 15.5 10.3C15.8 10 15.9 9.80003 15.9 9.70003C15.9 9.60003 16.1 9.60004 16.3 9.60004C16.5 9.60004 16.7 9.70003 16.8 9.80003C16.9 9.90003 17 10.2 17 10.5V17.2C17 18 16.7 18.4 16.2 18.4C16 18.4 15.8 18.3 15.6 18.2C15.4 18.1 15.3 17.8 15.3 17.5Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">TIMETABLE</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='dossiers') echo "active"; ?>" href="<?php echo $base_url; ?>dossiers">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/technology/teh004.svg-->
                            <span class="svg-icon svg-icon-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22Z" fill="black"/>
<path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
</svg></span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">LESSONS</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='course_attendants_marks') echo "active"; ?>" href="<?php echo $base_url; ?>course_attendants_marks">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/art/art009.svg-->
                            <span class="svg-icon svg-icon-2"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
<path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
<rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
<rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
<rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
<path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
</svg></span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">MARKS</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='absences') echo "active"; ?>" href="<?php echo $base_url; ?>absences">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/general/gen022.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M11.2929 2.70711C11.6834 2.31658 12.3166 2.31658 12.7071 2.70711L15.2929 5.29289C15.6834 5.68342 15.6834 6.31658 15.2929 6.70711L12.7071 9.29289C12.3166 9.68342 11.6834 9.68342 11.2929 9.29289L8.70711 6.70711C8.31658 6.31658 8.31658 5.68342 8.70711 5.29289L11.2929 2.70711Z" fill="black" />
                                    <path d="M11.2929 14.7071C11.6834 14.3166 12.3166 14.3166 12.7071 14.7071L15.2929 17.2929C15.6834 17.6834 15.6834 18.3166 15.2929 18.7071L12.7071 21.2929C12.3166 21.6834 11.6834 21.6834 11.2929 21.2929L8.70711 18.7071C8.31658 18.3166 8.31658 17.6834 8.70711 17.2929L11.2929 14.7071Z" fill="black" />
                                    <path opacity="0.3" d="M5.29289 8.70711C5.68342 8.31658 6.31658 8.31658 6.70711 8.70711L9.29289 11.2929C9.68342 11.6834 9.68342 12.3166 9.29289 12.7071L6.70711 15.2929C6.31658 15.6834 5.68342 15.6834 5.29289 15.2929L2.70711 12.7071C2.31658 12.3166 2.31658 11.6834 2.70711 11.2929L5.29289 8.70711Z" fill="black" />
                                    <path opacity="0.3" d="M17.2929 8.70711C17.6834 8.31658 18.3166 8.31658 18.7071 8.70711L21.2929 11.2929C21.6834 11.6834 21.6834 12.3166 21.2929 12.7071L18.7071 15.2929C18.3166 15.6834 17.6834 15.6834 17.2929 15.2929L14.7071 12.7071C14.3166 12.3166 14.3166 11.6834 14.7071 11.2929L17.2929 8.70711Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">ABSENCES</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='disciplinary') echo "active"; ?>" href="<?php echo $base_url; ?>disciplinary">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/general/gen002.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M4.05424 15.1982C8.34524 7.76818 13.5782 3.26318 20.9282 2.01418C21.0729 1.98837 21.2216 1.99789 21.3618 2.04193C21.502 2.08597 21.6294 2.16323 21.7333 2.26712C21.8372 2.37101 21.9144 2.49846 21.9585 2.63863C22.0025 2.7788 22.012 2.92754 21.9862 3.07218C20.7372 10.4222 16.2322 15.6552 8.80224 19.9462L4.05424 15.1982ZM3.81924 17.3372L2.63324 20.4482C2.58427 20.5765 2.5735 20.7163 2.6022 20.8507C2.63091 20.9851 2.69788 21.1082 2.79503 21.2054C2.89218 21.3025 3.01536 21.3695 3.14972 21.3982C3.28408 21.4269 3.42387 21.4161 3.55224 21.3672L6.66524 20.1802L3.81924 17.3372ZM16.5002 5.99818C16.2036 5.99818 15.9136 6.08615 15.6669 6.25097C15.4202 6.41579 15.228 6.65006 15.1144 6.92415C15.0009 7.19824 14.9712 7.49984 15.0291 7.79081C15.0869 8.08178 15.2298 8.34906 15.4396 8.55884C15.6494 8.76862 15.9166 8.91148 16.2076 8.96935C16.4986 9.02723 16.8002 8.99753 17.0743 8.884C17.3484 8.77046 17.5826 8.5782 17.7474 8.33153C17.9123 8.08486 18.0002 7.79485 18.0002 7.49818C18.0002 7.10035 17.8422 6.71882 17.5609 6.43752C17.2796 6.15621 16.8981 5.99818 16.5002 5.99818Z" fill="black" />
                                    <path d="M4.05423 15.1982L2.24723 13.3912C2.15505 13.299 2.08547 13.1867 2.04395 13.0632C2.00243 12.9396 1.9901 12.8081 2.00793 12.679C2.02575 12.5498 2.07325 12.4266 2.14669 12.3189C2.22013 12.2112 2.31752 12.1219 2.43123 12.0582L9.15323 8.28918C7.17353 10.3717 5.4607 12.6926 4.05423 15.1982ZM8.80023 19.9442L10.6072 21.7512C10.6994 21.8434 10.8117 21.9129 10.9352 21.9545C11.0588 21.996 11.1903 22.0083 11.3195 21.9905C11.4486 21.9727 11.5718 21.9252 11.6795 21.8517C11.7872 21.7783 11.8765 21.6809 11.9402 21.5672L15.7092 14.8442C13.6269 16.8245 11.3061 18.5377 8.80023 19.9442ZM7.04023 18.1832L12.5832 12.6402C12.7381 12.4759 12.8228 12.2577 12.8195 12.032C12.8161 11.8063 12.725 11.5907 12.5653 11.4311C12.4057 11.2714 12.1901 11.1803 11.9644 11.1769C11.7387 11.1736 11.5205 11.2583 11.3562 11.4132L5.81323 16.9562L7.04023 18.1832Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">DISCIPLINARY</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='coaching') echo "active"; ?>" href="<?php echo $base_url; ?>coaching">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/ecommerce/ecm001.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M18.041 22.041C18.5932 22.041 19.041 21.5932 19.041 21.041C19.041 20.4887 18.5932 20.041 18.041 20.041C17.4887 20.041 17.041 20.4887 17.041 21.041C17.041 21.5932 17.4887 22.041 18.041 22.041Z" fill="black" />
                                    <path opacity="0.3" d="M6.04095 22.041C6.59324 22.041 7.04095 21.5932 7.04095 21.041C7.04095 20.4887 6.59324 20.041 6.04095 20.041C5.48867 20.041 5.04095 20.4887 5.04095 21.041C5.04095 21.5932 5.48867 22.041 6.04095 22.041Z" fill="black" />
                                    <path opacity="0.3" d="M7.04095 16.041L19.1409 15.1409C19.7409 15.1409 20.141 14.7409 20.341 14.1409L21.7409 8.34094C21.9409 7.64094 21.4409 7.04095 20.7409 7.04095H5.44095L7.04095 16.041Z" fill="black" />
                                    <path d="M19.041 20.041H5.04096C4.74096 20.041 4.34095 19.841 4.14095 19.541C3.94095 19.241 3.94095 18.841 4.14095 18.541L6.04096 14.841L4.14095 4.64095L2.54096 3.84096C2.04096 3.64096 1.84095 3.04097 2.14095 2.54097C2.34095 2.04097 2.94096 1.84095 3.44096 2.14095L5.44096 3.14095C5.74096 3.24095 5.94096 3.54096 5.94096 3.84096L7.94096 14.841C7.94096 15.041 7.94095 15.241 7.84095 15.441L6.54096 18.041H19.041C19.641 18.041 20.041 18.441 20.041 19.041C20.041 19.641 19.641 20.041 19.041 20.041Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">COACHING</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='students') echo "active"; ?>" href="<?php echo $base_url; ?>students">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/general/gen051.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M20.5543 4.37824L12.1798 2.02473C12.0626 1.99176 11.9376 1.99176 11.8203 2.02473L3.44572 4.37824C3.18118 4.45258 3 4.6807 3 4.93945V13.569C3 14.6914 3.48509 15.8404 4.4417 16.984C5.17231 17.8575 6.18314 18.7345 7.446 19.5909C9.56752 21.0295 11.6566 21.912 11.7445 21.9488C11.8258 21.9829 11.9129 22 12.0001 22C12.0872 22 12.1744 21.983 12.2557 21.9488C12.3435 21.912 14.4326 21.0295 16.5541 19.5909C17.8169 18.7345 18.8277 17.8575 19.5584 16.984C20.515 15.8404 21 14.6914 21 13.569V4.93945C21 4.6807 20.8189 4.45258 20.5543 4.37824Z" fill="black" />
                                    <path d="M14.854 11.321C14.7568 11.2282 14.6388 11.1818 14.4998 11.1818H14.3333V10.2272C14.3333 9.61741 14.1041 9.09378 13.6458 8.65628C13.1875 8.21876 12.639 8 12 8C11.361 8 10.8124 8.21876 10.3541 8.65626C9.89574 9.09378 9.66663 9.61739 9.66663 10.2272V11.1818H9.49999C9.36115 11.1818 9.24306 11.2282 9.14583 11.321C9.0486 11.4138 9 11.5265 9 11.6591V14.5227C9 14.6553 9.04862 14.768 9.14583 14.8609C9.24306 14.9536 9.36115 15 9.49999 15H14.5C14.6389 15 14.7569 14.9536 14.8542 14.8609C14.9513 14.768 15 14.6553 15 14.5227V11.6591C15.0001 11.5265 14.9513 11.4138 14.854 11.321ZM13.3333 11.1818H10.6666V10.2272C10.6666 9.87594 10.7969 9.57597 11.0573 9.32743C11.3177 9.07886 11.6319 8.9546 12 8.9546C12.3681 8.9546 12.6823 9.07884 12.9427 9.32743C13.2031 9.57595 13.3333 9.87594 13.3333 10.2272V11.1818Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">STUDENTS</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='reports') echo "active"; ?>" href="<?php echo $base_url; ?>reports">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/communication/com011.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19Z" fill="black" />
                                    <path d="M21 5H2.99999C2.69999 5 2.49999 5.10005 2.29999 5.30005L11.2 13.3C11.7 13.7 12.4 13.7 12.8 13.3L21.7 5.30005C21.5 5.10005 21.3 5 21 5Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">REPORTS</span>
                    </a>
                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='notifications') echo "active"; ?>" href="<?php echo $base_url; ?>notifications">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/communication/com012.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M20 3H4C2.89543 3 2 3.89543 2 5V16C2 17.1046 2.89543 18 4 18H4.5C5.05228 18 5.5 18.4477 5.5 19V21.5052C5.5 22.1441 6.21212 22.5253 6.74376 22.1708L11.4885 19.0077C12.4741 18.3506 13.6321 18 14.8167 18H20C21.1046 18 22 17.1046 22 16V5C22 3.89543 21.1046 3 20 3Z" fill="black" />
                                    <rect x="6" y="12" width="7" height="2" rx="1" fill="black" />
                                    <rect x="6" y="7" width="12" height="2" rx="1" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">MESSAGES</span>
                    </a>

                </div>
                <div class="menu-item">
                    <a class="menu-link <?php if($controller_name=='team_meetings') echo "active"; ?>" href="<?php echo $base_url; ?>team_meetings">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/finance/fin006.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M20 15H4C2.9 15 2 14.1 2 13V7C2 6.4 2.4 6 3 6H21C21.6 6 22 6.4 22 7V13C22 14.1 21.1 15 20 15ZM13 12H11C10.5 12 10 12.4 10 13V16C10 16.5 10.4 17 11 17H13C13.6 17 14 16.6 14 16V13C14 12.4 13.6 12 13 12Z" fill="black" />
                                    <path d="M14 6V5H10V6H8V5C8 3.9 8.9 3 10 3H14C15.1 3 16 3.9 16 5V6H14ZM20 15H14V16C14 16.6 13.5 17 13 17H11C10.5 17 10 16.6 10 16V15H4C3.6 15 3.3 14.9 3 14.7V18C3 19.1 3.9 20 5 20H19C20.1 20 21 19.1 21 18V14.7C20.7 14.9 20.4 15 20 15Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">TEAM MEETINGS</span>
                    </a>

                </div>
                <?php
                    $administration=false;
                    if($controller_name=='timetable'||$controller_name=='users'||$controller_name=='students_terms'||$controller_name=='students_courses')
                        $administration=true;
                ?>
                <div data-kt-menu-trigger="click" class="menu-item menu-accordion <?php if($administration) echo "show"; ?>">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/files/fil025.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path opacity="0.3" d="M14 2H6C4.89543 2 4 2.89543 4 4V20C4 21.1046 4.89543 22 6 22H18C19.1046 22 20 21.1046 20 20V8L14 2Z" fill="black" />
                                    <path d="M20 8L14 2V6C14 7.10457 14.8954 8 16 8H20Z" fill="black" />
                                    <path d="M10.3629 14.0084L8.92108 12.6429C8.57518 12.3153 8.03352 12.3153 7.68761 12.6429C7.31405 12.9967 7.31405 13.5915 7.68761 13.9453L10.2254 16.3488C10.6111 16.714 11.215 16.714 11.6007 16.3488L16.3124 11.8865C16.6859 11.5327 16.6859 10.9379 16.3124 10.5841C15.9665 10.2565 15.4248 10.2565 15.0789 10.5841L11.4631 14.0084C11.1546 14.3006 10.6715 14.3006 10.3629 14.0084Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">ADMINISTRATION</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='users') echo "active"; ?>" href="<?php echo $base_url; ?>users">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">PERSONNEL & PARENTS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='students_terms') echo "active"; ?>" href="<?php echo $base_url; ?>students_terms">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">STUDENTS TO TERMS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='students_courses') echo "active"; ?>" href="<?php echo $base_url; ?>students_courses">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">STUDENTS TO COURSES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='timetable') echo "active"; ?>" href="<?php echo $base_url; ?>timetable">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">MAIN TIMETABLE</span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
                    $base_data=false;
                    if($controller_name=='absence_categories'||$controller_name=='career_goals'||$controller_name=='coaching_categories'||$controller_name=='competence_levels'||$controller_name=='countries'||$controller_name=='courses'||$controller_name=='curriculum_categories'||$controller_name=='curriculum_item_cycles'||$controller_name=='curriculum_item_types'||$controller_name=='curricula'||$controller_name=='curriculum_items'||$controller_name=='disciplinary_categories'||$controller_name=='dossier_languages'||$controller_name=='genders'||$controller_name=='classes'||$controller_name=='intended_professions'||$controller_name=='lesson_numbers'||$controller_name=='main_levels'||$controller_name=='mark_categories'||$controller_name=='marks'||$controller_name=='meeting_item_categories'||$controller_name=='personnel_functions'||$controller_name=='room_functions'||$controller_name=='rooms'||$controller_name=='school'||$controller_name=='school_data'||$controller_name=='preparation_types'||$controller_name=='student_course_statuses'||$controller_name=='subject_categories'||$controller_name=='subject_types'||$controller_name=='subjects'||$controller_name=='terms'||$controller_name=='weekdays'||$controller_name=='file_manager')
                        $base_data=true;
                ?>
                <div data-kt-menu-trigger="click" class="menu-item menu-accordion <?php if($base_data) echo "show"; ?>">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/finance/fin002.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M22 7H2V11H22V7Z" fill="black" />
                                    <path opacity="0.3" d="M21 19H3C2.4 19 2 18.6 2 18V6C2 5.4 2.4 5 3 5H21C21.6 5 22 5.4 22 6V18C22 18.6 21.6 19 21 19ZM14 14C14 13.4 13.6 13 13 13H5C4.4 13 4 13.4 4 14C4 14.6 4.4 15 5 15H13C13.6 15 14 14.6 14 14ZM16 15.5C16 16.3 16.7 17 17.5 17H18.5C19.3 17 20 16.3 20 15.5C20 14.7 19.3 14 18.5 14H17.5C16.7 14 16 14.7 16 15.5Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">BASE DATA</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                                <a class="menu-link <?php if($controller_name=='absence_categories') echo "active"; ?>" href="<?php echo $base_url; ?>absence_categories">
                                    <span class="menu-bullet">
                                        <span class="bullet bullet-dot"></span>
                                    </span>
                                    <span class="menu-title">ABSENCE CATEGORIES</span>
                                </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='career_goals') echo "active"; ?>" href="<?php echo $base_url; ?>career_goals">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CAREER GOALS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='coaching_categories') echo "active"; ?>" href="<?php echo $base_url; ?>coaching_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">COACHING CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='competence_levels') echo "active"; ?>" href="<?php echo $base_url; ?>competence_levels">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">COMPETENCE LEVELS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='countries') echo "active"; ?>" href="<?php echo $base_url; ?>countries">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">COUNTRIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='courses') echo "active"; ?>" href="<?php echo $base_url; ?>courses">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">COURSES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='curriculum_categories') echo "active"; ?>" href="<?php echo $base_url; ?>curriculum_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CURRICULUM CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='curriculum_item_cycles') echo "active"; ?>" href="<?php echo $base_url; ?>curriculum_item_cycles">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CURRICULUM CYCLES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='curriculum_item_types') echo "active"; ?>" href="<?php echo $base_url; ?>curriculum_item_types">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CURRICULUM ITEM TYPES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='curricula') echo "active"; ?>" href="<?php echo $base_url; ?>curricula">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CURRICULA</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='curriculum_items') echo "active"; ?>" href="<?php echo $base_url; ?>curriculum_items">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CURRICULUM ITEMS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='disciplinary_categories') echo "active"; ?>" href="<?php echo $base_url; ?>disciplinary_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">DISCIPLINARY CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='dossier_languages') echo "active"; ?>" href="<?php echo $base_url; ?>dossier_languages">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">LESSON LANGUAGES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='genders') echo "active"; ?>" href="<?php echo $base_url; ?>genders">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">GENDER</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='classes') echo "active"; ?>" href="<?php echo $base_url; ?>classes">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">GRADES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='intended_professions') echo "active"; ?>" href="<?php echo $base_url; ?>intended_professions">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">PROFESSIONS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='lesson_numbers') echo "active"; ?>" href="<?php echo $base_url; ?>lesson_numbers">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">LESSON NUMBERS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='main_levels') echo "active"; ?>" href="<?php echo $base_url; ?>main_levels">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">STUDY LEVELS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='mark_categories') echo "active"; ?>" href="<?php echo $base_url; ?>mark_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">MARK CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='marks') echo "active"; ?>" href="<?php echo $base_url; ?>marks">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">MARKS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='meeting_item_categories') echo "active"; ?>" href="<?php echo $base_url; ?>meeting_item_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">MEETING ITEM CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='personnel_functions') echo "active"; ?>" href="<?php echo $base_url; ?>personnel_functions">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">PERSONNEL FUNCTIONS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='room_functions') echo "active"; ?>" href="<?php echo $base_url; ?>room_functions">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">ROOM FUNCTIONS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='rooms') echo "active"; ?>" href="<?php echo $base_url; ?>rooms">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">ROOMS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='school') echo "active"; ?>" href="<?php echo $base_url; ?>school">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SCHOOL</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='school_data') echo "active"; ?>" href="<?php echo $base_url; ?>school_data">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SCHOOL DATA</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='preparation_types') echo "active"; ?>" href="<?php echo $base_url; ?>preparation_types">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">LEARNING TYPES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='student_course_statuses') echo "active"; ?>" href="<?php echo $base_url; ?>student_course_statuses">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">STUDENT COURSE STATUS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='subject_categories') echo "active"; ?>" href="<?php echo $base_url; ?>subject_categories">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SUBJECT CATEGORIES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='subject_types') echo "active"; ?>" href="<?php echo $base_url; ?>subject_types">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SUBJECT TYPES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='subjects') echo "active"; ?>" href="<?php echo $base_url; ?>subjects">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SUBJECTS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='terms') echo "active"; ?>" href="<?php echo $base_url; ?>terms">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">TERMS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='weekdays') echo "active"; ?>" href="<?php echo $base_url; ?>weekdays">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">WEEKDAYS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='file_manager') echo "active"; ?>" href="<?php echo $base_url; ?>file_manager">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">File Manager</span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php
                    $system=false;
                    if($controller_name=='acl_groups'||$controller_name=='acl_resources'||$controller_name=='backups'||$controller_name=='bulk_labeling'||$controller_name=='translations'||$controller_name=='cronjob_reports'||$controller_name=='cron_jobs'||$controller_name=='email_settings'||$controller_name=='email_templates'||$controller_name=='languages'||$controller_name=='system_settings')
                        $system=true;
                ?>
                <div data-kt-menu-trigger="click" class="menu-item menu-accordion <?php if($system) echo "show"; ?>">
                    <span class="menu-link">
                        <span class="menu-icon">
                            <!--begin::Svg Icon | path: icons/duotune/ecommerce/ecm002.svg-->
                            <span class="svg-icon svg-icon-2">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 10H13V11C13 11.6 12.6 12 12 12C11.4 12 11 11.6 11 11V10H3C2.4 10 2 10.4 2 11V13H22V11C22 10.4 21.6 10 21 10Z" fill="black" />
                                    <path opacity="0.3" d="M12 12C11.4 12 11 11.6 11 11V3C11 2.4 11.4 2 12 2C12.6 2 13 2.4 13 3V11C13 11.6 12.6 12 12 12Z" fill="black" />
                                    <path opacity="0.3" d="M18.1 21H5.9C5.4 21 4.9 20.6 4.8 20.1L3 13H21L19.2 20.1C19.1 20.6 18.6 21 18.1 21ZM13 18V15C13 14.4 12.6 14 12 14C11.4 14 11 14.4 11 15V18C11 18.6 11.4 19 12 19C12.6 19 13 18.6 13 18ZM17 18V15C17 14.4 16.6 14 16 14C15.4 14 15 14.4 15 15V18C15 18.6 15.4 19 16 19C16.6 19 17 18.6 17 18ZM9 18V15C9 14.4 8.6 14 8 14C7.4 14 7 14.4 7 15V18C7 18.6 7.4 19 8 19C8.6 19 9 18.6 9 18Z" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </span>
                        <span class="menu-title">SYSTEM ADMIN</span>
                        <span class="menu-arrow"></span>
                    </span>
                    <div class="menu-sub menu-sub-accordion">
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='acl_groups') echo "active"; ?>" href="<?php echo $base_url; ?>acl_groups">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">ACL GROUPS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='acl_resources') echo "active"; ?>" href="<?php echo $base_url; ?>acl_resources">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">ACL RESOURCES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='backups') echo "active"; ?>" href="<?php echo $base_url; ?>backups">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">BACKUPS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='bulk_labeling') echo "active"; ?>" href="<?php echo $base_url; ?>bulk_labeling">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">BULK LABELING</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='translations') echo "active"; ?>" href="<?php echo $base_url; ?>translations">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">TRANSLATIONS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='cronjob_reports') echo "active"; ?>" href="<?php echo $base_url; ?>cronjob_reports">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CRONJOB REPORTS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='cron_jobs') echo "active"; ?>" href="<?php echo $base_url; ?>cron_jobs">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">CRONJOBS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='email_settings') echo "active"; ?>" href="<?php echo $base_url; ?>email_settings">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">E-MAIL SETTINGS</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='email_templates') echo "active"; ?>" href="<?php echo $base_url; ?>email_templates">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">E-MAIL TEMPLATES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='languages') echo "active"; ?>" href="<?php echo $base_url; ?>languages">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">LANGUAGES</span>
                            </a>
                        </div>
                        <div class="menu-item">
                            <a class="menu-link <?php if($controller_name=='system_settings') echo "active"; ?>" href="<?php echo $base_url; ?>system_settings">
                                <span class="menu-bullet">
                                    <span class="bullet bullet-dot"></span>
                                </span>
                                <span class="menu-title">SETTINGS</span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
            <!--end::Menu-->
        </div>
    </div>
    <!--end::Aside menu-->

</div>
<!--end::Aside-->
                
                
       

