<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style type="text/css">
		
        .message_ribbon.ribbon-label {
  position: absolute;
  top: 0;
  right: 60px;
    padding: 8px 10px;
  font-size: 13px;
  font-weight: 300;
    text-transform: uppercase;
  color: #fff;
  border-radius: 0px 0px 5px 5px;
  z-index: 10;
  min-width:140px;
}
.accordion .accordion-header {
  position: relative;
}
.accordion-item {
  position: relative;
}
.card-toolbar.dash_msg_cls {
    display: block;
    position: absolute;
    top: 10px;
    left: 10px;
    z-index: 10;
}
.message_ribbon.ribbon-label i {
  color: #fff;
}
#absences_table {
    border: 1px solid #ddd;
}

#absences_table thead tr th {
    border-right: 1px solid #ddd;
    /* white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; */
}
#absences_table tbody tr td {
    border-right: 1px solid #ddd;
    /* white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; */
}
#disciplinary_table {
    border: 1px solid #ddd;
}

#disciplinary_table thead tr th {
    border-right: 1px solid #ddd;
    /* white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; */
}
#disciplinary_table tbody tr td {
    border-right: 1px solid #ddd;
    /* white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis; */
}
div#absences_table_wrapper {
    padding: 0px!important;
}
div#disciplinary_table_wrapper {
    padding: 0px!important;
}

        .label.label-sm {
          display: inline-block;
          width: 20px;
          height: 20px;
          line-height: 19px;
          text-align: center;
          border-radius: 2px;
        }
        .label-primary {
          background-color: #659be0;
        }
        .label.label-sm i {
          color: #fff;
          font-size: 12px;
        }
        .dInline{
            display: inline-block!important;
        }
        .label-info {
          background-color: #7239ea;
        }
        .label-warning {
          background-color: #f1c40f;
        }
        .label-danger {
          background-color: #ed6b75;
        }
        .label-success {
          background-color: #36c6d3;
        }
        .label-primary {
          background-color: #009ef7;
        }
        .height-5 {
            height: 50px;
        }
        .students {
          background-color: rgba(51, 122, 183, 0.1);
        }
        .btn.btn-danger.close-btn {
          padding: 5px 10px !important;
        }
        .personnel {
          background-color: rgba(244, 208, 63, 0.1);
        }
        .text-blue{
            color: #009ef7;
        }
        .text-orange{
            color: #ff9b00;
        }
        .parents {
          background-color: rgb(142,68,173, 0.1);
        }
        .text-purple {
          color: #8e44ad;
        }
            
        </style>
<!--begin::Container-->
<div class="d-flex flex-column flex-column-fluid container-fluid" style="padding: 0 20px!important;">
    <!--begin::Toolbar-->
    <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
        <!--begin::Page title-->
        <div class="page-title d-flex flex-column me-3">
            <!--begin::Title-->
            <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $dashboard_details[1]['name']; ?></h1>
            <!--end::Title-->
            <!--begin::Breadcrumb-->
            <!-- <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1"> -->
            <!--begin::Item-->
            <!-- <li class="breadcrumb-item text-gray-600">
                    <a href="../../demo14/dist/index.html" class="text-gray-600 text-hover-primary">Home</a>
                </li> -->
            <!--end::Item-->
            <!--begin::Item-->
            <!-- <li class="breadcrumb-item text-gray-500">Light Aside</li> -->
            <!--end::Item-->
            <!-- </ul> -->
            <!--end::Breadcrumb-->
        </div>
        <!--end::Page title-->
    </div>
    <!--end::Toolbar-->
    <!--begin::Post-->
    <div class="content flex-column-fluid" id="kt_content">
        <!--begin::Row-->
        <div class="row g-5">
            <!--begin::Col-->
            <div class="col-xl-4 mb-xl-10">
                <!--begin::Mixed Widget 18-->
                <div class="card mb-5 mb-xl-8 border">

                    <div class="divrel">
                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                            <div class="ribbon-label">
                            <?php echo $dashboard_details[2]['name']; ?>
                                <span class="ribbon-inner bg-info"></span>
                            </div>
                        </div>
                        <div class="ribbon ribbon-right ribbon-vertical-right ribbon-shadow ribbon-color-primary uppercase ribbon-flag">
                            <div class="ribbon-sub ribbon-bookmark"></div>
                            <i class="fa fa-star col_white"></i>
                        </div>
                    </div>
                    <!--begin::Card body-->
                    <div class="card-body py-4">
                        <!--begin::Summary-->
                        <!--begin::User Info-->
                        <div class="d-flex flex-center flex-column py-0">
                            <!--begin::Avatar-->
                            <div class="symbol-circle mb-7">
                                <img src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $school_details[0]['logo']; ?>" alt="image" />
                            </div>
                            <!--end::Avatar-->
                        </div>
                        <!--end::User Info-->
                        <!--end::Summary-->
                        <!--begin::Details toggle-->
                        <div class="d-flex flex-stack fs-4">
                            <div class="fw-bolder rotate collapsible" data-bs-toggle="collapse" href="#kt_user_view_details" role="button" aria-expanded="false" aria-controls="kt_user_view_details">
                            <?php echo $dashboard_details[3]['name']; ?>
                                <span class="ms-2 rotate-180">
                                    <!--begin::Svg Icon | path: icons/duotune/arrows/arr072.svg-->
                                    <span class="svg-icon svg-icon-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path
                                                d="M11.4343 12.7344L7.25 8.55005C6.83579 8.13583 6.16421 8.13584 5.75 8.55005C5.33579 8.96426 5.33579 9.63583 5.75 10.05L11.2929 15.5929C11.6834 15.9835 12.3166 15.9835 12.7071 15.5929L18.25 10.05C18.6642 9.63584 18.6642 8.96426 18.25 8.55005C17.8358 8.13584 17.1642 8.13584 16.75 8.55005L12.5657 12.7344C12.2533 13.0468 11.7467 13.0468 11.4343 12.7344Z"
                                                fill="black"
                                            />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                </span>
                            </div>
                        </div>
                        <!--end::Details toggle-->
                        <div class="separator"></div>
                        <!--begin::Details content-->
                        <div id="kt_user_view_details" class="collapse show">
                            <div class="pb-5 fs-6">
                                <!--begin::Details item-->
                                <div class="text-gray-600 mt-5"><?php echo $dashboard_details[4]['name']; ?></div>
                                <div class="fw-bolder"><?php echo $school_details[0]['name']; ?></div>
                                <!--begin::Details item-->
                                <!--begin::Details item-->
                                <div class="text-gray-600 mt-5"><?php echo $dashboard_details[5]['name']; ?></div>
                                <div class="fw-bolder">
                                    <a class="fw-bolder mt-5" class="text-gray-600 text-hover-primary"><?php echo $school_details[0]['gen_email']; ?></a>
                                </div>
                                <!--begin::Details item-->
                                <!--begin::Details item-->
                                <div class="text-gray-600 mt-5"><?php echo $dashboard_details[6]['name']; ?></div>
                                <div class="fw-bolder"><?php echo $school_details[0]['address1']; ?>, <?php echo $school_details[0]['city']; ?> <?php echo $school_details[0]['zip_code']; ?>,<?php echo $school_details[0]['country']; ?></div>
                                <!--begin::Details item-->
                                <!--begin::Details item-->
                                <div class="text-gray-600 mt-5"><?php echo $dashboard_details[7]['name']; ?></div>
                                <div class="fw-bolder"><?php echo $school_details[0]['phone_no']; ?></div>
                                <!--begin::Details item-->
                            </div>
                        </div>
                        <!--end::Details content-->
                    </div>
                    <!--end::Card body-->
                </div>
                <!--end::Mixed Widget 18-->

                <!--end::Col-->
                <!--begin::Col-->
                
                <!--end::Col-->
            </div>
            <div class="col-xl-8">

                <!--begin::Row-->
                <!--begin::Content-->
                <div class="flex-lg-row-fluid mb-6">
                    <!--begin::Card-->
                    <div class="card border">
                        <div class="card-body p-0">
                            <!--begin::Accordion-->
                            <div class="accordion" id="kt_accordion_1">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="kt_accordion_1_header_1">
                                        <button class="accordion-button fs-4 fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#kt_accordion_1_body_1" aria-expanded="true" aria-controls="kt_accordion_1_body_1" id="kt_accordion_msg">
                                        </button>
                                        <div class="message_ribbon ribbon-label bg-primary"><i class="bi bi-chat-left-text"></i>&nbsp;&nbsp;&nbsp; <?php echo $dashboard_details[137]['name']; ?></div>
                                    </h2>
                                    <div class="card-toolbar dash_msg_cls">
                                    <a href="<?php echo $base_url; ?>notifications" class="btn btn-sm btn-flex btn-primary me-lg-4 me-4">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="14.3" viewBox="0 0 24 21.453">
                                                <path id="view_all" data-name="view all" d="M11.984,21.453a2.269,2.269,0,0,0-.363-.2L.143,15.391C.1,15.37.049,15.361.02,15.309c.776-.4,1.55-.79,2.323-1.188a.152.152,0,0,1,.158.017l2.738,1.4q3.339,1.7,6.678,3.41a.182.182,0,0,0,.19,0q4.7-2.4,9.394-4.8a.215.215,0,0,1,.224,0c.755.39,1.512.775,2.273,1.163-.017.047-.061.052-.093.068L12.4,21.256a2.534,2.534,0,0,0-.362.2ZM0,10.74c.053-.022.088.021.126.041Q6.02,13.788,11.912,16.8a.181.181,0,0,0,.189,0q5.908-3.022,11.819-6.039c.026-.014.065-.015.073-.061l-.118-.062c-.709-.363-1.42-.724-2.127-1.09a.26.26,0,0,0-.268,0q-4.68,2.4-9.362,4.786a.206.206,0,0,1-.214,0q-4.68-2.394-9.362-4.787a.258.258,0,0,0-.268,0Q1.2,10.108.115,10.655c-.034.017-.065.066-.115.035ZM23.9,6.053Q18.011,3.042,12.12.03a.216.216,0,0,0-.223,0Q6.3,2.9.691,5.758l-.684.351c.031.019.046.03.063.038Q6,9.173,11.92,12.2a.184.184,0,0,0,.191-.007q4.336-2.217,8.674-4.432L24,6.12a.19.19,0,0,0-.1-.067m-4.937.6q-3.421,1.749-6.841,3.5a.225.225,0,0,1-.234,0q-3.9-2-7.811-4l-.067-.035c.012-.049.058-.052.091-.069q3.911-2,7.821-4a.164.164,0,0,1,.17,0q3.91,2,7.822,4c.032.016.062.035.107.061l-1.058.541" transform="translate(0 0)" fill="#ffffff"/>
                                            </svg>
                                        <!--end::Svg Icon-->&nbsp;<?php echo $dashboard_details[9]['name']; ?>
                                    </a>
                                    <?php if(in_array(306,$role_details)||in_array(307,$role_details)||in_array(308,$role_details)||in_array(309,$role_details)||in_array(310,$role_details)) { ?>
                                    <button type="button" id="create_new_message" class="btn btn-sm btn-flex btn-danger">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen035.svg-->
                                        <span class="svg-icon svg-icon-3">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="15.912" viewBox="0 0 16 15.912">
                                                <path id="svg_new_message" data-name="svg_new message" d="M3.469,13.832C4.6,13.075,5.654,12.376,6.7,11.655a1.566,1.566,0,0,1,.947-.294c1.777.01,3.554.006,5.331,0,1.1,0,1.571-.469,1.572-1.557,0-1.237,0-2.475,0-3.712,0-.6.256-.9.739-.889.457.009.707.314.708.877C16,7.4,16,8.708,16,10.019a2.728,2.728,0,0,1-2.805,2.793q-2.621.017-5.242,0a1.155,1.155,0,0,0-.7.216c-1.306.889-2.621,1.764-3.928,2.65a.82.82,0,0,1-.9.156.807.807,0,0,1-.4-.858c.01-.648,0-1.3.007-1.944a.37.37,0,0,0-.275-.419A2.625,2.625,0,0,1,0,10Q0,6.38,0,2.756A2.71,2.71,0,0,1,2.752.005C5.136-.005,7.52,0,9.9,0c.558,0,.863.264.858.727s-.307.709-.875.71q-3.4,0-6.8,0c-1.188,0-1.642.451-1.642,1.625q0,3.38,0,6.761a1.32,1.32,0,0,0,1.323,1.541.722.722,0,0,1,.7.807c.006.526,0,1.052,0,1.656m9.053-9.683c0,.968.187,1.317.71,1.325s.732-.345.732-1.3V3.459c.456,0,.854.007,1.252,0a.718.718,0,1,0,0-1.431c-.408-.008-.817,0-1.251,0,0-.453.006-.848,0-1.244a.721.721,0,1,0-1.438,0c-.008.406,0,.813,0,1.245-.439,0-.822,0-1.2,0-.506.007-.829.3-.822.724s.332.7.842.708c.381,0,.762,0,1.184,0Z" transform="translate(0.001 0.001)" fill="#ffffff"/>
                                            </svg>
                                        </span>
                                        <!--end::Svg Icon-->&nbsp;<?php echo $dashboard_details[10]['name']; ?>
                                    </button>
                                    <?php } ?>
                                    <input type="hidden" id="dashboard_reply" value="1" />
                                </div>
                                    <div id="kt_accordion_1_body_1" class="accordion-collapse collapse hide" aria-labelledby="kt_accordion_1_header_1" data-bs-parent="#kt_accordion_1">
                                        <div class="accordion-body">
                                <div class="cct-scrool">
                                    <!--begin::Table-->
                                    <table class="table table-hover table-row-dashed fs-6 gy-5 my-0 px-4" id="notify_list">
                                        <!--begin::Table head-->
                                        <thead class="d-none">
                                            <tr>
                                                <th>Author</th>
                                                <th>Title</th>
                                                <th>Date</th>
                                            </tr>
                                        </thead>
                                        <!--end::Table head-->
                                        <!--begin::Table body-->
                                        <tbody>
                                            
                                        </tbody>
                                        <!--end::Table body-->
                                    </table>
                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end::Accordion-->
                            <!--end::Table-->
                        </div>
                    </div>
                    <!--end::Card-->
                </div>
                <div class="flex-lg-row-fluid mb-6" style="display:none;" id="dash_marks">
                    <!--begin::Card-->
                    <div class="card border">
                        <div class="card-body p-0">
                            <!--begin::Accordion-->
                            <div class="accordion" id="kt_accordion_2">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="kt_accordion_1_header_2">
                                        <button class="accordion-button fs-4 fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#kt_accordion_1_body_2" aria-expanded="true" aria-controls="kt_accordion_1_body_2">
                                        </button>
                                        <div class="message_ribbon ribbon-label bg-info"><i class="bi bi-check2-circle"></i></i>&nbsp;&nbsp;&nbsp; <?php echo $dashboard_details[141]['name']; ?></div>
                                    </h2>
                                    <div class="card-toolbar dash_msg_cls">
                                    
                                </div>
                                    <div id="kt_accordion_1_body_2" class="accordion-collapse collapse hide" aria-labelledby="kt_accordion_1_header_2" data-bs-parent="#kt_accordion_2">
                                        <div class="accordion-body">
                                            <div class="cct-scrool">
                                                <!--begin::Table-->
                                                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="students_table">
                                                        <!--begin::Table head-->
                                                        <thead >
                                                            <tr>
                                                                <th></th>
                                                                <th data-priority="1" class="fw-bolder"> Term </th>
                                                                <th class="fw-bolder"> Course </th>
                                                                <th data-priority="4" class="fw-bolder"> Avg. Mark </th>
                                                                <th class="fw-bolder"></th>
                                                            </tr>
                                                        </thead>
                                                        <!--end::Table head-->
                                                        <!--begin::Table body-->
                                                        <tbody class=" text-gray-800 actionBtns_table mark_cls">
                                                        </tbody>
                                                        <tfoot>
                                                            <tr>
                                                                <th id="avg_footer" colspan="5"></th> 
                                                            </tr>
                                                        </tfoot>
                                                        <!--end::Table body-->
                                                    </table>
                                                <!--end::Table-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end::Accordion-->
                            <!--end::Table-->
                        </div>
                    </div>
                    <!--end::Card-->
                </div>
                <div class="flex-lg-row-fluid mb-6" style="display:none;" id="dash_absences">
                    <!--begin::Card-->
                    <div class="card border">
                        <div class="card-body p-0">
                            <!--begin::Accordion-->
                            <div class="accordion" id="kt_accordion_3">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="kt_accordion_1_header_3">
                                        <button class="accordion-button fs-4 fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#kt_accordion_1_body_3" aria-expanded="true" aria-controls="kt_accordion_1_body_3">
                                        </button>
                                        <div class="message_ribbon ribbon-label bg-danger"><i class="bi bi-person-dash-fill"></i>&nbsp;&nbsp;&nbsp; <?php echo $dashboard_details[145]['name']; ?></div>
                                    </h2>
                                </div>
                                    <div id="kt_accordion_1_body_3" class="accordion-collapse collapse hide" aria-labelledby="kt_accordion_1_header_3" data-bs-parent="#kt_accordion_3">
                                        <div class="accordion-body">
                                <div class="cct-scrool">
                                    <!--begin::Table-->
                                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="absences_table">
                                        <!--begin::Table head-->
                                        <thead >
                                            <tr>
                                                <th></th>
                                                <th style="text-align: center;" data-priority="4" class="fw-bolder"><?php echo $dashboard_details[146]['name']; ?> </th>
                                                <th data-priority="5" class="fw-bolder"><?php echo $dashboard_details[147]['name']; ?> </th>
                                                <th data-priority="6" class="fw-bolder"> <?php echo $dashboard_details[148]['name']; ?> </th>
                                                <th data-priority="7" class="fw-bolder"> <?php echo $dashboard_details[149]['name']; ?> </th>
                                                <th data-priority="8" class="fw-bolder"> <?php echo $dashboard_details[150]['name']; ?> </th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[151]['name']; ?> </th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[152]['name']; ?> </th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[153]['name']; ?> </th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[154]['name']; ?> </th>
                                            </tr>
                                        </thead>
                                        <!--end::Table head-->
                                        <!--begin::Table body-->
                                        <tbody class=" text-gray-800 actionBtns_table">
                                        </tbody>
                                        <!--end::Table body-->
                                    </table>
                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end::Accordion-->
                            <!--end::Table-->
                        </div>
                    </div>
                    <!--end::Card-->
                <div class="flex-lg-row-fluid mb-6" style="display:none;" id="dash_disciplinary">
                    <!--begin::Card-->
                    <div class="card border">
                        <div class="card-body p-0">
                            <!--begin::Accordion-->
                            <div class="accordion" id="kt_accordion_4">
                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="kt_accordion_1_header_4">
                                        <button class="accordion-button fs-4 fw-semibold collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#kt_accordion_1_body_4" aria-expanded="true" aria-controls="kt_accordion_1_body_4">
                                        </button>
                                        <div class="message_ribbon ribbon-label bg-warning"><i class="bi bi-person-dash-fill"></i>&nbsp;&nbsp;&nbsp; <?php echo $dashboard_details[155]['name']; ?></div>
                                    </h2>
                                </div>
                                    <div id="kt_accordion_1_body_4" class="accordion-collapse collapse hide" aria-labelledby="kt_accordion_1_header_4" data-bs-parent="#kt_accordion_4">
                                        <div class="accordion-body">
                                <div class="cct-scrool">
                                    <!--begin::Table-->
                                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="disciplinary_table">
                                        <!--begin::Table head-->
                                        <thead >
                                            <tr>
                                                <th></th>
                                                <th data-priority="5" class="fw-bolder"> <?php echo $dashboard_details[156]['name']; ?> </th>
                                                <th data-priority="6" class="fw-bolder"> <?php echo $dashboard_details[157]['name']; ?> </th>
                                                <th data-priority="7" class="fw-bolder"> <?php echo $dashboard_details[158]['name']; ?> </th>
                                                <th data-priority="8" class="fw-bolder"> <?php echo $dashboard_details[159]['name']; ?> </th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[160]['name']; ?></th>
                                                <th class="fw-bolder"> <?php echo $dashboard_details[161]['name']; ?> </th>
                                            </tr>
                                        </thead>
                                        <!--end::Table head-->
                                        <!--begin::Table body-->
                                        <tbody class=" text-gray-800 actionBtns_table">
                                        </tbody>
                                        <!--end::Table body-->
                                    </table>
                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--end::Accordion-->
                            <!--end::Table-->
                        </div>
                    </div>
                    <!--end::Card-->
                </div>
            </div>
                
                
                
                <!--begin::Accordion-->
            </div>
        </div>
    </div>
    <!--end::Post-->
    <?php echo $notifications_modals; ?>
    <?php echo $file_manager; ?>

<!--end::Container-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>notifications.js"></script>
<script src="<?php echo $js_path;?>dashboard.js"></script>
<script type="text/javascript">
var  notification_details=<?php echo json_encode($notification_details); ?>;
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],address_fields=[],selected=[],id="<?php  echo $user_det['id'];?>",term_fld="",course_fld="",subject_fld="",created_at_fld="",due_date_fld="",feedback_fld="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,inbox_messages_table,inbox_messages_selected=[],outbox_messages_table,outbox_messages_selected=[],inbox_task_table,inbox_task_selected=[],outbox_task_table,outbox_task_selected=[],inbox_meetings_table,outbox_meetings_table,inbox_feedback_table,outbox_feedback_table,inbox_document_table,outbox_document_table,inbox_archive_table,outbox_archive_table,personnel_details=[],inbox_count=[],course_details=[],student_course_details=[],parent_info=[],tree_details=[],folder_id=1,inner_folder_id=1,attachmentCount = 0,uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],selected_folder_id="",document_files=[],reply_document_files=[],selected_folder=[],change_tree=true,folder_table,folder_tree=false,notification_type="",ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,file_manager_label_details=<?php echo json_encode($file_manager_label_details); ?>,send_message_role=false,send_task_role=false,send_meeting_role=false,send_feedback_role=false,send_document_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() {
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("306", role_details) != -1)
    {
        send_message_role=true;
    }
    if ($.inArray("307", role_details) != -1)
    {
        send_task_role=true;
    }
    if ($.inArray("308", role_details) != -1)
    {
        send_meeting_role=true;
    }
    if ($.inArray("309", role_details) != -1)
    {
        send_feedback_role=true;
    }
    if ($.inArray("310", role_details) != -1)
    {
        send_document_role=true;
    }
    $("#due_date").flatpickr({
        dateFormat: "d-m-Y"
    }); 
    $("#due_datetime").flatpickr({
        enableTime: true,
        dateFormat: "d-m-Y h:i",
        time_24hr: true
    });
    file_manager_details(); 
    notifications_details();  
	dashboard_details();
});
</script>