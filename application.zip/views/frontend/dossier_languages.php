<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(5) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(6) {
    text-align: center;
}
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[2]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[1]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(88,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="dossier_languages_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[3]['name']; ?></h3>
                    <button type="button" id="label_13_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
                        <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="status_fld" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[8]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[9]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[10]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="del_fld" name="del_fld" data-hide-search="true">
                                    <option value="all"><?php echo $label_details[11]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[12]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[13]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="dossier_languages_filter" name="dossier_languages_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[6]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="dossier_languages_reset" name="dossier_languages_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[7]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[14]['name']; ?></h3>
                                    <button type="button" id="label_13_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(89,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_dossier_languages_btn"><?php echo $label_details[17]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(90,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_dossier_languages" data-toggle="modal"><?php echo $label_details[18]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(91,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_dossier_languages" data-toggle="modal"><?php echo $label_details[21]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(92,$role_details)) { ?>
                            <button type="button" id="status_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#status_dossier_languages" data-toggle="modal" id="status_dossier_languages_btn"><?php echo $label_details[19]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(93,$role_details)) { ?>
                            <button type="button" class="btn btn-sm btn-success my-1 px-2" data-toggle="modal" data-target="#import_dossier_languages" id="import_dossier_languages_btn"><?php echo $label_details[20]['name']; ?> <i class="las la-external-link-alt fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th></th>
                                <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                        <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                        <span></span>
                                    </label>
                                </th>
                                <th data-priority="2" class="fw-bolder"> <?php echo $label_details[14]['name']; ?> </th>
								<th data-priority="4" class="fw-bolder"> <?php echo $label_details[23]['name']; ?> </th>
								<th data-priority="5" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[24]['name']; ?> </th>
                                <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[25]['name']; ?> </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossier_languages_create_id" style="display:none;">
                <form name="add_dossier_languages_form" id="add_dossier_languages_form" class="add_dossier_languages_form">
                    <a name="dossier_languages_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[29]['name']; ?> <?php echo $label_details[30]['name']; ?>
                            </h3>
                            <button type="button" id="label_13_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
						<div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[30]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="name" name="name" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
						<div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[31]['name']; ?> *</label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="bi bi-bookmarks-fill fs-4"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                            <select class="form-select rounded-start-0" data-control="select2" id="code" name="code">
                                                
                                            <option class="form-select rounded-start-0" value="" >Select Code</option><option value="af">Afrikaans</option><option value="af_NA">Afrikaans (Namibia)</option><option value="af_ZA">Afrikaans (South Africa)</option><option value="ak">Akan</option><option value="ak_GH">Akan (Ghana)</option><option value="sq">Albanian</option><option value="sq_AL">Albanian (Albania)</option><option value="sq_XK">Albanian (Kosovo)</option><option value="sq_MK">Albanian (Macedonia)</option><option value="am">Amharic</option><option value="am_ET">Amharic (Ethiopia)</option><option value="ar">Arabic</option><option value="ar_DZ">Arabic (Algeria)</option><option value="ar_BH">Arabic (Bahrain)</option><option value="ar_TD">Arabic (Chad)</option><option value="ar_KM">Arabic (Comoros)</option><option value="ar_DJ">Arabic (Djibouti)</option><option value="ar_EG">Arabic (Egypt)</option><option value="ar_ER">Arabic (Eritrea)</option><option value="ar_IQ">Arabic (Iraq)</option><option value="ar_IL">Arabic (Israel)</option><option value="ar_JO">Arabic (Jordan)</option><option value="ar_KW">Arabic (Kuwait)</option><option value="ar_LB">Arabic (Lebanon)</option><option value="ar_LY">Arabic (Libya)</option><option value="ar_MR">Arabic (Mauritania)</option><option value="ar_MA">Arabic (Morocco)</option><option value="ar_OM">Arabic (Oman)</option><option value="ar_PS">Arabic (Palestinian Territories)</option><option value="ar_QA">Arabic (Qatar)</option><option value="ar_SA">Arabic (Saudi Arabia)</option><option value="ar_SO">Arabic (Somalia)</option><option value="ar_SS">Arabic (South Sudan)</option><option value="ar_SD">Arabic (Sudan)</option><option value="ar_SY">Arabic (Syria)</option><option value="ar_TN">Arabic (Tunisia)</option><option value="ar_AE">Arabic (United Arab Emirates)</option><option value="ar_EH">Arabic (Western Sahara)</option><option value="ar_YE">Arabic (Yemen)</option><option value="hy">Armenian</option><option value="hy_AM">Armenian (Armenia)</option><option value="as">Assamese</option><option value="as_IN">Assamese (India)</option><option value="az">Azerbaijani</option><option value="az_AZ">Azerbaijani (Azerbaijan)</option><option value="az_Cyrl_AZ">Azerbaijani (Cyrillic, Azerbaijan)</option><option value="az_Cyrl">Azerbaijani (Cyrillic)</option><option value="az_Latn_AZ">Azerbaijani (Latin, Azerbaijan)</option><option value="az_Latn">Azerbaijani (Latin)</option><option value="bm">Bambara</option><option value="bm_ML">Bambara (Mali)</option><option value="bn">Bangla</option><option value="bn_BD">Bangla (Bangladesh)</option><option value="bn_IN">Bangla (India)</option><option value="eu">Basque</option><option value="eu_ES">Basque (Spain)</option><option value="be">Belarusian</option><option value="be_BY">Belarusian (Belarus)</option><option value="bs">Bosnian</option><option value="bs_BA">Bosnian (Bosnia &amp; Herzegovina)</option><option value="bs_Cyrl_BA">Bosnian (Cyrillic, Bosnia &amp; Herzegovina)</option><option value="bs_Cyrl">Bosnian (Cyrillic)</option><option value="bs_Latn_BA">Bosnian (Latin, Bosnia &amp; Herzegovina)</option><option value="bs_Latn">Bosnian (Latin)</option><option value="br">Breton</option><option value="br_FR">Breton (France)</option><option value="bg">Bulgarian</option><option value="bg_BG">Bulgarian (Bulgaria)</option><option value="my">Burmese</option><option value="my_MM">Burmese (Myanmar (Burma))</option><option value="ca">Catalan</option><option value="ca_AD">Catalan (Andorra)</option><option value="ca_FR">Catalan (France)</option><option value="ca_IT">Catalan (Italy)</option><option value="ca_ES">Catalan (Spain)</option><option value="ce">Chechen</option><option value="ce_RU">Chechen (Russia)</option><option value="zh">Chinese</option><option value="zh_CN">Chinese (China)</option><option value="zh_HK">Chinese (Hong Kong SAR China)</option><option value="zh_MO">Chinese (Macau SAR China)</option><option value="zh_Hans_CN">Chinese (Simplified, China)</option><option value="zh_Hans_HK">Chinese (Simplified, Hong Kong SAR China)</option><option value="zh_Hans_MO">Chinese (Simplified, Macau SAR China)</option><option value="zh_Hans_SG">Chinese (Simplified, Singapore)</option><option value="zh_Hans">Chinese (Simplified)</option><option value="zh_SG">Chinese (Singapore)</option><option value="zh_TW">Chinese (Taiwan)</option><option value="zh_Hant_HK">Chinese (Traditional, Hong Kong SAR China)</option><option value="zh_Hant_MO">Chinese (Traditional, Macau SAR China)</option><option value="zh_Hant_TW">Chinese (Traditional, Taiwan)</option><option value="zh_Hant">Chinese (Traditional)</option><option value="kw">Cornish</option><option value="kw_GB">Cornish (United Kingdom)</option><option value="hr">Croatian</option><option value="hr_BA">Croatian (Bosnia &amp; Herzegovina)</option><option value="hr_HR">Croatian (Croatia)</option><option value="cs">Czech</option><option value="cs_CZ">Czech (Czechia)</option><option value="da">Danish</option><option value="da_DK">Danish (Denmark)</option><option value="da_GL">Danish (Greenland)</option><option value="nl">Dutch</option><option value="nl_AW">Dutch (Aruba)</option><option value="nl_BE">Dutch (Belgium)</option><option value="nl_BQ">Dutch (Caribbean Netherlands)</option><option value="nl_CW">Dutch (Curaçao)</option><option value="nl_NL">Dutch (Netherlands)</option><option value="nl_SX">Dutch (Sint Maarten)</option><option value="nl_SR">Dutch (Suriname)</option><option value="dz">Dzongkha</option><option value="dz_BT">Dzongkha (Bhutan)</option><option value="en">English</option><option value="en_AS">English (American Samoa)</option><option value="en_AI">English (Anguilla)</option><option value="en_AG">English (Antigua &amp; Barbuda)</option><option value="en_AU">English (Australia)</option><option value="en_AT">English (Austria)</option><option value="en_BS">English (Bahamas)</option><option value="en_BB">English (Barbados)</option><option value="en_BE">English (Belgium)</option><option value="en_BZ">English (Belize)</option><option value="en_BM">English (Bermuda)</option><option value="en_BW">English (Botswana)</option><option value="en_IO">English (British Indian Ocean Territory)</option><option value="en_VG">English (British Virgin Islands)</option><option value="en_BI">English (Burundi)</option><option value="en_CM">English (Cameroon)</option><option value="en_CA">English (Canada)</option><option value="en_KY">English (Cayman Islands)</option><option value="en_CX">English (Christmas Island)</option><option value="en_CC">English (Cocos (Keeling) Islands)</option><option value="en_CK">English (Cook Islands)</option><option value="en_CY">English (Cyprus)</option><option value="en_DK">English (Denmark)</option><option value="en_DG">English (Diego Garcia)</option><option value="en_DM">English (Dominica)</option><option value="en_ER">English (Eritrea)</option><option value="en_FK">English (Falkland Islands)</option><option value="en_FJ">English (Fiji)</option><option value="en_FI">English (Finland)</option><option value="en_GM">English (Gambia)</option><option value="en_DE">English (Germany)</option><option value="en_GH">English (Ghana)</option><option value="en_GI">English (Gibraltar)</option><option value="en_GD">English (Grenada)</option><option value="en_GU">English (Guam)</option><option value="en_GG">English (Guernsey)</option><option value="en_GY">English (Guyana)</option><option value="en_HK">English (Hong Kong SAR China)</option><option value="en_IN">English (India)</option><option value="en_IE">English (Ireland)</option><option value="en_IM">English (Isle of Man)</option><option value="en_IL">English (Israel)</option><option value="en_JM">English (Jamaica)</option><option value="en_JE">English (Jersey)</option><option value="en_KE">English (Kenya)</option><option value="en_KI">English (Kiribati)</option><option value="en_LS">English (Lesotho)</option><option value="en_LR">English (Liberia)</option><option value="en_MO">English (Macau SAR China)</option><option value="en_MG">English (Madagascar)</option><option value="en_MW">English (Malawi)</option><option value="en_MY">English (Malaysia)</option><option value="en_MT">English (Malta)</option><option value="en_MH">English (Marshall Islands)</option><option value="en_MU">English (Mauritius)</option><option value="en_FM">English (Micronesia)</option><option value="en_MS">English (Montserrat)</option><option value="en_NA">English (Namibia)</option><option value="en_NR">English (Nauru)</option><option value="en_NL">English (Netherlands)</option><option value="en_NZ">English (New Zealand)</option><option value="en_NG">English (Nigeria)</option><option value="en_NU">English (Niue)</option><option value="en_NF">English (Norfolk Island)</option><option value="en_MP">English (Northern Mariana Islands)</option><option value="en_PK">English (Pakistan)</option><option value="en_PW">English (Palau)</option><option value="en_PG">English (Papua New Guinea)</option><option value="en_PH">English (Philippines)</option><option value="en_PN">English (Pitcairn Islands)</option><option value="en_PR">English (Puerto Rico)</option><option value="en_RW">English (Rwanda)</option><option value="en_WS">English (Samoa)</option><option value="en_SC">English (Seychelles)</option><option value="en_SL">English (Sierra Leone)</option><option value="en_SG">English (Singapore)</option><option value="en_SX">English (Sint Maarten)</option><option value="en_SI">English (Slovenia)</option><option value="en_SB">English (Solomon Islands)</option><option value="en_ZA">English (South Africa)</option><option value="en_SS">English (South Sudan)</option><option value="en_SH">English (St Helena)</option><option value="en_KN">English (St Kitts &amp; Nevis)</option><option value="en_LC">English (St Lucia)</option><option value="en_VC">English (St Vincent &amp; Grenadines)</option><option value="en_SD">English (Sudan)</option><option value="en_SZ">English (Swaziland)</option><option value="en_SE">English (Sweden)</option><option value="en_CH">English (Switzerland)</option><option value="en_TZ">English (Tanzania)</option><option value="en_TK">English (Tokelau)</option><option value="en_TO">English (Tonga)</option><option value="en_TT">English (Trinidad &amp; Tobago)</option><option value="en_TC">English (Turks &amp; Caicos Islands)</option><option value="en_TV">English (Tuvalu)</option><option value="en_UG">English (Uganda)</option><option value="en_GB">English (United Kingdom)</option><option value="en_US">English (United States)</option><option value="en_UM">English (US Outlying Islands)</option><option value="en_VI">English (US Virgin Islands)</option><option value="en_VU">English (Vanuatu)</option><option value="en_ZM">English (Zambia)</option><option value="en_ZW">English (Zimbabwe)</option><option value="eo">Esperanto</option><option value="et">Estonian</option><option value="et_EE">Estonian (Estonia)</option><option value="ee">Ewe</option><option value="ee_GH">Ewe (Ghana)</option><option value="ee_TG">Ewe (Togo)</option><option value="fo">Faroese</option><option value="fo_DK">Faroese (Denmark)</option><option value="fo_FO">Faroese (Faroe Islands)</option><option value="fi">Finnish</option><option value="fi_FI">Finnish (Finland)</option><option value="fr">French</option><option value="fr_DZ">French (Algeria)</option><option value="fr_BE">French (Belgium)</option><option value="fr_BJ">French (Benin)</option><option value="fr_BF">French (Burkina Faso)</option><option value="fr_BI">French (Burundi)</option><option value="fr_CM">French (Cameroon)</option><option value="fr_CA">French (Canada)</option><option value="fr_CF">French (Central African Republic)</option><option value="fr_TD">French (Chad)</option><option value="fr_KM">French (Comoros)</option><option value="fr_CG">French (Congo - Brazzaville)</option><option value="fr_CD">French (Congo - Kinshasa)</option><option value="fr_CI">French (Côte d’Ivoire)</option><option value="fr_DJ">French (Djibouti)</option><option value="fr_GQ">French (Equatorial Guinea)</option><option value="fr_FR">French (France)</option><option value="fr_GF">French (French Guiana)</option><option value="fr_PF">French (French Polynesia)</option><option value="fr_GA">French (Gabon)</option><option value="fr_GP">French (Guadeloupe)</option><option value="fr_GN">French (Guinea)</option><option value="fr_HT">French (Haiti)</option><option value="fr_LU">French (Luxembourg)</option><option value="fr_MG">French (Madagascar)</option><option value="fr_ML">French (Mali)</option><option value="fr_MQ">French (Martinique)</option><option value="fr_MR">French (Mauritania)</option><option value="fr_MU">French (Mauritius)</option><option value="fr_YT">French (Mayotte)</option><option value="fr_MC">French (Monaco)</option><option value="fr_MA">French (Morocco)</option><option value="fr_NC">French (New Caledonia)</option><option value="fr_NE">French (Niger)</option><option value="fr_RE">French (Réunion)</option><option value="fr_RW">French (Rwanda)</option><option value="fr_SN">French (Senegal)</option><option value="fr_SC">French (Seychelles)</option><option value="fr_BL">French (St Barthélemy)</option><option value="fr_MF">French (St Martin)</option><option value="fr_PM">French (St Pierre &amp; Miquelon)</option><option value="fr_CH">French (Switzerland)</option><option value="fr_SY">French (Syria)</option><option value="fr_TG">French (Togo)</option><option value="fr_TN">French (Tunisia)</option><option value="fr_VU">French (Vanuatu)</option><option value="fr_WF">French (Wallis &amp; Futuna)</option><option value="ff">Fulah</option><option value="ff_CM">Fulah (Cameroon)</option><option value="ff_GN">Fulah (Guinea)</option><option value="ff_MR">Fulah (Mauritania)</option><option value="ff_SN">Fulah (Senegal)</option><option value="gl">Galician</option><option value="gl_ES">Galician (Spain)</option><option value="lg">Ganda</option><option value="lg_UG">Ganda (Uganda)</option><option value="ka">Georgian</option><option value="ka_GE">Georgian (Georgia)</option><option value="de">German</option><option value="de_AT">German (Austria)</option><option value="de_BE">German (Belgium)</option><option value="de_DE">German (Germany)</option><option value="de_IT">German (Italy)</option><option value="de_LI">German (Liechtenstein)</option><option value="de_LU">German (Luxembourg)</option><option value="de_CH">German (Switzerland)</option><option value="el">Greek</option><option value="el_CY">Greek (Cyprus)</option><option value="el_GR">Greek (Greece)</option><option value="gu">Gujarati</option><option value="gu_IN">Gujarati (India)</option><option value="ha">Hausa</option><option value="ha_GH">Hausa (Ghana)</option><option value="ha_NE">Hausa (Niger)</option><option value="ha_NG">Hausa (Nigeria)</option><option value="he">Hebrew</option><option value="he_IL">Hebrew (Israel)</option><option value="hi">Hindi</option><option value="hi_IN">Hindi (India)</option><option value="hu">Hungarian</option><option value="hu_HU">Hungarian (Hungary)</option><option value="is">Icelandic</option><option value="is_IS">Icelandic (Iceland)</option><option value="ig">Igbo</option><option value="ig_NG">Igbo (Nigeria)</option><option value="id">Indonesian</option><option value="id_ID">Indonesian (Indonesia)</option><option value="ga">Irish</option><option value="ga_IE">Irish (Ireland)</option><option value="it">Italian</option><option value="it_IT">Italian (Italy)</option><option value="it_SM">Italian (San Marino)</option><option value="it_CH">Italian (Switzerland)</option><option value="it_VA">Italian (Vatican City)</option><option value="ja">Japanese</option><option value="ja_JP">Japanese (Japan)</option><option value="kl">Kalaallisut</option><option value="kl_GL">Kalaallisut (Greenland)</option><option value="kn">Kannada</option><option value="kn_IN">Kannada (India)</option><option value="ks">Kashmiri</option><option value="ks_IN">Kashmiri (India)</option><option value="kk">Kazakh</option><option value="kk_KZ">Kazakh (Kazakhstan)</option><option value="km">Khmer</option><option value="km_KH">Khmer (Cambodia)</option><option value="ki">Kikuyu</option><option value="ki_KE">Kikuyu (Kenya)</option><option value="rw">Kinyarwanda</option><option value="rw_RW">Kinyarwanda (Rwanda)</option><option value="ko">Korean</option><option value="ko_KP">Korean (North Korea)</option><option value="ko_KR">Korean (South Korea)</option><option value="ky">Kyrgyz</option><option value="ky_KG">Kyrgyz (Kyrgyzstan)</option><option value="lo">Lao</option><option value="lo_LA">Lao (Laos)</option><option value="lv">Latvian</option><option value="lv_LV">Latvian (Latvia)</option><option value="ln">Lingala</option><option value="ln_AO">Lingala (Angola)</option><option value="ln_CF">Lingala (Central African Republic)</option><option value="ln_CG">Lingala (Congo - Brazzaville)</option><option value="ln_CD">Lingala (Congo - Kinshasa)</option><option value="lt">Lithuanian</option><option value="lt_LT">Lithuanian (Lithuania)</option><option value="lu">Luba-Katanga</option><option value="lu_CD">Luba-Katanga (Congo - Kinshasa)</option><option value="lb">Luxembourgish</option><option value="lb_LU">Luxembourgish (Luxembourg)</option><option value="mk">Macedonian</option><option value="mk_MK">Macedonian (Macedonia)</option><option value="mg">Malagasy</option><option value="mg_MG">Malagasy (Madagascar)</option><option value="ms">Malay</option><option value="ms_BN">Malay (Brunei)</option><option value="ms_MY">Malay (Malaysia)</option><option value="ms_SG">Malay (Singapore)</option><option value="ml">Malayalam</option><option value="ml_IN">Malayalam (India)</option><option value="mt">Maltese</option><option value="mt_MT">Maltese (Malta)</option><option value="gv">Manx</option><option value="gv_IM">Manx (Isle of Man)</option><option value="mr">Marathi</option><option value="mr_IN">Marathi (India)</option><option value="mn">Mongolian</option><option value="mn_MN">Mongolian (Mongolia)</option><option value="ne">Nepali</option><option value="ne_IN">Nepali (India)</option><option value="ne_NP">Nepali (Nepal)</option><option value="nd">North Ndebele</option><option value="nd_ZW">North Ndebele (Zimbabwe)</option><option value="se">Northern Sami</option><option value="se_FI">Northern Sami (Finland)</option><option value="se_NO">Northern Sami (Norway)</option><option value="se_SE">Northern Sami (Sweden)</option><option value="no">Norwegian</option><option value="no_NO">Norwegian (Norway)</option><option value="nb">Norwegian Bokmål</option><option value="nb_NO">Norwegian Bokmål (Norway)</option><option value="nb_SJ">Norwegian Bokmål (Svalbard &amp; Jan Mayen)</option><option value="nn">Norwegian Nynorsk</option><option value="nn_NO">Norwegian Nynorsk (Norway)</option><option value="or">Odia</option><option value="or_IN">Odia (India)</option><option value="om">Oromo</option><option value="om_ET">Oromo (Ethiopia)</option><option value="om_KE">Oromo (Kenya)</option><option value="os">Ossetic</option><option value="os_GE">Ossetic (Georgia)</option><option value="os_RU">Ossetic (Russia)</option><option value="ps">Pashto</option><option value="ps_AF">Pashto (Afghanistan)</option><option value="fa">Persian</option><option value="fa_AF">Persian (Afghanistan)</option><option value="fa_IR">Persian (Iran)</option><option value="pl">Polish</option><option value="pl_PL">Polish (Poland)</option><option value="pt">Portuguese</option><option value="pt_AO">Portuguese (Angola)</option><option value="pt_BR">Portuguese (Brazil)</option><option value="pt_CV">Portuguese (Cape Verde)</option><option value="pt_GQ">Portuguese (Equatorial Guinea)</option><option value="pt_GW">Portuguese (Guinea-Bissau)</option><option value="pt_LU">Portuguese (Luxembourg)</option><option value="pt_MO">Portuguese (Macau SAR China)</option><option value="pt_MZ">Portuguese (Mozambique)</option><option value="pt_PT">Portuguese (Portugal)</option><option value="pt_ST">Portuguese (São Tomé &amp; Príncipe)</option><option value="pt_CH">Portuguese (Switzerland)</option><option value="pt_TL">Portuguese (Timor-Leste)</option><option value="pa">Punjabi</option><option value="pa_Arab_PK">Punjabi (Arabic, Pakistan)</option><option value="pa_Arab">Punjabi (Arabic)</option><option value="pa_Guru_IN">Punjabi (Gurmukhi, India)</option><option value="pa_Guru">Punjabi (Gurmukhi)</option><option value="pa_IN">Punjabi (India)</option><option value="pa_PK">Punjabi (Pakistan)</option><option value="qu">Quechua</option><option value="qu_BO">Quechua (Bolivia)</option><option value="qu_EC">Quechua (Ecuador)</option><option value="qu_PE">Quechua (Peru)</option><option value="ro">Romanian</option><option value="ro_MD">Romanian (Moldova)</option><option value="ro_RO">Romanian (Romania)</option><option value="rm">Romansh</option><option value="rm_CH">Romansh (Switzerland)</option><option value="rn">Rundi</option><option value="rn_BI">Rundi (Burundi)</option><option value="ru">Russian</option><option value="ru_BY">Russian (Belarus)</option><option value="ru_KZ">Russian (Kazakhstan)</option><option value="ru_KG">Russian (Kyrgyzstan)</option><option value="ru_MD">Russian (Moldova)</option><option value="ru_RU">Russian (Russia)</option><option value="ru_UA">Russian (Ukraine)</option><option value="sg">Sango</option><option value="sg_CF">Sango (Central African Republic)</option><option value="gd">Scottish Gaelic</option><option value="gd_GB">Scottish Gaelic (United Kingdom)</option><option value="sr">Serbian</option><option value="sr_BA">Serbian (Bosnia &amp; Herzegovina)</option><option value="sr_Cyrl_BA">Serbian (Cyrillic, Bosnia &amp; Herzegovina)</option><option value="sr_Cyrl_XK">Serbian (Cyrillic, Kosovo)</option><option value="sr_Cyrl_ME">Serbian (Cyrillic, Montenegro)</option><option value="sr_Cyrl_RS">Serbian (Cyrillic, Serbia)</option><option value="sr_Cyrl">Serbian (Cyrillic)</option><option value="sr_XK">Serbian (Kosovo)</option><option value="sr_Latn_BA">Serbian (Latin, Bosnia &amp; Herzegovina)</option><option value="sr_Latn_XK">Serbian (Latin, Kosovo)</option><option value="sr_Latn_ME">Serbian (Latin, Montenegro)</option><option value="sr_Latn_RS">Serbian (Latin, Serbia)</option><option value="sr_Latn">Serbian (Latin)</option><option value="sr_ME">Serbian (Montenegro)</option><option value="sr_RS">Serbian (Serbia)</option><option value="sh">Serbo-Croatian</option><option value="sh_BA">Serbo-Croatian (Bosnia &amp; Herzegovina)</option><option value="sn">Shona</option><option value="sn_ZW">Shona (Zimbabwe)</option><option value="ii">Sichuan Yi</option><option value="ii_CN">Sichuan Yi (China)</option><option value="si">Sinhala</option><option value="si_LK">Sinhala (Sri Lanka)</option><option value="sk">Slovak</option><option value="sk_SK">Slovak (Slovakia)</option><option value="sl">Slovenian</option><option value="sl_SI">Slovenian (Slovenia)</option><option value="so">Somali</option><option value="so_DJ">Somali (Djibouti)</option><option value="so_ET">Somali (Ethiopia)</option><option value="so_KE">Somali (Kenya)</option><option value="so_SO">Somali (Somalia)</option><option value="es">Spanish</option><option value="es_AR">Spanish (Argentina)</option><option value="es_BZ">Spanish (Belize)</option><option value="es_BO">Spanish (Bolivia)</option><option value="es_BR">Spanish (Brazil)</option><option value="es_IC">Spanish (Canary Islands)</option><option value="es_EA">Spanish (Ceuta &amp; Melilla)</option><option value="es_CL">Spanish (Chile)</option><option value="es_CO">Spanish (Colombia)</option><option value="es_CR">Spanish (Costa Rica)</option><option value="es_CU">Spanish (Cuba)</option><option value="es_DO">Spanish (Dominican Republic)</option><option value="es_EC">Spanish (Ecuador)</option><option value="es_SV">Spanish (El Salvador)</option><option value="es_GQ">Spanish (Equatorial Guinea)</option><option value="es_GT">Spanish (Guatemala)</option><option value="es_HN">Spanish (Honduras)</option><option value="es_MX">Spanish (Mexico)</option><option value="es_NI">Spanish (Nicaragua)</option><option value="es_PA">Spanish (Panama)</option><option value="es_PY">Spanish (Paraguay)</option><option value="es_PE">Spanish (Peru)</option><option value="es_PH">Spanish (Philippines)</option><option value="es_PR">Spanish (Puerto Rico)</option><option value="es_ES">Spanish (Spain)</option><option value="es_US">Spanish (United States)</option><option value="es_UY">Spanish (Uruguay)</option><option value="es_VE">Spanish (Venezuela)</option><option value="sw">Swahili</option><option value="sw_CD">Swahili (Congo - Kinshasa)</option><option value="sw_KE">Swahili (Kenya)</option><option value="sw_TZ">Swahili (Tanzania)</option><option value="sw_UG">Swahili (Uganda)</option><option value="sv">Swedish</option><option value="sv_AX">Swedish (Åland Islands)</option><option value="sv_FI">Swedish (Finland)</option><option value="sv_SE">Swedish (Sweden)</option><option value="tl">Tagalog</option><option value="tl_PH">Tagalog (Philippines)</option><option value="tg">Tajik</option><option value="tg_TJ">Tajik (Tajikistan)</option><option value="ta">Tamil</option><option value="ta_IN">Tamil (India)</option><option value="ta_MY">Tamil (Malaysia)</option><option value="ta_SG">Tamil (Singapore)</option><option value="ta_LK">Tamil (Sri Lanka)</option><option value="tt">Tatar</option><option value="tt_RU">Tatar (Russia)</option><option value="te">Telugu</option><option value="te_IN">Telugu (India)</option><option value="th">Thai</option><option value="th_TH">Thai (Thailand)</option><option value="bo">Tibetan</option><option value="bo_CN">Tibetan (China)</option><option value="bo_IN">Tibetan (India)</option><option value="ti">Tigrinya</option><option value="ti_ER">Tigrinya (Eritrea)</option><option value="ti_ET">Tigrinya (Ethiopia)</option><option value="to">Tongan</option><option value="to_TO">Tongan (Tonga)</option><option value="tr">Turkish</option><option value="tr_CY">Turkish (Cyprus)</option><option value="tr_TR">Turkish (Turkey)</option><option value="uk">Ukrainian</option><option value="uk_UA">Ukrainian (Ukraine)</option><option value="ur">Urdu</option><option value="ur_IN">Urdu (India)</option><option value="ur_PK">Urdu (Pakistan)</option><option value="ug">Uyghur</option><option value="ug_CN">Uyghur (China)</option><option value="uz">Uzbek</option><option value="uz_AF">Uzbek (Afghanistan)</option><option value="uz_Arab_AF">Uzbek (Arabic, Afghanistan)</option><option value="uz_Arab">Uzbek (Arabic)</option><option value="uz_Cyrl_UZ">Uzbek (Cyrillic, Uzbekistan)</option><option value="uz_Cyrl">Uzbek (Cyrillic)</option><option value="uz_Latn_UZ">Uzbek (Latin, Uzbekistan)</option><option value="uz_Latn">Uzbek (Latin)</option><option value="uz_UZ">Uzbek (Uzbekistan)</option><option value="vi">Vietnamese</option><option value="vi_VN">Vietnamese (Vietnam)</option><option value="cy">Welsh</option><option value="cy_GB">Welsh (United Kingdom)</option><option value="fy">Western Frisian</option><option value="fy_NL">Western Frisian (Netherlands)</option><option value="wo">Wolof</option><option value="wo_SN">Wolof (Senegal)</option><option value="yi">Yiddish</option><option value="yo">Yoruba</option><option value="yo_BJ">Yoruba (Benin)</option><option value="yo_NG">Yoruba (Nigeria)</option><option value="zu">Zulu</option><option value="zu_ZA">Zulu (South Africa)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                        <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[32]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_dossier_languages_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[33]['name']; ?></button>
                            <button type="button" id="add_dossier_languages_new_sub" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[34]['name']; ?></button>
                            <button type="button" id="add_dossier_languages_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[35]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="dossier_languages_edit_id" style="display:none;">
                <form name="edit_dossier_languages_form" id="edit_dossier_languages_form" class="edit_dossier_languages_form">
                    <a name="dossier_languages_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[38]['name']; ?> <?php echo $label_details[39]['name']; ?></h3>
                                <button type="button" id="label_13_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-10">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[39]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="name_up" name="name" class="form-control"  aria-describedby="basic-addon1">
                                <input type="hidden" id="token_id" name="token_id" />
                            </div>
                        </div>
						<div class="input-group mb-5 mb-5">
                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[40]['name']; ?> *</label>
                                    <div class="input-group flex-nowrap">
                                        <span class="input-group-text"><i class="bi bi-bookmarks-fill fs-4"></i></span>
                                        <div class="overflow-hidden flex-grow-1">
                                          <select class="form-select rounded-start-0" data-control="select2" id="code_up" name="code">
                                                    <option value="" selected="selected"></option>Select Code<option value="af">Afrikaans</option><option value="af_NA">Afrikaans (Namibia)</option><option value="af_ZA">Afrikaans (South Africa)</option><option value="ak">Akan</option><option value="ak_GH">Akan (Ghana)</option><option value="sq">Albanian</option><option value="sq_AL">Albanian (Albania)</option><option value="sq_XK">Albanian (Kosovo)</option><option value="sq_MK">Albanian (Macedonia)</option><option value="am">Amharic</option><option value="am_ET">Amharic (Ethiopia)</option><option value="ar">Arabic</option><option value="ar_DZ">Arabic (Algeria)</option><option value="ar_BH">Arabic (Bahrain)</option><option value="ar_TD">Arabic (Chad)</option><option value="ar_KM">Arabic (Comoros)</option><option value="ar_DJ">Arabic (Djibouti)</option><option value="ar_EG">Arabic (Egypt)</option><option value="ar_ER">Arabic (Eritrea)</option><option value="ar_IQ">Arabic (Iraq)</option><option value="ar_IL">Arabic (Israel)</option><option value="ar_JO">Arabic (Jordan)</option><option value="ar_KW">Arabic (Kuwait)</option><option value="ar_LB">Arabic (Lebanon)</option><option value="ar_LY">Arabic (Libya)</option><option value="ar_MR">Arabic (Mauritania)</option><option value="ar_MA">Arabic (Morocco)</option><option value="ar_OM">Arabic (Oman)</option><option value="ar_PS">Arabic (Palestinian Territories)</option><option value="ar_QA">Arabic (Qatar)</option><option value="ar_SA">Arabic (Saudi Arabia)</option><option value="ar_SO">Arabic (Somalia)</option><option value="ar_SS">Arabic (South Sudan)</option><option value="ar_SD">Arabic (Sudan)</option><option value="ar_SY">Arabic (Syria)</option><option value="ar_TN">Arabic (Tunisia)</option><option value="ar_AE">Arabic (United Arab Emirates)</option><option value="ar_EH">Arabic (Western Sahara)</option><option value="ar_YE">Arabic (Yemen)</option><option value="hy">Armenian</option><option value="hy_AM">Armenian (Armenia)</option><option value="as">Assamese</option><option value="as_IN">Assamese (India)</option><option value="az">Azerbaijani</option><option value="az_AZ">Azerbaijani (Azerbaijan)</option><option value="az_Cyrl_AZ">Azerbaijani (Cyrillic, Azerbaijan)</option><option value="az_Cyrl">Azerbaijani (Cyrillic)</option><option value="az_Latn_AZ">Azerbaijani (Latin, Azerbaijan)</option><option value="az_Latn">Azerbaijani (Latin)</option><option value="bm">Bambara</option><option value="bm_ML">Bambara (Mali)</option><option value="bn">Bangla</option><option value="bn_BD">Bangla (Bangladesh)</option><option value="bn_IN">Bangla (India)</option><option value="eu">Basque</option><option value="eu_ES">Basque (Spain)</option><option value="be">Belarusian</option><option value="be_BY">Belarusian (Belarus)</option><option value="bs">Bosnian</option><option value="bs_BA">Bosnian (Bosnia &amp; Herzegovina)</option><option value="bs_Cyrl_BA">Bosnian (Cyrillic, Bosnia &amp; Herzegovina)</option><option value="bs_Cyrl">Bosnian (Cyrillic)</option><option value="bs_Latn_BA">Bosnian (Latin, Bosnia &amp; Herzegovina)</option><option value="bs_Latn">Bosnian (Latin)</option><option value="br">Breton</option><option value="br_FR">Breton (France)</option><option value="bg">Bulgarian</option><option value="bg_BG">Bulgarian (Bulgaria)</option><option value="my">Burmese</option><option value="my_MM">Burmese (Myanmar (Burma))</option><option value="ca">Catalan</option><option value="ca_AD">Catalan (Andorra)</option><option value="ca_FR">Catalan (France)</option><option value="ca_IT">Catalan (Italy)</option><option value="ca_ES">Catalan (Spain)</option><option value="ce">Chechen</option><option value="ce_RU">Chechen (Russia)</option><option value="zh">Chinese</option><option value="zh_CN">Chinese (China)</option><option value="zh_HK">Chinese (Hong Kong SAR China)</option><option value="zh_MO">Chinese (Macau SAR China)</option><option value="zh_Hans_CN">Chinese (Simplified, China)</option><option value="zh_Hans_HK">Chinese (Simplified, Hong Kong SAR China)</option><option value="zh_Hans_MO">Chinese (Simplified, Macau SAR China)</option><option value="zh_Hans_SG">Chinese (Simplified, Singapore)</option><option value="zh_Hans">Chinese (Simplified)</option><option value="zh_SG">Chinese (Singapore)</option><option value="zh_TW">Chinese (Taiwan)</option><option value="zh_Hant_HK">Chinese (Traditional, Hong Kong SAR China)</option><option value="zh_Hant_MO">Chinese (Traditional, Macau SAR China)</option><option value="zh_Hant_TW">Chinese (Traditional, Taiwan)</option><option value="zh_Hant">Chinese (Traditional)</option><option value="kw">Cornish</option><option value="kw_GB">Cornish (United Kingdom)</option><option value="hr">Croatian</option><option value="hr_BA">Croatian (Bosnia &amp; Herzegovina)</option><option value="hr_HR">Croatian (Croatia)</option><option value="cs">Czech</option><option value="cs_CZ">Czech (Czechia)</option><option value="da">Danish</option><option value="da_DK">Danish (Denmark)</option><option value="da_GL">Danish (Greenland)</option><option value="nl">Dutch</option><option value="nl_AW">Dutch (Aruba)</option><option value="nl_BE">Dutch (Belgium)</option><option value="nl_BQ">Dutch (Caribbean Netherlands)</option><option value="nl_CW">Dutch (Curaçao)</option><option value="nl_NL">Dutch (Netherlands)</option><option value="nl_SX">Dutch (Sint Maarten)</option><option value="nl_SR">Dutch (Suriname)</option><option value="dz">Dzongkha</option><option value="dz_BT">Dzongkha (Bhutan)</option><option value="en">English</option><option value="en_AS">English (American Samoa)</option><option value="en_AI">English (Anguilla)</option><option value="en_AG">English (Antigua &amp; Barbuda)</option><option value="en_AU">English (Australia)</option><option value="en_AT">English (Austria)</option><option value="en_BS">English (Bahamas)</option><option value="en_BB">English (Barbados)</option><option value="en_BE">English (Belgium)</option><option value="en_BZ">English (Belize)</option><option value="en_BM">English (Bermuda)</option><option value="en_BW">English (Botswana)</option><option value="en_IO">English (British Indian Ocean Territory)</option><option value="en_VG">English (British Virgin Islands)</option><option value="en_BI">English (Burundi)</option><option value="en_CM">English (Cameroon)</option><option value="en_CA">English (Canada)</option><option value="en_KY">English (Cayman Islands)</option><option value="en_CX">English (Christmas Island)</option><option value="en_CC">English (Cocos (Keeling) Islands)</option><option value="en_CK">English (Cook Islands)</option><option value="en_CY">English (Cyprus)</option><option value="en_DK">English (Denmark)</option><option value="en_DG">English (Diego Garcia)</option><option value="en_DM">English (Dominica)</option><option value="en_ER">English (Eritrea)</option><option value="en_FK">English (Falkland Islands)</option><option value="en_FJ">English (Fiji)</option><option value="en_FI">English (Finland)</option><option value="en_GM">English (Gambia)</option><option value="en_DE">English (Germany)</option><option value="en_GH">English (Ghana)</option><option value="en_GI">English (Gibraltar)</option><option value="en_GD">English (Grenada)</option><option value="en_GU">English (Guam)</option><option value="en_GG">English (Guernsey)</option><option value="en_GY">English (Guyana)</option><option value="en_HK">English (Hong Kong SAR China)</option><option value="en_IN">English (India)</option><option value="en_IE">English (Ireland)</option><option value="en_IM">English (Isle of Man)</option><option value="en_IL">English (Israel)</option><option value="en_JM">English (Jamaica)</option><option value="en_JE">English (Jersey)</option><option value="en_KE">English (Kenya)</option><option value="en_KI">English (Kiribati)</option><option value="en_LS">English (Lesotho)</option><option value="en_LR">English (Liberia)</option><option value="en_MO">English (Macau SAR China)</option><option value="en_MG">English (Madagascar)</option><option value="en_MW">English (Malawi)</option><option value="en_MY">English (Malaysia)</option><option value="en_MT">English (Malta)</option><option value="en_MH">English (Marshall Islands)</option><option value="en_MU">English (Mauritius)</option><option value="en_FM">English (Micronesia)</option><option value="en_MS">English (Montserrat)</option><option value="en_NA">English (Namibia)</option><option value="en_NR">English (Nauru)</option><option value="en_NL">English (Netherlands)</option><option value="en_NZ">English (New Zealand)</option><option value="en_NG">English (Nigeria)</option><option value="en_NU">English (Niue)</option><option value="en_NF">English (Norfolk Island)</option><option value="en_MP">English (Northern Mariana Islands)</option><option value="en_PK">English (Pakistan)</option><option value="en_PW">English (Palau)</option><option value="en_PG">English (Papua New Guinea)</option><option value="en_PH">English (Philippines)</option><option value="en_PN">English (Pitcairn Islands)</option><option value="en_PR">English (Puerto Rico)</option><option value="en_RW">English (Rwanda)</option><option value="en_WS">English (Samoa)</option><option value="en_SC">English (Seychelles)</option><option value="en_SL">English (Sierra Leone)</option><option value="en_SG">English (Singapore)</option><option value="en_SX">English (Sint Maarten)</option><option value="en_SI">English (Slovenia)</option><option value="en_SB">English (Solomon Islands)</option><option value="en_ZA">English (South Africa)</option><option value="en_SS">English (South Sudan)</option><option value="en_SH">English (St Helena)</option><option value="en_KN">English (St Kitts &amp; Nevis)</option><option value="en_LC">English (St Lucia)</option><option value="en_VC">English (St Vincent &amp; Grenadines)</option><option value="en_SD">English (Sudan)</option><option value="en_SZ">English (Swaziland)</option><option value="en_SE">English (Sweden)</option><option value="en_CH">English (Switzerland)</option><option value="en_TZ">English (Tanzania)</option><option value="en_TK">English (Tokelau)</option><option value="en_TO">English (Tonga)</option><option value="en_TT">English (Trinidad &amp; Tobago)</option><option value="en_TC">English (Turks &amp; Caicos Islands)</option><option value="en_TV">English (Tuvalu)</option><option value="en_UG">English (Uganda)</option><option value="en_GB">English (United Kingdom)</option><option value="en_US">English (United States)</option><option value="en_UM">English (US Outlying Islands)</option><option value="en_VI">English (US Virgin Islands)</option><option value="en_VU">English (Vanuatu)</option><option value="en_ZM">English (Zambia)</option><option value="en_ZW">English (Zimbabwe)</option><option value="eo">Esperanto</option><option value="et">Estonian</option><option value="et_EE">Estonian (Estonia)</option><option value="ee">Ewe</option><option value="ee_GH">Ewe (Ghana)</option><option value="ee_TG">Ewe (Togo)</option><option value="fo">Faroese</option><option value="fo_DK">Faroese (Denmark)</option><option value="fo_FO">Faroese (Faroe Islands)</option><option value="fi">Finnish</option><option value="fi_FI">Finnish (Finland)</option><option value="fr">French</option><option value="fr_DZ">French (Algeria)</option><option value="fr_BE">French (Belgium)</option><option value="fr_BJ">French (Benin)</option><option value="fr_BF">French (Burkina Faso)</option><option value="fr_BI">French (Burundi)</option><option value="fr_CM">French (Cameroon)</option><option value="fr_CA">French (Canada)</option><option value="fr_CF">French (Central African Republic)</option><option value="fr_TD">French (Chad)</option><option value="fr_KM">French (Comoros)</option><option value="fr_CG">French (Congo - Brazzaville)</option><option value="fr_CD">French (Congo - Kinshasa)</option><option value="fr_CI">French (Côte d’Ivoire)</option><option value="fr_DJ">French (Djibouti)</option><option value="fr_GQ">French (Equatorial Guinea)</option><option value="fr_FR">French (France)</option><option value="fr_GF">French (French Guiana)</option><option value="fr_PF">French (French Polynesia)</option><option value="fr_GA">French (Gabon)</option><option value="fr_GP">French (Guadeloupe)</option><option value="fr_GN">French (Guinea)</option><option value="fr_HT">French (Haiti)</option><option value="fr_LU">French (Luxembourg)</option><option value="fr_MG">French (Madagascar)</option><option value="fr_ML">French (Mali)</option><option value="fr_MQ">French (Martinique)</option><option value="fr_MR">French (Mauritania)</option><option value="fr_MU">French (Mauritius)</option><option value="fr_YT">French (Mayotte)</option><option value="fr_MC">French (Monaco)</option><option value="fr_MA">French (Morocco)</option><option value="fr_NC">French (New Caledonia)</option><option value="fr_NE">French (Niger)</option><option value="fr_RE">French (Réunion)</option><option value="fr_RW">French (Rwanda)</option><option value="fr_SN">French (Senegal)</option><option value="fr_SC">French (Seychelles)</option><option value="fr_BL">French (St Barthélemy)</option><option value="fr_MF">French (St Martin)</option><option value="fr_PM">French (St Pierre &amp; Miquelon)</option><option value="fr_CH">French (Switzerland)</option><option value="fr_SY">French (Syria)</option><option value="fr_TG">French (Togo)</option><option value="fr_TN">French (Tunisia)</option><option value="fr_VU">French (Vanuatu)</option><option value="fr_WF">French (Wallis &amp; Futuna)</option><option value="ff">Fulah</option><option value="ff_CM">Fulah (Cameroon)</option><option value="ff_GN">Fulah (Guinea)</option><option value="ff_MR">Fulah (Mauritania)</option><option value="ff_SN">Fulah (Senegal)</option><option value="gl">Galician</option><option value="gl_ES">Galician (Spain)</option><option value="lg">Ganda</option><option value="lg_UG">Ganda (Uganda)</option><option value="ka">Georgian</option><option value="ka_GE">Georgian (Georgia)</option><option value="de">German</option><option value="de_AT">German (Austria)</option><option value="de_BE">German (Belgium)</option><option value="de_DE">German (Germany)</option><option value="de_IT">German (Italy)</option><option value="de_LI">German (Liechtenstein)</option><option value="de_LU">German (Luxembourg)</option><option value="de_CH">German (Switzerland)</option><option value="el">Greek</option><option value="el_CY">Greek (Cyprus)</option><option value="el_GR">Greek (Greece)</option><option value="gu">Gujarati</option><option value="gu_IN">Gujarati (India)</option><option value="ha">Hausa</option><option value="ha_GH">Hausa (Ghana)</option><option value="ha_NE">Hausa (Niger)</option><option value="ha_NG">Hausa (Nigeria)</option><option value="he">Hebrew</option><option value="he_IL">Hebrew (Israel)</option><option value="hi">Hindi</option><option value="hi_IN">Hindi (India)</option><option value="hu">Hungarian</option><option value="hu_HU">Hungarian (Hungary)</option><option value="is">Icelandic</option><option value="is_IS">Icelandic (Iceland)</option><option value="ig">Igbo</option><option value="ig_NG">Igbo (Nigeria)</option><option value="id">Indonesian</option><option value="id_ID">Indonesian (Indonesia)</option><option value="ga">Irish</option><option value="ga_IE">Irish (Ireland)</option><option value="it">Italian</option><option value="it_IT">Italian (Italy)</option><option value="it_SM">Italian (San Marino)</option><option value="it_CH">Italian (Switzerland)</option><option value="it_VA">Italian (Vatican City)</option><option value="ja">Japanese</option><option value="ja_JP">Japanese (Japan)</option><option value="kl">Kalaallisut</option><option value="kl_GL">Kalaallisut (Greenland)</option><option value="kn">Kannada</option><option value="kn_IN">Kannada (India)</option><option value="ks">Kashmiri</option><option value="ks_IN">Kashmiri (India)</option><option value="kk">Kazakh</option><option value="kk_KZ">Kazakh (Kazakhstan)</option><option value="km">Khmer</option><option value="km_KH">Khmer (Cambodia)</option><option value="ki">Kikuyu</option><option value="ki_KE">Kikuyu (Kenya)</option><option value="rw">Kinyarwanda</option><option value="rw_RW">Kinyarwanda (Rwanda)</option><option value="ko">Korean</option><option value="ko_KP">Korean (North Korea)</option><option value="ko_KR">Korean (South Korea)</option><option value="ky">Kyrgyz</option><option value="ky_KG">Kyrgyz (Kyrgyzstan)</option><option value="lo">Lao</option><option value="lo_LA">Lao (Laos)</option><option value="lv">Latvian</option><option value="lv_LV">Latvian (Latvia)</option><option value="ln">Lingala</option><option value="ln_AO">Lingala (Angola)</option><option value="ln_CF">Lingala (Central African Republic)</option><option value="ln_CG">Lingala (Congo - Brazzaville)</option><option value="ln_CD">Lingala (Congo - Kinshasa)</option><option value="lt">Lithuanian</option><option value="lt_LT">Lithuanian (Lithuania)</option><option value="lu">Luba-Katanga</option><option value="lu_CD">Luba-Katanga (Congo - Kinshasa)</option><option value="lb">Luxembourgish</option><option value="lb_LU">Luxembourgish (Luxembourg)</option><option value="mk">Macedonian</option><option value="mk_MK">Macedonian (Macedonia)</option><option value="mg">Malagasy</option><option value="mg_MG">Malagasy (Madagascar)</option><option value="ms">Malay</option><option value="ms_BN">Malay (Brunei)</option><option value="ms_MY">Malay (Malaysia)</option><option value="ms_SG">Malay (Singapore)</option><option value="ml">Malayalam</option><option value="ml_IN">Malayalam (India)</option><option value="mt">Maltese</option><option value="mt_MT">Maltese (Malta)</option><option value="gv">Manx</option><option value="gv_IM">Manx (Isle of Man)</option><option value="mr">Marathi</option><option value="mr_IN">Marathi (India)</option><option value="mn">Mongolian</option><option value="mn_MN">Mongolian (Mongolia)</option><option value="ne">Nepali</option><option value="ne_IN">Nepali (India)</option><option value="ne_NP">Nepali (Nepal)</option><option value="nd">North Ndebele</option><option value="nd_ZW">North Ndebele (Zimbabwe)</option><option value="se">Northern Sami</option><option value="se_FI">Northern Sami (Finland)</option><option value="se_NO">Northern Sami (Norway)</option><option value="se_SE">Northern Sami (Sweden)</option><option value="no">Norwegian</option><option value="no_NO">Norwegian (Norway)</option><option value="nb">Norwegian Bokmål</option><option value="nb_NO">Norwegian Bokmål (Norway)</option><option value="nb_SJ">Norwegian Bokmål (Svalbard &amp; Jan Mayen)</option><option value="nn">Norwegian Nynorsk</option><option value="nn_NO">Norwegian Nynorsk (Norway)</option><option value="or">Odia</option><option value="or_IN">Odia (India)</option><option value="om">Oromo</option><option value="om_ET">Oromo (Ethiopia)</option><option value="om_KE">Oromo (Kenya)</option><option value="os">Ossetic</option><option value="os_GE">Ossetic (Georgia)</option><option value="os_RU">Ossetic (Russia)</option><option value="ps">Pashto</option><option value="ps_AF">Pashto (Afghanistan)</option><option value="fa">Persian</option><option value="fa_AF">Persian (Afghanistan)</option><option value="fa_IR">Persian (Iran)</option><option value="pl">Polish</option><option value="pl_PL">Polish (Poland)</option><option value="pt">Portuguese</option><option value="pt_AO">Portuguese (Angola)</option><option value="pt_BR">Portuguese (Brazil)</option><option value="pt_CV">Portuguese (Cape Verde)</option><option value="pt_GQ">Portuguese (Equatorial Guinea)</option><option value="pt_GW">Portuguese (Guinea-Bissau)</option><option value="pt_LU">Portuguese (Luxembourg)</option><option value="pt_MO">Portuguese (Macau SAR China)</option><option value="pt_MZ">Portuguese (Mozambique)</option><option value="pt_PT">Portuguese (Portugal)</option><option value="pt_ST">Portuguese (São Tomé &amp; Príncipe)</option><option value="pt_CH">Portuguese (Switzerland)</option><option value="pt_TL">Portuguese (Timor-Leste)</option><option value="pa">Punjabi</option><option value="pa_Arab_PK">Punjabi (Arabic, Pakistan)</option><option value="pa_Arab">Punjabi (Arabic)</option><option value="pa_Guru_IN">Punjabi (Gurmukhi, India)</option><option value="pa_Guru">Punjabi (Gurmukhi)</option><option value="pa_IN">Punjabi (India)</option><option value="pa_PK">Punjabi (Pakistan)</option><option value="qu">Quechua</option><option value="qu_BO">Quechua (Bolivia)</option><option value="qu_EC">Quechua (Ecuador)</option><option value="qu_PE">Quechua (Peru)</option><option value="ro">Romanian</option><option value="ro_MD">Romanian (Moldova)</option><option value="ro_RO">Romanian (Romania)</option><option value="rm">Romansh</option><option value="rm_CH">Romansh (Switzerland)</option><option value="rn">Rundi</option><option value="rn_BI">Rundi (Burundi)</option><option value="ru">Russian</option><option value="ru_BY">Russian (Belarus)</option><option value="ru_KZ">Russian (Kazakhstan)</option><option value="ru_KG">Russian (Kyrgyzstan)</option><option value="ru_MD">Russian (Moldova)</option><option value="ru_RU">Russian (Russia)</option><option value="ru_UA">Russian (Ukraine)</option><option value="sg">Sango</option><option value="sg_CF">Sango (Central African Republic)</option><option value="gd">Scottish Gaelic</option><option value="gd_GB">Scottish Gaelic (United Kingdom)</option><option value="sr">Serbian</option><option value="sr_BA">Serbian (Bosnia &amp; Herzegovina)</option><option value="sr_Cyrl_BA">Serbian (Cyrillic, Bosnia &amp; Herzegovina)</option><option value="sr_Cyrl_XK">Serbian (Cyrillic, Kosovo)</option><option value="sr_Cyrl_ME">Serbian (Cyrillic, Montenegro)</option><option value="sr_Cyrl_RS">Serbian (Cyrillic, Serbia)</option><option value="sr_Cyrl">Serbian (Cyrillic)</option><option value="sr_XK">Serbian (Kosovo)</option><option value="sr_Latn_BA">Serbian (Latin, Bosnia &amp; Herzegovina)</option><option value="sr_Latn_XK">Serbian (Latin, Kosovo)</option><option value="sr_Latn_ME">Serbian (Latin, Montenegro)</option><option value="sr_Latn_RS">Serbian (Latin, Serbia)</option><option value="sr_Latn">Serbian (Latin)</option><option value="sr_ME">Serbian (Montenegro)</option><option value="sr_RS">Serbian (Serbia)</option><option value="sh">Serbo-Croatian</option><option value="sh_BA">Serbo-Croatian (Bosnia &amp; Herzegovina)</option><option value="sn">Shona</option><option value="sn_ZW">Shona (Zimbabwe)</option><option value="ii">Sichuan Yi</option><option value="ii_CN">Sichuan Yi (China)</option><option value="si">Sinhala</option><option value="si_LK">Sinhala (Sri Lanka)</option><option value="sk">Slovak</option><option value="sk_SK">Slovak (Slovakia)</option><option value="sl">Slovenian</option><option value="sl_SI">Slovenian (Slovenia)</option><option value="so">Somali</option><option value="so_DJ">Somali (Djibouti)</option><option value="so_ET">Somali (Ethiopia)</option><option value="so_KE">Somali (Kenya)</option><option value="so_SO">Somali (Somalia)</option><option value="es">Spanish</option><option value="es_AR">Spanish (Argentina)</option><option value="es_BZ">Spanish (Belize)</option><option value="es_BO">Spanish (Bolivia)</option><option value="es_BR">Spanish (Brazil)</option><option value="es_IC">Spanish (Canary Islands)</option><option value="es_EA">Spanish (Ceuta &amp; Melilla)</option><option value="es_CL">Spanish (Chile)</option><option value="es_CO">Spanish (Colombia)</option><option value="es_CR">Spanish (Costa Rica)</option><option value="es_CU">Spanish (Cuba)</option><option value="es_DO">Spanish (Dominican Republic)</option><option value="es_EC">Spanish (Ecuador)</option><option value="es_SV">Spanish (El Salvador)</option><option value="es_GQ">Spanish (Equatorial Guinea)</option><option value="es_GT">Spanish (Guatemala)</option><option value="es_HN">Spanish (Honduras)</option><option value="es_MX">Spanish (Mexico)</option><option value="es_NI">Spanish (Nicaragua)</option><option value="es_PA">Spanish (Panama)</option><option value="es_PY">Spanish (Paraguay)</option><option value="es_PE">Spanish (Peru)</option><option value="es_PH">Spanish (Philippines)</option><option value="es_PR">Spanish (Puerto Rico)</option><option value="es_ES">Spanish (Spain)</option><option value="es_US">Spanish (United States)</option><option value="es_UY">Spanish (Uruguay)</option><option value="es_VE">Spanish (Venezuela)</option><option value="sw">Swahili</option><option value="sw_CD">Swahili (Congo - Kinshasa)</option><option value="sw_KE">Swahili (Kenya)</option><option value="sw_TZ">Swahili (Tanzania)</option><option value="sw_UG">Swahili (Uganda)</option><option value="sv">Swedish</option><option value="sv_AX">Swedish (Åland Islands)</option><option value="sv_FI">Swedish (Finland)</option><option value="sv_SE">Swedish (Sweden)</option><option value="tl">Tagalog</option><option value="tl_PH">Tagalog (Philippines)</option><option value="tg">Tajik</option><option value="tg_TJ">Tajik (Tajikistan)</option><option value="ta">Tamil</option><option value="ta_IN">Tamil (India)</option><option value="ta_MY">Tamil (Malaysia)</option><option value="ta_SG">Tamil (Singapore)</option><option value="ta_LK">Tamil (Sri Lanka)</option><option value="tt">Tatar</option><option value="tt_RU">Tatar (Russia)</option><option value="te">Telugu</option><option value="te_IN">Telugu (India)</option><option value="th">Thai</option><option value="th_TH">Thai (Thailand)</option><option value="bo">Tibetan</option><option value="bo_CN">Tibetan (China)</option><option value="bo_IN">Tibetan (India)</option><option value="ti">Tigrinya</option><option value="ti_ER">Tigrinya (Eritrea)</option><option value="ti_ET">Tigrinya (Ethiopia)</option><option value="to">Tongan</option><option value="to_TO">Tongan (Tonga)</option><option value="tr">Turkish</option><option value="tr_CY">Turkish (Cyprus)</option><option value="tr_TR">Turkish (Turkey)</option><option value="uk">Ukrainian</option><option value="uk_UA">Ukrainian (Ukraine)</option><option value="ur">Urdu</option><option value="ur_IN">Urdu (India)</option><option value="ur_PK">Urdu (Pakistan)</option><option value="ug">Uyghur</option><option value="ug_CN">Uyghur (China)</option><option value="uz">Uzbek</option><option value="uz_AF">Uzbek (Afghanistan)</option><option value="uz_Arab_AF">Uzbek (Arabic, Afghanistan)</option><option value="uz_Arab">Uzbek (Arabic)</option><option value="uz_Cyrl_UZ">Uzbek (Cyrillic, Uzbekistan)</option><option value="uz_Cyrl">Uzbek (Cyrillic)</option><option value="uz_Latn_UZ">Uzbek (Latin, Uzbekistan)</option><option value="uz_Latn">Uzbek (Latin)</option><option value="uz_UZ">Uzbek (Uzbekistan)</option><option value="vi">Vietnamese</option><option value="vi_VN">Vietnamese (Vietnam)</option><option value="cy">Welsh</option><option value="cy_GB">Welsh (United Kingdom)</option><option value="fy">Western Frisian</option><option value="fy_NL">Western Frisian (Netherlands)</option><option value="wo">Wolof</option><option value="wo_SN">Wolof (Senegal)</option><option value="yi">Yiddish</option><option value="yo">Yoruba</option><option value="yo_BJ">Yoruba (Benin)</option><option value="yo_NG">Yoruba (Nigeria)</option><option value="zu">Zulu</option><option value="zu_ZA">Zulu (South Africa)</option>
                                                </select>
                                        </div>
                                    </div>
                                </div>
                       <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[41]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="status_up" name="status" checked="checked">
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_dossier_languages_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[42]['name']; ?></button>
                            <button type="button" id="edit_dossier_languages_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[43]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_dossier_languages" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[49]['name']; ?> <?php echo $label_details[125]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_13_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_dossier_languages_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[50]['name']; ?> <?php echo $label_details[125]['name']; ?>, <?php echo $label_details[51]['name']; ?></label>
                                        <label class="fs-6"><?php echo $label_details[52]['name']; ?> <?php echo $label_details[125]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_dossier_languages_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[53]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[54]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

            <!--begin::Modal - Restore Module-->
            <div class="modal fade" id="restore_dossier_languages" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[77]['name']; ?> <?php echo $label_details[126]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_13_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_dossier_languages_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[82]['name']; ?> <?php echo $label_details[126]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_dossier_languages_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[78]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[79]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->

            <!--begin::Modal - Status Module-->
            <div class="modal fade" id="status_dossier_languages" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[61]['name']; ?>
</h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_13_6" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="sta_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="sta_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="status_dossier_languages_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[60]['name']; ?> <?php echo $label_details[127]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="status_dossier_languages_sub" class="btn btn-primary"><i class="las la-toggle-on fs-5"></i> <?php echo $label_details[58]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_status_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[59]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Status Module-->

            <!--begin::Modal - Import Module-->
            <div class="modal fade" id="import_dossier_languages" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[73]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_13_7" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <form name="import_dossier_languages_form" id="import_dossier_languages_form" action="#" class="import_dossier_languages_form">

                                <!--begin::Input group-->
                                <div class="form-group pst_relt">
                                    <div class="add_dossier_languages_frm imp_file_cls">
                                        <div class="custom-file mb-4">
                                        <span class="uploadFile"><?php echo $label_details[114]['name']; ?></span>
                                            <input type="file" name="import_dossier_languages_file" id="import_dossier_languages_file" class="custom-file-input" accept=".xls" title="<?php echo $label_details[117]['name']; ?>">
                                            <label class="custom-file-label" for="customFile" id="import_label"><?php echo $label_details[66]['name']; ?></label>
                                            <input class="gui-input" id="import_uploader" style="display:none" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pst_relt mb-4">
                                    <div class="add_dossier_languages_frm">
                                        <button type="button" class="btn btn-link" id="import_download_sample" ><i class="fa fa-download"></i> <span><?php echo $label_details[67]['name']; ?> <?php echo $label_details[119]['name']; ?></span></button>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="import_dossier_languages_sub" class="btn btn-primary"><i class="las la-external-link-alt fs-5"></i><?php echo $label_details[68]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_import_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[69]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Import Module-->

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>dossier_languages.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,selected=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() {  
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("94", role_details) != -1)
    {
        edit_role=true;
    }  
	dossier_languages_details();
});
</script>  
