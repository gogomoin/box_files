<?php
    $user_det = $this->session->userdata('user_det');
 ?>
<html lang="en">
	<!--begin::Head-->
	<head><base href="../">
		<title>Dossier Preview</title>
		<meta charset="utf-8" />
		<meta HTTP-EQUIV="MSThemeCompatible" content="Yes" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=no">
		<link rel="shortcut icon" href="<?php echo $media_path; ?>logos/favicon.ico" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Page Vendor Stylesheets(used by this page)-->
		<link href="<?php echo $plugins_custom_path; ?>fullcalendar/fullcalendar.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $plugins_custom_path; ?>datatables/datatables.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Page Vendor Stylesheets-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<link href="<?php echo $plugins_global_path; ?>plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.css" rel="stylesheet" type="text/css" />
        <style>
            .logosection{
    float: left;
    width:50%;
}
.qrsection{
    float:left;
    width:50%;
}
.schooldetails{
    width: 50%;
    float: left;
}
.schoolimg{
    width: 50%;
    float: left;
    padding: 15px;
}
.sImg-size{
    width: 140px;
    float: right;
}


@media (max-width: 768px){
    .logosection {
  float: left;
  width: 100%;
}
.qrsection {
  float: left;
  width: 100%;
}
.schooldetails{
    width: 100%;
    float: left;
}
.schoolimg{
    width: 100%;
    float: left;
}
.sImg-size{
    width: 140px;
    float: none;
}
}
            </style>
		<!--end::Global Stylesheets Bundle-->
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="header-fixed header-tablet-and-mobile-fixed">
		<!--begin::Main-->
		<!--begin::Root-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Page-->
			<div class="page d-flex flex-row flex-column-fluid">
				<!--begin::Wrapper-->
				<div class="d-flex flex-column flex-row-fluid" id="kt_wrapper">
                    <!--begin::Post-->
                    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 15px!important; padding-top: 20px!important;">
                        <!--begin::Post-->
                        <div class="content flex-column-fluid noscreen" id="kt_content">
                            <!-- Preview Module -->
                            <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_preview_id">
                                <form name="preview_dossiers_form" id="preview_dossiers_form" class="preview_dossiers_form">
                                    <a name="dossiers_preview_id"></a>
                                    <!--begin::Card header-->
                                    <div class="card-header mb-10 hd-col-3">
                                        <!--begin::Heading-->
                                        <div class="card-title">
                                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                                </svg></span> <?php echo $label_details[212]['name']; ?> <?php echo $label_details[16]['name']; ?></h3>
                                        </div>
                                        <div class="card-toolbar float-xxl-end">
                                            <button type="button" id="preview_download_pdf_dossiers_sub"  class="btn btn-sm btn-success my-1 me-3 px-2 fs-8">
                                                <i class="las la-download fs-4"></i><?php echo $label_details[213]['name']; ?></button>
                                            <button type="button" id="preview_print_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                                <i class="las la-eye fs-4"></i><?php echo $label_details[214]['name']; ?></button>
                                            <button type="button" id="dossier_login" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-sign-in-alt fs-4"></i>LOGIN</button>
                                        </div>
                                        <!--end::Heading-->
                                    </div>
                                    <!--end::Card header-->
                                    <!--begin::Card body-->
                                    <div class="card-body p-0" id="print_preview_body">
                                        <div class="portlet-body my-10">
                                            <div class="dossier-preview-container p-0">
                                                <!-- print pdf page1 start -->
                                                <div class="pre_dos_cls">
                                                    <div style="padding: 20px; background: #fff;">
                                                        <div style="width: 100%;">
                                                            <div style="border: 1px solid #ddd; padding: 15px 0;">
                                                                <div class="logosection">
                                                                    <div style="width: 190px; float: left;"><img id="school_logo_preview" alt="" style="padding: 15px; max-width: 100%;" /></div>
                                                                    <div style="float: left; padding: 15px;">
                                                                        <div><strong><span id="school_name"></span></strong></div>
                                                                        <div><span id="school_gen_email"></span></div>
                                                                        <div><span id="school_address"></span></div>
                                                                        <div><span id="school_phoneno"></span></div>
                                                                    </div>
                                                                </div>
                                                                <div class="qrsection">
                                                                <div style="float: left;padding: 15px;">
                                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[216]['name']; ?>: </strong><span id="pr_start_date"></span></div>
                                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[217]['name']; ?>: </strong><span id="pr_end_date"></span></div>
                                                                    <div style="padding-bottom: 10px;"><strong><?php echo $label_details[218]['name']; ?>: </strong><span id="pr_term"></span></div>
                                                                </div>
                                                                <div style="float: right;">        
                                                                <div style="width: 100px;" align="center"><img id="pr_qr_code" alt="" style="padding: 5px; max-width: 100%;" /><span id="pr_dossier_key"></span></div> 
                                                                </div>
                                                                </div>
                                                                <div class="clearfix"></div>
                                                            </div>
                                                            <div style="border: 1px solid #ddd;">
                                                                <div>
                                                                    <div class="schooldetails">
                                                                        <ul style="list-style: none; padding-left: 15px;">
                                                                            <li>
                                                                                <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[219]['name']; ?> : </strong> <span id="pr_name"></span></h1>
                                                                            </li>
                                                                            <li>
                                                                                <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[220]['name']; ?>: </strong> <span id="pr_course"></span></h1>
                                                                            </li>
                                                                            <li>
                                                                                <h3 style="font-weight: normal; color: #578ebe ;"><strong><?php echo $label_details[221]['name']; ?>: </strong> <span id="pr_teacher"></span></h3>
                                                                            </li>
                                                                            <li>
                                                                                <h4 style="font-weight: normal;"><strong><?php echo $label_details[222]['name']; ?>: </strong> <span id="pr_language"></span></h4>
                                                                            </li>
                                                                            <li>
                                                                                <h4 style="font-weight: normal;"><strong><?php echo $label_details[223]['name']; ?>: </strong> <span id="pr_preparation_time"></span></h4>
                                                                            </li>
                                                                            
                                                                        </ul>
                                                                    </div>
                                                                    <div class="schoolimg">
                                                                        <div class="sImg-size"><img id="pr_teaser_image" alt="" style="padding: 5px; max-width: 100%;" /><span id="pr_teaser_text"></span></div>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <br />
                                                        <div id="pr_goals_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[224]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_goals"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_path_to_success_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[225]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_path_to_success"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_task_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[226]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_task"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_useful_links_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[228]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_useful_links"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_media_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;">Media</h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_media"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_description_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[227]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_description"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_learning_materials_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[229]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_learning_materials"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                        <div id="pr_solutions_table">
                                                            <div style="border-left: 5px solid #796799; background-color: #efefef;" >
                                                                <div>
                                                                    <div>
                                                                        <div style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[230]['name']; ?></h2></div>
                                                                    </div>
                                                                </div>
                                                                <div style="">
                                                                    <div>
                                                                        <div style="padding: 15px;">
                                                                            <div style="background-color: #fff;">
                                                                                <div>
                                                                                    <div style="padding: 5px 15px;">
                                                                                        <span id="pr_solutions"></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <br />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-box px-8">
                                        <div class="">&nbsp;</div>
                                                            <!--begin::Toolbar-->
                                        <div class="card-toolbar float-xxl-end">
                                            <button type="button" id="preview_download_pdf_dossiers_sub_bott"  class="btn btn-sm btn-success my-1 me-3 px-2 fs-8">
                                                <i class="las la-download fs-4"></i><?php echo $label_details[232]['name']; ?></button>
                                            <button type="button" id="preview_print_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                                <i class="las la-eye fs-4"></i><?php echo $label_details[233]['name']; ?></button>
                                            <button type="button" id="dossier_login_bott" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-sign-in-alt fs-4"></i>LOGIN</button>
                                        </div>
                                        <!--end::Toolbar-->
                                    </div>
                                    <!--end::Card body-->
                                </form>
                            </div>
                        </div>
                        <!--end::Post-->
                    
                    <!--end::Post-->
                        <!--end::Content wrapper-->
                    </div>
                <!--end::Wrapper-->
                </div>
            <!--end::Page-->
        </div>
        <script>var hostUrl = "assets/";</script>
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="<?php echo $plugins_global_path; ?>plugins.bundle.js"></script>
		<script src="<?php echo $js_path; ?>scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<!--begin::PDF Viewer -->
<script type="text/javascript">
      window.PDFJS_LOCALE = {
        pdfJsWorker: '<?php echo $assets_path;?>pdf/js/pdf.worker.js',
        pdfJsCMapUrl: '<?php echo $assets_path;?>pdf/cmaps'
      };
</script>
<script src="<?php echo $assets_path;?>pdf/js/libs/html2canvas.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/three.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/pdf.min.js"></script>

<script src="<?php echo $assets_path;?>pdf/js/dist/3dflipbook.js"></script>
<script src="<?php echo $js_path;?>pdfeditor/pspdfkit.js"></script>

<!-- <script src="<?php echo $assets_path;?>pdf/js/lightbox.js"></script> -->
		<!--end::PDF Viewer-->
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>dossier_preview.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",dossier_key_id="<?php  echo $dossier_key_id; ?>",dossier_key="<?php  echo $dossier_key; ?>",id="<?php  echo $user_det['id'];?>";
$(document).ready(function() {
    dossiers_preview_details();
});
</script>  
