<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(5) {
    text-align: center;
}

</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[2]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[3]['name']; ?></h3>
                                    <button type="button" id="label_50_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <!--begin::Table-->
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th></th>
                                <th data-priority="1" class="fw-bolder"> <?php echo $label_details[4]['name']; ?> </th>
                                <th data-priority="4" class="fw-bolder"> <?php echo $label_details[5]['name']; ?> </th>
                                <th data-priority="3" class="fw-bolder"> <?php echo $label_details[6]['name']; ?> </th>
                                <th data-priority="2" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[7]['name']; ?> </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="email_templates_edit_id" style="display:none;">
                <form name="edit_email_templates_form" id="edit_email_templates_form" class="edit_email_templates_form">
                    <a name="email_templates_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[8]['name']; ?> <?php echo $label_details[9]['name']; ?></h3>
                                <button type="button" id="label_50_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_email_templates_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[24]['name']; ?></button>
                            <button type="button" id="edit_email_templates_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[25]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[32]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="status" name="status">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-10">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[9]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-key fs-3 "></i></span>
                                <input type="text" disabled="disabled" id="template_key" name="template_key" class="form-control"  aria-describedby="basic-addon1">
                                <input type="hidden" id="token_id" name="token_id" />
                                <input type="hidden" id="template_id" name="template_id" />
                            </div>
                            <div class="help-block"><i class="fa fa-info-circle"></i><strong> <?php echo $label_details[10]['name']; ?>: </strong><i><?php echo $label_details[11]['name']; ?></i></div>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[12]['name']; ?></label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <textarea disabled id="template_keywords" name="template_keywords" rows="1"></textarea>
                                </div>
                            </div>
                            <div class="help-block"><i class="fa fa-info-circle"></i><strong> <?php echo $label_details[13]['name']; ?>: </strong><i><?php echo $label_details[14]['name']; ?></i></div>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[15]['name']; ?></label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="language_id" name="language_id">
                                    </select>
                                </div>
                            </div>
                            <div class="help-block"><i class="fa fa-info-circle"></i><strong> <?php echo $label_details[16]['name']; ?>: </strong><i><?php echo $label_details[17]['name']; ?></i></div>
                        </div>
                        <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[18]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="is_translate" name="is_translate">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-10">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[19]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="from_email" name="from_email" class="form-control"  aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-10">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[20]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="subject" name="subject" class="form-control"  aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[21]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <textarea id="content" name="content"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[22]['name']; ?></label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <textarea id="text_content" name="text_content" rows="15"></textarea>
                                </div>
                            </div>
                        </div>
                        <button type="button" id="gen_plain_text"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><?php echo $label_details[23]['name']; ?></button>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_email_templates_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[24]['name']; ?></button>
                            <button type="button" id="edit_email_templates_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[25]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script src="<?php echo $plugins_path; ?>ckeditor/ckeditor.js" type="text/javascript"></script>
<script src="<?php echo $plugins_path; ?>ckeditor/adapters/jquery.js" type="text/javascript"></script>
<script src="<?php echo $js_path;?>email_templates.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,country=[],language_details=[],email_details=[],id="<?php  echo $user_det['id'];?>",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() {  
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("319", role_details) != -1)
    {
        edit_role=true;
    }
    $('#content').ckeditor();  
    CKEDITOR.instances.content.on( 'save', function( evt ) {
        return false; //Prevents Page Refresh
    });  
	email_templates_details();
});
</script>  
