<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
<link href="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.css" rel="stylesheet" type="text/css" />
 <style>
     .inbox_messages_css tr td:nth-child(6) {
    text-align: center;
}
.inbox_task_css tr td:nth-child(6) {
    text-align: center;
}
.inbox_meetings_css tr td:nth-child(7) {
    text-align: center;
}
.inbox_feedback_css tr td:nth-child(4) {
    text-align: center;
}
.inbox_document_css tr td:nth-child(7) {
    text-align: center;
}
.outbox_archive_css tr td:nth-child(5) {
    text-align: center;
}
    
.outbox_messages_css tr td:nth-child(4) {
    text-align: center;
}
.outbox_messages_css tr td:nth-child(7) {
    text-align: center;
}
.outbox_task_css tr td:nth-child(5) {
    text-align: center;
}
.outbox_task_css tr td:nth-child(6) {
    text-align: center;
}
.outbox_task_css tr td:nth-child(9) {
    text-align: center;
}
.outbox_meetings_css tr td:nth-child(9) {
    text-align: center;
}
.outbox_meetings_css tr td:nth-child(5) {
    text-align: center;
}
.outbox_meetings_css tr td:nth-child(6) {
    text-align: center;
}
.outbox_meetings_css tr td:nth-child(7) {
    text-align: center;
}

.outbox_feedback_css tr td:nth-child(5) {
    text-align: center;
}
.outbox_feedback_css tr td:nth-child(7) {
    text-align: center;
}
.outbox_feedback_css tr td:nth-child(8) {
    text-align: center;
}
.outbox_feedback_css tr td:nth-child(10) {
    text-align: center;
}

.outbox_document_css tr td:nth-child(5) {
    text-align: center;
}

.outbox_document_css tr td:nth-child(6) {
    text-align: center;
}
.outbox_document_css tr td:nth-child(9) {
    text-align: center;
}
</style>
<style type="text/css">
		

.label.label-sm {
  display: inline-block;
  width: 20px;
  height: 20px;
  line-height: 19px;
  text-align: center;
  border-radius: 2px;
}
.label-primary {
  background-color: #659be0;
}
.label.label-sm i {
  color: #fff;
  font-size: 12px;
}
.dInline{
    display: inline-block!important;
}
.label-info {
  background-color: #7239ea;
}
.label-warning {
  background-color: #f1c40f;
}
.label-danger {
  background-color: #ed6b75;
}
.label-success {
  background-color: #36c6d3;
}
.label-primary {
  background-color: #009ef7;
}
.height-5 {
    height: 50px;
}
.students {
  background-color: rgba(51, 122, 183, 0.1);
}
.btn.btn-danger.close-btn {
  padding: 5px 10px !important;
}
.personnel {
  background-color: rgba(244, 208, 63, 0.1);
}
.text-blue{
    color: #009ef7;
}
.text-orange{
    color: #ff9b00;
}
.parents {
  background-color: rgb(142,68,173, 0.1);
}
.text-purple {
  color: #8e44ad;
}
	
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                    <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-500"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Post-->
        <div class="content flex-column-fluid" id="kt_content">
            <!--begin::Inbox App - Messages -->
            <div class="d-flex flex-column flex-lg-row">
                <!--begin::Sidebar-->
                <div class="flex-column flex-lg-row-auto w-100 w-lg-225px mb-10 mb-lg-0">
                    <!--begin::Sticky aside-->
                    <div class="card card-flush mb-0" data-kt-sticky="false" data-kt-sticky-name="inbox-aside-sticky" data-kt-sticky-offset="{default: false, xl: '0px'}" data-kt-sticky-width="{lg: '275px'}" data-kt-sticky-left="auto" data-kt-sticky-top="150px" data-kt-sticky-animation="false" data-kt-sticky-zindex="95">
                        <!--begin::Aside content-->
                        <div class="card-body px-4">
                            <!--begin::Button-->
                            <?php if(in_array(306,$role_details)||in_array(307,$role_details)||in_array(308,$role_details)||in_array(309,$role_details)||in_array(310,$role_details)) { ?>
                            <button type="button" class="btn btn-primary text-uppercase w-100 mb-10 py-3 fs-7" id="create_new_message"><i class="las la-edit fs-4"></i> <?php echo $label_details[2]['name']; ?></button>
                            <?php } ?>
                            <!--end::Button-->
                            <span class="text-uppercase w-100 mb-10 fs-4 color_css"><?php echo $label_details[3]['name']; ?></span>
                            <!--begin::Menu-->
                            <div class="menu menu-column menu-rounded menu-state-bg menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary mb-10">
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Inbox-->
                                    <span class="menu-link active" id="menu_inbox_message_id">
                                        <div class="label label-sm label-info me-4">
                                            <i class="las la-sticky-note" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_message_btn"><?php echo $label_details[4]['name']; ?></span>
                                        <span class="badge badge-light-info"><span id="messages_count"></span></span>
                                    </span>
                                    <!--end::Inbox-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Marked-->
                                    <span class="menu-link" id="menu_inbox_task_id">
                                        <div class="label label-sm label-warning me-4">
                                            <i class="fa fa-tasks" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_task_btn"><?php echo $label_details[5]['name']; ?></span>
                                        <span class="badge badge-light-warning"><span id="task_count"></span></span>
                                    </span>
                                    <!--end::Marked-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Draft-->
                                    <span class="menu-link" id="menu_inbox_meetings_id">
                                        <div class="label label-sm label-danger me-4">
                                            <i class="las la-bell" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_meetings_btn"><?php echo $label_details[6]['name']; ?></span>
                                        <span class="badge badge-light-danger"><span id="meetings_count"></span></span>
                                    </span>
                                    <!--end::Draft-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Sent-->
                                    <span class="menu-link" id="menu_inbox_feedback_id">
                                        <div class="label label-sm label-success me-4">
                                            <i class="fa fa-rss" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_feedback_btn"><?php echo $label_details[7]['name']; ?></span>
                                        <span class="badge badge-light-success"><span id="feedback_count"></span></span>
                                    </span>
                                    <!--end::Sent-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item">
                                    <!--begin::Trash-->
                                    <span class="menu-link" id="menu_inbox_document_id">
                                        <div class="label label-sm label-primary me-4">
                                            <i class="fa fa-clone" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_document_btn"><?php echo $label_details[8]['name']; ?></span>
                                        <span class="badge badge-light-primary"><span id="document_count"></span></span>
                                    </span>
                                    <!--end::Trash-->
                                </div>
                                <!--end::Menu item-->
                            </div>
                            <!--end::Menu-->
                            <span class="text-uppercase w-100 mb-10 fs-4 purple_css"><?php echo $label_details[9]['name']; ?></span>
                            
                            <!--begin::Menu-->
                            <div class="menu menu-column menu-rounded menu-state-bg menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary mb-10">
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Inbox-->
                                    <span class="menu-link" id="menu_outbox_message_id">
                                        <div class="label label-sm label-info me-4">
                                            <i class="las la-sticky-note" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_message_btn" id="view_outbox_message_btn"><?php echo $label_details[10]['name']; ?></span>
                                    </span>
                                    <!--end::Inbox-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Marked-->
                                    <span class="menu-link" id="menu_outbox_task_id">
                                        <div class="label label-sm label-warning me-4">
                                            <i class="fa fa-tasks" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_task_btn"><?php echo $label_details[11]['name']; ?></span>
                                    </span>
                                    <!--end::Marked-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Draft-->
                                    <span class="menu-link" id="menu_outbox_meetings_id">
                                        <div class="label label-sm label-danger me-4">
                                            <i class="las la-bell" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_meetings_btn"><?php echo $label_details[12]['name']; ?></span>
                                    </span>
                                    <!--end::Draft-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Sent-->
                                    <span class="menu-link" id="menu_outbox_feedback_id">
                                        <div class="label label-sm label-success me-4">
                                            <i class="fa fa-rss" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_feedback_btn"><?php echo $label_details[13]['name']; ?></span>
                                    </span>
                                    <!--end::Sent-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item">
                                    <!--begin::Trash-->
                                    <span class="menu-link" id="menu_outbox_document_id">
                                        <div class="label label-sm label-primary me-4">
                                            <i class="fa fa-clone" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_document_btn"><?php echo $label_details[14]['name']; ?></span>
                                    </span>
                                    <!--end::Trash-->
                                </div>
                                <!--end::Menu item-->
                            </div>
                            <!--end::Menu-->
                            <span class="text-uppercase w-100 mb-10 fs-4 red_css"><?php echo $label_details[15]['name']; ?></span>
                            <!--begin::Menu-->
                            <div class="menu menu-column menu-rounded menu-state-bg menu-state-title-primary menu-state-icon-primary menu-state-bullet-primary mb-10">
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Inbox-->
                                    <span class="menu-link" id="menu_inbox_archive_id">
                                        <div class="label label-sm label-danger me-4">
                                            <i class="las la-archive" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_inbox_archive_btn"><?php echo $label_details[16]['name']; ?></span>
                                    </span>
                                    <!--end::Inbox-->
                                </div>
                                <!--end::Menu item-->
                                <!--begin::Menu item-->
                                <div class="menu-item mb-3">
                                    <!--begin::Marked-->
                                    <span class="menu-link" id="menu_outbox_archive_id">
                                        <div class="label label-sm label-danger me-4">
                                            <i class="las la-archive" aria-hidden="true"></i>
                                        </div>
                                        <span class="menu-title fw-bolder" id="view_outbox_archive_btn"><?php echo $label_details[17]['name']; ?></span>
                                    </span>
                                    <!--end::Marked-->
                                </div>
                                <!--end::Menu item-->
                            </div>
                            <!--end::Menu-->
                        </div>
                        <!--end::Aside content-->
                    </div>
                    <!--end::Sticky aside-->
                </div>
                <!--end::Sidebar-->
                <!--begin::Content-->
                
                <div class="flex-lg-row-fluid ms-lg-7 ms-xl-6">
                    <!--begin::Card-->
                    
                    <div class="card">
                        <?php if(in_array(343,$role_details)) { ?>
                        <div class="card mb-7 border">
                            <a name="notifications_table_id"></a>
                            <div class="card-header hd-col-2" id="filter_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                                </svg></span> <?php echo $label_details[18]['name']; ?></h3>
                                <button type="button" id="label_49_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                                <!--begin::Compact form-->
                                <div class="d-flex align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Row-->
                                        <div class="row g-8">
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[19]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="subject_fld" name="subject_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px" id="due_date_field" style="display:none;">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[20]['name']; ?></label>
                                                <div class="input-group">
                                                    <input class="form-control" placeholder="<?php echo $label_details[216]['name']; ?>" id="due_date_fld" name="due_date_fld" />
                                                </div>
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-250px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[21]['name']; ?></label>
                                                <div class="input-group">
                                                    <input class="form-control" placeholder="<?php echo $label_details[212]['name']; ?>" id="created_at_fld" name="created_at_fld" />
                                                </div>
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-150px" id="feedback_field" style="display:none;">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[22]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select id="feedback_fld" name="feedback_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                                    <option value="all" selected="selected"><?php echo $label_details[23]['name']; ?></option>
                                                    <option value="1"><?php echo $label_details[24]['name']; ?></option>
                                                    <option value="0"><?php echo $label_details[25]['name']; ?></option>
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <div class="col-lg-4 mt-16 w-md-250px">
                                                <!--end::Input group-->
                                                <!--begin:Action-->
                                                <div class="fltl me-3">
                                                    <button type="button" id="notifications_filter" name="notifications_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                        <i class="las la-filter"></i>
                                                        <!--end::Svg Icon--><?php echo $label_details[26]['name']; ?>
                                                    </button>
                                                </div>
                                                <div class="fltl">
                                                    <button type="button" id="notifications_reset" name="notifications_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[27]['name']; ?></button>
                                                </div>
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <?php } ?>
                        <!--begin::Card-->
                        <div class="card mb-lg-10 border noscreen" id="full_content">
                            <div class="card" id="page_container">
                                <!--begin::Card header-->
                                <div class="card-header mb-5 hd-col-1">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                                <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                                </svg></span> <span id="notification_title"><?php echo $label_details[28]['name']; ?></span></h3>
                                                <button type="button" id="label_49_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                        <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_messages">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <?php if(in_array(315,$role_details)) { ?>
                                        <button type="button" id="inbox_messages_mark_as_read_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#inbox_messages_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[29]['name']; ?> <i class="las la-check fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(342,$role_details)) { ?>
                                        <button type="button" id="inbox_messages_mark_as_unread_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[30]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(316,$role_details)) { ?>
                                        <button type="button" id="inbox_messages_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#inbox_messages_archive_notifications" data-toggle="modal"><?php echo $label_details[31]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                        <?php } ?>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_messages_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_messages_table_check_all" class="group-checkable" name="inbox_messages_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[32]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[33]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[34]['name']; ?> </th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[35]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table inbox_messages_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_task" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <?php if(in_array(315,$role_details)) { ?>
                                        <button type="button" id="inbox_task_mark_as_read_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[36]['name']; ?> <i class="las la-check fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(342,$role_details)) { ?>
                                        <button type="button" id="inbox_task_mark_as_unread_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[37]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(316,$role_details)) { ?>
                                        <button type="button" id="inbox_task_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#inbox_task_archive_notifications" data-toggle="modal"><?php echo $label_details[38]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                        <?php } ?>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_task_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_task_table_check_all" class="group-checkable" name="inbox_task_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[39]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[40]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[41]['name']; ?> </th>
                                            <th class="fw-bolder"> </th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[42]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table inbox_task_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_meetings" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <?php if(in_array(315,$role_details)) { ?>
                                        <button type="button" id="inbox_meetings_mark_as_read_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[43]['name']; ?> <i class="las la-check fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(342,$role_details)) { ?>
                                        <button type="button" id="inbox_meetings_mark_as_unread_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[44]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(316,$role_details)) { ?>
                                        <button type="button" id="inbox_meetings_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#inbox_meetings_archive_notifications" data-toggle="modal"><?php echo $label_details[45]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                        <?php } ?>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_meetings_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_meetings_table_check_all" class="group-checkable" name="inbox_meetings_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[46]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[47]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[48]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[49]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table inbox_meetings_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_feedback" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <?php if(in_array(315,$role_details)) { ?>
                                        <button type="button" id="inbox_feedback_mark_as_read_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[50]['name']; ?> <i class="las la-check fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(342,$role_details)) { ?>
                                        <button type="button" id="inbox_feedback_mark_as_unread_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"  data-target="#inbox_meetings_mark_as_read_notifications" data-toggle="modal"><?php echo $label_details[51]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(316,$role_details)) { ?>
                                        <button type="button" id="inbox_feedback_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#inbox_feedback_archive_notifications" data-toggle="modal"><?php echo $label_details[52]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                        <?php } ?>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_feedback_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_feedback_table_check_all" class="group-checkable" name="inbox_feedback_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[53]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[54]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[55]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[56]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[73]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[57]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table inbox_feedback_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_document" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <?php if(in_array(315,$role_details)) { ?>
                                        <button type="button" id="inbox_document_mark_as_read_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2" ><?php echo $label_details[58]['name']; ?> <i class="las la-check fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(342,$role_details)) { ?>
                                        <button type="button" id="inbox_document_mark_as_unread_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"><?php echo $label_details[59]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                        <?php } ?>
                                        <?php if(in_array(316,$role_details)) { ?>
                                        <button type="button" id="inbox_document_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#inbox_document_archive_notifications" data-toggle="modal"><?php echo $label_details[60]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                        <?php } ?>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_document_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_document_table_check_all" class="group-checkable" name="inbox_document_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[61]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[62]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[63]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[64]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table inbox_document_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="outbox_messages" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_messages_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#outbox_messages_archive_notifications" data-toggle="modal"><?php echo $label_details[65]['name']; ?><i class="las la-trash-alt fs-6"></i> </button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_messages_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_messages_table_check_all" class="group-checkable" name="outbox_messages_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[66]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[67]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[68]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[69]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_messages_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="outbox_task" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_task_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#outbox_task_archive_notifications" data-toggle="modal"><?php echo $label_details[70]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_task_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_task_table_check_all" class="group-checkable" name="outbox_task_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[71]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[72]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[73]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[74]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[75]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[76]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_task_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="outbox_meetings" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_meetings_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#outbox_meetings_archive_notifications" data-toggle="modal"><?php echo $label_details[77]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_meetings_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_meetings_table_check_all" class="group-checkable" name="outbox_meetings_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[78]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[79]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[80]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[81]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[82]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[83]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_meetings_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div  px-4" id="outbox_feedback" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_feedback_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#outbox_feedback_archive_notifications" data-toggle="modal"><?php echo $label_details[84]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_feedback_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_feedback_table_check_all" class="group-checkable" name="outbox_feedback_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[85]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[86]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[87]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[88]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[89]['name']; ?> </th>
                                            <th data-priority="8" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[80]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[90]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_feedback_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="outbox_document" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_document_archive_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#outbox_document_archive_notifications" data-toggle="modal"><?php echo $label_details[91]['name']; ?> <i class="las la-trash-alt fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_document_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_document_table_check_all" class="group-checkable" name="outbox_document_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[92]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[93]['name']; ?> </th>
                                            <th data-priority="5" style="text-align: center;" class="fw-bolder"> <?php echo $label_details[94]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[95]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[96]['name']; ?> </th>
                                            <th class="fw-bolder"></th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[97]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_document_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="inbox_archive" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="inbox_archive_restore_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#inbox_archive_restore_notifications" data-toggle="modal"><?php echo $label_details[98]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="inbox_archive_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="inbox_archive_table_check_all" class="group-checkable" name="inbox_archive_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="3" class="fw-bolder"> <?php echo $label_details[99]['name']; ?> </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[100]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[101]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[102]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table  inbox_archive_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                            <!--begin::Card body-->
                            <div class="card-body pt-0 px-4" id="outbox_archive" style="display:none;">
                                <div class="card-box">
                                    <!--begin::Add customer-->
                                    <!--begin::Toolbar-->
                                    <div class="card-toolbar ml-auto">
                                        <button type="button" id="outbox_archive_restore_btn_id" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#outbox_archive_restore_notifications" data-toggle="modal"><?php echo $label_details[103]['name']; ?> <i class="las la-undo fs-6"></i></button>
                                    </div>
                                    <!--end::Toolbar-->
                                    <!--end::Add customer-->
                                </div>
                                <!--begin::Table-->
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 not_cls" id="outbox_archive_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="outbox_archive_table_check_all" class="group-checkable" name="outbox_archive_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="3" class="fw-bolder"> <?php echo $label_details[104]['name']; ?> </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[105]['name']; ?> </th>
                                            <th data-priority="4" style="text-align: center;" class="fw-bolder"> <?php echo $label_details[106]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[107]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 actionBtns_table outbox_archive_css">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                                <!--end::Table-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Card-->
                    </div>
                    <!--end::Card-->
                </div>
                
                <!--end::Content-->
            </div>
            <!--end::Inbox App - Messages -->
        </div>
        <!--end::Post-->
        
        <?php echo $notifications_modals; ?>
        <?php echo $file_manager; ?>
        
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
<script src="<?php echo $js_path;?>common.js"></script>
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>notifications.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,school_details=[],country=[],address_fields=[],selected=[],id="<?php  echo $user_det['id'];?>",subject_fld="",created_at_fld="",due_date_fld="",feedback_fld="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,inbox_messages_table,inbox_messages_selected=[],outbox_messages_table,outbox_messages_selected=[],inbox_task_table,inbox_task_selected=[],outbox_task_table,outbox_task_selected=[],inbox_meetings_table,outbox_meetings_table,inbox_feedback_table,outbox_feedback_table,inbox_document_table,outbox_document_table,inbox_archive_table,outbox_archive_table,personnel_details=[],inbox_count=[],course_details=[],student_course_details=[],parent_info=[],tree_details=[],folder_id=1,inner_folder_id=1,attachmentCount = 0,uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],selected_folder_id="",document_files=[],reply_document_files=[],selected_folder=[],change_tree=true,folder_table,folder_tree=false,notification_type="inbox_messages",ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,file_manager_label_details=<?php echo json_encode($file_manager_label_details); ?>,move_id=1,send_message_role=false,send_task_role=false,send_meeting_role=false,send_feedback_role=false,send_document_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];
$(document).ready(function() { 
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("306", role_details) != -1)
    {
        send_message_role=true;
    }
    if ($.inArray("307", role_details) != -1)
    {
        send_task_role=true;
    }
    if ($.inArray("308", role_details) != -1)
    {
        send_meeting_role=true;
    }
    if ($.inArray("309", role_details) != -1)
    {
        send_feedback_role=true;
    }
    if ($.inArray("310", role_details) != -1)
    {
        send_document_role=true;
    }
    $("#due_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#due_date_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#created_at_fld").flatpickr({
        dateFormat: "d-m-Y",
        mode:"range"
    });
    $("#due_datetime").flatpickr({
        enableTime: true,
        dateFormat: "d-m-Y h:i",
        time_24hr: true
    });
    file_manager_details();  
	notifications_details();
});
</script>  
