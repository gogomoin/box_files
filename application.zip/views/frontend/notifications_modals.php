        <!--begin::Modal - New Message Module-->
        <div class="modal fade" id="new_message" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[108]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_3" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_create_id">
                            <form name="add_notifications_form" id="add_notifications_form" class="add_notifications_form">
                            <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;">  
                                <i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                                <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <a name="new_message_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[108]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_new_message_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-4 me-2"></i><?php echo $label_details[109]['name']; ?></button>
                                        <button type="button" id="add_new_message_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4 me-2"></i><?php echo $label_details[110]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-5 py-5">
                                    <div class="row mb-10">
                                        <div class="col-lg-12">
                                            <label class="fs-5 form-label text-dark"><?php echo $label_details[111]['name']; ?>: *</label>
                                            <div class="clearfix"></div>
                                            <!--begin::Select-->
                                            <?php if(in_array(306,$role_details)) { ?>
                                            <div class="form-check form-check-custom form-check-solid dInline me-3 mb-3">
                                                <input class="form-check-input" type="radio" value="note" name="message_type" id="send_message_rbtn" checked="checked"/>
                                                <label class="form-check-label" for="flexRadioDefault">
                                                    <div class="label label-sm label-info me-1"><i class="fa fa-file" aria-hidden="true"></i>
                                                    </div>
                                                    <?php echo $label_details[112]['name']; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                            <?php if(in_array(307,$role_details)) { ?>
                                            <div class="form-check form-check-custom form-check-solid dInline me-3 mb-3">
                                                <input class="form-check-input" type="radio" value="task" name="message_type" id="send_task_rbtn" />
                                                <label class="form-check-label" for="flexRadioDefault">
                                                    <div class="label label-sm label-warning me-1">
                                                        <i class="fa fa-tasks" aria-hidden="true"></i>
                                                    </div>
                                                    <?php echo $label_details[113]['name']; ?>
                                                </label>
                                            </div>
                                            <?php } ?>
                                            <?php if(in_array(308,$role_details)) { ?>
                                            <div class="form-check form-check-custom form-check-solid dInline me-3 mb-3">
                                                <input class="form-check-input" type="radio" value="appointment" name="message_type" id="send_meeting_rbtn" />
                                                <label class="form-check-label" for="flexRadioDefault">
                                                    <div class="label label-sm label-danger me-1"><i class="fa fa-bell" aria-hidden="true"></i>
                                                    </div>
                                                    <?php echo $label_details[114]['name']; ?> 
                                                </label>
                                            </div>
                                            <?php } ?>
                                            <?php if(in_array(309,$role_details)) { ?>
                                            <div class="form-check form-check-custom form-check-solid dInline me-3 mb-3">
                                                <input class="form-check-input" type="radio" value="feedback" name="message_type" id="send_feedback_rbtn" />
                                                <label class="form-check-label" for="flexRadioDefault">
                                                    <div class="label label-sm label-success me-1"><i class="fa fa-rss" aria-hidden="true"></i>
                                                    </div>
                                                        <?php echo $label_details[115]['name']; ?> 
                                                </label>
                                            </div>
                                            <?php } ?>
                                            <?php if(in_array(310,$role_details)) { ?>
                                            <div class="form-check form-check-custom form-check-solid dInline  mb-3">
                                                <input class="form-check-input" type="radio" value="document" name="message_type" id="send_document_rbtn" />
                                                <label class="form-check-label" for="flexRadioDefault">
                                                    <div class="label label-sm label-primary me-1"><i class="fa fa-clone" aria-hidden="true"></i>
                                                    </div>
                                                        <?php echo $label_details[116]['name']; ?> 
                                                </label>
                                            </div>
                                            <?php } ?>
                                            
                                            <!--end::Select-->
                                        </div>
                                    </div>
                                    <div class="row mb-10">
                                        
                                        <div class="msg_btn_css" id="add_personnel_btn_block">
                                            <?php if(in_array(311,$role_details)) { ?>
                                            <button type="button" id="add_personnel_btn" class="btn btn-sm btn-warning my-1 px-2 fs-8"><?php echo $label_details[117]['name']; ?></button>
                                            <?php } ?>
                                        </div>
                                        <div class="msg_btn_css">
                                            <?php if(in_array(312,$role_details)) { ?>
                                            <button type="button" id="add_students_btn" class="btn btn-sm btn-primary my-1 px-2 fs-8"><?php echo $label_details[118]['name']; ?></button>
                                            <?php } ?>
                                        </div>
                                        <div class="msg_btn_css" id="add_parents_btn_block">
                                            <?php if(in_array(313,$role_details)) { ?>
                                            <button type="button" id="add_parents_btn" class="btn btn-sm btn-info my-1 px-2 fs-8"><?php echo $label_details[119]['name']; ?></button>
                                            <?php } ?>
                                        </div>
                                    </div>
                                    <div class="row" id="personnel_recipients_block">
                                        <div class="card card-bordered mb-5 personnel">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-orange"><?php echo $label_details[120]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="personnel_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="personnel_rbtn" id="personnel_select_list" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[121]['name']; ?></label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <div id="personnel_send_all_view">
                                                        <input class="form-check-input" type="radio" value="all" name="personnel_rbtn" id="personnel_send_all" />
                                                        <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[122]['name']; ?></label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12" id="personnel_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[123]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="personnel_id" name="personnel_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" id="students_recipients_block">
                                        <div class="card card-bordered mb-5 students">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-blue"><?php echo $label_details[124]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="students_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="student_rbtn" id="student_select_list" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[125]['name']; ?> </label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <div id="student_select_course_view">
                                                        <input class="form-check-input" type="radio" value="course" name="student_rbtn" id="student_select_course" />
                                                        <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[126]['name']; ?></label>
                                                    </div>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <div id="student_send_all_view">
                                                        <input class="form-check-input" type="radio" value="all" name="student_rbtn" id="student_send_all" />
                                                        <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[127]['name']; ?></label>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12"  id="student_course_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[128]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="student_course_id" name="student_course_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12" id="student_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[129]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="student_id" name="student_id[]" disabled="disabled" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Select-->
                                                    <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b>Hint</b>: <i><?php echo $label_details[130]['name']; ?></i></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row" id="parents_recipients_block">
                                        <div class="card card-bordered mb-5 parents">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-purple"><?php echo $label_details[131]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="parents_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="parent_rbtn" id="parent_select_list"/>
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[132]['name']; ?></label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="course" name="parent_rbtn" id="parent_select_course" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[133]['name']; ?></label>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12" id="parent_course_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[134]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="parent_course_id" name="parent_course_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12" id="parent_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[135]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="parent_id" name="parent_id[]" disabled="disabled" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Select-->
                                                    <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b>Hint</b>: <i><?php echo $label_details[136]['name']; ?></i></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[137]['name']; ?> *</label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="fa fa-book fs-3 "></i></span>
                                                    <input type="text" maxlength="256" id="subject" name="subject" class="form-control" aria-describedby="basic-addon1">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[138]['name']; ?> *</label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa fa-comment fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="message" name="message"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="link_block">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[139]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa fa-link fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="link" name="link"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12" id="attachment_block">
                                            <div class="input-group mb-5">
                                                <button type="button" id="doc_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="fa fa-upload fs-6"></i> <?php echo $label_details[140]['name']; ?></button>
                                                <input type="hidden" id="school_mng" value="msg_doc_add" />
                                            </div>
                                            <div id="display_document_block" style="display:none;">
                                                <div class="card mb-5 mb-xl-8">
                                                    <div id="document_list"></div>
                                                </div> 
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="due_date_block">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[141]['name']; ?></label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                    <input class="form-control" placeholder="<?php echo $label_details[216]['name']; ?>" id="due_date" name="due_date" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="due_datetime_block">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[142]['name']; ?> *</label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                    <input class="form-control" placeholder="<?php echo $label_details[216]['name']; ?>" id="due_datetime" name="due_datetime" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="reply_enabled_block">
                                            <div class="mb-4">
                                                <label for="" class="form-label"><?php echo $label_details[143]['name']; ?></label>
                                                <div class="form-check form-switch form-check-custom form-check-solid">
                                                    <input class="form-check-input" type="checkbox" value="" id="reply_enabled" name="reply_enabled" />
                                                    <label class="form-check-label" for="flexSwitchChecked">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="feedback_message_block">
                                            <div class="mb-4">
                                                <label for="" class="form-label"><?php echo $label_details[144]['name']; ?></label>
                                                <div class="form-check form-switch form-check-custom form-check-solid">
                                                    <input class="form-check-input" checked="checked" type="checkbox" value="" id="text_message_enabled" name="text_message_enabled" />
                                                    <label class="form-check-label" for="flexSwitchChecked">
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_new_message_sub_bott" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-6 me-2"></i><?php echo $label_details[145]['name']; ?></button>
                                        <button type="button" id="add_new_message_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4 me-2"></i><?php echo $label_details[146]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - New Message Module-->

        <!--begin::Modal - mark_as_read Module-->
        <div class="modal fade" id="mark_as_read" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[148]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_20" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <div class="alert alert-danger errYxt" id="mar_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mar_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <!--begin::Form-->
                        <div class="mark_as_read_marks_form">
                            <!--begin::Input group-->
                            <div class="fv-row mb-10">
                                <div class="me-5 fw-bold text-center">
                                    <label class="fs-6"><?php echo $label_details[149]['name']; ?>?</label>
                                </div>
                                <input type="hidden" name="read_type" id="read_type" />
                            </div>
                            <!--end::Input group-->
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" id="mark_as_read_marks_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[150]['name']; ?>
                                </button>
                                <button type="button" class="btn btn-danger me-3" id="close_com_mar_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[151]['name']; ?></button>
                            </div>
                            <!--end::Actions-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - mark_as_read Module-->

        <!--begin::Modal - mark_as_unread Module-->
        <div class="modal fade" id="mark_as_unread" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[152]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_21" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <div class="alert alert-danger errYxt" id="mau_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mau_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <!--begin::Form-->
                        <div class="mark_as_unread_marks_form">
                            <!--begin::Input group-->
                            <div class="fv-row mb-10">
                                <div class="me-5 fw-bold text-center">
                                    <label class="fs-6"><?php echo $label_details[153]['name']; ?>?</label>
                                </div>
                                <input type="hidden" name="unread_type" id="unread_type" />
                            </div>
                            <!--end::Input group-->
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" id="mark_as_unread_marks_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[154]['name']; ?>
                                </button>
                                <button type="button" class="btn btn-danger me-3" id="close_com_mau_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[155]['name']; ?></button>
                            </div>
                            <!--end::Actions-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - mark_as_unread Module-->
        
        <!--begin::Modal - archive Module-->
        <div class="modal fade" id="archive" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[158]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_22" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <div class="alert alert-danger errYxt" id="arc_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="arc_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <!--begin::Form-->
                        <div class="archive_marks_form">
                            <!--begin::Input group-->
                            <div class="fv-row mb-10">
                                <div class="me-5 fw-bold text-center">
                                    <label class="fs-6"><?php echo $label_details[157]['name']; ?>?</label>
                                </div>
                                <input type="hidden" name="archive_type" id="archive_type" />
                            </div>
                            <!--end::Input group-->
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" id="archive_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[158]['name']; ?>
                                </button>
                                <button type="button" class="btn btn-danger me-3" id="close_com_arc_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[163]['name']; ?></button>
                            </div>
                            <!--end::Actions-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - archive Module-->

        <!--begin::Modal - Restore Module-->
        <div class="modal fade" id="restore_notifications" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[160]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <!--begin::Form-->
                        <div class="restore_notifications_form">
                            <!--begin::Input group-->
                            <div class="fv-row mb-10">
                                <div class="me-5 fw-bold text-center">
                                    <label class="fs-6"><?php echo $label_details[161]['name']; ?>?</label>
                                </div>
                                <input type="hidden" name="restore_type" id="restore_type" />
                            </div>
                            <!--end::Input group-->
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" id="restore_notifications_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[162]['name']; ?>
                                </button>
                                <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[163]['name']; ?></button>
                            </div>
                            <!--end::Actions-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Restore Module-->

        <!--begin::Modal - reply Notifiations Module-->
        <div class="modal fade" id="reply_notifications" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[164]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_3" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4">
                            <form name="reply_notifications_form" id="reply_notifications_form" class="reply_notifications_form">
                            <div class="alert alert-danger errYxt" id="rep_err_msg" style="display:none;">
                                <i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <div class="alert alert-success errYxt" id="rep_succ_msg" style="display:none;">
                                <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <a name="reply_message_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[165]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="preview_notifications_reply" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-4 me-2"></i><?php echo $label_details[166]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="row">
                                        <input type="hidden" id="token_id" name="token_id" />
                                        <div class="col-lg-12" id="reply_message_block">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[167]['name']; ?> <span id="hide_comp_icon">*</span></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa fa-comment fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="reply_message" name="message"></textarea>
                                                    </div>
                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="reply_links">
                                            <div class="input-group mb-5">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[168]['name']; ?></label>
                                                <div class="input-group flex-nowrap">
                                                    <span class="input-group-text"><i class="fa fa-link fs-3"></i></span>
                                                    <div class="overflow-hidden flex-grow-1">
                                                        <textarea id="reply_link" name="link"></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-5">
                                        <div class="col-lg-12" id="reply_attachment_block">
                                            <div class="input-group mb-5">
                                                <button type="button" id="reply_doc_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><i class="fa fa-upload fs-6"></i> <?php echo $label_details[169]['name']; ?></button>
                                            </div>
                                            <div id="display_reply_document_block" style="display:none;">
                                                <div class="card mb-5 mb-xl-8">
                                                    <div id="reply_document_list"></div>
                                                </div> 
                                            </div>
                                        </div>
                                        <div class="col-lg-12" id="reply_feedback">
                                            <input class="form-check-input me-3" type="radio" value="yes" name="feedback_option" id="feedback_yes" /><?php echo $label_details[170]['name']; ?>
                                            <input class="form-check-input me-3" type="radio" value="no" name="feedback_option" id="feedback_no" /><?php echo $label_details[171]['name']; ?>
                                            <input type="hidden" id="option_check" />
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="reply_message_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-6 me-2"></i><?php echo $label_details[172]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - reply Notifiations Module-->

        <!--begin::Modal - Preview Notifiations Module-->
        <div class="modal fade" id="preview_notifications" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[147]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_16" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y">
                        <!--begin::Messenger-->
                        <div class="card w-100 rounded-0 border-0" id="kt_drawer_chat_messenger">
                            <!--begin::Card header-->
                            <!--begin::User-->
                            <div class="d-flex p-6 card-box border-bot">
                                <div class="fs-4" id="pr_subject"></div>
                                <div class="fs-4 me-1 mb-2 lh-1 ml-auto card-toolbar"><div id="pr_due_date"></div></div>
                            </div>
                            <!--end::User-->
                            <!--end::Title-->
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body" id="kt_drawer_chat_messenger_body">
                                <!--begin::Messages-->
                                <div class="scroll-y me-n5 pe-5" data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_drawer_chat_messenger_header, #kt_drawer_chat_messenger_footer" data-kt-scroll-wrappers="#kt_drawer_chat_messenger_body" data-kt-scroll-offset="0px">
                                    <div id="message_body"></div>
                                </div>
                                <!--end::Messages-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Messenger-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Preview Notifiations Module-->

        <!--begin::Modal - Lesson Preview Module-->
        <div class="modal fade" id="timeline_preview" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[313]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_preview_id">
                            <form name="preview_dossiers_form" id="preview_dossiers_form" class="preview_dossiers_form">
                                <a name="dossiers_preview_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-10 hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[314]['name']; ?></h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="preview_download_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-download fs-4"></i><?php echo $label_details[315]['name']; ?></button>
                                        <button type="button" id="preview_print_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-eye fs-4"></i><?php echo $label_details[316]['name']; ?></button>
                                       
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9" id="print_preview_body">
                                    <div class="portlet-body my-10">
                                        <div class="dossier-preview-container p-0">
                                            <!-- print pdf page1 start -->
                                            <div>
                                                <table style="width: 100%;">
                                                    <tbody>
                                                        <tr>
                                                            <td valign="top" style="width: 190px;"><img id="school_logo_preview" alt="" style="padding: 15px; max-width: 100%;" /></td>
                                                            <td valign="top"><strong><span id="school_name"></span><br></strong><span id="school_gen_email"></span><br><span id="school_address"></span><br><span id="school_phoneno"></span></td>
                                                            <td valign="top" style="width: 140px;text-align:right;"><strong><?php echo $label_details[317]['name']; ?>: </strong><span id="pr_start_date"></span><br><strong><?php echo $label_details[334]['name']; ?>: </strong><span id="pr_end_date"></span><br><strong><?php echo $label_details[318]['name']; ?>: </strong><span id="pr_term"></span></td>
                                                            <td valign="top" style="width: 100px;" align="center"><img id="pr_qr_code" alt="" style="padding: 0px 5px; max-width: 100%;" /><span id="pr_dossier_key"></span></td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="2">
                                                                <ul style="list-style: none; padding-left: 15px;">
                                                                    <li>
                                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[319]['name']; ?>:</strong> <span id="pr_name"></span></h1>
                                                                    </li>
                                                                    <li>
                                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[320]['name']; ?>:</strong> <span id="pr_course"></span></h1>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal; color: #578ebe ;"><strong><?php echo $label_details[321]['name']; ?>:</strong> <span id="pr_teacher"></span></h3>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal;"><strong><?php echo $label_details[322]['name']; ?>:</strong> <span id="pr_language"></span></h3>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal;"><strong><?php echo $label_details[323]['name']; ?>:</strong> <span id="pr_preparation_time"></span></h3>
                                                                    </li>
                                                                    
                                                                </ul>
                                                            </td>
                                                            <td colspan="2" align="right" style="width: 140px;"><img id="pr_teaser_image" alt="" style="padding: 5px; max-width: 100%;" /><span id="pr_teaser_text"></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br />
                                                <table style="border: 1px solid #ddd; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                    <tbody style="border-left: 5px solid #2ab4c0;">
                                                        <tr>
                                                            <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #2ab4c0;"><?php echo $label_details[324]['name']; ?></h2></th>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 5px 15px;"><span id="pr_goals"></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br />
                                                <table style="border: 1px solid #ddd; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                    <tbody style="border-left: 5px solid #5c9bd1;">
                                                        <tr>
                                                            <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #5c9bd1;"><?php echo $label_details[325]['name']; ?></h2></th>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 5px 15px;"><span id="pr_path_to_success"></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br />
                                                <table style="border: 1px solid #ddd; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                    <tbody style="border-left: 5px solid #f2784b;">
                                                        <tr>
                                                            <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #f2784b;"><?php echo $label_details[326]['name']; ?></h2></th>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 5px 15px;"><span id="pr_task"></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br />
                                                <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                    <tbody>
                                                        <tr>
                                                            <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[327]['name']; ?></h2></th>
                                                        </tr>
                                                        <tr>
                                                            <td style="padding: 5px 15px;"><span id="pr_description"></span></td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody style="">
                                                        <tr>
                                                            <td style="padding: 15px;">
                                                                <table style="background-color: #fff;" width="100%" cellspacing="0" cellpadding="0" id="mytable">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td colspan="3" style="padding: 10px 15px; border-bottom: 1px solid #ddd;"><h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;"><?php echo $label_details[328]['name']; ?></h2></td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <span id="useful_links"></span>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td colspan="3" style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                                <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                                    <?php echo $label_details[329]['name']; ?>
                                                                                </h2>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <ul style="list-style: none;padding-top: 15px;">
                                                                                    <span id="pr_learning_materials"></span>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                                <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                                    <?php echo $label_details[330]['name']; ?>
                                                                                </h2>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <ul style="list-style: none;padding-top: 15px;">
                                                                                    <span id="pr_solutions"></span>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td style="padding: 10px 15px; border-bottom: 1px solid #ddd;">
                                                                                <h2 style="margin: 0; color: #1ba39c; font-size: 16px; font-weight: normal;">
                                                                                    <?php echo $label_details[331]['name']; ?>
                                                                                </h2>
                                                                            </td>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <ul style="list-style: none;padding-top: 15px;">
                                                                                    <span id="pr_evaluations"></span>
                                                                                </ul>
                                                                            </td>
                                                                        </tr>
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="preview_download_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-download fs-4"></i><?php echo $label_details[332]['name']; ?></button>
                                        <button type="button" id="preview_print_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-eye fs-4"></i><?php echo $label_details[333]['name']; ?></button>
                                        
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Lesson Preview Module-->

        

        