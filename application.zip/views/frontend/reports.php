<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .draggable_btn_sec {
  list-style: none;
  padding: 0 0 0 15px;
  margin: 0 0 15px 0;
}
.col.draggable.draggable_btns {
    display: inline-block;
    min-width: 100px;
    margin-right: 10px;
    border: 1px solid #ddd;
    border-radius: 3px;
    padding: 5px 8px;
    margin-bottom: 10px;
    background-color: #ffffe0;
}
.col.draggable.draggable_btns a {
  display: inline-block;
  width: auto;
  height: auto;
  padding: 5px 10px;
  
}

</style>
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7 no-print" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[1]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[2]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[1]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <div class="card mb-7 border no-print" id="weekly_filter">
            <a name="timetable_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[1]['name']; ?></h4>
                    <button type="button" id="label_46_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                    <div class="tool_tip">
                        <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                        <i class="las la-edit fs-1"></i>
                    </div>
                    <!--end::Svg Icon-->
                </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <form name="reports_form" id="reports_form" class="reports_form">
                    <a name="report_anchor_id"></a>
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-250px pb-3 mb-3">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[3]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="report_fld" name="report_fld">
                                    <option><?php echo $label_details[4]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[5]['name']; ?></option>
                                    <option value="3"><?php echo $label_details[7]['name']; ?></option>
                                    <option value="4"><?php echo $label_details[8]['name']; ?></option>
                                    <option value="5"><?php echo $label_details[9]['name']; ?></option>
                                    <option value="2"><?php echo $label_details[6]['name']; ?></option>
                                    <option value="6"><?php echo $label_details[10]['name']; ?></option>
                                </select>

                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <div class="alert alert-danger errYxt" id="rep_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="rep_succ_msg" style="display:none;">
                                <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <div class="clearfix"></div>
                            <div id="report_block" style="display:none;">
                                <div class="row pb-3 mb-3">
                                    <div class="col-lg-3 w-md-200px">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[11]['name']; ?> *</label>
                                        <!--begin::Select-->
                                        <select class="form-select form-select-solid border" data-control="select2" id="term_fld" name="term_fld">
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <div class="col-lg-3 w-md-200px" id="course_group_flt">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[12]['name']; ?> <span id="course_star"></span></label>
                                        <!--begin::Select-->
                                        <select class="form-select form-select-solid border" data-control="select2" id="course_fld" name="course_fld">
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <div class="col-lg-3 w-md-200px" id="student_group_flt">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[13]['name']; ?> <span id="student_star"></span></label>
                                        <!--begin::Select-->
                                        <select class="form-select form-select-solid border" data-control="select2" id="student_fld" name="student_fld">
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <div class="col-lg-3 w-md-200px" id="excused_group_flt">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[14]['name']; ?></label>
                                        <!--begin::Select-->
                                        <select id="excusable_fld" name="excusable_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                            <option value="all" selected="selected"><?php echo $label_details[15]['name']; ?></option>
                                            <option value="1"><?php echo $label_details[16]['name']; ?></option>
                                            <option value="0"><?php echo $label_details[17]['name']; ?></option>
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <div class="col-lg-3 w-md-200px" id="eval_date_group_flt">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[18]['name']; ?></label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                            <input class="form-control" placeholder="<?php echo $label_details[112]['name']; ?>" id="evaluation_date_fld" name="evaluation_date_fld" />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <h3 class="font-green-steel pb-3"><?php echo $label_details[19]['name']; ?></h3>
                                    <ul class="draggable_btn_sec" id="columns_list">
                                        <div id="column_names" class="draggable-zone">

                                        </div>
                                    </ul>
                                    <div class="col-lg-3 w-md-200px" id="add_more_columns_block">
                                        <label class="fs-7 form-label text-dark"><?php echo $label_details[20]['name']; ?></label>
                                        <!--begin::Select-->
                                        <select class="form-select form-select-solid border" data-control="select2" id="column_fld" name="column_fld">
                                        </select>
                                        <!--end::Select-->
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-lg-4 mt-4 w-md-250px">
                                        <!--end::Input group-->
                                        <!--begin:Action-->
                                        <div class="fltl me-3">
                                            <button type="button" id="reports_filter" name="reports_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                <i class="las la-filter"></i>
                                                <!--end::Svg Icon--><?php echo $label_details[21]['name']; ?>
                                            </button>
                                        </div>
                                        <div class="fltl">
                                            <button type="button" id="reports_reset" name="reports_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[22]['name']; ?></button>
                                        </div>
                                    </div>
                                    <div class="card-box mt-6">
                                        <!--begin::Add customer-->
                                        <span>&nbsp;</span>
                                        <!--begin::Toolbar-->
                                        <div class="card-toolbar">
                                            
                                            <div class="fltl">
                                                <?php if(in_array(297,$role_details)) { ?>
                                                <button type="button" id="save_current_settings_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2"><?php echo $label_details[23]['name']; ?> <i class="las la-save fs-3"></i></button>
                                                <?php } ?>
                                            </div>
                                            <div id="preset_block" class="fltl">
                                                <div class="fltl me-3">
                                                    <label class="fs-7 form-label text-dark fltl  me-3 mt-4"><?php echo $label_details[24]['name']; ?></label>
                                                    <div class="fltl w-md-250px me-3">
                                                        <select class="form-select form-select-solid border" data-control="select2" id="preset_fld" name="preset_fld">
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="fltl me-3">
                                                    <?php if(in_array(298,$role_details)) { ?>
                                                    <button type="button" id="open_preset_btn_id" class="btn btn-sm btn-info my-1 me-3 px-2"><?php echo $label_details[25]['name']; ?> <i class="las la-undo fs-3"></i></button>
                                                    <?php } ?>
                                                </div>
                                                <div class="fltl me-3" style="display:none;" id="delete_preset_block">
                                                    <?php if(in_array(299,$role_details)) { ?>
                                                    <button type="button" id="delete_preset_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2"><?php echo $label_details[26]['name']; ?> <i class="las la-trash fs-3"></i></button>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                        <!--end::Toolbar-->
                                        <!--end::Add customer-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->
                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
                </form>
            </div>
            <!--end::Card body-->
        </div>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content" style="display:none;">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <a name="report_table_anchor_id"></a>
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                </svg></span> <span id="report_title"></span></h3>
                                <button type="button" id="label_46_2" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                    <div class="tool_tip">
                                        <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                                        <i class="las la-edit fs-1"></i>
                                    </div>
                                    <!--end::Svg Icon-->
                                </button>
                                
                        </div>
                        <div class="card-toolbar">
                            <?php if(in_array(300,$role_details)) { ?>
                            <button type="button" id="print-timetable" class="btn btn-sm btn-info me-3 px-2 no-print" ><?php echo $label_details[27]['name']; ?> <i class="las la-print fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(301,$role_details)) { ?>
                            <button type="button" id="export_btn" class="btn btn-sm btn-success me-3 px-2 no-print" ><?php echo $label_details[28]['name']; ?> <i class="las la-file-export fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div id="report_table">
                        <div id="print_data"></div>
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="cc-table">
                        </table>
                        <div id="avg_display"></div>
                    </div>
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
        </div>
        <!--end::Post-->
        <!--begin::Modal - Save Report -->
        <div class="modal fade" id="add_save_report" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-650px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[29]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_46_3" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                    <div class="tool_tip">
                        <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                        <i class="las la-edit fs-1"></i>
                    </div>
                    <!--end::Svg Icon-->
                </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <!--begin::Form-->
                        <div class="add_save_report_form">
                            <!--begin::Input group-->
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[31]['name']; ?> *</label>
                            <div class="input-group flex-nowrap mb-4">
                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <input type="text" id="report_name" name="report_name" class="form-control" aria-describedby="basic-addon1">
                                </div>
                            </div>
                            <!--end::Input group-->
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" id="add_save_report_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[32]['name']; ?>
                                </button>
                                <button type="button" class="btn btn-danger me-3" id="close_com_add_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[33]['name']; ?></button>
                            </div>
                            <!--end::Actions-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Save Report -->

        <!--begin::Modal - Delete Module-->
        <div class="modal fade" id="delete_reports" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[34]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_46_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_reports_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[35]['name']; ?></label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_reports_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[36]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[37]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<script src="<?php echo $plugins_path;?>custom/draggable/draggable.bundle.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/draggable/cards.js"></script>
<script src="<?php echo $js_path;?>reports.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,active_columns=[],inactive_columns=[],columns_order=[],id="<?php  echo $user_det['id'];?>",term_fld="",student_fld="",course_fld="",excusable_fld="",evaluation_date_fld="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",preset_details=[],column_details=[],row_details=[],course_details=[],role_details=[];

$(document).ready(function() { 
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    $("#evaluation_date_fld").flatpickr({
        dateFormat: "d-m-Y"
    });
    if ($.inArray("15", role_details) != -1)
    {
        edit_role=true;
    }
	reports_details();
});
</script>  
