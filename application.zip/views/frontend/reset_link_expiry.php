<!DOCTYPE html>
<html lang="en">
	<!--begin::Head-->
	<head>
		<title>ProScola - Reset Password</title>
		<link rel="shortcut icon" href="<?php echo $media_path; ?>logos/favicon.ico" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<link href="<?php echo $plugins_global_path; ?>plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Global Stylesheets Bundle-->
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="bg-dark">
		<!--begin::Main-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Authentication - Sign-in -->
			<div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(<?php echo $media_path; ?>illustrations/sketchy-1/14-dark.png">
				<!--begin::Content-->
				<div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
					<!--begin::Logo-->
					
					<!--end::Logo-->
					<!--begin::Wrapper-->
					<div class="w-lg-500px bg-body rounded shadow-sm p-10 p-lg-15 mx-auto">
                        <a href="" class="mb-12">
                            <img alt="Logo" src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $header_logo_image; ?>" class="h-40px" />
                        </a>
						<!--begin::Form-->
						<div class="pt-lg-10 mb-10">
							<!--begin::Logo-->
							<h1 class="fw-bolder fs-2qx text-gray-800 mb-7">Reset Password</h1>
							<!--end::Logo-->
							<!--begin::Message-->
							<div class="fw-bold fs-3 text-muted mb-15">Reset Link Expired.
							<br />Already Password Has Been Reset Using This Link</div>
							<!--end::Message-->
							<!--begin::Action-->
							<div class="text-center">
								<a href="<?php echo $base_url . "login"; ?>" class="btn btn-primary btn-lg fw-bolder">Sign In</a>
							</div>
							<!--end::Action-->
							<!--begin::Action-->
							<div class="text-gray-700 fw-bold fs-4 pt-7">Forgot Password?
							<a href="<?php echo $base_url . "forgot_password"; ?>" class="text-primary fw-bolder">Try Again</a></div>
							<!--end::Action-->
						</div>
						<!--end::Form-->
					</div>
					<!--end::Wrapper-->
				</div>
				<!--end::Content-->		
                <!--begin::Footer-->
				<div class="d-flex flex-center flex-column-auto p-10">
					<!--begin::Links-->
					<div class="d-flex align-items-center fw-bold fs-6">
                        Copyright ProScola GmbH, Switzerland. All rights reserved! | ProScola - Version 3.5
					</div>
					<!--end::Links-->
				</div>
				<!--end::Footer-->		
			</div>
			<!--end::Authentication - Sign-in-->
		</div>
		<!--end::Main-->
		<!--begin::Javascript-->
		<!--begin::Global Javascript Bundle(used by all pages)-->
        <script>var hostUrl = "<?php echo $assets_path; ?>";</script>
		<script src="<?php echo $plugins_global_path; ?>plugins.bundle.js"></script>
		<script src="<?php echo $js_path; ?>scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Custom Javascript(used by this page)-->
		<!--end::Page Custom Javascript-->
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>