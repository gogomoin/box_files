<!DOCTYPE html>
<html lang="en">
	<!--begin::Head-->
	<head>
		<title>ProScola - Reset Password</title>
		<link rel="shortcut icon" href="<?php echo $media_path; ?>logos/favicon.ico" />
		<!--begin::Fonts-->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
		<!--end::Fonts-->
		<!--begin::Global Stylesheets Bundle(used by all pages)-->
		<link href="<?php echo $plugins_global_path; ?>plugins.bundle.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo $css_path; ?>style.bundle.css" rel="stylesheet" type="text/css" />
		<!--end::Global Stylesheets Bundle-->
	</head>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="bg-dark">
		<!--begin::Main-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Authentication - Sign-in -->
			<div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(<?php echo $media_path; ?>illustrations/sketchy-1/14-dark.png">
				<!--begin::Content-->
				<div class="d-flex flex-center flex-column flex-column-fluid p-10 pb-lg-20">
					<!--begin::Logo-->
					
					<!--end::Logo-->
					<!--begin::Wrapper-->
					<div class="w-lg-500px bg-body rounded shadow-sm p-10 p-lg-15 mx-auto">
                        <a href="" class="mb-12">
                            <img alt="Logo" src="<?php echo $assets_path; ?>uploads/user_files/<?php echo $header_logo_image; ?>" class="h-40px" />
                        </a>
						<!--begin::Form-->
						<form class="form w-100" method="post" name="reset_form" action="<?php echo $base_url . "update_password"; ?>" autocomplete="off">
							<!--begin::Heading-->
							<div class="text-center mb-10">
								<!--begin::Title-->
								<h1 class="text-dark mb-3">Reset Password</h1>
								<!--end::Title-->
							</div>
							<div class="login__check"> <span id="error_message" style="color:red;margin: 10% 0% 0% 21%; display:none;"></span></div>
							<!--begin::Heading-->
							<!--begin::Input group-->
							<div class="fv-row mb-10">
								<!--begin::Label-->
								<label class="form-label fs-6 fw-bolder text-dark">New Password</label>
								<!--end::Label-->
								<!--begin::Input-->
								<input class="form-control form-control-lg form-control-solid" type="password" placeholder="New Password" aria-label="new_password" aria-describedby="basic-addon1" name="new_password" id="new_password" autocomplete="off" />
								<input type="hidden" name="token_id" value="<?php echo $token_id ?>" />
								<!--end::Input-->
							</div>
							<div class="fv-row mb-10">
								<!--begin::Label-->
								<label class="form-label fs-6 fw-bolder text-dark">Confirm Password</label>
								<!--end::Label-->
								<!--begin::Input-->
								<input class="form-control form-control-lg form-control-solid" type="password" placeholder="Confirm Password" aria-label="confirm_password" aria-describedby="basic-addon1" name="confirm_password" id="confirm_password" autocomplete="off" />
								<!--end::Input-->
							</div>
							<!--end::Input group-->
							<!--begin::Actions-->
							<div class="text-center">
								<!--begin::Submit button-->
                                <span style="color:#ea4646; font-weight:bold;display: block;padding: 10px 0px;"  id="status"><?php echo $error_message ?></span>
								<button type="submit" onClick="return check_add_form();" class="btn btn-lg btn-primary w-100 mb-5">
									<span class="indicator-label">RESET</span>
									<span class="indicator-progress">Please wait...
									<span class="spinner-border spinner-border-sm align-middle ms-2"></span></span>
								</button>
								<!--end::Submit button-->
							</div>
							<!--end::Actions-->
						</form>
						<!--end::Form-->
					</div>
					<!--end::Wrapper-->
				</div>
				<!--end::Content-->		
                <!--begin::Footer-->
				<div class="d-flex flex-center flex-column-auto p-10">
					<!--begin::Links-->
					<div class="d-flex align-items-center fw-bold fs-6">
					Copyright ProScola GmbH, Switzerland. All rights reserved! | ProScola - Version 3.5
					</div>
					<!--end::Links-->
				</div>
				<!--end::Footer-->		
			</div>
			<!--end::Authentication - Sign-in-->
		</div>
		<!--end::Main-->
		<!--begin::Javascript-->
		<!--begin::Global Javascript Bundle(used by all pages)-->
        <script>var hostUrl = "<?php echo $assets_path; ?>";</script>
		<script src="<?php echo $plugins_global_path; ?>plugins.bundle.js"></script>
		<script src="<?php echo $js_path; ?>scripts.bundle.js"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Custom Javascript(used by this page)-->
		<!--end::Page Custom Javascript-->
        <script>
            $(".preloader").fadeOut();
            setTimeout(function(){
            $('#status').fadeOut();
            }, 5000);            
        </script>
        <script> 
        
        function check_add_form(){
            
            usrSubPrev = true;
            var new_password = document.forms["reset_form"]["new_password"].value;
            var confirm_password = document.forms["reset_form"]["confirm_password"].value;
            if(new_password==""){
					$('#error_message').html("New Password: Please Fill Out Required Field");	
                    $('#error_message').show();
                    $("#new_password").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
                    return false;
            }
			else{
				$("#new_password").css("border-bottom", "1px solid #eee");
				$('#error_message').hide();
			}
			if(confirm_password==""){
					$('#error_message').html("Confirm Password: Please Fill Out Required Field");	
                    $('#error_message').show();
                    $("#confirm_password").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
                    return false;
            }
			else{
				$("#confirm_password").css("border-bottom", "1px solid #eee");
				$('#error_message').hide();
			}
			if(new_password!=confirm_password){
				$('#error_message').html("Error - Confirm Password Doesn't Match");	
				$('#error_message').show();
				$("#confirm_password").css("border-bottom", "1px solid rgba(232, 8, 8, 0.94)");
				return false;
            }  
			else{
				$("#confirm_password").css("border-bottom", "1px solid #eee");
				$('#error_message').hide();
			}
        }
        </script>
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html>