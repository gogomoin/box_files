<?php echo $header; ?>
<?php echo $sideheader; ?>
<link href="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.css" rel="stylesheet" type="text/css" />
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
     .actionBtns_table tr td:nth-child(14) {
    text-align: center;
}

</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[2]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[1]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(174,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="school_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[3]['name']; ?></h3>
                    <button type="button" id="label_25_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="status_fld" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[8]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[9]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[10]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="del_fld" name="del_fld" data-hide-search="true">
                                    <option value="all"><?php echo $label_details[11]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[12]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[13]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="school_filter" name="school_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[6]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="school_reset" name="school_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[7]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[14]['name']; ?></h3>
                                    <button type="button" id="label_25_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(175,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_school_btn"><?php echo $label_details[17]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(176,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_school" data-toggle="modal"><?php echo $label_details[18]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(177,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_school" data-toggle="modal"><?php echo $label_details[21]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(178,$role_details)) { ?>
                            <button type="button" id="status_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#status_school" data-toggle="modal" id="status_school_btn"><?php echo $label_details[19]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="2" class="fw-bolder"> <?php echo $label_details[23]['name']; ?> </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[24]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder"> <?php echo $label_details[25]['name']; ?> </th>
                                    <th data-priority="6" class="fw-bolder"> <?php echo $label_details[26]['name']; ?> </th>
                                    <th data-priority="7" class="fw-bolder"> <?php echo $label_details[27]['name']; ?> </th>
                                    <th data-priority="8" class="fw-bolder"> <?php echo $label_details[28]['name']; ?> </th>
                                    <th data-priority="9" class="fw-bolder"> <?php echo $label_details[29]['name']; ?> </th>
                                    <th data-priority="10" class="fw-bolder"> <?php echo $label_details[30]['name']; ?> </th>
                                    <th data-priority="11" class="fw-bolder"> <?php echo $label_details[31]['name']; ?> </th>
                                    <th data-priority="12" class="fw-bolder"> <?php echo $label_details[32]['name']; ?> </th>
                                    <th data-priority="13" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[33]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[34]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="school_create_id" style="display:none;">
                <form name="add_school_form" id="add_school_form" class="add_school_form">
                    <a name="school_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[38]['name']; ?> <?php echo $label_details[160]['name']; ?>
                            </h3>
                            <button type="button" id="label_25_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[39]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="name" name="name" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5">
                            <div class="input-group">
                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[40]['name']; ?> *</label>
                                <button type="button" id="file_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><?php echo $label_details[118]['name']; ?><i class="las la-file-image fs-3"></i></button>
                            </div>
                            <div id="logo_image_block">
                                <div class="rounded border p-0">
                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                        <!--begin::Preview existing avatar-->
                                        <div id="logo_image" class="image-input-wrapper w-125px h-125px"></div>
                                        <!--end::Preview existing avatar-->
                                        <!--begin::Edit-->
                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                        <i class="bi bi-pencil-fill fs-7"></i>
                                        </button>
                                        <!--end::Edit-->
                                        <!--begin::Remove-->
                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file" data-bs-original-title="Remove Logo">
                                        <i class="bi bi-x fs-2"></i>
                                        </a>
                                        <input type="hidden" id="school_logo_file_name" name="school_logo_file_name" />
                                        <!--end::Remove-->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[41]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="country_id" name="country_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[42]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-pin fs-3 "></i></span>
                                <input type="text" id="city" name="city" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[43]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                <input type="text" id="address1" name="address1" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[44]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="zip_code" name="zip_code" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[45]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                <input type="text" id="address2" name="address2" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[46]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-phone fs-3 "></i></span>
                                <input type="text" id="phone_no" name="phone_no" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[47]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="gen_email" name="gen_email" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[48]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="specific_email" name="specific_email" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[158]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="domain" name="domain" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[159]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="db_name" name="db_name" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[49]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_school_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[50]['name']; ?></button>
                            <button type="button" id="add_school_new_sub" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[51]['name']; ?></button>
                            <button type="button" id="add_school_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[52]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="school_edit_id" style="display:none;">
                <form name="edit_school_form" id="edit_school_form" class="edit_school_form">
                    <a name="school_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[55]['name']; ?> <?php echo $label_details[161]['name']; ?></h3>
                                <button type="button" id="label_25_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[56]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="name_up" name="name" class="form-control" aria-describedby="basic-addon1">
                                <input type="hidden" id="token_id" name="token_id" />
                            </div>
                        </div>
                        <div class="logo_edit_css mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[57]['name']; ?> *</label>
                            <div class="rounded border p-0 input-group">
                                <div class="image-input image-input-outline" data-kt-image-input="true" id="logo_image_block_up">
                                <!--begin::Preview existing avatar-->
                                    <div id="logo_image_up" class="image-input-wrapper w-125px h-125px"></div>
                                    <!--end::Preview existing avatar-->
                                    <!--begin::Edit-->
                                    <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit_up" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                    <i class="bi bi-pencil-fill fs-7"></i>
                                    </button>
                                    <!--end::Edit-->
                                    <!--begin::Remove-->
                                    <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file_up" data-bs-original-title="Remove Logo">
                                    <i class="bi bi-x fs-2"></i>
                                    </a>
                                    <input type="hidden" id="school_logo_file_name_up" name="school_logo_file_name" />
                                    <input type="hidden" id="school_mng" />
                                    <!--end::Remove-->
                                </div>
                            </div>
                            <!-- <label class="control-label" for="create_name">Logo *</label>
                            <div class="imp_file_cls">
                                <div class="custom-file">
                                    <input type="file" name="school_logo_file" id="school_logo_file_up" class="custom-file-input" accept="image/*">
                                    <label class="custom-file-label" for="customFile" id="school_logo_label_up">Choose Logo (Images only)</label>
                                    <img src="<?php echo $base_url?>assets/images/no_image.png" alt="Logo" width="55px" height="55px" class="img-thumbnail" style="margin-top: 10px;" id="school_logo_preview_up">
                                    <a class="" style="cursor:pointer" id="remove_school_logo_file_up"><span>Remove</span></a>
                                    <input type="hidden" id="old_logo_file_name" name="old_logo_file_name" />
                                    <input type="hidden" id="new_logo_file_name" name="new_logo_file_name" />
                                    <input type="hidden" id="school_logo_name" name="school_logo_name" />
                                </div>
                            </div> -->
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[58]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="country_id_up" name="country_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[59]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-pin fs-3 "></i></span>
                                <input type="text" id="city_up" name="city" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[60]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                <input type="text" id="address1_up" name="address1" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[61]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                <input type="text" id="zip_code_up" name="zip_code" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[62]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                <input type="text" id="address2_up" name="address2" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[63]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-phone fs-3 "></i></span>
                                <input type="text" id="phone_no_up" name="phone_no" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[64]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="gen_email_up" name="gen_email" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[65]['name']; ?></label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="specific_email_up" name="specific_email" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[162]['name']; ?> *</label>
                            <div class="input-group">
                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                <input type="text" id="domain_up" name="domain" class="form-control" aria-describedby="basic-addon1">
                            </div>
                        </div>
                        <div class="mb-10">
                            <label class="fs-6 form-label text-dark"><?php echo $label_details[66]['name']; ?></label>
                            <div class="form-check form-switch form-check-custom form-check-solid">
                                <input class="form-check-input" type="checkbox" id="status_up" name="status" checked="checked">
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_school_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[67]['name']; ?></button>
                            <button type="button" id="edit_school_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[68]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_school" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[74]['name']; ?> <?php echo $label_details[164]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_25_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_school_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[77]['name']; ?> ?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_school_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[78]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[79]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

            <!--begin::Modal - Restore Module-->
            <div class="modal fade" id="restore_school" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[90]['name']; ?> <?php echo $label_details[165]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_25_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_school_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[95]['name']; ?> ?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_school_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[91]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[92]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->

            <!--begin::Modal - Status Module-->
            <div class="modal fade" id="status_school" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[166]['name']; ?> <?php echo $label_details[82]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_25_6" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="sta_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="sta_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="status_school_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[85]['name']; ?> <?php echo $label_details[166]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="status_school_sub" class="btn btn-primary"><i class="las la-toggle-on fs-5"></i> <?php echo $label_details[83]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_status_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[84]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Status Module-->
             
            <?php echo $file_manager; ?>
            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
		<!--end::Page Custom Javascript-->
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>school.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,selected=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",country_details=[],tree_details=[],folder_id=1,attachmentCount = 0,uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],selected_folder_id="",file_details=[],selected_folder=[],change_tree=true,folder_table,folder_tree=true,label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,file_manager_label_details=<?php echo json_encode($file_manager_label_details); ?>,move_id=1,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() { 
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("179", role_details) != -1)
    {
        edit_role=true;
    }
	file_manager_details();
	school_details();
});
</script>  
