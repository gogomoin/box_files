<?php echo $header; ?>
<?php echo $sideheader; ?>
<link href="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.css" rel="stylesheet" type="text/css" />
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
    
    .actionBtns_table tr td:nth-child(10) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(12) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(11) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(5) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(6) {
    text-align: center;
}

.assign_actionBtns_table tr td:nth-child(1) {
    text-align: center;
}
.assign_actionBtns_table tr td:nth-child(2) {
    text-align: center;
}
.assign_actionBtns_table tr td:nth-child(3) {
    text-align: center;
}
.assign_actionBtns_table tr td:nth-child(4) {
    text-align: center;
}
#assign_table {
  border: 1px solid #ddd;
}
#assign_table thead tr th {
  border-right: 1px solid #ddd;
}
#assign_table tbody tr td {
  border-right: 1px solid #ddd;
}
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(288,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="students_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[2]['name']; ?></h3>
                    <button type="button" id="label_45_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[3]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="grade_fld" name="grade_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="study_level_fld" name="study_level_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[416]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="teacher_fld" name="teacher_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                             <!--begin::Col-->
                             <div class="col-lg-3 w-md-100px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="resigned_fld" name="resigned_fld" data-hide-search="true">
                                    <option selected="selected" value="all"><?php echo $label_details[6]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[7]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[8]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-150px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[9]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="status_fld" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[10]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[11]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[12]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-100px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[13]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="del_fld" name="del_fld" data-hide-search="true">
                                    <option value="all"><?php echo $label_details[14]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[15]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[16]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <div class="col-lg-4 w-md-250px">
                                <label >&nbsp;</label>
                                <div class="clearfix"></div>
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="students_filter" name="students_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[17]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="students_reset" name="students_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[18]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[19]['name']; ?></h3>
                                    <button type="button" id="label_45_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(289,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_students_btn"><?php echo $label_details[20]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(291,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_students" data-toggle="modal"><?php echo $label_details[21]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(292,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_students" data-toggle="modal"><?php echo $label_details[22]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(293,$role_details)) { ?>
                            <button type="button" id="status_btn_id"  class="btn btn-sm btn-warning reset-btn my-1 me-3 px-2"  data-target="#status_students" data-toggle="modal" id="status_students_btn"><?php echo $label_details[23]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(294,$role_details)) { ?>
                            <button type="button" id="resigned_btn_id"  class="btn btn-sm btn-dark reset-btn my-1 me-3 px-2"  data-target="#resigned_students" data-toggle="modal" id="resigned_students_btn"><?php echo $label_details[24]['name']; ?> <i class="las la-toggle-on fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(295,$role_details)) { ?>
                            <button type="button" class="btn btn-sm btn-success my-1 px-2" data-toggle="modal" data-target="#import_students" id="import_students_btn"><?php echo $label_details[25]['name']; ?> <i class="las la-external-link-alt fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 cam_cls" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="2" class="fw-bolder"> <?php echo $label_details[26]['name']; ?> </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[419]['name']; ?> </th>
                                    <th data-priority="8" class="fw-bolder"> <?php echo $label_details[27]['name']; ?> </th>
                                    <th data-priority="9" class="fw-bolder"> <?php echo $label_details[28]['name']; ?> </th>
                                    <th data-priority="10" class="fw-bolder"> <?php echo $label_details[29]['name']; ?> </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[30]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder"> <?php echo $label_details[305]['name']; ?> </th>
                                    <th data-priority="6" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[31]['name']; ?> </th>
                                    <th class="fw-bolder" style="text-align: center;"> <?php echo $label_details[450]['name']; ?> </th>
                                    <th data-priority="7" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[32]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-150px fw-bolder" style="text-align: center;"> <?php echo $label_details[33]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                    <div class="text-center add_col_loader" style="display:none">
                        <div class="loader"></div>
                    </div>
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="students_create_id" style="display:none;">
                <form name="add_students_form" id="add_students_form" class="add_students_form">
                    <a name="students_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-8  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[34]['name']; ?> <?php echo $label_details[421]['name']; ?>
                            </h3>
                            <button type="button" id="label_45_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_students_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[35]['name']; ?></button>
                            <button type="button" id="add_students_new_sub" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[36]['name']; ?></button>
                            <button type="button" id="add_students_new_con_sub" class="btn btn-sm btn-warning my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[37]['name']; ?></button>
                            <button type="button" id="add_students_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[38]['name']; ?></button>
                        </div>
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[39]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_2">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                        <path id="parents" d="M14.654,12.652c-.167,0-.323,0-.474-.009H14.1a3.315,3.315,0,0,0-1.642.481,5.052,5.052,0,0,0-1.992,2.118A12.964,12.964,0,0,0,9.242,22.31a1.365,1.365,0,0,0,1.022,1.179,1.539,1.539,0,0,0,.545.1,1.711,1.711,0,0,0,.96-.314,1.365,1.365,0,0,0,.593-1.245,13.344,13.344,0,0,1,.327-3.4V23.97c-.98.01-1.961.021-2.942.024q-3.207.007-6.413,0a1.5,1.5,0,0,1-.657-.067c.569-3.56,1.139-7.116,1.726-10.79a1.376,1.376,0,0,0-.6.719,11.878,11.878,0,0,0-1.194,4.975c-.016.678-.017,1.357-.057,2.034A1.187,1.187,0,0,1,1.3,21.952,1.182,1.182,0,0,1,.014,20.9,19.707,19.707,0,0,1,.74,13.965a8.074,8.074,0,0,1,2.417-3.786A4.126,4.126,0,0,1,6,9.177c2.193.043,4.389.011,6.584,0A3.708,3.708,0,0,0,13.823,12.1a3.79,3.79,0,0,0,.83.548m9.337,9.236a8.157,8.157,0,0,1-.06-1.137,10.932,10.932,0,0,0-.257-2.86,6.9,6.9,0,0,0-2.241-4.051,2.834,2.834,0,0,0-2.018-.7c-.731.038-1.464.012-2.2.01h-.112l-.391,0c-.231,0-.463,0-.694,0s-.445,0-.667,0-.443,0-.664,0c-.177,0-.353-.005-.53-.01a2.635,2.635,0,0,0-1.392.4,4.5,4.5,0,0,0-1.78,1.91A12.747,12.747,0,0,0,9.82,22.293c.014.36.3.6.676.741a.97.97,0,0,0,.917-.15.911.911,0,0,0,.37-.847,11.454,11.454,0,0,1,.919-5.151.982.982,0,0,1,.564-.667v7.746h7.284V16.3a1.778,1.778,0,0,1,.624.848,11.22,11.22,0,0,1,.785,4.831.976.976,0,0,0,1,1.1,1.006,1.006,0,0,0,1.026-1.2M8.862,0a4.184,4.184,0,1,0,4.184,4.184A4.184,4.184,0,0,0,8.862,0M16.9,6.187a3.234,3.234,0,1,0,3.234,3.234A3.234,3.234,0,0,0,16.9,6.187" transform="translate(0)"/>
                                    </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[40]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_3">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="contact_data" data-name="contact data" d="M18.87,12.233a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m4.439,4.259a.584.584,0,0,0,.684-.645c.01-.721.011-1.442,0-2.163a.554.554,0,0,0-.654-.609c-.339.013-.678,0-1.026,0V11.246c.385,0,.728-.006,1.071,0a.538.538,0,0,0,.608-.6c.013-.738.015-1.477,0-2.215a.553.553,0,0,0-.621-.6c-.354,0-.709,0-1.071,0V6.049c.367,0,.706,0,1.046,0a.579.579,0,0,0,.65-.63c.007-.721.006-1.442,0-2.163a.582.582,0,0,0-.638-.645c-.341-.008-.682,0-1.087,0,0-.573,0,.473,0-.024A2.548,2.548,0,0,0,19.7,0Q11.122,0,2.544,0A2.5,2.5,0,0,0,.007,2.5C0,9.965,0,14.028.007,21.5A2.5,2.5,0,0,0,2.537,24q8.577,0,17.155,0a2.549,2.549,0,0,0,2.575-2.575c0-.51,0,.439,0-.111.383,0,.706,0,1.028,0a.613.613,0,0,0,.7-.692q0-1.03,0-2.061a.608.608,0,0,0-.7-.69c-.335,0-.669,0-1,0v-1.38c.358,0,.682-.009,1.006,0m-10.542-.926c-.01.3,0,1.42,0,1.637H4.305a5.587,5.587,0,0,1,3.266-5.127.439.439,0,0,1,.423.079,3.624,3.624,0,0,0,3.862,0,.441.441,0,0,1,.425-.074,3.318,3.318,0,0,1,.487.217.962.962,0,0,0,0,.154,9.535,9.535,0,0,1,0,1.01c-.022.4.012,1.763,0,2.1M9.934,12.136a3.111,3.111,0,1,1,3.112-3.124,3.122,3.122,0,0,1-3.112,3.124m3.115.526a.838.838,0,0,1,.423-.783,3.464,3.464,0,0,1,1.324-.5,7.049,7.049,0,0,1,3.358.142,2.421,2.421,0,0,1,.9.456.736.736,0,0,1,.292.62c-.008.179,0,.359,0,.539,0,.155-.011.31,0,.464a.815.815,0,0,1-.41.776,3.3,3.3,0,0,1-1.249.489,7.2,7.2,0,0,1-3.241-.065,3.06,3.06,0,0,1-.962-.409.859.859,0,0,1-.434-.8,8.428,8.428,0,0,0,0-.927m0,1.918.04,0a1.112,1.112,0,0,0,.54.534,4.2,4.2,0,0,0,1.51.459,7.161,7.161,0,0,0,2.809-.142,2.892,2.892,0,0,0,1.041-.469,1.064,1.064,0,0,0,.342-.421c0,.389.015.779,0,1.168a.761.761,0,0,1-.4.56,3.321,3.321,0,0,1-1.249.487,7.2,7.2,0,0,1-3.166-.049,2.856,2.856,0,0,1-1.152-.521.778.778,0,0,1-.309-.663c.01-.313,0-.626,0-.94m5.85,3.59a3.71,3.71,0,0,1-1.34.493,5.57,5.57,0,0,1-.794.1c-.018,0-.032,0-.036.024h-1.1a2.517,2.517,0,0,0-.5-.074,4.554,4.554,0,0,1-1.487-.452,1.8,1.8,0,0,1-.318-.221.748.748,0,0,1-.277-.6c.006-.336,0-.672,0-1.027a1.95,1.95,0,0,0,1.415.907,6.908,6.908,0,0,0,3.685-.062,2.488,2.488,0,0,0,.858-.423.915.915,0,0,0,.312-.419c.031.03.019.064.019.093,0,.285-.015.569,0,.852a.848.848,0,0,1-.441.81m-5.382-5.4a1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529m5.348-.537a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547" transform="translate(0 0)" fill="#010101"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[41]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_4">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="remarks" d="M7.065,24V18.258a1.894,1.894,0,0,0-.547-.028,17.2,17.2,0,0,1-2.474-.08A4.956,4.956,0,0,1,.059,13.706c-.11-1.411-.028-2.828-.04-4.242C0,7.841-.016,6.217.022,4.6a3.923,3.923,0,0,1,.39-1.52A4.724,4.724,0,0,1,4.839.024C7.6-.019,10.366.011,13.129.009c1.974,0,3.948-.008,5.922,0a4.916,4.916,0,0,1,4.842,4.009,5.607,5.607,0,0,1,.1,1.189c0,2.611-.024,5.222.01,7.833a5.035,5.035,0,0,1-4.232,5.144,5.913,5.913,0,0,1-.824.044q-2.631,0-5.261-.005a.627.627,0,0,0-.464.184q-2.989,2.76-5.986,5.51c-.038.035-.067.093-.168.08M12.1,7.3a1.8,1.8,0,1,0,1.719,1.814A1.775,1.775,0,0,0,12.1,7.3m-6.032,0a1.8,1.8,0,0,0-.008,3.6,1.8,1.8,0,0,0,.008-3.6m12.013,0a1.766,1.766,0,0,0-1.751,1.8,1.751,1.751,0,1,0,1.751-1.8" transform="translate(0 0)" fill="#020201"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[42]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_5">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="permission" d="M11.361,24h-.669c-.013-.029-.041-.025-.066-.025H9.7c-.025,0-.053,0-.065.025H9.2c-.007-.027-.03-.024-.051-.024-.626-.019-1.251-.056-1.875-.1-.782-.054-1.564-.119-2.343-.206-.868-.1-1.735-.2-2.6-.335a13.691,13.691,0,0,1-1.622-.313.637.637,0,0,1-.472-.437,4.7,4.7,0,0,1-.226-1.212,9.541,9.541,0,0,1,.157-2.218,2.034,2.034,0,0,1,.9-1.415,4.937,4.937,0,0,1,.937-.5,15.424,15.424,0,0,1,1.914-.587,5.7,5.7,0,0,0,2.192-1.026,1.824,1.824,0,0,0,.736-1.086,3.854,3.854,0,0,0,0-1.086,1.277,1.277,0,0,0-.485-.889c-.181-.15-.35-.314-.533-.461a2.119,2.119,0,0,1-.542-.674,6.693,6.693,0,0,1-.453-1.178.167.167,0,0,0-.12-.125A1.088,1.088,0,0,1,4.3,9.849a2.082,2.082,0,0,1-.49-.943,1.748,1.748,0,0,1,.309-1.6.4.4,0,0,0,.093-.254,12.445,12.445,0,0,1,.355-2.995A5.278,5.278,0,0,1,5.967,1.529,5.139,5.139,0,0,1,9.038.062a6.763,6.763,0,0,1,3.281.351,4.988,4.988,0,0,1,2.738,2.233,7.989,7.989,0,0,1,.831,2.718,12.744,12.744,0,0,1,.12,1.795.12.12,0,0,0,.046.106,1.069,1.069,0,0,1,.331.5,2.127,2.127,0,0,1,0,1.267,1.465,1.465,0,0,1-.939,1.113c-.056.021-.06.065-.073.105-.07.209-.128.423-.208.629a2.8,2.8,0,0,1-.78,1.23,1.357,1.357,0,0,0-.418.622A5.618,5.618,0,0,1,13.3,14a7.193,7.193,0,0,0-1.035,2.248,6.938,6.938,0,0,0,.037,3.226,5.108,5.108,0,0,0,1.555,2.633,7.613,7.613,0,0,0,2.082,1.368c.037.017.091.018.105.071a18.006,18.006,0,0,1-1.949.275c-.883.088-1.769.134-2.657.153-.026,0-.062-.016-.077.023M24,17.6a5.539,5.539,0,0,1-5.357,5.538l-.091,0h-.209l-.117,0-.117-.006h0A5.541,5.541,0,1,1,24,17.6m-2.622-1.332a.211.211,0,0,0,0-.353c-.125-.13-.254-.255-.382-.383-.161-.162-.244-.162-.408,0l-3.042,3.046a.928.928,0,0,0-.088-.123q-.585-.589-1.173-1.175a.223.223,0,0,0-.366,0c-.134.132-.268.266-.4.4a.218.218,0,0,0,0,.348q.936.94,1.874,1.876a.212.212,0,0,0,.353,0l3.63-3.633" transform="translate(0 0)"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[43]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_6">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="documents" d="M1.822,0H14.566c.675,0,.86.172.86.849,0,1.361-.01,2.637-.01,4,0,1.179,1,1.794,2.417,1.763,1.351.012,3.346,0,4.7,0,1.123,0,1.47.337,1.47,1.433,0,4.6,0,8.8,0,13.4a2.267,2.267,0,0,1-2.576,2.531c-5.7,0-13.065-.028-18.765.018A2.452,2.452,0,0,1,0,21.392c.049-7.1.021-12.5.021-19.605A1.808,1.808,0,0,1,1.822,0M12.012,18.325c-1.807,0-3.615,0-5.422,0a1.156,1.156,0,0,0-1.3,1.084c-.023.665.5,1.135,1.3,1.158.278.008.556,0,.834,0h9.652c.179,0,.359.01.536-.007a1.149,1.149,0,0,0,1.124-1.149,1.121,1.121,0,0,0-1.18-1.084c-1.847-.015-3.694,0-5.541-.006m0-2.216h5.354c.85,0,1.381-.438,1.37-1.124-.011-.666-.538-1.107-1.341-1.108q-5.383,0-10.767,0c-.8,0-1.33.443-1.34,1.109-.01.686.52,1.122,1.37,1.123h5.354m0-6.658c-1.788,0-3.575,0-5.363,0a1.248,1.248,0,0,0-1.076.384,1.049,1.049,0,0,0-.184,1.159,1.23,1.23,0,0,0,1.26.706q5.363,0,10.726,0c.837,0,1.377-.48,1.358-1.163s-.517-1.077-1.358-1.08c-1.788,0-3.575,0-5.363,0M17.46.041a1.125,1.125,0,0,0-.836,1.166c0,1.1-.028,1.38.009,2.482A2.187,2.187,0,0,0,18.9,5.855c1.03.007,2.061-.014,3.091.007a1.121,1.121,0,0,0,.858-2.011c-1.338-1.315-2.369-1.679-3.7-3a3.5,3.5,0,0,0-1.1-.806,1.192,1.192,0,0,0-.6,0" transform="translate(0)" fill="#010101"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[44]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_7">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="assignment" d="M8.225,2.389A3.924,3.924,0,0,1,12.05,0,3.907,3.907,0,0,1,15.77,2.389c.087,0,3.705,0,5.413,0A2.544,2.544,0,0,1,24,4.931q0,8.257,0,16.515A2.547,2.547,0,0,1,21.166,24H2.825A2.546,2.546,0,0,1,0,21.467Q0,13.2,0,4.924A2.544,2.544,0,0,1,2.823,2.39q2.7,0,5.4,0M5.343,9.579h13.3V7.2H5.343Zm0,4.8h13.31V12.019H5.342Zm0,4.811h9.314V16.81H5.342ZM10.673,3.6a1.333,1.333,0,0,0,2.653-.006,1.265,1.265,0,0,0-1.346-1.2A1.259,1.259,0,0,0,10.673,3.6" transform="translate(0.001 0)"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[45]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[46]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5 mb-5">
                                            <div class="input-group">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[283]['name']; ?></label>
                                                <button type="button" id="file_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><?php echo $label_details[47]['name']; ?><i class="las la-file-image fs-3"></i></button>
                                            </div>
                                            <div id="logo_image_block" class="flex-nowrap">
                                                <div class="rounded border p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="logo_image" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                        <!--begin::Edit-->
                                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Logo">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        </button>
                                                        <!--end::Edit-->
                                                        <!--begin::Remove-->
                                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file" data-bs-original-title="Remove Logo">
                                                        <i class="bi bi-x fs-2"></i>
                                                        </a>
                                                        <input type="hidden" id="school_logo_file_name" name="school_logo_file_name" />
                                                        <input type="hidden" id="school_mng" />
                                                        <!--end::Remove-->
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="clearfix"></div>
                                            <div class="help-block">
                                                <i class="fa fa-info-circle"></i>
                                                <strong><?php echo $label_details[85]['name']; ?>: </strong>
                                                <i><?php echo $label_details[48]['name']; ?></i>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[49]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                                <input type="text" id="last_name" name="last_name" class="form-control" aria-describedby="basic-addon1">
                                                <input type="hidden" id="add_token_id" name="add_token_id" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[50]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                                <input type="text" id="first_name" name="first_name" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="mb-5">
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <div class="input-group teacher_role_css">
                                                    <input class="form-check-input me-2" type="checkbox" id="no_email" name="no_email"><label class="form-label mt-1 fs-6 text-dark ">&nbsp;<?php echo $label_details[407]['name']; ?></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[51]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                                <input type="text" id="email" name="email" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[52]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="gender_id" name="gender_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[53]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[314]['name']; ?>" id="birth_date" name="birth_date" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[54]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[314]['name']; ?>" id="admission" name="admission" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[55]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[314]['name']; ?>" id="emission" name="emission" />
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[451]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="special_needs" name="special_needs">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[56]['name']; ?> *</label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="resigned" name="resigned">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[57]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[58]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="card-body p-0 px-9 all_parents">
                                            <div class="card-box mb-8">
                                            
                                                <!--begin::Add customer-->
                                                <button type="button" class="btn btn-sm btn-primary" id="add-new-parent"><?php echo $label_details[59]['name']; ?> <i class="fa fa-plus fs-7"></i></button>
                                                <!--begin::Toolbar-->
                                                <div class="card-toolbar">
                                                    <a href="<?php  echo $base_url;?>parents" target="_blank" class="btn btn-sm btn-warning link-dark"><?php echo $label_details[60]['name']; ?> <i class="fa fa-plus fs-7"></i></a>
                                                </div>
                                                <!--end::Toolbar-->
                                                <!--end::Add customer-->
                                            </div>
                                            <div id="newRow"></div>
                                            <!--end::Item-->
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_3" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[61]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[62]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="country_id" name="country_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[63]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-pin fs-3 "></i></span>
                                                <input type="text" id="city" name="city" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[64]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                                <input type="text" id="address" name="address" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[65]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="zip" name="zip" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[66]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                                <input type="text" id="address2" name="address2" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[67]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-mobile fs-3 "></i></span>
                                                <input type="text" id="mobile_phone" name="mobile_phone" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[68]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-phone fs-3 "></i></span>
                                                <input type="text" id="fixed_phone" name="fixed_phone" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_4" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[69]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[70]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="profession_id" name="profession_id[]" multiple="multiple">
                                                    </select>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[71]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="career_goals_id" name="career_goals_id[]" multiple="multiple">
                                                    </select>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[72]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="remarks" name="remarks" rows="5"></textarea>
                                            </div>
                                        </div>  
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[73]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="detailed_career_goals" name="detailed_career_goals" rows="5"></textarea>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[74]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="personal_weaknesses" name="personal_weaknesses" rows="5"></textarea>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[75]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="personal_strengths" name="personal_strengths" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                            
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_5" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[76]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[77]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="has_smoking_permission" name="has_smoking_permission">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[78]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="has_outgoing_permission" name="has_outgoing_permission">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[79]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="other_permissions" name="other_permissions" rows="5"></textarea>
                                            </div>
                                        </div> 
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_6" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[80]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div id="document_msg">
                                            <div class="input-group mb-5 mb-5">
                                                <div class="help-block">
                                                    <i class="fa fa-info-circle"></i>&nbsp;
                                                        <strong><?php echo $label_details[81]['name']; ?>:</strong>
                                                    <i class=""><?php echo $label_details[82]['name']; ?></i>
                                                </div>
                                            </div> 
                                        </div>
                                        <div id="document_block">
                                            <div class="input-group mb-5 mb-5">
                                                <div class="input-group">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[83]['name']; ?> *</label>
                                                    <button type="button" id="document_manager_btn_id" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><?php echo $label_details[84]['name']; ?><i class="las la-upload fs-3"></i></button>
                                                </div>
                                                <div class="help-block">
                                                    <i class="fa fa-info-circle"></i>&nbsp;
                                                        <strong><?php echo $label_details[85]['name']; ?>:</strong>
                                                    <i class=""><?php echo $label_details[86]['name']; ?></i>
                                                </div>
                                            </div> 
                                        </div>
                                        <div id="display_document_block">
                                            <div class="card mb-5 mb-xl-8 border">
                                                <div class="divrel">
                                                    <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                                        <div class="ribbon-label">
                                                            <?php echo $label_details[87]['name']; ?>
                                                            <span class="ribbon-inner bg-info"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--begin::Card body-->
                                                <div class="card-body py-4">
                                                    <div id="document_list"></div>
                                                </div>
                                                <!--end::Card body-->
                                            </div> 
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                      
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_7" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[88]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[89]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="new_assignment" name="new_assignment">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[285]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="term_id" name="term_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[90]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="grade_id" name="grade_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[91]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="teacher_id" name="teacher_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[92]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="study_level_id" name="study_level_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                             
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_students_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[35]['name']; ?></button>
                            <button type="button" id="add_students_new_sub_bott" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[36]['name']; ?></button>
                            <button type="button" id="add_students_new_con_sub_bott" class="btn btn-sm btn-warning my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[37]['name']; ?></button>
                            <button type="button" id="add_students_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[38]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="students_edit_id" style="display:none;">
                <form name="edit_students_form" id="edit_students_form" class="edit_students_form">
                    <a name="students_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[93]['name']; ?> <?php echo $label_details[422]['name']; ?></h3>
                                <button type="button" id="label_45_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_students_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[94]['name']; ?></button>
                            <button type="button" id="edit_students_update_sub"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                            <i class="las la-edit fs-4"></i><?php echo $label_details[95]['name']; ?></button>
                            <button type="button" id="edit_students_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[96]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>
                            &nbsp;<span></span>
                        </div>
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[97]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_2_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                        <path id="parents" d="M14.654,12.652c-.167,0-.323,0-.474-.009H14.1a3.315,3.315,0,0,0-1.642.481,5.052,5.052,0,0,0-1.992,2.118A12.964,12.964,0,0,0,9.242,22.31a1.365,1.365,0,0,0,1.022,1.179,1.539,1.539,0,0,0,.545.1,1.711,1.711,0,0,0,.96-.314,1.365,1.365,0,0,0,.593-1.245,13.344,13.344,0,0,1,.327-3.4V23.97c-.98.01-1.961.021-2.942.024q-3.207.007-6.413,0a1.5,1.5,0,0,1-.657-.067c.569-3.56,1.139-7.116,1.726-10.79a1.376,1.376,0,0,0-.6.719,11.878,11.878,0,0,0-1.194,4.975c-.016.678-.017,1.357-.057,2.034A1.187,1.187,0,0,1,1.3,21.952,1.182,1.182,0,0,1,.014,20.9,19.707,19.707,0,0,1,.74,13.965a8.074,8.074,0,0,1,2.417-3.786A4.126,4.126,0,0,1,6,9.177c2.193.043,4.389.011,6.584,0A3.708,3.708,0,0,0,13.823,12.1a3.79,3.79,0,0,0,.83.548m9.337,9.236a8.157,8.157,0,0,1-.06-1.137,10.932,10.932,0,0,0-.257-2.86,6.9,6.9,0,0,0-2.241-4.051,2.834,2.834,0,0,0-2.018-.7c-.731.038-1.464.012-2.2.01h-.112l-.391,0c-.231,0-.463,0-.694,0s-.445,0-.667,0-.443,0-.664,0c-.177,0-.353-.005-.53-.01a2.635,2.635,0,0,0-1.392.4,4.5,4.5,0,0,0-1.78,1.91A12.747,12.747,0,0,0,9.82,22.293c.014.36.3.6.676.741a.97.97,0,0,0,.917-.15.911.911,0,0,0,.37-.847,11.454,11.454,0,0,1,.919-5.151.982.982,0,0,1,.564-.667v7.746h7.284V16.3a1.778,1.778,0,0,1,.624.848,11.22,11.22,0,0,1,.785,4.831.976.976,0,0,0,1,1.1,1.006,1.006,0,0,0,1.026-1.2M8.862,0a4.184,4.184,0,1,0,4.184,4.184A4.184,4.184,0,0,0,8.862,0M16.9,6.187a3.234,3.234,0,1,0,3.234,3.234A3.234,3.234,0,0,0,16.9,6.187" transform="translate(0)"/>
                                    </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[98]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_3_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="contact_data" data-name="contact data" d="M18.87,12.233a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m4.439,4.259a.584.584,0,0,0,.684-.645c.01-.721.011-1.442,0-2.163a.554.554,0,0,0-.654-.609c-.339.013-.678,0-1.026,0V11.246c.385,0,.728-.006,1.071,0a.538.538,0,0,0,.608-.6c.013-.738.015-1.477,0-2.215a.553.553,0,0,0-.621-.6c-.354,0-.709,0-1.071,0V6.049c.367,0,.706,0,1.046,0a.579.579,0,0,0,.65-.63c.007-.721.006-1.442,0-2.163a.582.582,0,0,0-.638-.645c-.341-.008-.682,0-1.087,0,0-.573,0,.473,0-.024A2.548,2.548,0,0,0,19.7,0Q11.122,0,2.544,0A2.5,2.5,0,0,0,.007,2.5C0,9.965,0,14.028.007,21.5A2.5,2.5,0,0,0,2.537,24q8.577,0,17.155,0a2.549,2.549,0,0,0,2.575-2.575c0-.51,0,.439,0-.111.383,0,.706,0,1.028,0a.613.613,0,0,0,.7-.692q0-1.03,0-2.061a.608.608,0,0,0-.7-.69c-.335,0-.669,0-1,0v-1.38c.358,0,.682-.009,1.006,0m-10.542-.926c-.01.3,0,1.42,0,1.637H4.305a5.587,5.587,0,0,1,3.266-5.127.439.439,0,0,1,.423.079,3.624,3.624,0,0,0,3.862,0,.441.441,0,0,1,.425-.074,3.318,3.318,0,0,1,.487.217.962.962,0,0,0,0,.154,9.535,9.535,0,0,1,0,1.01c-.022.4.012,1.763,0,2.1M9.934,12.136a3.111,3.111,0,1,1,3.112-3.124,3.122,3.122,0,0,1-3.112,3.124m3.115.526a.838.838,0,0,1,.423-.783,3.464,3.464,0,0,1,1.324-.5,7.049,7.049,0,0,1,3.358.142,2.421,2.421,0,0,1,.9.456.736.736,0,0,1,.292.62c-.008.179,0,.359,0,.539,0,.155-.011.31,0,.464a.815.815,0,0,1-.41.776,3.3,3.3,0,0,1-1.249.489,7.2,7.2,0,0,1-3.241-.065,3.06,3.06,0,0,1-.962-.409.859.859,0,0,1-.434-.8,8.428,8.428,0,0,0,0-.927m0,1.918.04,0a1.112,1.112,0,0,0,.54.534,4.2,4.2,0,0,0,1.51.459,7.161,7.161,0,0,0,2.809-.142,2.892,2.892,0,0,0,1.041-.469,1.064,1.064,0,0,0,.342-.421c0,.389.015.779,0,1.168a.761.761,0,0,1-.4.56,3.321,3.321,0,0,1-1.249.487,7.2,7.2,0,0,1-3.166-.049,2.856,2.856,0,0,1-1.152-.521.778.778,0,0,1-.309-.663c.01-.313,0-.626,0-.94m5.85,3.59a3.71,3.71,0,0,1-1.34.493,5.57,5.57,0,0,1-.794.1c-.018,0-.032,0-.036.024h-1.1a2.517,2.517,0,0,0-.5-.074,4.554,4.554,0,0,1-1.487-.452,1.8,1.8,0,0,1-.318-.221.748.748,0,0,1-.277-.6c.006-.336,0-.672,0-1.027a1.95,1.95,0,0,0,1.415.907,6.908,6.908,0,0,0,3.685-.062,2.488,2.488,0,0,0,.858-.423.915.915,0,0,0,.312-.419c.031.03.019.064.019.093,0,.285-.015.569,0,.852a.848.848,0,0,1-.441.81m-5.382-5.4a1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529m5.348-.537a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547" transform="translate(0 0)" fill="#010101"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[99]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_4_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="remarks" d="M7.065,24V18.258a1.894,1.894,0,0,0-.547-.028,17.2,17.2,0,0,1-2.474-.08A4.956,4.956,0,0,1,.059,13.706c-.11-1.411-.028-2.828-.04-4.242C0,7.841-.016,6.217.022,4.6a3.923,3.923,0,0,1,.39-1.52A4.724,4.724,0,0,1,4.839.024C7.6-.019,10.366.011,13.129.009c1.974,0,3.948-.008,5.922,0a4.916,4.916,0,0,1,4.842,4.009,5.607,5.607,0,0,1,.1,1.189c0,2.611-.024,5.222.01,7.833a5.035,5.035,0,0,1-4.232,5.144,5.913,5.913,0,0,1-.824.044q-2.631,0-5.261-.005a.627.627,0,0,0-.464.184q-2.989,2.76-5.986,5.51c-.038.035-.067.093-.168.08M12.1,7.3a1.8,1.8,0,1,0,1.719,1.814A1.775,1.775,0,0,0,12.1,7.3m-6.032,0a1.8,1.8,0,0,0-.008,3.6,1.8,1.8,0,0,0,.008-3.6m12.013,0a1.766,1.766,0,0,0-1.751,1.8,1.751,1.751,0,1,0,1.751-1.8" transform="translate(0 0)" fill="#020201"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[100]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_5_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="permission" d="M11.361,24h-.669c-.013-.029-.041-.025-.066-.025H9.7c-.025,0-.053,0-.065.025H9.2c-.007-.027-.03-.024-.051-.024-.626-.019-1.251-.056-1.875-.1-.782-.054-1.564-.119-2.343-.206-.868-.1-1.735-.2-2.6-.335a13.691,13.691,0,0,1-1.622-.313.637.637,0,0,1-.472-.437,4.7,4.7,0,0,1-.226-1.212,9.541,9.541,0,0,1,.157-2.218,2.034,2.034,0,0,1,.9-1.415,4.937,4.937,0,0,1,.937-.5,15.424,15.424,0,0,1,1.914-.587,5.7,5.7,0,0,0,2.192-1.026,1.824,1.824,0,0,0,.736-1.086,3.854,3.854,0,0,0,0-1.086,1.277,1.277,0,0,0-.485-.889c-.181-.15-.35-.314-.533-.461a2.119,2.119,0,0,1-.542-.674,6.693,6.693,0,0,1-.453-1.178.167.167,0,0,0-.12-.125A1.088,1.088,0,0,1,4.3,9.849a2.082,2.082,0,0,1-.49-.943,1.748,1.748,0,0,1,.309-1.6.4.4,0,0,0,.093-.254,12.445,12.445,0,0,1,.355-2.995A5.278,5.278,0,0,1,5.967,1.529,5.139,5.139,0,0,1,9.038.062a6.763,6.763,0,0,1,3.281.351,4.988,4.988,0,0,1,2.738,2.233,7.989,7.989,0,0,1,.831,2.718,12.744,12.744,0,0,1,.12,1.795.12.12,0,0,0,.046.106,1.069,1.069,0,0,1,.331.5,2.127,2.127,0,0,1,0,1.267,1.465,1.465,0,0,1-.939,1.113c-.056.021-.06.065-.073.105-.07.209-.128.423-.208.629a2.8,2.8,0,0,1-.78,1.23,1.357,1.357,0,0,0-.418.622A5.618,5.618,0,0,1,13.3,14a7.193,7.193,0,0,0-1.035,2.248,6.938,6.938,0,0,0,.037,3.226,5.108,5.108,0,0,0,1.555,2.633,7.613,7.613,0,0,0,2.082,1.368c.037.017.091.018.105.071a18.006,18.006,0,0,1-1.949.275c-.883.088-1.769.134-2.657.153-.026,0-.062-.016-.077.023M24,17.6a5.539,5.539,0,0,1-5.357,5.538l-.091,0h-.209l-.117,0-.117-.006h0A5.541,5.541,0,1,1,24,17.6m-2.622-1.332a.211.211,0,0,0,0-.353c-.125-.13-.254-.255-.382-.383-.161-.162-.244-.162-.408,0l-3.042,3.046a.928.928,0,0,0-.088-.123q-.585-.589-1.173-1.175a.223.223,0,0,0-.366,0c-.134.132-.268.266-.4.4a.218.218,0,0,0,0,.348q.936.94,1.874,1.876a.212.212,0,0,0,.353,0l3.63-3.633" transform="translate(0 0)"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[101]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_6_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="documents" d="M1.822,0H14.566c.675,0,.86.172.86.849,0,1.361-.01,2.637-.01,4,0,1.179,1,1.794,2.417,1.763,1.351.012,3.346,0,4.7,0,1.123,0,1.47.337,1.47,1.433,0,4.6,0,8.8,0,13.4a2.267,2.267,0,0,1-2.576,2.531c-5.7,0-13.065-.028-18.765.018A2.452,2.452,0,0,1,0,21.392c.049-7.1.021-12.5.021-19.605A1.808,1.808,0,0,1,1.822,0M12.012,18.325c-1.807,0-3.615,0-5.422,0a1.156,1.156,0,0,0-1.3,1.084c-.023.665.5,1.135,1.3,1.158.278.008.556,0,.834,0h9.652c.179,0,.359.01.536-.007a1.149,1.149,0,0,0,1.124-1.149,1.121,1.121,0,0,0-1.18-1.084c-1.847-.015-3.694,0-5.541-.006m0-2.216h5.354c.85,0,1.381-.438,1.37-1.124-.011-.666-.538-1.107-1.341-1.108q-5.383,0-10.767,0c-.8,0-1.33.443-1.34,1.109-.01.686.52,1.122,1.37,1.123h5.354m0-6.658c-1.788,0-3.575,0-5.363,0a1.248,1.248,0,0,0-1.076.384,1.049,1.049,0,0,0-.184,1.159,1.23,1.23,0,0,0,1.26.706q5.363,0,10.726,0c.837,0,1.377-.48,1.358-1.163s-.517-1.077-1.358-1.08c-1.788,0-3.575,0-5.363,0M17.46.041a1.125,1.125,0,0,0-.836,1.166c0,1.1-.028,1.38.009,2.482A2.187,2.187,0,0,0,18.9,5.855c1.03.007,2.061-.014,3.091.007a1.121,1.121,0,0,0,.858-2.011c-1.338-1.315-2.369-1.679-3.7-3a3.5,3.5,0,0,0-1.1-.806,1.192,1.192,0,0,0-.6,0" transform="translate(0)" fill="#010101"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[102]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_7_up">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="assignment" d="M8.225,2.389A3.924,3.924,0,0,1,12.05,0,3.907,3.907,0,0,1,15.77,2.389c.087,0,3.705,0,5.413,0A2.544,2.544,0,0,1,24,4.931q0,8.257,0,16.515A2.547,2.547,0,0,1,21.166,24H2.825A2.546,2.546,0,0,1,0,21.467Q0,13.2,0,4.924A2.544,2.544,0,0,1,2.823,2.39q2.7,0,5.4,0M5.343,9.579h13.3V7.2H5.343Zm0,4.8h13.31V12.019H5.342Zm0,4.811h9.314V16.81H5.342ZM10.673,3.6a1.333,1.333,0,0,0,2.653-.006,1.265,1.265,0,0,0-1.346-1.2A1.259,1.259,0,0,0,10.673,3.6" transform="translate(0.001 0)"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[103]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[104]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5">
                                            <div class="input-group">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[106]['name']; ?></label>
                                            </div>
                                            <div id="logo_image_block_up">
                                                <div class="rounded border p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="logo_image_up" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                        <!--begin::Edit-->
                                                        <button type="button" data-kt-image-input-action="change" id="file_manager_btn_id_edit_up" class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-target="#file_manager" data-toggle="modal" data-bs-original-title="Change Profile Pic">
                                                        <i class="bi bi-pencil-fill fs-7"></i>
                                                        </button>
                                                        <!--end::Edit-->
                                                        <!--begin::Remove-->
                                                        <a class="btn btn-icon btn-circle btn-active-color-primary w-25px h-25px bg-white shadow" data-kt-image-input-action="remove" id="remove_school_logo_file_up" data-bs-original-title="Remove Profile Pic">
                                                        <i class="bi bi-x fs-2"></i>
                                                        </a>
                                                        <input type="hidden" id="school_logo_file_name_up" name="school_logo_file_name" />
                                                        <input type="hidden" id="folder_type" value="1" />
                                                        <!--end::Remove-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[107]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                                <input type="text" id="last_name_up" name="last_name" class="form-control" aria-describedby="basic-addon1">
                                                <input type="hidden" id="token_id" name="token_id" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[108]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-user fs-3 "></i></span>
                                                <input type="text" id="first_name_up" name="first_name" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="mb-5">
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <div class="input-group teacher_role_css">
                                                    <input class="form-check-input me-2" type="checkbox" id="no_email_up" name="no_email"><label class="form-label mt-1 fs-6 text-dark ">&nbsp;<?php echo $label_details[423]['name']; ?></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[109]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-envelope fs-3 "></i></span>
                                                <input type="text" id="email_up" name="email" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[110]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="gender_id_up" name="gender_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[111]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[354]['name']; ?>" id="birth_date_up" name="birth_date" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[112]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[354]['name']; ?>" id="admission_up" name="admission" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[113]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[354]['name']; ?>" id="emission_up" name="emission" />
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[452]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="special_needs_up" name="special_needs">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[114]['name']; ?> *</label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="resigned_up" name="resigned">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[115]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="status_up" name="status" checked="checked">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[116]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="card-body p-0 px-9 all_parents">
                                            <div class="card-box mb-8">
                                                <!--begin::Add customer-->
                                                <a type="button" class="btn btn-primary mb-3" id="add-new-parent_up"><?php echo $label_details[117]['name']; ?> <i class="fa fa-plus"></i></a>
                                                <!--begin::Toolbar-->
                                                <div class="card-toolbar">
                                                    <a href="<?php  echo $base_url;?>parents" target="_blank" class="btn btn-sm btn-warning link-dark"><?php echo $label_details[118]['name']; ?> <i class="fa fa-plus"></i></a>
                                                </div>
                                                <!--end::Toolbar-->
                                                <!--end::Add customer-->
                                            </div>
                                            <div id="newRow_up"></div>
                                            <!--end::Item-->
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_3_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[119]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[120]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="country_id_up" name="country_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[121]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-pin fs-3 "></i></span>
                                                <input type="text" id="city_up" name="city" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[122]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                                <input type="text" id="address_up" name="address" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[123]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="zip_up" name="zip" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[124]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-map-signs fs-3 "></i></span>
                                                <input type="text" id="address2_up" name="address2" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[125]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-mobile fs-3 "></i></span>
                                                <input type="text" id="mobile_phone_up" name="mobile_phone" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[126]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-phone fs-3 "></i></span>
                                                <input type="text" id="fixed_phone_up" name="fixed_phone" class="form-control" aria-describedby="basic-addon1">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_4_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[127]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[128]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="profession_id_up" name="profession_id[]" multiple="multiple">
                                                    </select>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[129]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-map-pin fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="career_goals_id_up" name="career_goals_id[]" multiple="multiple">
                                                    </select>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[130]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="remarks_up" name="remarks" rows="5"></textarea>
                                            </div>
                                        </div>  
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[131]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="detailed_career_goals_up" name="detailed_career_goals" rows="5"></textarea>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[132]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="personal_weaknesses_up" name="personal_weaknesses" rows="5"></textarea>
                                            </div>
                                        </div> 
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[133]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="personal_strengths_up" name="personal_strengths" rows="5"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                            
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_5_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[134]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[135]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="has_smoking_permission_up" name="has_smoking_permission">
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[136]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="has_outgoing_permission_up" name="has_outgoing_permission">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[137]['name']; ?></label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <textarea class="form-control" id="other_permissions_up" name="other_permissions" rows="5"></textarea>
                                            </div>
                                        </div> 
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_6_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[138]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div id="document_block_up">
                                            <div class="input-group mb-5 mb-5">
                                                <div class="input-group">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[139]['name']; ?> *</label>
                                                    <button type="button" id="document_manager_btn_id_up" class="btn btn-sm btn-primary my-1 me-3 px-2" data-target="#file_manager" data-toggle="modal"><?php echo $label_details[140]['name']; ?><i class="las la-upload fs-3"></i></button>
                                                </div>
                                                <div class="help-block">
                                                    <i class="fa fa-info-circle"></i>&nbsp;
                                                        <strong><?php echo $label_details[141]['name']; ?>:</strong>
                                                    <i class=""><?php echo $label_details[142]['name']; ?></i>
                                                </div>
                                                <input type="hidden" id="doc_folder_type" value="2" />
                                            </div> 
                                        </div>
                                        <div id="display_document_block_up">
                                            <div class="card mb-5 mb-xl-8 border">
                                                <div class="divrel">
                                                    <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                                        <div class="ribbon-label">
                                                            <?php echo $label_details[143]['name']; ?>
                                                            <span class="ribbon-inner bg-info"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--begin::Card body-->
                                                <div class="card-body py-4">
                                                    <div id="document_list_up"></div>
                                                </div>
                                                <!--end::Card body-->
                                            </div> 
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                      
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_7_up" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[144]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="assign_table">
                                            <!--begin::Table head-->
                                            <thead >
                                                <tr>
                                                    <th class="fw-bolder"> <?php echo $label_details[145]['name']; ?> </th>
                                                    <th class="fw-bolder"> <?php echo $label_details[146]['name']; ?> </th>
                                                    <th class="fw-bolder"> <?php echo $label_details[147]['name']; ?> </th>
                                                    <th class="fw-bolder"> <?php echo $label_details[148]['name']; ?> </th>
                                                </tr>
                                            </thead>
                                            <!--end::Table head-->
                                            <!--begin::Table body-->
                                            <tbody class=" text-gray-800 assign_actionBtns_table">
                                            </tbody>
                                            <!--end::Table body-->
                                        </table>
                                    </div>
                                    <!--end::Card body-->
                                </div>  
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[149]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[150]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="new_assignment_up" name="new_assignment">
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[151]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="term_id_up" name="term_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[152]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="grade_id_up" name="grade_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[153]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="teacher_id_up" name="teacher_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[154]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="study_level_id_up" name="study_level_id" disabled="disabled">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                             
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_students_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[94]['name']; ?></button>
                            <button type="button" id="edit_students_update_sub_bott"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                            <i class="las la-edit fs-4"></i><?php echo $label_details[95]['name']; ?></button>
                            <button type="button" id="edit_students_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[96]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Preview Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="students_preview_id" style="display:none;">
                <form name="add_students_form" id="add_students_form" class="add_students_form">
                    <a name="students_preview_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-8  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[155]['name']; ?>
                            </h3>
                            <button type="button" id="label_45_16" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="preview_students_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[156]['name']; ?></button>
                        </div>
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[157]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_2_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[158]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_3_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[159]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_4_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[160]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_5_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[161]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_6_pr">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[162]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[163]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5">
                                            <div id="logo_image_block_pv" class="flex-nowrap">
                                                <div class="rounded border p-0">
                                                    <div class="image-input image-input-outline" data-kt-image-input="true" >
                                                        <!--begin::Preview existing avatar-->
                                                        <div id="pv_profile_pic" class="image-input-wrapper w-125px h-125px"></div>
                                                        <!--end::Preview existing avatar-->
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_info">
                                            <tbody>
                                                <tr>
                                                    <th class="fw-bolder" width="20%"><?php echo $label_details[164]['name']; ?></th>
                                                    <td><div id="pv_name"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[165]['name']; ?></th>
                                                    <td><div id="pv_email"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[166]['name']; ?></th>
                                                    <td><div id="pv_gender"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[167]['name']; ?></th>
                                                    <td><div id="pv_birth_date"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[168]['name']; ?></th>
                                                    <td><div id="pv_admission"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[169]['name']; ?></th>
                                                    <td><div id="pv_emission"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[170]['name']; ?></th>
                                                    <td> <div id="pv_resigned"></div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[453]['name']; ?></th>
                                                    <td> <div id="pv_special_needs"></div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[171]['name']; ?></th>
                                                    <td> <div id="pv_status"></div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[172]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="pv_parents">
                                            <thead>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[173]['name']; ?></th>
                                                    <th class="fw-bolder"><?php echo $label_details[174]['name']; ?></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_3_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[175]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_location">
                                            <tbody>
                                                <tr>
                                                    <th class="fw-bolder" width="20%"><?php echo $label_details[176]['name']; ?></th>
                                                    <td><div id="pv_country"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[177]['name']; ?></th>
                                                    <td><div id="pv_city"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[178]['name']; ?></th>
                                                    <td><div id="pv_address"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[424]['name']; ?></th>
                                                    <td><div id="pv_zip"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[179]['name']; ?></th>
                                                    <td><div id="pv_address2"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[180]['name']; ?></th>
                                                    <td><div id="pv_mobile_phone"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[181]['name']; ?></th>
                                                    <td><div id="pv_fixed_phone"></div></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_4_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[182]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_goals">
                                            <tbody>
                                                <tr>
                                                    <th class="fw-bolder" width="20%"><?php echo $label_details[183]['name']; ?></th>
                                                    <td><div id="pv_profession"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[184]['name']; ?></th>
                                                    <td><div id="pv_carrer_goals"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[185]['name']; ?></th>
                                                    <td><div id="pv_remarks"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[186]['name']; ?></th>
                                                    <td><div id="pv_detailed_career_goals"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[187]['name']; ?></th>
                                                    <td><div id="pv_personal_weaknesses"></div></td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[188]['name']; ?></th>
                                                    <td><div id="pv_personal_strengths"></div></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <!--end::Card body-->
                                </div>                            
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_5_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[189]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_permissions">
                                            <tbody>
                                                <tr>
                                                    <th class="fw-bolder" width="20%"><?php echo $label_details[190]['name']; ?></th>
                                                    <td> <div id="pv_has_permission_to_smoke"></div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[191]['name']; ?></th>
                                                    <td> <div id="pv_has_permission_to_leave"></div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="fw-bolder"><?php echo $label_details[192]['name']; ?></th>
                                                    <td><div id="pv_other_permissions"></div></td>
                                                </tr>
                                            </tbody>
                                        </table> 
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_6_pr" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[193]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div id="display_document_block_pr">
                                            <div class="card mb-5 mb-xl-8 border">
                                                <!--begin::Card body-->
                                                <div class="card-body py-4">
                                                    <div id="document_list_pr"></div>
                                                </div>
                                                <!--end::Card body-->
                                            </div> 
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                      
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="preview_students_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[194]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_students" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[195]['name']; ?> <?php echo $label_details[425]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_45_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_students_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[196]['name']; ?> <?php echo $label_details[425]['name']; ?>, <?php echo $label_details[197]['name']; ?></label>
                                        <label class="fs-6"><?php echo $label_details[198]['name']; ?> <?php echo $label_details[425]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_students_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[199]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[200]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

            <!--begin::Modal - Restore Module-->
            <div class="modal fade" id="restore_students" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[201]['name']; ?> <?php echo $label_details[426]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_45_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_students_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[204]['name']; ?> <?php echo $label_details[426]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_students_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[205]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[206]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->

             <!--begin::Modal - Reset Password Module-->
             <div class="modal fade" id="reset_password" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[409]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                        <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                    </svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="reset_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
                            <div class="alert alert-success errYxt" id="reset_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i><span></span></div>
                            <!--begin::Form-->
                            <div class="reset_password_form">
                                <label class="fs-6"><?php echo $label_details[410]['name']; ?> *</label>
                                <input type="password" name="new_password" id="new_password" class="form-control mt-2 me-3 mb-4" autofocus>
                                <input type="hidden" name="token_id" id="token_id" />
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="reset_password_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[411]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_res_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[412]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - rename Module-->

            <!--begin::Modal - Status Module-->
            <div class="modal fade" id="status_students" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[427]['name']; ?> <?php echo $label_details[207]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_45_6" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="sta_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="sta_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="status_students_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[208]['name']; ?> <?php echo $label_details[427]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="status_students_sub" class="btn btn-primary"><i class="las la-toggle-on fs-5"></i> <?php echo $label_details[209]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_status_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[210]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Status Module-->

            <!--begin::Modal - Resigned Module-->
            <div class="modal fade" id="resigned_students" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[428]['name']; ?> <?php echo $label_details[211]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_45_14" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="resi_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="resi_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="resigned_students_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[212]['name']; ?> <?php echo $label_details[428]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="resigned_students_sub" class="btn btn-primary"><i class="las la-toggle-on fs-5"></i> <?php echo $label_details[213]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_resigned_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[214]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - resigned Module-->

            <!--begin::Modal - Parent Info Module-->
            <div class="modal fade" id="parents_info" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[215]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 cct-scrool">
                                <!--begin::Table head-->
                                <tbody>
                                    <tr>
                                        <th class="left" width="20%"><?php echo $label_details[216]['name']; ?></th>
                                        <td><div id="pra_name"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[217]['name']; ?></th>
                                        <td><div id="pra_last_name"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[218]['name']; ?></th>
                                        <td><div id="pra_mobile_phone"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[219]['name']; ?></th>
                                        <td><div id="pra_email"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[220]['name']; ?></th>
                                        <td><div id="pra_address"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[221]['name']; ?></th>
                                        <td><div id="pra_city"></div></td>
                                    </tr>
                                    <tr>
                                        <th class="left"><?php echo $label_details[222]['name']; ?></th>
                                        <td><div id="pra_zip"></div></td>
                                    </tr>
                                </tbody>
                                <!--end::Table body-->
                            </table>
                            <!--begin::Actions-->
                            <div class="text-center">
                                <button type="button" class="btn btn-danger me-3" id="close_com_resigned_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[223]['name']; ?></button>
                            </div>
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - resigned Module-->

            <!--begin::Modal - Import Module-->
            <div class="modal fade" id="import_students" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[224]['name']; ?> <?php echo $label_details[429]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_45_7" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <form name="import_students_form" id="import_students_form" action="#" class="import_students_form">

                                <!--begin::Input group-->
                                <div class="form-group pst_relt">
                                    <div class="add_students_frm imp_file_cls">
                                        <div class="custom-file mb-4">
                                        <span class="uploadFile"><?php echo $label_details[277]['name']; ?></span>
                                            <input type="file" name="import_students_file" id="import_students_file" class="custom-file-input" accept=".xls" title="<?php echo $label_details[363]['name']; ?>">
                                            <label class="custom-file-label" for="customFile" id="import_label"><?php echo $label_details[225]['name']; ?></label>
                                            <input class="gui-input" id="import_uploader" style="display:none" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pst_relt mb-4">
                                    <div class="add_students_frm">
                                        <button type="button" class="btn stu_import" id="import_download_sample" ><i class="fa fa-download"></i> <span><?php echo $label_details[226]['name']; ?> <?php echo $label_details[429]['name']; ?></span></button>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="import_students_sub" class="btn btn-primary"><i class="las la-external-link-alt fs-5"></i><?php echo $label_details[227]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_import_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[228]['name']; ?></button>
                                    
                                </div>
                                <!--end::Actions-->
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Import Module-->

            <?php echo $file_manager; ?>

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<!--begin::Page Vendors Javascript(used by this page)-->
<script src="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.js"></script>
<!--end::Page Vendors Javascript-->
<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/general/jstree/basic.js"></script>
		<!--end::Page Custom Javascript-->
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>students.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,student_term_table,selected=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",grade_fld="",teacher_fld="",study_level_fld="",resigned_fld="",country_details=[],parent_details=[],profession_details=[],career_goal_details=[],term_details=[],grade_details=[],user_details=[],study_level_details=[],gender_details=[],parent_count=0,parent_count_up=0,flag=false,student_id="",tree_details=[],folder_id=1,inner_folder_id=1,attachmentCount = 0,uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],selected_folder_id="",file_details=[],document_files=[],selected_folder=[],change_tree=true,folder_table,folder_tree=false,label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,preview_role=false,file_manager_label_details=<?php echo json_encode($file_manager_label_details); ?>,move_id=1,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() { 

    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("290", role_details) !== -1)
    {
        edit_role=true;
    } 
    if ($.inArray("291", role_details) !== -1)
    {
        preview_role=true;
    } 
    $("#birth_date").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#admission").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#emission").flatpickr({
        dateFormat: "d-m-Y"
    }); 
    $("#birth_date_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#admission_up").flatpickr({
        dateFormat: "d-m-Y"
    });
    $("#emission_up").flatpickr({
        dateFormat: "d-m-Y"
    });  
    file_manager_details();
	students_details();
});
</script>  
