<?php echo $header; ?>
<?php echo $sideheader; ?>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
  <style>

.selected_student_css tr td:nth-child(6) {
    text-align: center;
}
.main_table_css tr td:nth-child(6) {
    text-align: center;
}
.main_table_css tr td:nth-child(7) {
    text-align: center;
}
.main_table_css tr td:nth-child(8) {
    text-align: center;
}
.ind_css tr td:nth-child(5) {
    text-align: center;
}
 </style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[2]['name']; ?></li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(242,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="students_courses_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[3]['name']; ?></h3>
                    <button type="button" id="label_36_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
						 <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="term_fld" name="term_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="course_fld" name="course_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[6]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="student_fld" name="student_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
							<!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[7]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="grade_fld" name="grade_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
							<!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[8]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="study_level_fld" name="study_level_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[9]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="teacher_fld" name="teacher_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="students_courses_filter" name="students_courses_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[10]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="students_courses_reset" name="students_courses_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[11]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[12]['name']; ?></h3>
                                    <button type="button" id="label_36_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(243,$role_details)) { ?>
                        <div>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7 me-3" id="add_students_courses_btn"><?php echo $label_details[22]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <button type="button" class="btn btn-info mb-3 py-3 fs-7" id="duplicate_students_courses_btn" data-toggle="modal" data-target="#duplicate_students_courses"><?php echo $label_details[234]['name']; ?> <i class="las la-copy fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        </div>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(245,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_students_courses" data-toggle="modal"><?php echo $label_details[23]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(246,$role_details)) { ?>
                            <button type="button" class="btn btn-sm btn-success my-1 px-2" data-toggle="modal" data-target="#import_students_courses" id="import_students_courses_btn"><?php echo $label_details[24]['name']; ?> <i class="las la-external-link-alt fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[171]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder"> <?php echo $label_details[172]['name']; ?> </th>
                                    <th data-priority="2" class="fw-bolder"> <?php echo $label_details[173]['name']; ?> </th>
                                    <th data-priority="6" style="text-align: center;" class="fw-bolder"> <?php echo $label_details[174]['name']; ?> </th>
                                    <th data-priority="7" style="text-align: center;" class="fw-bolder"> <?php echo $label_details[175]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[19]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table main_table_css">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="students_courses_create_id" style="display:none;">
                <form name="add_students_courses_form" id="add_students_courses_form" class="add_students_courses_form">
                    <a name="students_courses_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-2  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[209]['name']; ?> 
                            </h3>
                            <button type="button" id="label_36_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_students_courses_sub" disabled="disabled"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[82]['name']; ?></button>
                            <button type="button" id="add_students_courses_new_con_sub" disabled="disabled" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[83]['name']; ?></button>
                            <button type="button" id="add_students_courses_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[84]['name']; ?></button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_assignment_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.06 24"><path d="M8,5.6c.11-1.09,0-2.15.06-3.23C8,2,6.69,2,6.28,1.85c-.1,1.75.16.62.57,1.57-.32.91-.57-.11-.48,1.59L6.7,5v6.71H5.52V5l.32,0c.1-1.75-.17-.66-.47-1.6.47-1,.64.21.56-1.65L4.62,1.5v0C7.2,1,9.78.32,12.36,0c2.48.54,5,.91,7.47,1.53l-3.41.65v3.3c0,.08,0,.14.1.18.71.34.45,1.57-.14,1.92-.28,0-.32.27-.4.48a7.7,7.7,0,0,1-1.5,2.44,1.32,1.32,0,0,0-.21,1c-.34,1-1.66,1.12-2.56,1-2.28-.62-.94-1.1-1.81-2.15a6.54,6.54,0,0,1-1.48-2.5.32.32,0,0,0-.25-.25c-.8-.2-1.09-1.87-.13-2M6.83,16.18A1,1,0,0,0,5.7,17a.76.76,0,0,0,0,.3q.52,2.85,1.06,5.7a1,1,0,0,0,1,.84c10.88-.53,9.05,2.57,10.57-6.42a1,1,0,0,0-1.09-1.27H6.83M21,16c-.94-2.15-3.49-3.07-5.54-3.87-.22,1-.47,1.9-.73,2.83,4.13.08,5.53-.54,4.37,4.37a2.53,2.53,0,0,0,2-3A1.89,1.89,0,0,0,21,16M9.66,15c-.28-.93-.52-1.87-.74-2.83-2.83.8-8.8,4.58-4.06,7.09-1.38-5.19.9-4,4.8-4.26m2.43-2.08c-1.48.31-1.44,1.91,0,2.13,1.7-.1,1.5-1.93,0-2.13" transform="translate(-3.09 0.02)" style="fill:#1b1819"/></svg></span> 1. <?php echo $label_details[29]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_assignment_fields">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Row-->
                                        <div class="row g-8">
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[30]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="term_fld_list" name="term_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[31]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="grade_fld_list" name="grade_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[32]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="study_level_fld_list" name="study_level_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[33]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="teacher_fld_list" name="teacher_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[34]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="student_fld_list" name="student_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <div class="col-lg-4 mt-16 w-md-250px">
                                                <!--end::Input group-->
                                                <!--begin:Action-->
                                                <div class="fltl me-3">
                                                    <button type="button" id="students_courses_filter_list" name="students_courses_filter_list" class="btn btn-primary pb-3 pt-2 fs-7">
                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                        <i class="las la-filter"></i>
                                                        <!--end::Svg Icon--><?php echo $label_details[177]['name']; ?>
                                                    </button>
                                                </div>
                                                <div class="fltl">
                                                    <button type="button" id="students_courses_reset_list" name="students_courses_reset_list" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[178]['name']; ?></button>
                                                </div>
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="all_assign_student_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th></th>
                                                        <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="table_check_all_list" class="group-checkable" name="table_check_all_list" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[35]['name']; ?> </th>
                                                        <th data-priority="2" class="fw-bolder"> <?php echo $label_details[36]['name']; ?> </th>
                                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[37]['name']; ?> </th>
                                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[38]['name']; ?> </th>
                                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[39]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                        <div class="card-toolbar float-xxl-end">
                                            <button title="Add selected students for further assignments." type="button" id="add_selected" disabled="disabled" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[40]['name']; ?></button>
                                        </div>
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="selected_students_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 18.06 24"><path d="M12.09,12.91c-1.48.31-1.44,1.91,0,2.13C13.79,14.94,13.59,13.11,12.09,12.91Zm-3.17-.75c-2.83.8-8.8,4.58-4.06,7.09-1.38-5.19.9-4,4.8-4.26C9.38,14.06,9.14,13.12,8.92,12.16ZM21.1,16.4A1.89,1.89,0,0,0,21,16c-.94-2.15-3.49-3.07-5.54-3.87-.22,1-.47,1.9-.73,2.83,4.13.08,5.53-.54,4.37,4.37A2.53,2.53,0,0,0,21.1,16.4Zm-3.4-.19a1,1,0,0,0-.42,0H6.83A1,1,0,0,0,5.7,17a.76.76,0,0,0,0,.3q.52,2.85,1.06,5.7a1,1,0,0,0,1,.84c10.88-.53,9.05,2.57,10.57-6.42A1,1,0,0,0,17.7,16.21ZM12.61,22l-.37.06h-.38a.32.32,0,0,0-.14,0,2.34,2.34,0,1,1,2.59-2.9A2.32,2.32,0,0,1,12.61,22Zm.25-3-.7.69-.42.44-.56-.45a.1.1,0,0,0-.09,0,.14.14,0,0,0-.15.09A.15.15,0,0,0,11,20l.63.51a.16.16,0,0,0,.24,0l.64-.63.56-.56a.16.16,0,0,0,0-.17A.15.15,0,0,0,12.86,19.06ZM16.52,5.64c-.1,0-.1-.1-.1-.18V2.16l3.41-.65c-2.44-.62-5-1-7.47-1.53C9.78.32,7.2,1,4.62,1.46v0l1.31.26c.08,1.86-.09.67-.56,1.65.3.94.57-.15.47,1.6L5.52,5v6.71H6.7V5L6.37,5c-.09-1.7.16-.68.48-1.59-.41-.95-.67.18-.57-1.57C6.69,2,8,2,8.1,2.37c0,1.08.05,2.14-.06,3.23-1,.14-.67,1.81.13,2a.32.32,0,0,1,.25.25,6.54,6.54,0,0,0,1.48,2.5c.87,1.05-.47,1.53,1.81,2.15.9.13,2.22,0,2.56-1a1.32,1.32,0,0,1,.21-1A7.7,7.7,0,0,0,16,8c.08-.21.12-.44.4-.48C17,7.21,17.23,6,16.52,5.64Z" transform="translate(-3.09 0.02)" style="fill:#1b1819"/></svg></span> 2. <?php echo $label_details[41]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="selected_students">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="assigned_student_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th></th>
                                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[35]['name']; ?> </th>
                                                        <th data-priority="1" class="fw-bolder"> <?php echo $label_details[36]['name']; ?> </th>
                                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[37]['name']; ?> </th>
                                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[38]['name']; ?> </th>
                                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[39]['name']; ?> </th>
                                                        <th data-priority="2" class="fw-bolder" style="text-align:center"> <?php echo $label_details[67]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table selected_student_css">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                        <div class="help-block">
                                            <i class="fa fa-info-circle"></i>
                                            <strong><?php echo $label_details[42]['name']; ?>::</strong>
                                            <i><?php echo $label_details[43]['name']; ?>.</i>
                                        </div> 
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_courses_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 20.77"><path d="M22.6,11.13v8.11a2.17,2.17,0,0,1,0,.36.58.58,0,0,1-.87.52c-.44-.18-.88-.38-1.32-.55a18.91,18.91,0,0,0-7-1.35.93.93,0,0,1-1-1c0-4.05,0-8.09,0-12.14a1.6,1.6,0,0,1,1-1.55,19.2,19.2,0,0,1,6.89-1.83c.36,0,.73,0,1.1,0a1.07,1.07,0,0,1,1.2.94,3.4,3.4,0,0,1,0,.45Zm-11-6.06a1.63,1.63,0,0,0-1-1.58A19.29,19.29,0,0,0,2.5,1.61a1,1,0,0,0-1,.67,1.75,1.75,0,0,0-.1.64V19.31a1.47,1.47,0,0,0,0,.21c0,.57.4.8.93.58L2.52,20a20,20,0,0,1,5-1.54,18.74,18.74,0,0,1,3.08-.26.89.89,0,0,0,1-1V11.13Q11.58,8.1,11.59,5.07ZM15,19c.37.1.74.19,1.1.3a45.2,45.2,0,0,1,5.69,2.42l1.27.59a.61.61,0,0,0,.95-.57V5.07a1.59,1.59,0,0,0-.08-.53,1.1,1.1,0,0,0-.68-.7V19.33a2,2,0,0,1,0,.34,1.21,1.21,0,0,1-1.79,1A19.73,19.73,0,0,0,15,18.93ZM8.67,19A18.34,18.34,0,0,0,4,20.1c-.49.19-1,.41-1.46.61A1.22,1.22,0,0,1,.8,19.85a1.83,1.83,0,0,1,0-.47V4.12a.38.38,0,0,0,0-.27l-.1,0A1.16,1.16,0,0,0,0,5V21.65c0,.64.39.89,1,.64l.19-.09c1.19-.55,2.37-1.12,3.56-1.66A22.84,22.84,0,0,1,9.19,19,4.51,4.51,0,0,0,8.67,19Z" transform="translate(0 -1.61)" style="fill:#010101"/></svg></span> 3. <?php echo $label_details[44]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="collapse"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_courses_fields">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Row-->
                                        <div class="row g-8">
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[45]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="subject_fld" name="subject_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[46]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="personnel_fld" name="personnel_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[47]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select class="form-select form-select-solid border" data-control="select2" id="competence_level_fld" name="competence_level_fld">
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[48]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select id="individual_fld" name="individual_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                                    <option value="all" selected="selected"><?php echo $label_details[50]['name']; ?></option>
                                                    <option value="1"><?php echo $label_details[51]['name']; ?></option>
                                                    <option value="0"><?php echo $label_details[52]['name']; ?></option>
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <?php if(in_array(318,$role_details)) { ?>
                                            <!--begin::Col-->
                                            <div class="col-lg-3 w-md-200px">
                                                <label class="fs-7 form-label text-dark"><?php echo $label_details[49]['name']; ?></label>
                                                <!--begin::Select-->
                                                <select id="del_fld" name="del_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                                    <option value="all"><?php echo $label_details[50]['name']; ?></option>
                                                    <option value="1"><?php echo $label_details[51]['name']; ?></option>
                                                    <option value="0" selected="selected"><?php echo $label_details[52]['name']; ?></option>
                                                </select>
                                                <!--end::Select-->
                                            </div>
                                            <!--end::Col-->
                                            <?php } ?>
                                            <div class="col-lg-4 mt-16 w-md-250px">
                                                <!--end::Input group-->
                                                <!--begin:Action-->
                                                <div class="fltl me-3">
                                                    <button type="button" id="students_all_courses_filter_list" name="students_all_courses_filter_list" class="btn btn-primary pb-3 pt-2 fs-7">
                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                        <i class="las la-filter"></i>
                                                        <!--end::Svg Icon--><?php echo $label_details[177]['name']; ?>
                                                    </button>
                                                </div>
                                                <div class="fltl">
                                                    <button type="button" id="students_all_courses_reset_list" name="students_all_courses_reset_list" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[178]['name']; ?></button>
                                                </div>
                                            </div>
                                            <!--end::Col-->
                                        </div>
                                        <!--end::Row-->
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="all_course_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th></th>
                                                        <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                                <input type="checkbox" id="table_check_all_course_list" class="group-checkable" name="table_check_all_course_list" >
                                                                <span></span>
                                                            </label>
                                                        </th>
                                                        <th data-priority="2" class="fw-bolder"> <?php echo $label_details[53]['name']; ?> </th>
                                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[54]['name']; ?> </th>
                                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[55]['name']; ?> </th>
                                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[56]['name']; ?> </th>
                                                        <th data-priority="6" class="fw-bolder" style="text-align:center"> <?php echo $label_details[57]['name']; ?> </th>
                                                        <th data-priority="7" class="fw-bolder" style="text-align:center"> <?php echo $label_details[58]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table selected_student_css main_table_css">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                        <div class="card-toolbar float-xxl-end">
                                            <button title="Add selected students for further courses." type="button" id="add_selected_courses" disabled="disabled"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[40]['name']; ?></button>
                                        </div>
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->

                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_selected_courses_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                    <path id="assignment" d="M8.225,2.389A3.924,3.924,0,0,1,12.05,0,3.907,3.907,0,0,1,15.77,2.389c.087,0,3.705,0,5.413,0A2.544,2.544,0,0,1,24,4.931q0,8.257,0,16.515A2.547,2.547,0,0,1,21.166,24H2.825A2.546,2.546,0,0,1,0,21.467Q0,13.2,0,4.924A2.544,2.544,0,0,1,2.823,2.39q2.7,0,5.4,0M5.343,9.579h13.3V7.2H5.343Zm0,4.8h13.31V12.019H5.342Zm0,4.811h9.314V16.81H5.342ZM10.673,3.6a1.333,1.333,0,0,0,2.653-.006,1.265,1.265,0,0,0-1.346-1.2A1.259,1.259,0,0,0,10.673,3.6" transform="translate(0.001 0)"/>
                                    </svg></span> 4. <?php echo $label_details[59]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_selected_courses_fields">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <div class="help-block">
                                            <i class="fa fa-info-circle"></i>
                                            <strong><?php echo $label_details[60]['name']; ?>::</strong>
                                            <i><?php echo $label_details[61]['name']; ?>.</i>
                                        </div>
                                        <!--begin::Table-->
                                        <div class="mb-3">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="all_selected_course_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th></th>
                                                        <th data-priority="1" class="fw-bolder"> <?php echo $label_details[62]['name']; ?> </th>
                                                        <th data-priority="3" class="fw-bolder"> <?php echo $label_details[63]['name']; ?> </th>
                                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[64]['name']; ?> </th>
                                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[65]['name']; ?> </th>
                                                        <th data-priority="6" class="fw-bolder" style="text-align:center"> <?php echo $label_details[66]['name']; ?> </th>
                                                        <th data-priority="2" class="fw-bolder" style="text-align:center"> <?php echo $label_details[67]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table selected_student_css ind_css">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                        <div class="row">
                                            <div class="alert alert-danger errYxt" id="cor_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
                                            <div class="col-md-6">
                                                <div class="input-group mb-5 mb-5">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[69]['name']; ?> *</label>
                                                    <div class="input-group flex-nowrap">
                                                        <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                                        <div class="overflow-hidden flex-grow-1">
                                                            <select class="form-select rounded-start-0" data-control="select2" id="student_course_status_fld" name="student_course_status_fld">
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                        <div class="card-toolbar float-xxl-end">
                                            <button title="Assign selected students and course." type="button" id="assign_student_course" disabled="disabled"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[70]['name']; ?></button>
                                        </div>
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->
                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <div class="card mb-7 border">
                            <div class="card-header hd-col-2" id="student_final_container">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                    <path id="assignment" d="M8.225,2.389A3.924,3.924,0,0,1,12.05,0,3.907,3.907,0,0,1,15.77,2.389c.087,0,3.705,0,5.413,0A2.544,2.544,0,0,1,24,4.931q0,8.257,0,16.515A2.547,2.547,0,0,1,21.166,24H2.825A2.546,2.546,0,0,1,0,21.467Q0,13.2,0,4.924A2.544,2.544,0,0,1,2.823,2.39q2.7,0,5.4,0M5.343,9.579h13.3V7.2H5.343Zm0,4.8h13.31V12.019H5.342Zm0,4.811h9.314V16.81H5.342ZM10.673,3.6a1.333,1.333,0,0,0,2.653-.006,1.265,1.265,0,0,0-1.346-1.2A1.259,1.259,0,0,0,10.673,3.6" transform="translate(0.001 0)"/>
                                    </svg></span> 5. <?php echo $label_details[72]['name']; ?></h4>
                                    <div class="tools">
                                        <a href="javascript:;" class="expand"></a>
                                    </div>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--begin::Card body-->
                            <div class="card-body px-8 pb-7 pt-2" id="student_final_fields">
                                <!--begin::Compact form-->
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <div class="help-block">
                                            <i class="fa fa-info-circle"></i>
                                            <strong><?php echo $label_details[73]['name']; ?>::</strong>
                                            <i><?php echo $label_details[74]['name']; ?></i>
                                        </div>
                                        <!--begin::Table-->
                                        <div class="">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="student_course_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th></th>
                                                        <th data-priority="1" class="fw-bolder"> <?php echo $label_details[75]['name']; ?> </th>
                                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[76]['name']; ?> </th>
                                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[77]['name']; ?> </th>
                                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[78]['name']; ?> </th>
                                                        <th data-priority="7" class="fw-bolder"> <?php echo $label_details[79]['name']; ?> </th>
                                                        <th data-priority="3" class="fw-bolder" style="text-align:center"> <?php echo $label_details[80]['name']; ?> </th>
                                                        <th data-priority="2" class="fw-bolder" style="text-align:center"> <?php echo $label_details[81]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table selected_student_css main_table_css">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->
                                    <!--end:Action-->
                                </div>
                                <!--end::Compact form-->
                            </div>
                            <!--end::Card body-->
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_students_courses_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[82]['name']; ?></button>
                            <button type="button" id="add_students_courses_new_con_sub_bott" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[83]['name']; ?></button>
                            <button type="button" id="add_students_courses_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[84]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!-- Edit Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="students_courses_edit_id" style="display:none;">
                <form name="edit_students_courses_form" id="edit_students_courses_form" class="edit_students_courses_form">
                    <a name="students_courses_edit_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-10 hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <?php echo $label_details[85]['name']; ?> <?php echo $label_details[240]['name']; ?></h3>
                                <button type="button" id="label_36_4" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="edt_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="edt_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[86]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" disabled="disabled" data-control="select2" id="student_id_up" name="student_id">
                                    </select>
                                    <input type="hidden" id="token_id" name="token_id" />
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[87]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" disabled="disabled" data-control="select2" id="term_id_up" name="term_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[88]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" disabled="disabled" data-control="select2" id="grade_id_up" name="grade_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[89]['name']; ?></label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="study_level_id_up" disabled="disabled" name="study_level_id">
                                    </select>
                                </div>
                            </div>
                        </div>
						<div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[90]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="teacher_id_up" name="teacher_id" disabled="disabled">
                                    </select>
                                </div>
                            </div>
                        </div>
						<div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[91]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="course_id_up" name="course_id">
                                    </select>
                                </div>
                            </div>
                        </div>
						<div class="input-group mb-5 mb-5">
                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[92]['name']; ?> *</label>
                            <div class="input-group flex-nowrap">
                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                <div class="overflow-hidden flex-grow-1">
                                    <select class="form-select rounded-start-0" data-control="select2" id="course_status_id_up" name="course_status_id">
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="edit_students_courses_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[93]['name']; ?></button>
                            <button type="button" id="edit_students_courses_update_sub"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8">
                                <i class="las la-edit fs-4"></i><?php echo $label_details[94]['name']; ?></button>
                            <button type="button" id="edit_students_courses_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[95]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_students_courses" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[96]['name']; ?> <?php echo $label_details[208]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_36_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_students_courses_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[97]['name']; ?> <?php echo $label_details[208]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_students_courses_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[98]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[99]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

            <!--begin::Modal - Duplicate Time Table-->
            <div class="modal fade" id="duplicate_student_courses" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[241]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_37_17" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                    <div class="tool_tip">
                                        <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                                        <i class="las la-edit fs-1"></i>
                                    </div>
                                    <!--end::Svg Icon-->
                                </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="dup_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="dup_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="duplicate_student_courses_form">
                                <!--begin::Input group-->
                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[242]['name']; ?> *</label>
                                <div class="input-group flex-nowrap mb-4">
                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                    <div class="overflow-hidden flex-grow-1">
                                        <select class="form-select rounded-start-0" data-dropdown-parent="#duplicate_student_courses" data-control="select2" id="source_term_id" name="source_term_id">
                                        </select>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Input group-->
                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[243]['name']; ?> *</label>
                                <div class="input-group flex-nowrap mb-4">
                                    <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                    <div class="overflow-hidden flex-grow-1">
                                        <select class="form-select rounded-start-0" data-dropdown-parent="#duplicate_student_courses" data-control="select2" id="destination_term_id" name="destination_term_id">
                                        </select>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="duplicate_student_courses_sub" class="btn btn-primary"><i class="las la-edit fs-5"></i><?php echo $label_details[244]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_dup_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[93]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Duplicate Time Table-->

            <!--begin::Modal - Import Module-->
            <div class="modal fade" id="import_students_courses" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[104]['name']; ?> <?php echo $label_details[245]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_36_7" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="imp_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="imp_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <form name="import_students_courses_form" id="import_students_courses_form" action="#" class="import_students_courses_form">

                                <!--begin::Input group-->
                                <div class="form-group pst_relt">
                                    <div class="add_students_courses_frm imp_file_cls">
                                        <div class="custom-file mb-4">
                                        <span class="uploadFile"><?php echo $label_details[107]['name']; ?></span>
                                            <input type="file" name="import_students_courses_file" id="import_students_courses_file" class="custom-file-input" accept=".xls" title="<?php echo $label_details[218]['name']; ?>">
                                            <label class="custom-file-label" for="customFile" id="import_label"><?php echo $label_details[105]['name']; ?></label>
                                            <input class="gui-input" id="import_uploader" style="display:none" type="text">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group pst_relt mb-4">
                                    <div class="add_students_courses_frm">
                                        <button type="button" class="btn btn-link" id="import_download_sample" ><i class="fa fa-download"></i> <span><?php echo $label_details[106]['name']; ?> <?php echo $label_details[245]['name']; ?></span></button>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="import_students_courses_sub" class="btn btn-primary"><i class="las la-external-link-alt fs-5"></i><?php echo $label_details[108]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_import_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[109]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </form>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Import Module-->

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $js_path;?>students_courses.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,all_assign_table,assigned_table,all_course_table,final_table,selected=[],selected_courses=[],assigned_selected_courses=[],id="<?php  echo $user_det['id'];?>",term_fld="",course_fld="",student_fld="",grade_fld="",teacher_fld="",study_level_fld="",term_details=[],teacher_details=[],grade_details=[],course_details=[],student_details=[],study_level_details=[],flag=false,selected_students=[],assign_selected_students=[],term_fld_list="",assigned_fld_list="",grade_fld_list="",teacher_fld_list="",study_level_fld_list="",status_fld_list="",student_fld_list="",selected_students_list="",selected_courses_list="",term_id="",grade_id="",teacher_id="",study_level_id="",term="",grade="",teacher="",study_level="",subject_fld="",personnel_fld="",competence_level_fld="",individual_fld="",del_fld="",course_status_details=[],selected_student_courses_list="",student_course_status_fld="",final_selected_courses=[],subject_details=[],competence_level_details=[],label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];
$(document).ready(function() { 
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("244", role_details) != -1)
    {
        edit_role=true;
    }
    students_courses_details();
});
</script>  
