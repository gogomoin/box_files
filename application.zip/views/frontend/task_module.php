<div class="card mb-5 mb-lg-10 border pb-4" id="task_manage_id" style="display: none;">
    <div class="card-header hd-col-2" id="tasks_container">
        <!--begin::Heading-->
        <div class="card-title">
            <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="18.762" height="23.999" viewBox="0 0 18.762 23.999">
            <path id="Tasks" d="M.476,24A1.091,1.091,0,0,1,0,22.971Q.015,13.137.008,3.3c0-.823.228-1.049,1.056-1.05H2.258v.541q0,8.759,0,17.517c0,1.059.379,1.442,1.43,1.442H16.535c-.179.786.365,1.693-.59,2.25ZM4.55,0c-.524,0-.791.313-.791.889q0,9.232,0,18.464c0,.62.267.89.878.891q6.56,0,13.12,0c.7,0,1-.308,1-.992q0-6.818,0-13.637c0-.118.05-.249-.088-.391H13.877V0C10.732,0,7.641,0,4.55,0M6.017,8.652H16.48V10.1H6.017Zm.007,2.994H16.486v1.46H6.025Zm-.007,3.006H16.48V16.1H6.017Zm9.4-10.926h3.319L15.414.012Z" transform="translate(0 0)" fill="#58585a"/>
            </svg></span> <?php echo $label_details[393]['name']; ?></h4>
            <button type="button" id="label_40_28" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                <div class="tool_tip">
                    <span class="tool_tip_text"><?php echo $label_details[395]['name']; ?></span>
                    <i class="las la-edit fs-1"></i>
                </div>
                <!--end::Svg Icon-->
            </button>
        </div>
        <!--end::Heading-->
    </div>
    <div class="card-body px-8 pb-7 pt-2" id="tasks_sub_container">
        <div class="card mb-7 border">
            <a name="task_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[394]['name']; ?></h3>
                    
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row g-8">
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[396]['name']; ?></label>
                                <div class="input-group">
                                    <input class="form-control" placeholder="Pick a date" id="from_date_fld" name="from_date" />
                                </div>
                            </div>
                            <!--end::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[397]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="task_category_fld" name="task_category_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--begin::Col-->
                            <?php if(in_array(717,$role_details)) { ?>
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[398]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="is_published_fld" name="is_published_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[399]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[400]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[401]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <?php } ?>
                            <!--end::Col-->
                                <!--begin::Col-->
                            <?php if(in_array(718,$role_details)) { ?>
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[402]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="is_locked_fld" name="is_locked_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[403]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[404]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[405]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <?php } ?>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <?php if(in_array(719,$role_details)) { ?>
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[406]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="is_del_fld" name="is_del_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all"><?php echo $label_details[407]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[408]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[409]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <?php } ?>
                            <!--end::Col-->
                            <div class="col-lg-4 mt-16 w-md-250px">
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="tasks_filter" name="tasks_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[410]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="tasks_reset" name="tasks_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[411]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <div class="card mb-lg-10 border noscreen" id="full_content">
            <div class="card" id="page_container">
                <!--begin::Card header-->
                <div class="card-header mb-5 hd-col-1">
                    <!--begin::Heading-->
                    <div class="card-title">
                        <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                </svg></span> <?php echo $label_details[412]['name']; ?></h3>                                            
                        
                    </div>
                    <!--end::Heading-->
                </div>
                <!--end::Card header-->
            </div>
            <!--begin::Card body-->
            <div class="card-body pt-0" id="add_container">
                <div class="card-box">
                    <!--begin::Add customer-->
                    <?php if(in_array(720,$role_details)) { ?>
                    <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_task_btn"><?php echo $label_details[413]['name']; ?> <i class="las la-plus fs-5"></i></button>
                    <?php } ?>
                    <span>&nbsp;</span>
                    <!--begin::Toolbar-->
                    <div class="card-toolbar">
                    <?php if(in_array(725,$role_details)) { ?>
                        <button type="button" id="publish_btn_id" class="btn btn-sm btn-primary px-2"><?php echo $label_details[414]['name']; ?> <i class="fas fa-upload fs-6"></i></button>
                        <?php } ?>
                        <?php if(in_array(726,$role_details)) { ?>
                        <button type="button" id="lock_btn_id" class="btn btn-sm btn-info px-2"><?php echo $label_details[415]['name']; ?> <i class="las la-lock"></i></button>
                        <?php } ?>
                        <?php if(in_array(727,$role_details)) { ?>
                        <button type="button" id="grade_btn_id" class="btn btn-sm btn-success px-2"><?php echo $label_details[416]['name']; ?> <i class="fas fa-graduation-cap"></i></button>
                        <?php } ?>
                        <?php if(in_array(747,$role_details)) { ?>
                        <button type="button" id="task_restore_btn_id" style="display:none;" class="btn btn-sm btn-warning px-2"  data-target="#restore_tasks" data-toggle="modal"><?php echo $label_details[417]['name']; ?> <i class="las la-undo fs-3"></i></button> 
                        <?php } ?>
                        <?php if(in_array(728,$role_details)) { ?>
                        <button type="button" id="task_delete_btn_id" class="btn btn-sm btn-danger px-2" data-target="#delete_tasks" data-toggle="modal"><?php echo $label_details[418]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>      
                        <?php } ?>                                 
                    </div>
                    <!--end::Toolbar-->
                    <!--end::Add customer-->
                </div>
                <!--begin::Table-->
                <div class="">
                    <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="task_table">
                        <!--begin::Table head-->
                        <thead >
                            <tr>
                                <th></th>
                                <th style="text-align: center;" data-priority="1" width="20px" rowspan="1" colspan="1">
                                    <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                        <input type="checkbox" id="task_table_check_all" class="group-checkable" name="task_table_check_all" >
                                        <span></span>
                                    </label>
                                </th>
                                <th data-priority="2" class="fw-bolder"> <?php echo $label_details[419]['name']; ?> </th>
                                <th data-priority="4" class="fw-bolder"> <?php echo $label_details[420]['name']; ?> </th>
                                <th data-priority="5" class="fw-bolder"> <?php echo $label_details[421]['name']; ?> </th>
                                <th data-priority="6" class="fw-bolder"> <?php echo $label_details[422]['name']; ?> </th>
                                <th class="fw-bolder"> <?php echo $label_details[423]['name']; ?> </th>
                                <th class="fw-bolder"> <?php echo $label_details[424]['name']; ?> </th>
                                <th data-priority="7" class="fw-bolder"> <?php echo $label_details[425]['name']; ?> </th>
                                <th class="fw-bolder" data-priority="8"> <?php echo $label_details[426]['name']; ?> </th>
                                <th data-priority="9" class="fw-bolder"> <?php echo $label_details[427]['name']; ?> </th>
                                <th data-priority="10" class="fw-bolder"> <?php echo $label_details[428]['name']; ?> </th>
                                <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[429]['name']; ?> </th>
                            </tr>
                        </thead>
                        <!--end::Table head-->
                        <!--begin::Table body-->
                        <tbody class=" text-gray-800 task_actionBtns_table">
                        </tbody>
                        <!--end::Table body-->
                    </table>
                </div>
                <!--end::Table-->
            </div>
            <!--end::Card body-->
        </div>
    </div>                            
</div>