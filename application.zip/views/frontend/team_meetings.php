<?php echo $header; ?>
<?php echo $sideheader; ?>
<link href="<?php echo $plugins_custom_path; ?>prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $plugins_custom_path; ?>jstree/jstree.bundle.css" rel="stylesheet" type="text/css" />
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <style>
    .actionBtns_table tr td:nth-child(7) {
    text-align: center;
    }
    .actionBtns_table tr td:nth-child(8) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(10) {
    text-align: center;
}
.actionBtns_table tr td:nth-child(11) {
    text-align: center;
}

.actionBtns_table tr td:nth-child(6) {
    text-align: center;
}
</style>
<style type="text/css">
		

.label.label-sm {
  display: inline-block;
  width: 20px;
  height: 20px;
  line-height: 19px;
  text-align: center;
  border-radius: 2px;
}
.label-primary {
  background-color: #659be0;
}
.label.label-sm i {
  color: #fff;
  font-size: 12px;
}
.dInline{
    display: inline-block!important;
}
.label-info {
  background-color: #7239ea;
}
.label-warning {
  background-color: #f1c40f;
}
.label-danger {
  background-color: #ed6b75;
}
.label-success {
  background-color: #36c6d3;
}
.label-primary {
  background-color: #009ef7;
}
.height-5 {
    height: 50px;
}
.students {
  background-color: rgba(51, 122, 183, 0.1);
}
.btn.btn-danger.close-btn {
  padding: 5px 10px !important;
}
.personnel {
  background-color: rgba(244, 208, 63, 0.1);
}
.text-blue{
    color: #009ef7;
}
.text-orange{
    color: #ff9b00;
}
.parents {
  background-color: rgb(142,68,173, 0.1);
}
.text-purple {
  color: #8e44ad;
}
	
</style>
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        <!--begin::Form-->
        <!--begin::Card-->
        <?php if(in_array(302,$role_details)) { ?>
        <div class="card mb-7 border">
            <a name="team_meetings_table_id"></a>
            <div class="card-header hd-col-2" id="filter_container">
                <!--begin::Heading-->
                <div class="card-title">
                    <h3><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M19.0759 3H4.72777C3.95892 3 3.47768 3.83148 3.86067 4.49814L8.56967 12.6949C9.17923 13.7559 9.5 14.9582 9.5 16.1819V19.5072C9.5 20.2189 10.2223 20.7028 10.8805 20.432L13.8805 19.1977C14.2553 19.0435 14.5 18.6783 14.5 18.273V13.8372C14.5 12.8089 14.8171 11.8056 15.408 10.964L19.8943 4.57465C20.3596 3.912 19.8856 3 19.0759 3Z" fill="black"/>
                    </svg></span> <?php echo $label_details[2]['name']; ?></h3>
                    <button type="button" id="label_48_1" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <!--end::Heading-->
            </div>
            <!--begin::Card body-->
            <div class="card-body px-8 pb-7 pt-2" id="filter_fields">
                <!--begin::Compact form-->
                <div class="d-flex align-items-center">
                    <!--begin::Col-->
                    <div class="col-xxl-12">
                        <!--begin::Row-->
                        <div class="row">
                            <!--begin::Col-->
                            <div class="col-lg-3 mb-4 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[3]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="created_by_fld" name="created_by_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[4]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="personnel_fld" name="personnel_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                             <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[5]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="student_fld" name="student_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                             <!--begin::Col-->
                             <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[6]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="groups_fld" name="groups_fld">
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[7]['name']; ?></label>
                                <div class="input-group">
                                    <input class="form-control" placeholder="<?php echo $label_details[132]['name']; ?>" id="date_created_fld" name="date_created_fld" />
                                </div>
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-200px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[8]['name']; ?></label>
                                <div class="input-group">
                                    <input class="form-control" placeholder="<?php echo $label_details[133]['name']; ?>" id="deadline_fld" name="deadline_fld" />
                                </div>
                            </div>
                            <!--end::Col-->
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-150px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[9]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="meeting_status_fld" name="meeting_status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[17]['name']; ?></option>
                                    <option value="new"><?php echo $label_details[10]['name']; ?></option>
                                    <option value="pending"><?php echo $label_details[11]['name']; ?></option>
                                    <option value="done"><?php echo $label_details[12]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                             <!--begin::Col-->
                             <div class="col-lg-3 w-md-150px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[13]['name']; ?></label>
                                <!--begin::Select-->
                                <select id="status_fld" name="status_fld" class="form-select form-select-solid border" data-control="select2"  data-hide-search="true">
                                    <option value="all" selected="selected"><?php echo $label_details[17]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[14]['name']; ?></option>
                                    <option value="0"><?php echo $label_details[15]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php if(in_array(318,$role_details)) { ?>
                            <!--begin::Col-->
                            <div class="col-lg-3 w-md-100px">
                                <label class="fs-7 form-label text-dark"><?php echo $label_details[16]['name']; ?></label>
                                <!--begin::Select-->
                                <select class="form-select form-select-solid border" data-control="select2" id="del_fld" name="del_fld" data-hide-search="true">
                                    <option value="all"><?php echo $label_details[17]['name']; ?></option>
                                    <option value="1"><?php echo $label_details[18]['name']; ?></option>
                                    <option value="0" selected="selected"><?php echo $label_details[19]['name']; ?></option>
                                </select>
                                <!--end::Select-->
                            </div>
                            <!--end::Col-->
                            <?php } ?>
                            <div class="col-lg-4 w-md-250px">
                                <label >&nbsp;</label>
                                <div class="clearfix"></div>
                                <!--end::Input group-->
                                <!--begin:Action-->
                                <div class="fltl me-3">
                                    <button type="button" id="team_meetings_filter" name="team_meetings_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                        <i class="las la-filter"></i>
                                        <!--end::Svg Icon--><?php echo $label_details[20]['name']; ?>
                                    </button>
                                </div>
                                <div class="fltl">
                                    <button type="button" id="team_meetings_reset" name="team_meetings_reset" class="btn btn-danger me-5 pb-3 pt-2 fs-7" ><i class="las la-redo-alt"></i> <?php echo $label_details[21]['name']; ?></button>
                                </div>
                            </div>
                            <!--end::Col-->
                        </div>
                        <!--end::Row-->
                    </div>
                    <!--end::Col-->
                    <!--begin::Input group-->

                    <!--end:Action-->
                </div>
                <!--end::Compact form-->
            </div>
            <!--end::Card body-->
        </div>
        <?php } ?>
        <!--end::Card-->
        <!--end::Form-->
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <!--begin::Card-->
            <div class="card mb-lg-10 border noscreen" id="full_content">
                <div class="card" id="page_container">
                    <!--begin::Card header-->
                    <div class="card-header mb-5 hd-col-1">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                    <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                    </svg></span> <?php echo $label_details[22]['name']; ?></h3>
                                    <button type="button" id="label_48_2" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <a href="javascript:;" id="open_full" class="fullscreen" data-placement="left" data-original-title="Full Screen" title=""><i class="las la-arrows-alt fs-3"></i> </a>
                        </div>
                        <!--end::Heading-->
                    </div>
                    <!--end::Card header-->
                </div>
                <!--begin::Card body-->
                <div class="card-body pt-0" id="add_container">
                    <div class="card-box">
                        <!--begin::Add customer-->
                        <?php if(in_array(303,$role_details)) { ?>
                        <button type="button" class="btn btn-primary mb-3 py-3 fs-7" id="add_team_meetings_btn"><?php echo $label_details[23]['name']; ?> <i class="las la-plus fs-5"></i></button>
                        <?php } ?><span>&nbsp;</span>
                        <!--begin::Toolbar-->
                        <div class="card-toolbar">
                            <?php if(in_array(304,$role_details)) { ?>
                            <button type="button" id="delete_btn_id" class="btn btn-sm btn-danger my-1 me-3 px-2" data-target="#delete_team_meetings" data-toggle="modal"><?php echo $label_details[24]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>
                            <?php } ?>
                            <?php if(in_array(305,$role_details)) { ?>
                            <button type="button" id="restore_btn_id" style="display:none;" class="btn btn-sm btn-warning my-1 me-3 px-2"  data-target="#restore_team_meetings" data-toggle="modal"><?php echo $label_details[25]['name']; ?> <i class="las la-undo fs-3"></i></button>
                            <?php } ?>
                        </div>
                        <!--end::Toolbar-->
                        <!--end::Add customer-->
                    </div>
                    <!--begin::Table-->
                    <div class="">
                        <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="cc-table">
                            <!--begin::Table head-->
                            <thead >
                                <tr>
                                    <th></th>
                                    <th data-priority="1" width="20px" rowspan="1" colspan="1">
                                        <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                            <input type="checkbox" id="table_check_all" class="group-checkable" name="table_check_all" >
                                            <span></span>
                                        </label>
                                    </th>
                                    <th data-priority="2" class="fw-bolder"> <?php echo $label_details[26]['name']; ?> </th>
                                    <th data-priority="4" class="fw-bolder"> <?php echo $label_details[27]['name']; ?> </th>
                                    <th data-priority="5" class="fw-bolder"> <?php echo $label_details[28]['name']; ?> </th>
                                    <th data-priority="9" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[29]['name']; ?> </th>
                                    <th data-priority="10" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[30]['name']; ?> </th>
                                    <th data-priority="6" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[31]['name']; ?> </th>
                                    <th data-priority="7" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[32]['name']; ?> </th>
                                    <th data-priority="8" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[33]['name']; ?> </th>
                                    <th data-priority="3" class="w-md-150px fw-bolder" style="text-align: center;"> <?php echo $label_details[34]['name']; ?> </th>
                                </tr>
                            </thead>
                            <!--end::Table head-->
                            <!--begin::Table body-->
                            <tbody class=" text-gray-800 actionBtns_table">
                            </tbody>
                            <!--end::Table body-->
                        </table>
                    </div>
                    <!--end::Table-->
                    <div class="text-center add_col_loader" style="display:none">
                        <div class="loader"></div>
                    </div>
                </div>
                <!--end::Card body-->
            </div>
            <!--end::Card-->
            <!-- Add Module -->
            <div class="card mb-5 mb-lg-10 border pb-4" id="team_meetings_create_id" style="display:none;">
                <form name="add_team_meetings_form" id="add_team_meetings_form" class="add_team_meetings_form">
                    <a name="team_meetings_create_id"></a>
                    <!--begin::Card header-->
                    <div class="card-header mb-8  hd-col-3">
                        <!--begin::Heading-->
                        <div class="card-title">
                            <h3>
                                <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                </svg></span> <span id="meeting_title"></span>
                            </h3>
                            <button type="button" id="label_48_3" class="pb-3 pt-3 fs-7 bulk_label_cls_sp" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                        </div>
                        <!--end::Heading-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_team_meetings_send_sub"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-icon-bell fs-4"></i><?php echo $label_details[36]['name']; ?></button>
                            <button type="button" id="add_team_meetings_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[37]['name']; ?></button>
                            <button type="button" id="add_team_meetings_new_con_sub" class="btn btn-sm btn-warning my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[38]['name']; ?></button>
                            <button type="button" id="add_team_meetings_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[39]['name']; ?></button>
                        </div>
                    </div>
                    <!--end::Card header-->
                    <!--begin::Card body-->
                    <div class="card-body p-0 px-9">
                        <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                        <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                            <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                        </div>
                        <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                            <li class="nav-item">
                                <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[40]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_2">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                        <path id="parents" d="M14.654,12.652c-.167,0-.323,0-.474-.009H14.1a3.315,3.315,0,0,0-1.642.481,5.052,5.052,0,0,0-1.992,2.118A12.964,12.964,0,0,0,9.242,22.31a1.365,1.365,0,0,0,1.022,1.179,1.539,1.539,0,0,0,.545.1,1.711,1.711,0,0,0,.96-.314,1.365,1.365,0,0,0,.593-1.245,13.344,13.344,0,0,1,.327-3.4V23.97c-.98.01-1.961.021-2.942.024q-3.207.007-6.413,0a1.5,1.5,0,0,1-.657-.067c.569-3.56,1.139-7.116,1.726-10.79a1.376,1.376,0,0,0-.6.719,11.878,11.878,0,0,0-1.194,4.975c-.016.678-.017,1.357-.057,2.034A1.187,1.187,0,0,1,1.3,21.952,1.182,1.182,0,0,1,.014,20.9,19.707,19.707,0,0,1,.74,13.965a8.074,8.074,0,0,1,2.417-3.786A4.126,4.126,0,0,1,6,9.177c2.193.043,4.389.011,6.584,0A3.708,3.708,0,0,0,13.823,12.1a3.79,3.79,0,0,0,.83.548m9.337,9.236a8.157,8.157,0,0,1-.06-1.137,10.932,10.932,0,0,0-.257-2.86,6.9,6.9,0,0,0-2.241-4.051,2.834,2.834,0,0,0-2.018-.7c-.731.038-1.464.012-2.2.01h-.112l-.391,0c-.231,0-.463,0-.694,0s-.445,0-.667,0-.443,0-.664,0c-.177,0-.353-.005-.53-.01a2.635,2.635,0,0,0-1.392.4,4.5,4.5,0,0,0-1.78,1.91A12.747,12.747,0,0,0,9.82,22.293c.014.36.3.6.676.741a.97.97,0,0,0,.917-.15.911.911,0,0,0,.37-.847,11.454,11.454,0,0,1,.919-5.151.982.982,0,0,1,.564-.667v7.746h7.284V16.3a1.778,1.778,0,0,1,.624.848,11.22,11.22,0,0,1,.785,4.831.976.976,0,0,0,1,1.1,1.006,1.006,0,0,0,1.026-1.2M8.862,0a4.184,4.184,0,1,0,4.184,4.184A4.184,4.184,0,0,0,8.862,0M16.9,6.187a3.234,3.234,0,1,0,3.234,3.234A3.234,3.234,0,0,0,16.9,6.187" transform="translate(0)"/>
                                    </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[41]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_3">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="contact_data" data-name="contact data" d="M18.87,12.233a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m4.439,4.259a.584.584,0,0,0,.684-.645c.01-.721.011-1.442,0-2.163a.554.554,0,0,0-.654-.609c-.339.013-.678,0-1.026,0V11.246c.385,0,.728-.006,1.071,0a.538.538,0,0,0,.608-.6c.013-.738.015-1.477,0-2.215a.553.553,0,0,0-.621-.6c-.354,0-.709,0-1.071,0V6.049c.367,0,.706,0,1.046,0a.579.579,0,0,0,.65-.63c.007-.721.006-1.442,0-2.163a.582.582,0,0,0-.638-.645c-.341-.008-.682,0-1.087,0,0-.573,0,.473,0-.024A2.548,2.548,0,0,0,19.7,0Q11.122,0,2.544,0A2.5,2.5,0,0,0,.007,2.5C0,9.965,0,14.028.007,21.5A2.5,2.5,0,0,0,2.537,24q8.577,0,17.155,0a2.549,2.549,0,0,0,2.575-2.575c0-.51,0,.439,0-.111.383,0,.706,0,1.028,0a.613.613,0,0,0,.7-.692q0-1.03,0-2.061a.608.608,0,0,0-.7-.69c-.335,0-.669,0-1,0v-1.38c.358,0,.682-.009,1.006,0m-10.542-.926c-.01.3,0,1.42,0,1.637H4.305a5.587,5.587,0,0,1,3.266-5.127.439.439,0,0,1,.423.079,3.624,3.624,0,0,0,3.862,0,.441.441,0,0,1,.425-.074,3.318,3.318,0,0,1,.487.217.962.962,0,0,0,0,.154,9.535,9.535,0,0,1,0,1.01c-.022.4.012,1.763,0,2.1M9.934,12.136a3.111,3.111,0,1,1,3.112-3.124,3.122,3.122,0,0,1-3.112,3.124m3.115.526a.838.838,0,0,1,.423-.783,3.464,3.464,0,0,1,1.324-.5,7.049,7.049,0,0,1,3.358.142,2.421,2.421,0,0,1,.9.456.736.736,0,0,1,.292.62c-.008.179,0,.359,0,.539,0,.155-.011.31,0,.464a.815.815,0,0,1-.41.776,3.3,3.3,0,0,1-1.249.489,7.2,7.2,0,0,1-3.241-.065,3.06,3.06,0,0,1-.962-.409.859.859,0,0,1-.434-.8,8.428,8.428,0,0,0,0-.927m0,1.918.04,0a1.112,1.112,0,0,0,.54.534,4.2,4.2,0,0,0,1.51.459,7.161,7.161,0,0,0,2.809-.142,2.892,2.892,0,0,0,1.041-.469,1.064,1.064,0,0,0,.342-.421c0,.389.015.779,0,1.168a.761.761,0,0,1-.4.56,3.321,3.321,0,0,1-1.249.487,7.2,7.2,0,0,1-3.166-.049,2.856,2.856,0,0,1-1.152-.521.778.778,0,0,1-.309-.663c.01-.313,0-.626,0-.94m5.85,3.59a3.71,3.71,0,0,1-1.34.493,5.57,5.57,0,0,1-.794.1c-.018,0-.032,0-.036.024h-1.1a2.517,2.517,0,0,0-.5-.074,4.554,4.554,0,0,1-1.487-.452,1.8,1.8,0,0,1-.318-.221.748.748,0,0,1-.277-.6c.006-.336,0-.672,0-1.027a1.95,1.95,0,0,0,1.415.907,6.908,6.908,0,0,0,3.685-.062,2.488,2.488,0,0,0,.858-.423.915.915,0,0,0,.312-.419c.031.03.019.064.019.093,0,.285-.015.569,0,.852a.848.848,0,0,1-.441.81m-5.382-5.4a1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529m5.348-.537a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547m0,0a1.857,1.857,0,0,0-.666-.362,5.987,5.987,0,0,0-2.006-.308,6.005,6.005,0,0,0-2,.308,1.85,1.85,0,0,0-.676.369.309.309,0,0,0,0,.529,1.944,1.944,0,0,0,.7.376,5.617,5.617,0,0,0,1.607.289,6.2,6.2,0,0,0,2.416-.314,1.793,1.793,0,0,0,.62-.341c.211-.192.213-.354.006-.547" transform="translate(0 0)" fill="#010101"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[42]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_4">
                                    <span class="svg-icon svg-icon-2 svg-icon-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
                                            <path id="remarks" d="M7.065,24V18.258a1.894,1.894,0,0,0-.547-.028,17.2,17.2,0,0,1-2.474-.08A4.956,4.956,0,0,1,.059,13.706c-.11-1.411-.028-2.828-.04-4.242C0,7.841-.016,6.217.022,4.6a3.923,3.923,0,0,1,.39-1.52A4.724,4.724,0,0,1,4.839.024C7.6-.019,10.366.011,13.129.009c1.974,0,3.948-.008,5.922,0a4.916,4.916,0,0,1,4.842,4.009,5.607,5.607,0,0,1,.1,1.189c0,2.611-.024,5.222.01,7.833a5.035,5.035,0,0,1-4.232,5.144,5.913,5.913,0,0,1-.824.044q-2.631,0-5.261-.005a.627.627,0,0,0-.464.184q-2.989,2.76-5.986,5.51c-.038.035-.067.093-.168.08M12.1,7.3a1.8,1.8,0,1,0,1.719,1.814A1.775,1.775,0,0,0,12.1,7.3m-6.032,0a1.8,1.8,0,0,0-.008,3.6,1.8,1.8,0,0,0,.008-3.6m12.013,0a1.766,1.766,0,0,0-1.751,1.8,1.751,1.751,0,1,0,1.751-1.8" transform="translate(0 0)" fill="#020201"/>
                                        </svg>
                                    </span>
                                    <!--end::Svg Icon-->
                                    <span class="d-flex flex-column align-items-start">
                                        <span class="fs-4 fw-bolder"><?php echo $label_details[43]['name']; ?></span>
                                    </span>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="kt_tab_pane_1" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[44]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[45]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                <input type="text" id="title" name="title" class="form-control" aria-describedby="basic-addon1">
                                                <input type="hidden" id="token_id" name="token_id" />
                                            </div>
                                        </div>
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[46]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="category_id" name="category_id">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[47]['name']; ?> *</label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <select class="form-select rounded-start-0" data-control="select2" id="created_by" name="created_by">
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-group mb-5 mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[48]['name']; ?> *</label>
                                            <div class="input-group">
                                                <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                                <input class="form-control" placeholder="<?php echo $label_details[263]['name']; ?>" id="deadline_date" name="deadline_date" />
                                            </div>
                                        </div>
                                        <div class="card mb-5 mb-xl-8 border">
                                            <div class="divrel">
                                                <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                                    <div class="ribbon-label">
                                                        <?php echo $label_details[49]['name']; ?>
                                                        <span class="ribbon-inner bg-info"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body py-4">
                                                <div class="input-group mb-5">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[50]['name']; ?></label>
                                                    <div class="input-group flex-nowrap">
                                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                        <div class="overflow-hidden flex-grow-1">
                                                            <select class="form-select rounded-start-0" data-control="select2" id="group_id" name="group_id[]" multiple>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group mb-5">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[51]['name']; ?></label>
                                                    <div class="input-group flex-nowrap">
                                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                        <div class="overflow-hidden flex-grow-1">
                                                            <select class="form-select rounded-start-0" data-control="select2" id="student_id" name="student_id[]" multiple>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="input-group mb-5">
                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[52]['name']; ?></label>
                                                    <div class="input-group flex-nowrap">
                                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                        <div class="overflow-hidden flex-grow-1">
                                                            <select class="form-select rounded-start-0" data-control="select2" id="personnel_id" name="personnel_id[]" multiple>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">    
                                                <div class="card mb-5 mb-xl-8 border">
                                                    <div class="divrel">
                                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                                            <div class="ribbon-label">
                                                                <?php echo $label_details[53]['name']; ?>
                                                                <span class="ribbon-inner bg-info"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--begin::Card body-->
                                                    <div class="card-body py-4">
                                                        <div class="row">
                                                            <div class="row">
                                                                <div class="col-md-6">    
                                                                    <div class="form-group priority_css">
                                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[54]['name']; ?></label>
                                                                    <label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="low_priority" name="priority" value="low" checked="checked">
                                                                    <?php echo $label_details[55]['name']; ?>
                                                                    <span></span></label><label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="medium_priority" name="priority" value="medium">
                                                                        <?php echo $label_details[56]['name']; ?>
                                                                    <span></span></label><label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="high_priority" name="priority" value="high">
                                                                        <?php echo $label_details[57]['name']; ?>
                                                                    <span></span></label></div>
                                                                </div>
                                                                <div class="col-md-6">    
                                                                    <div class="form-group priority_css">
                                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[58]['name']; ?></label>
                                                                        <label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="new_status" name="meeting_status" value="new" checked="checked">
                                                                        <?php echo $label_details[59]['name']; ?>
                                                                    <span></span></label><label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="pending_status" name="meeting_status" value="pending">
                                                                        <?php echo $label_details[60]['name']; ?>
                                                                    <span></span></label><label class="mt-radio mt-radio-single mt-radio-outline"><input type="radio" id="done_status" name="meeting_status" value="done">
                                                                        <?php echo $label_details[61]['name']; ?>
                                                                    <span></span></label></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Card body-->
                                                </div>
                                            </div>
                                            <div class="col-md-6">    
                                                <div class="card mb-5 mb-xl-8 border">
                                                    <div class="divrel">
                                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                                            <div class="ribbon-label">
                                                                <?php echo $label_details[62]['name']; ?>
                                                                <span class="ribbon-inner bg-info"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--begin::Card body-->
                                                    <div class="card-body py-4">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group inc_css">
                                                                    <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[63]['name']; ?></label>
                                                                    
                                                                    <div class="input-group flex-nowrap">
                                                                        <span class="input-group-text"><i class="las la-circle fs-3"></i></span>
                                                                        <div class="overflow-hidden flex-grow-1">
                                                                            <input type="text" id="fail" name="fail" readonly="readonly" class="form-control " value="0">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="inc_css">
                                                                    <label class="no-colon">&nbsp;</label>
                                                                    <button type="button" class="btn btn-success mt-9" id="increment">+</button>
                                                                    <label class="no-colon">&nbsp;</label>
                                                                    <button type="button" class="btn btn-danger mt-9" id="decrement">-</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Card body-->
                                                </div>   
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <label class="fs-6 form-label text-dark"><?php echo $label_details[64]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" id="status" name="status" checked="checked">
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_2" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[65]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[66]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="opinion" name="opinion"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_3" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[67]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[68]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="decision" name="decision"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div> 
                            </div>
                            <div class="tab-pane fade" id="kt_tab_pane_4" role="tabpanel">
                                <div class="card mb-5 mb-xl-8 border">
                                    <div class="divrel">
                                        <div class="card-header justify-content-end ribbon ribbon-start ribbon-clip ribbon-top bd-0">
                                            <div class="ribbon-label">
                                                <?php echo $label_details[69]['name']; ?>
                                                <span class="ribbon-inner bg-info"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <!--begin::Card body-->
                                    <div class="card-body py-4">
                                        <div class="card mb-7 border">
                                            <div class="card-header hd-col-2" id="stats_block">
                                                <!--begin::Heading-->
                                                <div class="card-title">
                                                    <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 21.91 24"><defs><style>.a{fill:#27393f;}</style></defs><path class="a" d="M0,2.93H3.49v1H13.64c.09-.31,0-.64.06-1h3.46v9c-2.53-.82-4.61-.29-6.05,2.06a4.42,4.42,0,0,0,.4,5.32c1.48,1.87,3.43,2.18,5.65,1.47v3.24H0Zm7.05,7.13H11.7A1.31,1.31,0,0,0,12,10a.43.43,0,0,0,.35-.48.45.45,0,0,0-.4-.44,1.48,1.48,0,0,0-.3,0H2.51a1.6,1.6,0,0,0-.38,0,.44.44,0,0,0-.39.45A.43.43,0,0,0,2.1,10a1.31,1.31,0,0,0,.34,0Zm-1.22,2H2.37c-.42,0-.64.17-.64.48S2,13,2.35,13H9.28c.4,0,.6-.16.61-.46s-.21-.48-.63-.48ZM5.26,16c1,0,1.93,0,2.89,0,.4,0,.64-.19.63-.49S8.55,15,8.16,15H2.34c-.38,0-.61.18-.61.47s.23.48.6.48C3.31,16,4.29,16,5.26,16Zm-.62,2H2.31c-.33,0-.54.14-.57.47s.2.49.54.49H7a.5.5,0,0,0,.57-.48c0-.29-.21-.48-.58-.48Zm13.65,1,2.43,2.34c.28.27.56.53.84.81a1.88,1.88,0,0,1,.27.36.57.57,0,0,1-.17.78.61.61,0,0,1-.82-.13l-1.55-1.93-1.48-1.85a3.84,3.84,0,0,1-5.06-5.76,3.85,3.85,0,0,1,5.05-.21C19.46,14.7,19.64,16.75,18.29,19Zm-3.22-1.79L13.88,16a.48.48,0,1,0-.7.65c.51.53,1,1.06,1.55,1.57a.45.45,0,0,0,.75-.05c.2-.24.4-.49.59-.74l1.57-2c.24-.3.23-.59,0-.76s-.52-.11-.72.14l-.26.33ZM12.89,1.64h-2.7C9.84.44,9.43,0,8.57.07a1.67,1.67,0,0,0-1,.34A1.61,1.61,0,0,0,7,1.71H4.33V3.14h8.56Z" transform="translate(0 -0.06)"/></svg></span> <?php echo $label_details[70]['name']; ?></h4>
                                                    <div class="tools">
                                                        <a href="javascript:;" class="collapse"></a>
                                                    </div>
                                                </div>
                                                <!--end::Heading-->
                                            </div>
                                            <!--begin::Card body-->
                                            <div class="card-body px-8 pb-7 pt-2" id="stats_fields">
                                                <!--begin::Compact form-->
                                                <div class="align-items-center">
                                                    <!--begin::Col-->
                                                    <div class="col-xxl-12">
                                                        <!--begin::Row-->
                                                        <div class="row g-8">
                                                            <div class="col-lg-4 w-md-250px">
                                                                <div class="input-group mb-5">
                                                                    <label class="fs-7 form-label text-dark"><?php echo $label_details[71]['name']; ?></label>
                                                                    <div class="input-group flex-nowrap">
                                                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                                        <div class="overflow-hidden flex-grow-1">
                                                                            <select class="form-select form-select-solid border" data-control="select2" id="stats_term_id" name="stats_term_id">
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-4 w-md-250px">
                                                                <div class="input-group mb-5">
                                                                    <label class="fs-7 form-label text-dark"><?php echo $label_details[72]['name']; ?></label>
                                                                    <div class="input-group flex-nowrap">
                                                                        <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                                        <div class="overflow-hidden flex-grow-1">
                                                                            <select class="form-select form-select-solid border" data-control="select2" id="stats_student_id" name="stats_student_id">
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-4 w-md-250px">
                                                                <!--end::Input group-->
                                                                <!--begin:Action-->
                                                                <div class="fltl me-3 mt-8">
                                                                    <button type="button" id="stats_filter" name="stats_filter" class="btn btn-primary pb-3 pt-2 fs-7">
                                                                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                                        <i class="las la-filter"></i>
                                                                        <!--end::Svg Icon--><?php echo $label_details[73]['name']; ?>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <!--end::Col-->
                                                        </div>
                                                        <!--end::Row-->
                                                        <div id="all_statistics" style="display:none;">
                                                            <div class="card mb-7 border">
                                                                <div class="card-header hd-col-2" id="absences_block">
                                                                    <!--begin::Heading-->
                                                                    <div class="card-title">
                                                                        <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 23.98"><path d="M6,2V0H8V2h8V0h2V2H22.9A1,1,0,0,1,24,3.1V22.8a1.67,1.67,0,0,1-.05.5,1,1,0,0,1-1,.68H1.08A1,1,0,0,1,0,22.9V3.12A1,1,0,0,1,.76,2a1.71,1.71,0,0,1,.39,0H6ZM22,8H2V22H22ZM12,16.29,15.63,20,17,18.54l-3.63-3.62,3.32-3.39L15.26,10.1l-3.39,3.39L8.56,10.16,7.11,11.59,10.51,15,6.85,18.56,8.33,20Z" transform="translate(0 -0.01)" style="fill:#f7090a"/></svg></span> <?php echo $label_details[74]['name']; ?></h4>
                                                                        <div class="tools">
                                                                            <a href="javascript:;" class="expand"></a>
                                                                        </div>
                                                                    </div>
                                                                    <!--end::Heading-->
                                                                </div>
                                                                <!--begin::Card body-->
                                                                <div class="card-body px-8 pb-7 pt-2" id="student_final_fields">
                                                                    <!--begin::Compact form-->
                                                                    <div class="align-items-center">
                                                                        <!--begin::Col-->
                                                                        <div class="col-xxl-12">
                                                                            <!--begin::Table-->
                                                                            <div class="cct-scrool">
                                                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_absences">
                                                                                    <!--begin::Table head-->
                                                                                    <thead >
                                                                                        <tr>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[75]['name']; ?> </th>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[76]['name']; ?> </th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <!--end::Table head-->
                                                                                    <!--begin::Table body-->
                                                                                    <tbody class=" text-gray-800 actionBtns_table">
                                                                                    </tbody>
                                                                                    <!--end::Table body-->
                                                                                </table>
                                                                            </div>
                                                                            <!--end::Table-->
                                                                        </div>
                                                                        <!--end::Col-->
                                                                        <!--begin::Input group-->
                                                                        <!--end:Action-->
                                                                    </div>
                                                                    <!--end::Compact form-->
                                                                </div>
                                                                <!--end::Card body-->
                                                            </div>
                                                            <div class="card mb-7 border">
                                                                <div class="card-header hd-col-2" id="disciplinary_block">
                                                                    <!--begin::Heading-->
                                                                    <div class="card-title">
                                                                        <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M0,13.36V10.64a1,1,0,0,1,1.09-.53c.43,0,.86,0,1.31,0A9.79,9.79,0,0,1,3.88,6.54c-.39-.39-.77-.76-1.15-1.15a.73.73,0,0,1,0-1.07c.53-.54,1.06-1.08,1.6-1.61a.74.74,0,0,1,.76-.17.82.82,0,0,1,.35.23l1.1,1.12A10.07,10.07,0,0,1,10.12,2.4V.83A.76.76,0,0,1,11,0H13a.77.77,0,0,1,.87.87V2.4a9.72,9.72,0,0,1,3.58,1.48c.36-.36.7-.71,1.05-1a.79.79,0,0,1,1.28,0l1.36,1.36a.81.81,0,0,1,0,1.34l-1,1a10.13,10.13,0,0,1,1.49,3.58h1.55A.76.76,0,0,1,24,11V13a.77.77,0,0,1-.87.86H21.6a9.72,9.72,0,0,1-1.48,3.58l1.1,1.09a.78.78,0,0,1,0,1.21l-1.42,1.42a.78.78,0,0,1-1.26,0l-1.07-1.07a10,10,0,0,1-3.58,1.48c0,.48,0,.94,0,1.4a.92.92,0,0,1-.58,1H10.64a1,1,0,0,1-.53-1.09c0-.43,0-.86,0-1.31a10,10,0,0,1-3.58-1.48c-.37.36-.72.73-1.08,1.08a.78.78,0,0,1-1.23,0L2.81,19.78a.79.79,0,0,1,0-1.26l1.07-1.06A9.52,9.52,0,0,1,3,15.74a10,10,0,0,1-.56-1.86H.79a.73.73,0,0,1-.59-.25C.13,13.55.07,13.45,0,13.36ZM12,4.22A7.78,7.78,0,1,0,19.78,12,7.78,7.78,0,0,0,12,4.22Z" transform="translate(0 0)" style="fill:#343434"/><path d="M8.68,11h.9V16.2h-.9Zm6.64.07h-.9v5.1h.9Zm-3.77,1.25h.9V7.8h-.9ZM10.3,10.67v-1H8v1Zm.54,3.05h2.32v-1H10.84Zm5.2-3v-1H13.71v1ZM11.55,16.2h.9V14.08h-.9Zm-2-6.9V7.81H8.67V9.3Zm5.75.06V7.8h-.91V9.36Z" transform="translate(0 0)" style="fill:#075a9c"/></svg></span> <?php echo $label_details[77]['name']; ?></h4>
                                                                        <div class="tools">
                                                                            <a href="javascript:;" class="expand"></a>
                                                                        </div>
                                                                    </div>
                                                                    <!--end::Heading-->
                                                                </div>
                                                                <!--begin::Card body-->
                                                                <div class="card-body px-8 pb-7 pt-2" id="student_selected_courses_fields">
                                                                    <!--begin::Compact form-->
                                                                    <div class="align-items-center">
                                                                        <!--begin::Col-->
                                                                        <div class="col-xxl-12">
                                                                            <!--begin::Table-->
                                                                            <div class="cct-scrool">
                                                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_disciplinary">
                                                                                    <!--begin::Table head-->
                                                                                    <thead >
                                                                                        <tr>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[78]['name']; ?> </th>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[79]['name']; ?> </th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <!--end::Table head-->
                                                                                    <!--begin::Table body-->
                                                                                    <tbody class=" text-gray-800 actionBtns_table">
                                                                                    </tbody>
                                                                                    <!--end::Table body-->
                                                                                </table>
                                                                            </div>
                                                                            <!--end::Table-->
                                                                        </div>
                                                                        <!--end::Col-->
                                                                        <!--begin::Input group-->
                                                                        <!--end:Action-->
                                                                    </div>
                                                                    <!--end::Compact form-->
                                                                </div>
                                                                <!--end::Card body-->
                                                            </div>
                                                            <div class="card mb-7 border">
                                                                <div class="card-header hd-col-2" id="marks_block">
                                                                    <!--begin::Heading-->
                                                                    <div class="card-title">
                                                                        <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 15.63 24"><path d="M9.21,3.94A.18.18,0,0,1,9,3.76V1.29A1.26,1.26,0,0,0,8.65.38,1.24,1.24,0,0,0,7.74,0,1.29,1.29,0,0,0,6.45,1.29V3.76a.18.18,0,0,1-.18.18H3.87V5.17a.59.59,0,0,0,.59.59H11a.58.58,0,0,0,.59-.59V3.94ZM7.71,1.77a.51.51,0,0,1,0-1,.51.51,0,0,1,0,1ZM13.55,7.9H2.09V7.1H13.55Zm0,2.11H2.09v-.8H13.55Zm0,2.1H2.09v-.8H13.55Zm-.24,3.26L8.47,20.21,6.82,21.87h0L3,18.11a.68.68,0,0,1,0-1l.7-.7a.69.69,0,0,1,1,0l2.11,2.11,4.84-4.84a.67.67,0,0,1,1,0l.7.7A.67.67,0,0,1,13.31,15.37Zm1-12.52H9.49v.63h4.84a.67.67,0,0,1,.67.66V22.7a.66.66,0,0,1-.67.66H1.3a.65.65,0,0,1-.66-.66V4.15a.66.66,0,0,1,.66-.66H6V2.85H1.3A1.3,1.3,0,0,0,0,4.15V22.7A1.3,1.3,0,0,0,1.3,24h13a1.3,1.3,0,0,0,1.3-1.3V4.15A1.3,1.3,0,0,0,14.33,2.85Z" style="fill:#2c9f5a"/></svg></span> <?php echo $label_details[80]['name']; ?></h4>
                                                                        <div class="tools">
                                                                            <a href="javascript:;" class="expand"></a>
                                                                        </div>
                                                                    </div>
                                                                    <!--end::Heading-->
                                                                </div>
                                                                <!--begin::Card body-->
                                                                <div class="card-body px-8 pb-7 pt-2" id="selected_students">
                                                                    <!--begin::Compact form-->
                                                                    <div class="align-items-center">
                                                                        <!--begin::Col-->
                                                                        <div class="col-xxl-12">
                                                                            <!--begin::Table-->
                                                                            <div class="cct-scrool">
                                                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3" id="student_marks">
                                                                                    <!--begin::Table head-->
                                                                                    <thead >
                                                                                        <tr>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[81]['name']; ?> </th>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[82]['name']; ?> </th>
                                                                                            <th class="fw-bolder"> <?php echo $label_details[83]['name']; ?> </th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <!--end::Table head-->
                                                                                    <!--begin::Table body-->
                                                                                    <tbody class=" text-gray-800 actionBtns_table">
                                                                                    </tbody>
                                                                                    <!--end::Table body-->
                                                                                </table>
                                                                            </div>
                                                                            <!--end::Table-->
                                                                        </div>
                                                                        <!--end::Col-->
                                                                        <!--begin::Input group-->

                                                                        <!--end:Action-->
                                                                    </div>
                                                                    <!--end::Compact form-->
                                                                </div>
                                                                <!--end::Card body-->
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Col-->
                                                    <!--begin::Input group-->

                                                    <!--end:Action-->
                                                </div>
                                                <!--end::Compact form-->
                                            </div>
                                            <!--end::Card body-->
                                        </div>
                                    </div>
                                    <!--end::Card body-->
                                </div>                            
                            </div>
                        </div>
                    </div>
                    <div class="card-box px-8">
                        <div class="">&nbsp;</div>
                                            <!--begin::Toolbar-->
                        <div class="card-toolbar float-xxl-end">
                            <button type="button" id="add_team_meetings_send_sub_bott"  class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><i class="las la-icon-bell fs-4"></i><?php echo $label_details[84]['name']; ?></button>
                            <button type="button" id="add_team_meetings_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[85]['name']; ?></button>
                            <button type="button" id="add_team_meetings_new_con_sub_bott" class="btn btn-sm btn-warning my-1 me-3 px-2 fs-8"><i class="las la-plus fs-4"></i><?php echo $label_details[86]['name']; ?></button>
                            <button type="button" id="add_team_meetings_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4"></i><?php echo $label_details[87]['name']; ?></button>
                        </div>
                        <!--end::Toolbar-->
                    </div>
                    <!--end::Card body-->
                </form>
            </div>

            <!--begin::Modals-->
            
            <!--begin::Modal - Delete Module-->
            <div class="modal fade" id="delete_team_meetings" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[88]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_48_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_team_meetings_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[89]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_team_meetings_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[90]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[91]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->

            <!--begin::Modal - Restore Module-->
            <div class="modal fade" id="restore_team_meetings" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[92]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_48_8" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="res_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="res_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="restore_team_meetings_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[93]['name']; ?>?</label>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="restore_team_meetings_sub" class="btn btn-primary"><i class="las la-undo fs-5"></i><?php echo $label_details[94]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" data-bs-dismiss="modal" id="close_com_res_btn"><i class="las la-times fs-5"></i><?php echo $label_details[91]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Restore Module-->
            
            <!--begin::Modal - New Message Module-->
        <div class="modal fade" id="new_message" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[222]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <button type="button" id="label_49_3" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $all_page_label_details[159]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_create_id">
                            <form name="add_notifications_form" id="add_notifications_form" class="add_notifications_form">
                            <div class="alert alert-danger errYxt" id="team_mrk_err_msg" style="display:none;">  
                                <i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <div class="alert alert-success errYxt" id="team_mrk_succ_msg" style="display:none;">
                                <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <a name="new_message_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[223]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_new_message_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-4 me-2"></i><?php echo $label_details[224]['name']; ?></button>
                                        <button type="button" id="add_new_message_cancel_sub" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4 me-2"></i><?php echo $label_details[225]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="row mb-10">
                                        <div class="col-md-4" id="add_personnel_btn_block">
                                            <button type="button" id="add_personnel_btn" class="btn btn-sm btn-warning my-1 me-3 px-2 fs-8"><?php echo $label_details[232]['name']; ?></button>
                                            <input type="hidden" name="team_token_id" id="team_token_id" />
                                        </div>
                                        <div class="col-md-4">
                                            <button type="button" id="add_students_btn" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><?php echo $label_details[233]['name']; ?></button>
                                        </div>
                                        <div class="col-md-4" id="add_parents_btn_block">
                                            <button type="button" id="add_parents_btn" class="btn btn-sm btn-info my-1 me-3 px-2 fs-8"><?php echo $label_details[234]['name']; ?></button>
                                        </div>
                                    </div>
                                    <div class="row" id="personnel_recipients_block">
                                        <div class="card card-bordered mb-5 personnel">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-orange"><?php echo $label_details[235]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="personnel_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="personnel_rbtn" id="personnel_select_list" checked="checked" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[236]['name']; ?></label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="all" name="personnel_rbtn" id="personnel_send_all" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[237]['name']; ?></label>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12" id="personnel_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[238]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="personnel_team_id" name="personnel_team_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" id="students_recipients_block">
                                        <div class="card card-bordered mb-5 students">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-blue"><?php echo $label_details[240]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="students_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="student_rbtn" id="student_select_list" checked="checked" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[241]['name']; ?> </label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="course" name="student_rbtn" id="student_select_course" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[242]['name']; ?></label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="all" name="student_rbtn" id="student_send_all" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[243]['name']; ?></label>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12"  id="student_course_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[244]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="student_course_id" name="student_course_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12" id="student_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[246]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="student_id_not" name="student_id[]" disabled="disabled" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Select-->
                                                    <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b>Hint</b>: <i><?php echo $label_details[247]['name']; ?></i></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row" id="parents_recipients_block">
                                        <div class="card card-bordered mb-5 parents">
                                            <div class="card-body p-5">
                                                <div class="d-flex flex-stack mb-7">
                                                    <h2 class="fw-bolder text-purple"><?php echo $label_details[248]['name']; ?></h2>
                                                    <button type="button" class="btn btn-danger close-btn" id="parents_recipients_block_close">x</button>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="list" name="parent_rbtn" id="parent_select_list" checked="checked" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[249]['name']; ?></label>
                                                </div>
                                                <div class="form-check form-check-custom form-check-solid dInline me-3">
                                                    <input class="form-check-input" type="radio" value="course" name="parent_rbtn" id="parent_select_course" />
                                                    <label class="form-check-label" for="flexRadioDefault"><?php echo $label_details[250]['name']; ?></label>
                                                </div>
                                                <div class="clearfix"></div>
                                                <br>
                                                <div class="col-lg-12" id="parent_course_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[251]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="parent_course_id" name="parent_course_id[]" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12" id="parent_id_block">
                                                    <div class="input-group mb-5">
                                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[253]['name']; ?></label>
                                                        <div class="input-group flex-nowrap">
                                                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                                                            <div class="overflow-hidden flex-grow-1">
                                                                <select class="form-select rounded-start-0" data-control="select2" id="parent_id" name="parent_id[]" disabled="disabled" multiple>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <!--end::Select-->
                                                    <label for="" class="form-label"><i class="fas fa-info-circle"></i> <b>Hint</b>: <i><?php echo $label_details[254]['name']; ?></i></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12" id="reply_enabled_block">
                                        <div class="mb-4">
                                            <label for="" class="form-label"><?php echo $label_details[261]['name']; ?></label>
                                            <div class="form-check form-switch form-check-custom form-check-solid">
                                                <input class="form-check-input" type="checkbox" value="" id="reply_enabled" name="reply_enabled" />
                                                <label class="form-check-label" for="flexSwitchChecked">
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_new_message_sub_bott" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="fa fa-paper-plane fs-6 me-2"></i><?php echo $label_details[224]['name']; ?></button>
                                        <button type="button" id="add_new_message_cancel_sub_bott" class="btn btn-sm btn-danger my-1 me-3 px-2 fs-8"><i class="las la-times fs-4 me-2"></i><?php echo $label_details[225]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - New Message Module-->

            <!--end::Modals-->
        </div>
        <!--end::Post-->
    
    <!--end::Post-->
<?php echo $footer; ?>
<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $plugins_path; ?>ckeditor/ckeditor.js" type="text/javascript"></script>
<script src="<?php echo $plugins_path; ?>ckeditor/adapters/jquery.js" type="text/javascript"></script>
<script src="<?php echo $js_path;?>team_meetings.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,marks_table,disciplinary_table,absences_table,selected=[],id="<?php  echo $user_det['id'];?>",created_by_fld="",personnel_fld="",student_fld="",groups_fld="",date_created_fld="",deadline_fld="",meeting_status_fld="",status_fld="",del_fld="",term_details=[],personnel_details=[],category_details=[],function_details=[],mark_student_id="",mark_term_id="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,group_id="<?php  echo $user_det['group_id'];?>",role_details=[];

$(document).ready(function() { 
    CKEDITOR.env.isCompatible = true;
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("304", role_details) != -1)
    {
        edit_role=true;
    } 
    $('#opinion').ckeditor();  
    CKEDITOR.instances.opinion.on( 'save', function( evt ) {
        return false; //Prevents Page Refresh
        });
    $('#decision').ckeditor(); 
    CKEDITOR.instances.decision.on( 'save', function( evt ) {
        return false; //Prevents Page Refresh
        });
    $("#date_created_fld").flatpickr({
        dateFormat: "d-m-Y",
        mode: "range"
    });
    $("#deadline_fld").flatpickr({
        dateFormat: "d-m-Y",
        mode: "range"
    });
    $("#deadline_date").flatpickr({
        dateFormat: "d-m-Y"
    });
	team_meetings_details();
});
</script>  
