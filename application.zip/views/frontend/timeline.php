<?php echo $header; ?>
<?php echo $sideheader; ?>
<script type="text/javascript" src="<?php echo $js_path;?>Webviewer/lib/webviewer.min.js"></script>
<?php
    $user_det = $this->session->userdata('user_det');
 ?>
 <link rel="stylesheet" type="text/css" href="<?php echo $assets_path;?>/owlcarousel/css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="<?php echo $assets_path;?>/owlcarousel/css/styles.css">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.2.0/css/font-awesome.min.css">
<link href="<?php echo $assets_path; ?>pdf/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
<style>
    .dropzone-previews {
  margin-top: 0;
  font-size: 24px;
  font-weight: 300;
}
.size {
  font-size: 20px;
  font-weight: 300;
}
.ribbon-content.dropzone-content {
  padding: 20px;
}
.preview img {
  line-height: 0;
  font-size: 0;
  display: block;
  margin: 0 auto;
}
.dropzone-container {
  min-height: 150px;
  border: 1px dashed;
  background: white;
  text-align: center;
}
.justify_content_center{
  justify-content: center;  
}
.input-group.up-imgWrap {
    justify-content: center;
}
.modal:nth-of-type(even) {
    //z-index: 1052 !important;
}
.modal-backdrop.show:nth-of-type(even) {
    //z-index: 1051 !important;
}
.st_files_css tr td:nth-child(4) {
    text-align: center;
}
.st_files_css tr td:nth-child(5) {
    text-align: center;
}
.st_files_css tr td:nth-child(6) {
    text-align: center;
}
#timeline_task_table td:nth-child(9) {
    text-align:center;
}
#timeline_task_table td:nth-child(8) {
    text-align:center;
}
#timeline_task_table td:nth-child(11) {
    text-align:center;
}
#timeline_task_table td:nth-child(10) {
    text-align:center;
}

#task_view_table td:nth-child(4) {
    text-align:center;
}
#task_view_table td:nth-child(5) {
    text-align:center;
}
#task_view_table td:nth-child(6) {
    text-align:center;
}
#task_view_table td:nth-child(7) {
    text-align:center;
}
#task_view_table td:nth-child(8) {
    text-align:center;
}
#task_view_table td:nth-child(11) {
    text-align:center;
}
    </style>
    
 
    <!--begin::Post-->
    <div class="d-flex flex-column flex-column-fluid container-fluid" style="padding-left: 15px !important; padding-right: 20px!important;">
        <!--begin::Toolbar-->
        <div class="toolbar mb-5 mb-lg-7" id="kt_toolbar">
            <!--begin::Page title-->
            <div class="page-title d-flex flex-column me-3">
                <!--begin::Title-->
                <h1 class="d-flex text-dark fw-bolder my-1 fs-3"><?php echo $label_details[0]['name']; ?></h1>
                <!--end::Title-->
                <!--begin::Breadcrumb-->
                <ul class="breadcrumb breadcrumb-dot fw-bold text-gray-600 fs-7 my-1">
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600">
                        <a href="javascript:void(0)" id="dash_bread_id" class="text-gray-600 text-hover-primary"><?php echo $label_details[1]['name']; ?></a>
                    </li>
                    <!--end::Item-->
                    <!--begin::Item-->
                    <li class="breadcrumb-item text-gray-600"><?php echo $label_details[0]['name']; ?></li>
                    <!--end::Item-->
                </ul>
                <!--end::Breadcrumb-->
            </div>
            <!--end::Page title-->
        </div>
        <!--end::Toolbar-->
        
        <!--begin::Post-->
        <div class="content flex-column-fluid noscreen" id="kt_content">
            <div class="row">
                <div class="w-md-200px">
                    <div class="input-group timeline-calendar">
                        <span class="input-group-btn arrow_btn_css">
                            <button class="btn btn-icon-only blue" id="prev">
                                <i class="bi bi-chevron-left"></i>
                            </button>
                        </span>
                        <input type="text" class="form-control" id="timeline_date" data-date-language="en" data-date-format="dd/mm/yyyy">
                        <span class="input-group-btn arrow_btn_css">
                            <button class="btn btn-icon-only blue" id="next">
                                <i class="bi bi-chevron-right"></i>
                            </button>
                        </span>
                    </div>
                </div>
                <div class="w-md-30px count_css">
                    <div class="countdown"></div>
                </div>
                <div class="w-md-150px">
                    <div class="timeline-buttons-container">
                        
                        <div class="pull-left ml-5 count_btn">
                            <button class="btn bold btn-danger" id="stop-refresh" title="Stop" style="display: inline-block;">
                                <i class="fa fa-stop"></i>
                            </button>
                        </div>
                        <div class="pull-left ml-5 count_btn">
                            <button class="btn bold btn-primary" style="display:none;" id="start-refresh" title="Start" >
                                <i class="fa fa-play"></i>
                            </button>
                        </div>
                        <div class="pull-left ml-5 count_btn">
                            <button class="btn bold btn-success" id="reset" title="Reset Timeline" >
                                <i class="fa fa-undo"></i>
                            </button>
                        </div>
                        <div class="pull-left ml-5 count_btn">
                            <button class="btn bold btn-warning" id="refresh" title="Refresh">
                                <i class="fa fa-refresh"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4" id="student_id_timeline_block" style="display:none;">
                    <div class="input-group mb-5">
                        <div class="input-group flex-nowrap">
                            <span class="input-group-text"><i class="las la-list fs-3"></i></span>
                            <div class="overflow-hidden flex-grow-1">
                                <select class="form-select rounded-start-0" data-control="select2" id="student_parent_id" name="student_parent_id">
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="no_timeline_view" style="display:none;"></div>
            <div id="timeline_view" style="display:none;">
                <section id="slider" class="pt-5">
                    <div class="container">
                        <h1 class="text-center"><b><div id="date_display"></div></b></h1>
                        <h1 class="text-center"><b><div id="slider_no_display"></div></b></h1>
                        <div class="slider">
                            <div class="owl-carousel" id="slider_block">
                                
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!--end::Post-->
        
        <!--begin::Modal - Timeline Absences Module-->
        <div class="modal fade" id="timeline_absence" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[2]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_absence_create_id">
                            <form name="add_timeline_absence_form" id="add_timeline_absence_form" class="add_timeline_absence_form">
                            <a name="timeline_absence_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[2]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_absence_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="alert alert-danger errYxt" id="add_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
                                    <div class="alert alert-success errYxt" id="add_succ_msg" style="display:none;">
                                        <i class="fa fa-check-circle" aria-hidden="true"></i><span></span>
                                    </div>
                                    <div class="mark-wrapper">
                                        <!--begin::Table-->
                                        <div class="py-6">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="timeline_absence_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th class="fw-bolder"> <?php echo $label_details[4]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[5]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[6]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[7]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[8]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_absence_sub_bott" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timeline Absences Module-->

        <!--begin::Modal - Timline Disciplinary Module-->
        <div class="modal fade" id="timeline_disciplinary" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[9]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_disciplinary_create_id">
                            <form name="add_timeline_disciplinary_form" id="add_timeline_disciplinary_form" class="add_timeline_disciplinary_form">
                            <a name="timeline_disciplinary_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[9]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_disciplinary_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="alert alert-danger errYxt" id="dis_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
                                    <div class="alert alert-success errYxt" id="dis_succ_msg" style="display:none;">
                                        <i class="fa fa-check-circle" aria-hidden="true"></i><span></span>
                                    </div>
                                    <div class="mark-wrapper">
                                        <!--begin::Table-->
                                        <div class="py-6">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="timeline_disciplinary_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th class="fw-bolder"> <?php echo $label_details[10]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[11]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[12]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[13]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[14]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_disciplinary_sub_bott" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timline Disciplinary Module-->

        <!--begin::Modal - Timline Marks Module-->
        <div class="modal fade" id="timeline_marks" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[15]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_create_id">
                            <form name="add_timeline_marks_form" id="add_timeline_marks_form" class="add_timeline_marks_form">
                            <div class="alert alert-danger errYxt" id="mrk_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="mrk_succ_msg" style="display:none;">
                                <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                            </div>
                            <a name="timeline_marks_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[15]['name']; ?>
                                        </h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_marks_sub" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[16]['name']; ?> *</label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="mark_category_id" name="mark_category_id">
                                                </select>
                                                <input type="hidden" id="min_mark" name="min_mark" />
                                                <input type="hidden" id="max_mark" name="max_mark" />
                                                <input type="hidden" id="medium_mark" name="medium_mark" />
                                                <input type="hidden" id="course_id" name="course_id" />
                                                <input type="hidden" id="total_students" name="total_students" />
                                                <input type="hidden" id="student_ids" name="student_ids" />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[17]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <textarea id="remark" name="remark" rows="8"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[18]['name']; ?> *</label>
                                        <div class="input-group">
                                            <span class="input-group-text" id="basic-addon1"><i class="las la-calendar fs-3 "></i></span>
                                            <input class="form-control" placeholder="<?php echo $label_details[151]['name']; ?>" id="evaluation_date" name="evaluation_date" />
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5">
                                        <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[19]['name']; ?></label>
                                        <div class="input-group flex-nowrap">
                                            <span class="input-group-text"><i class="las la-venus-mars fs-3"></i></span>
                                            <div class="overflow-hidden flex-grow-1">
                                                <select class="form-select rounded-start-0" data-control="select2" id="dossier_id" name="dossier_id">
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mb-10">
                                        <label class="fs-6 form-label text-dark"><?php echo $label_details[20]['name']; ?></label>
                                        <div class="form-check form-switch form-check-custom form-check-solid">
                                            <input class="form-check-input" type="checkbox" checked="checked" id="mark_counts" name="mark_counts">
                                        </div>
                                    </div>
                                    <div class="input-group mb-5 mb-5 marks_chk_css">
                                        <label><?php echo $label_details[21]['name']; ?>: </label>
                                        <span><input type="radio" checked id="marks_from_list_chk" name="marks_assignment" value="1"></span><span>
                                        <label for="teacher"> <?php echo $label_details[22]['name']; ?></label></span>
                                        <span><input type="radio" id="linear_chk" name="marks_assignment" value="2"></span><span><label for="parents"> <?php echo $label_details[23]['name']; ?></label></span>
                                        <div class="nonlinearchk">
                                            <span><input type="radio" id="non_linear_chk" name="marks_assignment" value="3"></span><span><label for="admin"> <?php echo $label_details[24]['name']; ?></label></span>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="mark-wrapper">
                                        <div class="col-lg-12">
                                            <div class="alert alert-danger errYxt" id="mark_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i><span></span></div>
                                            <h4><?php echo $label_details[25]['name']; ?>:</h4>
                                            <a name="mark_scheme_id"></a>
                                        </div>
                                        <div class="marks_points_css">
                                            <div class="col-lg-3 w-md-200px mark_points">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[26]['name']; ?></label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                    <input type="text" id="min_points" name="min_points" class="form-control" aria-describedby="basic-addon1" disabled="disabled">
                                                </div>
                                            </div>
                                            <div class="col-lg-3 w-md-200px mark_points">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[27]['name']; ?></label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                    <input type="text" id="medium_points" name="medium_points" class="form-control" aria-describedby="basic-addon1" disabled="disabled">
                                                </div>
                                            </div>
                                            <div class="col-lg-3 w-md-200px mark_points">
                                                <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[28]['name']; ?></label>
                                                <div class="input-group">
                                                    <span class="input-group-text" id="basic-addon1"><i class="las la-sticky-note fs-3 "></i></span>
                                                    <input type="text" id="max_points" name="max_points" class="form-control" aria-describedby="basic-addon1" disabled="disabled">
                                                </div>
                                            </div>
                                        </div>
                                        <!--begin::Table-->
                                        <div class="py-6">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="student_table">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th class="fw-bolder"> <?php echo $label_details[29]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[30]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[31]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                        <div class="fltl_btn me-3 mb-5">
                                            <button type="button" id="calculate" class="btn btn-primary pb-2 pt-2 fs-7" disabled="disabled">
                                                <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                                <i class="las la-filter"></i>
                                                <!--end::Svg Icon--><?php echo $label_details[32]['name']; ?>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="add_timeline_marks_sub_bott" class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8"><i class="las la-save fs-4"></i><?php echo $label_details[3]['name']; ?></button>
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timline Marks Module-->

        <!--begin::Modal - Timline Files Module-->
        <div class="modal fade" id="timeline_files" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[33]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="timeline_create_id">
                            <form name="add_timeline_files_form" id="add_timeline_files_form" class="add_timeline_files_form">
                            <a name="timeline_files_table_create_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-2  hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3>
                                            <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[33]['name']; ?>
                                        </h3>
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9">
                                    <div class="alert alert-danger errYxt" id="fil_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                                    <div class="alert alert-success errYxt" id="fil_succ_msg" style="display:none;">
                                        <i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span>
                                    </div>
                                    <ul class="nav nav-tabs nav-line-tabs nav-line-tabs-2x mb-5 fs-6">
                                        <li class="nav-item">
                                            <a class="nav-link active btn btn-flex btn-active-light-success py-4" data-bs-toggle="tab" href="#kt_tab_pane_1">
                                                <span class="svg-icon svg-icon-2 svg-icon-primary me-3">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M11 2.375L2 9.575V20.575C2 21.175 2.4 21.575 3 21.575H9C9.6 21.575 10 21.175 10 20.575V14.575C10 13.975 10.4 13.575 11 13.575H13C13.6 13.575 14 13.975 14 14.575V20.575C14 21.175 14.4 21.575 15 21.575H21C21.6 21.575 22 21.175 22 20.575V9.575L13 2.375C12.4 1.875 11.6 1.875 11 2.375Z" fill="black" />
                                                    </svg>
                                                </span>
                                                <!--end::Svg Icon-->
                                                <span class="d-flex flex-column align-items-start">
                                                    <span class="fs-4 fw-bolder"><?php echo $label_details[34]['name']; ?></span>
                                                </span>
                                            </a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link btn btn-flex btn-active-light-info py-4" data-bs-toggle="tab" href="#kt_tab_pane_2">
                                                <span class="svg-icon svg-icon-2 svg-icon-primary">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                        <path d="M13.0079 2.6L15.7079 7.2L21.0079 8.4C21.9079 8.6 22.3079 9.7 21.7079 10.4L18.1079 14.4L18.6079 19.8C18.7079 20.7 17.7079 21.4 16.9079 21L12.0079 18.8L7.10785 21C6.20785 21.4 5.30786 20.7 5.40786 19.8L5.90786 14.4L2.30785 10.4C1.70785 9.7 2.00786 8.6 3.00786 8.4L8.30785 7.2L11.0079 2.6C11.3079 1.8 12.5079 1.8 13.0079 2.6Z" fill="black" />
                                                    </svg>
                                                </span>
                                                <!--end::Svg Icon-->
                                                <span class="d-flex flex-column align-items-start">
                                                    <span class="fs-4 fw-bolder"><?php echo $label_details[35]['name']; ?></span>
                                                </span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="kt_tab_pane_1" role="tabpanel">
                                            <div class="card mb-7 border">
                                                <div class="card-header hd-col-2" id="student_files_container">
                                                    <!--begin::Heading-->
                                                    <div class="card-title">
                                                        <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20.57 24"><path d="M18.6,15.53a3.45,3.45,0,0,0-.57,0,4.34,4.34,0,1,0,.57,0ZM20,19h-1a.08.08,0,0,0-.08.09v3.47a.11.11,0,0,1-.09.09H17.33a.09.09,0,0,1-.09-.09V19.06a.09.09,0,0,0-.09-.09h-1a.09.09,0,0,1-.07-.15L18,16.9a.08.08,0,0,1,.12,0l1.28,1.27.65.65A.09.09,0,0,1,20,19Zm-7.36.78a5.36,5.36,0,0,0,.35,1.92c-2.64,0-5.29,0-7.94-.08a6.56,6.56,0,0,1-1.07-.15,2.6,2.6,0,0,1-2.21-2.79,5.76,5.76,0,0,1,5.22-6,23.81,23.81,0,0,0,2.82,4.77,16.31,16.31,0,0,1,.17-1.92c.15-.72-.78-.86-.68-1.55a3.62,3.62,0,0,0,2.59,0,.74.74,0,0,1-.28.72c-.5.31-.41.76-.37,1.21s.08,1,.14,1.57a24.15,24.15,0,0,0,2.81-4.77,5.48,5.48,0,0,1,2.94,1.16c.2.15.38.32.56.48A5.45,5.45,0,0,0,12.59,19.75ZM6.33,3.87,5,3.31c.07.92,0,1.82.07,2.72s.38,1.9-.23,2.84a3.05,3.05,0,0,1-.31-1.71c.1-.82.14-1.64.2-2.46,0-.16.07-.38,0-.47-.32-.38-.15-.64.18-.85-.18-.33-.64-.25-.75-.61s.23-.27.39-.34L9.78.16a1.87,1.87,0,0,1,1.52,0l5.23,2.27a.51.51,0,0,1,.4.39,4.89,4.89,0,0,1-1.62.79.79.79,0,0,0-.56.83,32.79,32.79,0,0,1,.15,3.29,7.44,7.44,0,0,1-1.84,4.35,3.25,3.25,0,0,1-5,0,7.42,7.42,0,0,1-1.79-6.2C6.32,5.21,6.26,4.56,6.33,3.87Zm7.44,2.22c-.8.35-1.56.66-2.3,1a2.1,2.1,0,0,1-1.86,0c-.75-.34-1.52-.66-2.3-1a6.75,6.75,0,0,0,0,1.79c-.2.07-.34-.23-.55-.09a6.24,6.24,0,0,0,1.71,3.89,2.88,2.88,0,0,0,4.2,0,6.14,6.14,0,0,0,1.72-4l-.56.21A7,7,0,0,0,13.77,6.09Z" transform="translate(-1.72)" style="fill:#58585a"/></svg></span> <?php echo $label_details[36]['name']; ?></h4>
                                                        
                                                    </div>
                                                    <!--end::Heading-->
                                                </div>
                                                <!--begin::Card body-->
                                                <div class="card-body px-8 pb-7 pt-2" id="student_files_fields">
                                                    <!--begin::Compact form-->
                                                    <div class="align-items-center">
                                                        <!--begin::Col-->
                                                        <div class="col-xxl-12">
                                                            <!--begin::Table-->
                                                            <div class="files_css">
                                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="student_files_list">
                                                                    <!--begin::Table head-->
                                                                    <thead >
                                                                        <tr>
                                                                            <th class="fw-bolder"> <?php echo $label_details[37]['name']; ?> </th>
                                                                            <th class="fw-bolder"> <?php echo $label_details[38]['name']; ?> </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <!--end::Table head-->
                                                                    <!--begin::Table body-->
                                                                    <tbody class=" text-gray-800 actionBtns_table">
                                                                    </tbody>
                                                                    <!--end::Table body-->
                                                                </table>
                                                            </div>
                                                            <!--end::Table-->
                                                        </div>
                                                        <!--end::Col-->
                                                        <!--begin::Input group-->
                                                        <!--end:Action-->
                                                    </div>
                                                    <!--end::Compact form-->
                                                </div>
                                                <!--end::Card body-->
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="kt_tab_pane_2" role="tabpanel">
                                            <div class="container tea_files">
                                                <div class="row">
                                                    <div class="col-md-12 dropzone-template-row dz-image-preview">
                                                        <div class="dropzone-container p-10">
                                                            <div id="teacher_file_upload">
                                                            </div>
                                                            <div class="row">
                                                                <div class="dz-message needsclick mt-4">
                                                                    <!--begin::Icon-->
                                                                    <i class="bi bi-file-earmark-arrow-up text-primary fs-3x"></i>
                                                                    <!--end::Icon-->
                                                                    <!--begin::Info-->
                                                                    <div class="ms-4">
                                                                        <h3 class="fs-5 fw-bolder text-gray-900 mb-1"><?php echo $label_details[39]['name']; ?></h3>
                                                                    </div>
                                                                    <!--end::Info-->
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-group mb-5 mt-5 p-5 ">
                                                                    <div class="input-group up-imgWrap">
                                                                        <div class="file btn btn-lg btn-primary up-image">
                                                                            <i class="bi bi-plus fs-1"></i><?php echo $label_details[40]['name']; ?>
                                                                            <input id="upload_teacher_files" type="file" name="upload_teacher_files"/>
                                                                            <input type="hidden" id="course_id" />
                                                                            <input type="hidden" id="allow_uploads" />
                                                                        </div>
                                                                    </div>  
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="card mb-7 border">
                                                <div class="card-header hd-col-2" id="teacher_files_container">
                                                    <!--begin::Heading-->
                                                    <div class="card-title">
                                                        <h4><span class="svg-icon svg-icon-info svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 22.28"><path d="M22.12,15.08,21.73,15A4,4,0,0,0,21,15a5,5,0,0,0-1.47.22l-1.26-3.53a.78.78,0,0,0-.22-.39c.18,1.45.37,2.89.55,4.32a5,5,0,0,0-2.32,5.88H6.63V19.81H9.4c.38-2.84.75-5.66,1.13-8.54a.91.91,0,0,0-.23.37C9.71,13.1,9.13,14.57,8.54,16a1.22,1.22,0,0,1-2.09.4q-2.12-2.48-4.18-5a1.12,1.12,0,0,1-.15-1.29.33.33,0,0,0-.07-.44L.42,7.65c-.48-.6.07.1-.42-.52.14-.1.25-.19.38-.3A2.61,2.61,0,0,1,.55,7l.5.62c.92,1.16.48.62,1.41,1.79.07.08.11.21.26.12A1.29,1.29,0,0,1,4.3,10c.45.59.94,1.17,1.42,1.76L7,13.31c.36-.88.7-1.72,1-2.56a3.86,3.86,0,0,1,3.65-2.48H17a3.75,3.75,0,0,1,3.62,2.55c.44,1.23.88,2.46,1.31,3.69C22,14.7,22.06,14.9,22.12,15.08ZM24,19.81a3.33,3.33,0,0,1-6.3,1.5,3.29,3.29,0,0,1-.36-1.5,3.32,3.32,0,0,1,3.32-3.34,2.15,2.15,0,0,1,.45,0A3.33,3.33,0,0,1,24,19.81Zm-1.83-.61-.45-.63-1-1a.07.07,0,0,0-.1,0l-1.5,1.51a.06.06,0,0,0,0,.11H20a.07.07,0,0,1,.07.07V22a.08.08,0,0,0,.07.08h1.1a.08.08,0,0,0,.07-.08V19.27a.07.07,0,0,1,.07-.07ZM14,7.45a3.3,3.3,0,1,0-3.31-3.3A3.31,3.31,0,0,0,14,7.45Z" transform="translate(0 -0.86)" style="fill:#58585a"/></svg></span> <?php echo $label_details[41]['name']; ?></h4>
                                                        
                                                    </div>
                                                    <!--end::Heading-->
                                                </div>
                                                <!--begin::Card body-->
                                                <div class="card-body px-8 pb-7 pt-2" id="teacher_files_fields">
                                                    <!--begin::Compact form-->
                                                    <div class="align-items-center">
                                                        <!--begin::Col-->
                                                        <div class="col-xxl-12">
                                                            <!--begin::Table-->
                                                            <div class="files_css">
                                                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="teacher_files_list">
                                                                    <!--begin::Table head-->
                                                                    <thead >
                                                                        <tr>
                                                                            <th class="fw-bolder"> <?php echo $label_details[42]['name']; ?> </th>
                                                                            <th class="fw-bolder"> <?php echo $label_details[43]['name']; ?> </th>
                                                                            <th class="fw-bolder"> <?php echo $label_details[44]['name']; ?> </th>
                                                                            <th class="fw-bolder"> <?php echo $label_details[45]['name']; ?> </th>
                                                                        </tr>
                                                                    </thead>
                                                                    <!--end::Table head-->
                                                                    <!--begin::Table body-->
                                                                    <tbody class=" text-gray-800 actionBtns_table">
                                                                    </tbody>
                                                                    <!--end::Table body-->
                                                                </table>
                                                            </div>
                                                            <!--end::Table-->
                                                        </div>
                                                        <!--end::Col-->
                                                        <!--begin::Input group-->
                                                        <!--end:Action-->
                                                    </div>
                                                    <!--end::Compact form-->
                                                </div>
                                                <!--end::Card body-->
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                               
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timline Files Module-->

        <!--begin::Modal - Student Timline Files Module-->
        <div class="modal fade" id="student_timeline_files" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[33]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="student_timeline_files_create_id">
                            <!--begin::Card header-->
                            <div class="card-header mb-2  hd-col-3">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h3>
                                        <span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                        <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                        <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                        <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                        <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                        <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                        </svg></span> <?php echo $label_details[33]['name']; ?>
                                    </h3>
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body p-0 px-9">
                                <div class="align-items-center">
                                    <!--begin::Col-->
                                    <div class="col-xxl-12">
                                        <!--begin::Table-->
                                        <div class="files_css">
                                            <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 sin_cls" id="student_timeline_files_list">
                                                <!--begin::Table head-->
                                                <thead >
                                                    <tr>
                                                        <th class="fw-bolder"> <?php echo $label_details[46]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[47]['name']; ?> </th>
                                                        <th class="fw-bolder"> <?php echo $label_details[48]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align:center"> <?php echo $label_details[49]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align:center"> <?php echo $label_details[50]['name']; ?> </th>
                                                        <th class="fw-bolder" style="text-align:center"> <?php echo $label_details[51]['name']; ?> </th>
                                                    </tr>
                                                </thead>
                                                <!--end::Table head-->
                                                <!--begin::Table body-->
                                                <tbody class=" text-gray-800 actionBtns_table st_files_css">
                                                </tbody>
                                                <!--end::Table body-->
                                            </table>
                                        </div>
                                        <!--end::Table-->
                                    </div>
                                    <!--end::Col-->
                                    <!--begin::Input group-->
                                    <!--end:Action-->
                                </div>
                                
                                </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timline Marks Module-->

        <!--begin::Modal - Timline Preview Module-->
        <div class="modal fade" id="timeline_preview" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[52]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-xl-5">
                        <!--begin::Form-->
                        <div class="card mb-5 mb-lg-10 border pb-4" id="dossiers_preview_id">
                            <form name="preview_dossiers_form" id="preview_dossiers_form" class="preview_dossiers_form">
                                <a name="dossiers_preview_id"></a>
                                <!--begin::Card header-->
                                <div class="card-header mb-10 hd-col-3">
                                    <!--begin::Heading-->
                                    <div class="card-title">
                                        <h3><span class="svg-icon svg-icon-success svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path opacity="0.3" d="M19 22H5C4.4 22 4 21.6 4 21V3C4 2.4 4.4 2 5 2H14L20 8V21C20 21.6 19.6 22 19 22ZM12.5 18C12.5 17.4 12.6 17.5 12 17.5H8.5C7.9 17.5 8 17.4 8 18C8 18.6 7.9 18.5 8.5 18.5L12 18C12.6 18 12.5 18.6 12.5 18ZM16.5 13C16.5 12.4 16.6 12.5 16 12.5H8.5C7.9 12.5 8 12.4 8 13C8 13.6 7.9 13.5 8.5 13.5H15.5C16.1 13.5 16.5 13.6 16.5 13ZM12.5 8C12.5 7.4 12.6 7.5 12 7.5H8C7.4 7.5 7.5 7.4 7.5 8C7.5 8.6 7.4 8.5 8 8.5H12C12.6 8.5 12.5 8.6 12.5 8Z" fill="black"/>
                                            <rect x="7" y="17" width="6" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="12" width="10" height="2" rx="1" fill="black"/>
                                            <rect x="7" y="7" width="6" height="2" rx="1" fill="black"/>
                                            <path d="M15 8H20L14 2V7C14 7.6 14.4 8 15 8Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[53]['name']; ?></h3>
                                    </div>
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="preview_download_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-download fs-4"></i><?php echo $label_details[54]['name']; ?></button>
                                        <button type="button" id="preview_print_pdf_dossiers_sub"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-eye fs-4"></i><?php echo $label_details[55]['name']; ?></button>
                                       
                                    </div>
                                    <!--end::Heading-->
                                </div>
                                <!--end::Card header-->
                                <!--begin::Card body-->
                                <div class="card-body p-0 px-9" id="print_preview_body">
                                    <div class="portlet-body my-10">
                                        <div class="dossier-preview-container p-0">
                                            <!-- print pdf page1 start -->
                                            <div>
                                                <table style="width: 100%;">
                                                    <tbody>
                                                        <tr>
                                                            <td valign="top" style="width: 190px;"><img id="school_logo_preview" alt="" style="padding: 15px; max-width: 100%;" /></td>
                                                            <td valign="top"><strong><span id="school_name"></span><br></strong><span id="school_gen_email"></span><br><span id="school_address"></span><br><span id="school_phoneno"></span></td>
                                                            <td valign="top" style="width: 140px;text-align:right;"><strong><?php echo $label_details[56]['name']; ?>: </strong><span id="pr_start_date"></span><br><strong><?php echo $label_details[127]['name']; ?>: </strong><span id="pr_end_date"></span><br><strong><?php echo $label_details[57]['name']; ?>: </strong><span id="pr_term"></span></td>
                                                            <td valign="top" style="width: 100px;" align="center"><img id="pr_qr_code" alt="" style="padding: 0px 5px; max-width: 100%;" /><span id="pr_dossier_key"></span></td>
                                                        </tr>
                                                    </tbody>
                                                    <tbody>
                                                        <tr>
                                                            <td colspan="2">
                                                                <ul style="list-style: none; padding-left: 15px;">
                                                                    <li>
                                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[58]['name']; ?>:</strong> <span id="pr_name"></span></h1>
                                                                    </li>
                                                                    <li>
                                                                        <h1 style="font-weight: normal;color: #36c6d3;"><strong><?php echo $label_details[59]['name']; ?>:</strong> <span id="pr_course"></span></h1>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal; color: #578ebe ;"><strong><?php echo $label_details[60]['name']; ?>:</strong> <span id="pr_teacher"></span></h3>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal;"><strong><?php echo $label_details[61]['name']; ?>:</strong> <span id="pr_language"></span></h3>
                                                                    </li>
                                                                    <li>
                                                                        <h3 style="font-weight: normal;"><strong><?php echo $label_details[62]['name']; ?>:</strong> <span id="pr_preparation_time"></span></h3>
                                                                    </li>
                                                                    
                                                                </ul>
                                                            </td>
                                                            <td colspan="2" align="right" style="width: 140px;"><img id="pr_teaser_image" alt="" style="padding: 5px; max-width: 100%;" /><span id="pr_teaser_text"></span></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                                <br />
                                                <div id="pr_goals_table">
                                                    <table style="border: 1px solid #ddd; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[63]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_goals"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_path_to_success_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[64]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_path_to_success"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_task_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[65]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_task"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_useful_links_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[67]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_useful_links"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_description_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;">DOCUMENTS</h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_description"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_media_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[165]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_media"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_learning_materials_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[68]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_learning_materials"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_solutions_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[69]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_solutions"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                                <div id="pr_evaluations_table">
                                                    <table style="border-left: 5px solid #796799; background-color: #efefef;" width="100%" cellspacing="0" cellpadding="0">
                                                        <tbody>
                                                            <tr>
                                                                <th style="padding: 5px 15px;"><h2 style="margin: 0; color: #796799;"><?php echo $label_details[70]['name']; ?></h2></th>
                                                            </tr>
                                                        </tbody>
                                                        <tbody style="">
                                                            <tr>
                                                                <td style="padding: 15px;">
                                                                    <table style="background-color: #fff;" width="100%" cellspacing="10" cellpadding="10">
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    <span id="pr_evaluations"></span>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                        </tbody>
                                                    </table>
                                                    <br />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-box px-8">
                                    <div class="">&nbsp;</div>
                                                        <!--begin::Toolbar-->
                                    <div class="card-toolbar float-xxl-end">
                                        <button type="button" id="preview_download_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-download fs-4"></i><?php echo $label_details[71]['name']; ?></button>
                                        <button type="button" id="preview_print_pdf_dossiers_sub_bott"  class="btn btn-sm btn-primary my-1 me-3 px-2 fs-8">
                                            <i class="las la-eye fs-4"></i><?php echo $label_details[72]['name']; ?></button>
                                        
                                    </div>
                                    <!--end::Toolbar-->
                                </div>
                                <!--end::Card body-->
                            </form>
                        </div>
                        <!--end::Form-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Timline Preview Module-->

        <!--begin::Modal - Delete Module-->
        <div class="modal fade" id="delete_timeline_uploads" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[73]['name']; ?> <?php echo $label_details[74]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_timeline_uploads_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[75]['name']; ?> <?php echo $label_details[74]['name']; ?>?</label>
                                    </div>
                                    <input type="hidden" id="file_id" />
                                    <input type="hidden" id="del_stu_upload_file_id" />
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_timeline_uploads_sub" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[76]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[77]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
        <!--end::Modal - Delete Module-->

        <!--begin::Modal - Delete Student Module-->
        <div class="modal fade" id="delete_timeline_uploads_teacher" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[73]['name']; ?> <?php echo $label_details[74]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg_teacher" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg_teacher" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_timeline_uploads_form_teacher">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[75]['name']; ?> <?php echo $label_details[74]['name']; ?>?</label>
                                    </div>
                                    <input type="hidden" id="file_id_teacher" />
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_timeline_uploads_sub_teacher" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[76]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn_teacher" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[77]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
        <!--end::Modal - Delete Module-->

        <!--begin::Modal - Delete Teacher Student Module-->
        <div class="modal fade" id="delete_timeline_uploads_teacher_student" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[73]['name']; ?> <?php echo $label_details[74]['name']; ?></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="del_err_msg_teacher_student" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="del_succ_msg_teacher_student" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="delete_timeline_uploads_form_teacher_student">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><?php echo $label_details[75]['name']; ?> <?php echo $label_details[74]['name']; ?>?</label>
                                    </div>
                                    <input type="hidden" id="file_id_teacher_student" />
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="delete_timeline_uploads_sub_teacher_student" class="btn btn-primary"><i class="las la-trash fs-5"></i><?php echo $label_details[76]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_del_btn_teacher_student" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[77]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
        <!--end::Modal - Delete Module-->
        <!--begin::Modal - Preview Notifiations Module-->
        <div class="modal fade" id="preview_notifications" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-dialog-centered mw-1000px">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"><?php echo $label_details[161]['name']; ?></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y">
                        <!--begin::Messenger-->
                        <div class="card w-100 rounded-0 border-0" id="kt_drawer_chat_messenger">
                            <!--begin::Card header-->
                            <!--begin::User-->
                            <div class="d-flex p-6 card-box border-bot">
                                <div class="fs-4" id="pr_subject"></div>
                                <div class="fs-4 me-1 mb-2 lh-1 ml-auto card-toolbar"><div id="pr_due_date"></div></div>
                            </div>
                            <!--end::User-->
                            <!--end::Title-->
                            <!--end::Card header-->
                            <!--begin::Card body-->
                            <div class="card-body" id="kt_drawer_chat_messenger_body">
                                <!--begin::Messages-->
                                <div class="scroll-y me-n5 pe-5" data-kt-element="messages" data-kt-scroll="true" data-kt-scroll-activate="true" data-kt-scroll-height="auto" data-kt-scroll-dependencies="#kt_drawer_chat_messenger_header, #kt_drawer_chat_messenger_footer" data-kt-scroll-wrappers="#kt_drawer_chat_messenger_body" data-kt-scroll-offset="0px">
                                    <div id="message_body"></div>
                                </div>
                                <!--end::Messages-->
                            </div>
                            <!--end::Card body-->
                        </div>
                        <!--end::Messenger-->
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        <!--end::Modal - Preview Notifiations Module-->
        <div class="modal fade" id="pdf_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
            <!--begin::Modal dialog-->
            <div class="modal-dialog modal-fullscreen">
                <!--begin::Modal content-->
                <div class="modal-content">
                    <!--begin::Modal header-->
                    <div class="modal-header">
                        <!--begin::Modal title-->
                        <h2 class="fw-bolder"></h2>
                        <!--end::Modal title-->
                        <!--begin::Close-->
                        <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                            <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                            <span class="svg-icon svg-icon-1">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                    <rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
                                    <rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
                                </svg>
                            </span>
                            <!--end::Svg Icon-->
                        </div>
                        <!--end::Close-->
                    </div>
                    <!--end::Modal header-->
                    <!--begin::Modal body-->
                    <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                        <div id="pdf_container"></div>
                    </div>
                    <!--end::Modal body-->
                </div>
                <!--end::Modal content-->
            </div>
            <!--end::Modal dialog-->
        </div>
        
        <?php echo $video_modal; ?>   
        
        
    <!--begin::Modal - PDF Ediotr Module-->
    <div class="modal fade task_modal_cls_large" id="teach_pdf_view_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-fullscreen">
            <!--begin::Modal content-->
            <div class="modal-content">
                <!--begin::Modal header-->
                <div class="pdf_close_cls">
                    <!--begin::Modal title-->
                    <h2 class="fw-bolder"></h2>
                    <!--end::Modal title-->
                    <!--begin::Close-->
                    <div class="" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <div class="close_pdf_div">
                            <span><i class="fa fa-arrow-left"></i></span>
                            <span class="close_pdf">
                            <?php echo $label_details[266]['name']; ?>
                            </span>
                        </div>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body scroll-y">
                    <div id="pdftron_viewer"></div>
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - PDF Tools Module-->

    <!--begin::Modal - PDF Timeline Module-->
    <div class="modal fade" id="timeline_task_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-fullscreen">
            <!--begin::Modal content-->
            <div class="modal-content">
                <!--begin::Modal header-->
                <div class="pdf_close_cls">
                    <!--begin::Modal title-->
                    <h2 class="fw-bolder"></h2>
                    <!--end::Modal title-->
                    <!--begin::Close-->
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body scroll-y">
                    <div class="card mb-lg-10 border noscreen" id="full_content">
                        <div class="card" id="page_container">
                            <!--begin::Card header-->
                            <div class="card-header mb-5 hd-col-1">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                            <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[265]['name']; ?></h3>                                            
                                    
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--end::Card header-->
                        </div>
                        <!--begin::Card body-->
                        <div class="card-body pt-0" id="add_timeline_container">
                            <div class="card-box">
                                <!--begin::Add customer-->
                                <span>&nbsp;</span>
                                <!--begin::Toolbar-->
                                <div class="card-toolbar">
                                <?php if(in_array(725,$role_details)) { ?>
                                    <button type="button" id="timeline_publish_btn_id" class="btn btn-sm btn-primary px-2"><?php echo $label_details[264]['name']; ?> <i class="fas fa-upload fs-6"></i></button>
                                    <?php } ?>
                                    <?php if(in_array(726,$role_details)) { ?>
                                    <button type="button" id="timeline_lock_btn_id" class="btn btn-sm btn-info px-2"><?php echo $label_details[263]['name']; ?> <i class="las la-lock"></i></button>
                                    <?php } ?>
                                    <?php if(in_array(747,$role_details)) { ?>
                                    <button type="button" id="timeline_task_restore_btn_id" style="display:none;" class="btn btn-sm btn-warning px-2"  data-target="#restore_tasks" data-toggle="modal"><?php echo $label_details[262]['name']; ?> <i class="las la-undo fs-3"></i></button> 
                                    <?php } ?>
                                    <?php if(in_array(728,$role_details)) { ?>
                                    <button type="button" id="timeline_task_delete_btn_id" class="btn btn-sm btn-danger px-2" data-target="#delete_tasks" data-toggle="modal"><?php echo $label_details[261]['name']; ?> <i class="las la-trash-alt fs-3"></i></button>      
                                    <?php } ?>                                 
                                </div>
                                <!--end::Toolbar-->
                                <!--end::Add customer-->
                            </div>
                            <!--begin::Table-->
                            <div class="">
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="timeline_task_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                            <th></th>
                                            <th style="text-align: center;" data-priority="1" width="20px" rowspan="1" colspan="1">
                                                <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                    <input type="checkbox" id="timeline_task_table_check_all" class="group-checkable" name="timeline_task_table_check_all" >
                                                    <span></span>
                                                </label>
                                            </th>
                                            <th data-priority="2" class="fw-bolder"> <?php echo $label_details[260]['name']; ?> </th>
                                            <th data-priority="4" class="fw-bolder"> <?php echo $label_details[259]['name']; ?> </th>
                                            <th data-priority="5" class="fw-bolder"> <?php echo $label_details[258]['name']; ?> </th>
                                            <th data-priority="6" class="fw-bolder"> <?php echo $label_details[257]['name']; ?> </th>
                                            <th class="fw-bolder"> <?php echo $label_details[256]['name']; ?> </th>
                                            <th class="fw-bolder"> <?php echo $label_details[255]['name']; ?> </th>
                                            <th data-priority="7" class="fw-bolder"> <?php echo $label_details[254]['name']; ?> </th>
                                            <th class="fw-bolder" data-priority="8"> <?php echo $label_details[253]['name']; ?> </th>
                                            <th data-priority="9" class="fw-bolder"> <?php echo $label_details[252]['name']; ?> </th>
                                            <th data-priority="10" class="fw-bolder"> <?php echo $label_details[252]['name']; ?> </th>
                                            <th data-priority="3" class="w-md-100px fw-bolder" style="text-align: center;"> <?php echo $label_details[251]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 timeline_task_actionBtns_table">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                            </div>
                            <!--end::Table-->
                        </div>
                        <!--end::Card body-->
                    </div>                    
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - PDF Timeline Module-->

    <!--begin::Modal - PDF Timeline Module-->
    <div class="modal fade task_modal_cls" id="student_timeline_task_modal" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <!--begin::Modal dialog-->
        <div class="modal-dialog modal-fullscreen">
            <!--begin::Modal content-->
            <div class="modal-content">
                <!--begin::Modal header-->
                <div class="pdf_close_cls">
                    <!--begin::Modal title-->
                    <h2 class="fw-bolder"></h2>
                    <!--end::Modal title-->
                    <!--begin::Close-->
                    <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                        <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                        <span class="svg-icon svg-icon-1">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                        </span>
                        <!--end::Svg Icon-->
                    </div>
                    <!--end::Close-->
                </div>
                <!--end::Modal header-->
                <!--begin::Modal body-->
                <div class="modal-body scroll-y">
                    <div class="card mb-lg-10 border noscreen" id="full_content">
                        <div class="card" id="page_container">
                            <!--begin::Card header-->
                            <div class="card-header mb-5 hd-col-1">
                                <!--begin::Heading-->
                                <div class="card-title">
                                    <h3><span class="svg-icon svg-icon-danger svg-icon-2hx"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                            <path d="M21 7H3C2.4 7 2 6.6 2 6V4C2 3.4 2.4 3 3 3H21C21.6 3 22 3.4 22 4V6C22 6.6 21.6 7 21 7Z" fill="black"/>
                                            <path opacity="0.3" d="M21 14H3C2.4 14 2 13.6 2 13V11C2 10.4 2.4 10 3 10H21C21.6 10 22 10.4 22 11V13C22 13.6 21.6 14 21 14ZM22 20V18C22 17.4 21.6 17 21 17H3C2.4 17 2 17.4 2 18V20C2 20.6 2.4 21 3 21H21C21.6 21 22 20.6 22 20Z" fill="black"/>
                                            </svg></span> <?php echo $label_details[250]['name']; ?></h3>                                            
                                    
                                </div>
                                <!--end::Heading-->
                            </div>
                            <!--end::Card header-->
                        </div>
                        <!--begin::Card body-->
                        <div class="card-body pt-0" id="add_timeline_container">
                            <div class="card-box">
                                <!--begin::Add customer-->
                                <span>&nbsp;</span>
                                <!--begin::Toolbar-->
                                <div class="card-toolbar">
                                    <?php if(in_array(726,$role_details)) { ?>
                                    <button type="button" id="lock_teacher_view_btn_id" class="btn btn-sm btn-info px-2"><?php echo $label_details[249]['name']; ?> <i class="las la-lock"></i></button>
                                    <?php } ?>
                                    <?php if(in_array(727,$role_details)) { ?>
                                    <button type="button" id="grade_teacher_view_btn_id" class="btn btn-sm btn-success px-2"><?php echo $label_details[248]['name']; ?> <i class="fas fa-graduation-cap"></i></button>
                                    <?php } ?>                                  
                                </div>
                                <!--end::Toolbar-->
                                <!--end::Add customer-->
                            </div>
                            <!--begin::Table-->
                            <div class="">
                                <table class="table align-middle table-row-dashed fs-6 gy-3 gx-3 less_cls" id="task_view_table">
                                    <!--begin::Table head-->
                                    <thead >
                                        <tr>
                                        <th></th>
                                        <th style="text-align: center;" data-priority="1" width="20px" rowspan="1" colspan="1">
                                            <label class="mt-checkbox mt-checkbox-single mt-checkbox-outline ms-xxl-1">
                                                <input type="checkbox" id="task_view_table_check_all" class="group-checkable" name="task_view_table_check_all" >
                                                <span></span>
                                            </label>
                                        </th>
                                        <th data-priority="2" class="fw-bolder"> <?php echo $label_details[247]['name']; ?> </th>
                                        <th data-priority="4" class="fw-bolder"> <?php echo $label_details[246]['name']; ?> </th>
                                        <th data-priority="5" class="fw-bolder"> <?php echo $label_details[245]['name']; ?> </th>
                                        <th data-priority="6" class="fw-bolder"> <?php echo $label_details[244]['name']; ?> </th>
                                        <th data-priority="7" class="fw-bolder"> <?php echo $label_details[243]['name']; ?> </th>
                                        <th data-priority="8" class="fw-bolder"> <?php echo $label_details[242]['name']; ?> </th>
                                        <th class="fw-bolder"> <?php echo $label_details[241]['name']; ?> </th>
                                        <th class="fw-bolder"> <?php echo $label_details[240]['name']; ?> </th>
                                        <th data-priority="3" class="fw-bolder" style="text-align: center;"> <?php echo $label_details[239]['name']; ?> </th>
                                        </tr>
                                    </thead>
                                    <!--end::Table head-->
                                    <!--begin::Table body-->
                                    <tbody class=" text-gray-800 task_actionBtns_table">
                                    </tbody>
                                    <!--end::Table body-->
                                </table>
                            </div>
                            <!--end::Table-->
                        </div>
                        <!--end::Card body-->
                    </div>                    
                </div>
                <!--end::Modal body-->
            </div>
            <!--end::Modal content-->
        </div>
        <!--end::Modal dialog-->
    </div>
    <!--end::Modal - PDF Timeline Module-->
    
        <!--begin::Modal - Task Modals-->
        <div class="modal fade task_modal_cls" id="task_modals" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><span id="modal_header_title"></span></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                                    <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                                    <div class="tool_tip">
                                        <span class="tool_tip_text"><?php echo $label_details[236]['name']; ?></span>
                                        <i class="las la-edit fs-1"></i>
                                    </div>
                                    <!--end::Svg Icon-->
                                </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="tskmod_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="tskmod_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="task_modals_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="me-5 fw-bold text-center">
                                        <label class="fs-6"><span id="modal_alert_title"></span></label>
                                        <label class="fs-6"><span id="modal_task_title"></span>?</label>   
                                        <input type="hidden" id="student_submit_id" />                                     
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="modal_tasks_sub" class="btn btn-primary"><span id="modal_alert_icon"></span><span id="modal_task_btn_text"></span>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_tskmod_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[238]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>

            <!--begin::Modal - Task Comments Modals-->
            <div class="modal fade task_modal_cls_large" id="task_comments_modals" tabindex="-1" aria-hidden="true" data-backdrop="static" data-keyboard="false">
                <!--begin::Modal dialog-->
                <div class="modal-dialog modal-dialog-centered mw-650px">
                    <!--begin::Modal content-->
                    <div class="modal-content">
                        <!--begin::Modal header-->
                        <div class="modal-header">
                            <!--begin::Modal title-->
                            <h2 class="fw-bolder"><?php echo $label_details[237]['name']; ?></span></h2>
                            <!--end::Modal title-->
                            <!--begin::Close-->
                            <div class="btn btn-icon btn-sm btn-active-icon-primary" data-bs-dismiss="modal">
                                <!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
                                <button type="button" id="label_40_5" class="pb-3 pt-3 fs-7 bulk_label_cls" style="display:none;">
                        <!--begin::Svg Icon | path: icons/duotune/general/gen031.svg-->
                        <div class="tool_tip">
                            <span class="tool_tip_text"><?php echo $label_details[236]['name']; ?></span>
                            <i class="las la-edit fs-1"></i>
                        </div>
                        <!--end::Svg Icon-->
                    </button>
                                <span class="svg-icon svg-icon-1">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M12,0A12,12,0,1,1,0,11.93,12,12,0,0,1,12,0Zm9,12a9,9,0,1,0-9,9A9.07,9.07,0,0,0,21,12ZM8.76,6.58c-.72-.72-1-.74-1.82-.08a2.79,2.79,0,0,0-.83,1.06.74.74,0,0,0,.17.92c.66.63,1.29,1.29,1.94,1.92s1.09,1,1.65,1.56L6.63,15.18c-.79.8-.8,1.15,0,2a3.13,3.13,0,0,0,.74.61.89.89,0,0,0,1.25-.16c1.11-1.16,2.26-2.28,3.42-3.44l3.24,3.25c.72.71,1,.72,1.82.08a3.06,3.06,0,0,0,.79-1,.81.81,0,0,0-.17-1.07c-.68-.64-1.31-1.31-2-2-.51-.5-1-1-1.56-1.48l3.23-3.22c.79-.79.81-1.14,0-2a3.78,3.78,0,0,0-.64-.56c-.6-.39-.87-.36-1.38.15L12,9.83Z" transform="translate(0)" style="fill:#686868"/></svg>
                                </span>
                                <!--end::Svg Icon-->
                            </div>
                            <!--end::Close-->
                        </div>
                        <!--end::Modal header-->
                        <!--begin::Modal body-->
                        <div class="modal-body scroll-y mx-5 mx-xl-15 my-7">
                            <div class="alert alert-danger errYxt" id="tskcom_err_msg" style="display:none;"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <div class="alert alert-success errYxt" id="tskcom_succ_msg" style="display:none;"><i class="fa fa-check-circle" aria-hidden="true"></i>&nbsp;<span></span></div>
                            <!--begin::Form-->
                            <div class="task_comments_modals_form">
                                <!--begin::Input group-->
                                <div class="fv-row mb-10">
                                    <div class="row mb-5">
                                        <div class="input-group mb-5">
                                            <label class="fs-6 form-label text-dark me-5"><?php echo $label_details[235]['name']; ?></label>
                                            <div class="input-group flex-nowrap">
                                                <span class="input-group-text"><i class="las la-sticky-note fs-3"></i></span>
                                                <div class="overflow-hidden flex-grow-1">
                                                    <textarea id="task_comments" name="task_comments" rows="5"></textarea>
                                                    <input type="hidden" id="st_task_id" name="st_task_id" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--end::Input group-->
                                <!--begin::Actions-->
                                <div class="text-center">
                                    <button type="button" id="modal_task_comments_sub" class="btn btn-primary"><i class="fas fa-comment fs-8"></i> <?php echo $label_details[234]['name']; ?>
                                    </button>
                                    <button type="button" class="btn btn-danger me-3" id="close_com_tskcom_btn" data-bs-dismiss="modal"><i class="las la-times fs-5"></i><?php echo $label_details[233]['name']; ?></button>
                                </div>
                                <!--end::Actions-->
                            </div>
                            <!--end::Form-->
                        </div>
                        <!--end::Modal body-->
                    </div>
                    <!--end::Modal content-->
                </div>
                <!--end::Modal dialog-->
            </div>
            <!--end::Modal - Delete Module-->   
    <!--end::Post-->
<?php echo $footer; ?>

<script type="text/javascript" src="<?php echo $js_path;?>mailclient/xlsx.full.min.js"></script>
<script src="<?php echo $plugins_custom_path;?>prismjs/prismjs.bundle.js"></script>
<script src="<?php echo $js_path;?>jQuery.print.js"></script>
<!--end::Page Vendors Javascript-->

<!--begin::Page Custom Javascript(used by this page)-->
<script src="<?php echo $js_path;?>custom/documentation/documentation.js"></script>
<script src="<?php echo $js_path;?>custom/documentation/search.js"></script>
<script src="<?php echo $js_path;?>swiper.js"></script>
<script src="<?php echo $assets_path;?>/owlcarousel/js/owl.carousel.min.js"></script>
<script src="<?php echo $assets_path;?>/owlcarousel/js/script.js"></script>
<!--begin::PDF Viewer -->
<script type="text/javascript">
      window.PDFJS_LOCALE = {
        pdfJsWorker: '<?php echo $assets_path;?>pdf/js/pdf.worker.js',
        pdfJsCMapUrl: '<?php echo $assets_path;?>pdf/cmaps'
      };
</script>
<script src="<?php echo $assets_path;?>pdf/js/libs/html2canvas.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/three.min.js"></script>
<script src="<?php echo $assets_path;?>pdf/js/libs/pdf.min.js"></script>

<script src="<?php echo $assets_path;?>pdf/js/dist/3dflipbook.js"></script>
		<!--end::PDF Viewer-->
<script src="<?php echo $js_path;?>file_manager.js"></script>
<script src="<?php echo $js_path;?>timeline.js"></script>
<script type="text/javascript">
var  baseurl="<?php  echo $base_url;?>",user_pristine=false,table,teacher_table,selected=[],id="<?php  echo $user_det['id'];?>",status_fld="",del_fld="",cur=0,seconds=300,lesson_number,interval,weekday_fld="",course_date="",student_details=[],absent_students=[],daily_timeline_details=[],absence_category_details=[],disciplinary_category_details=[],mark_details=[],min_mark="",max_mark="",medium_mark="",mark_categories_details=[],dossier_details=[],attachmentCount = 0,uploadFiles = [],student_uploadFiles = [],attachFilenames='',attachFilenames1='',selected_file=[],id_count=0,school_details=[],cur_lesson_number="",label_details=<?php echo json_encode($label_details); ?>,pgn_details=<?php echo json_encode($pgn_details); ?>,ro_details=<?php echo json_encode($role_details); ?>,edit_role=false,num='',glb_course_id,group_id="<?php  echo $user_det['group_id'];?>",role_details=[],number_system="<?php  echo $number_system;?>",cur_student_id="",task_table,dos_id,task_selected=[],task_view_table,task_view_selected=[],lang_code="<?php  echo $lang_code;?>";
$(document).ready(function() {
    role_details = $.map(ro_details, function(value, index) {
    return [value];
    });
    if ($.inArray("15", role_details) != -1)
    {
        edit_role=true;
    }
	timeline_details();
});
</script>  
