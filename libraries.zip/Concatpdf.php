<?php
//============================================================+
// File name   : example_008.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 008 for TCPDF class
//               Include external UTF-8 text file
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Include external UTF-8 text file
 * @author Nicola Asuni
 * @since 2008-03-04
 */
use setasign\Fpdi;

// Include the main TCPDF library (search for installation path).

require_once('tcpdf/examples/fpdi2/src/autoload.php');
require_once('tcpdf/examples/fpdi2/src/parser/autoload.php');

class Concatpdf extends Fpdi\Tcpdf\Fpdi
{
    function addImage_to_pdf($image_path,$link)
	{
		$this->AddPage();
		if($link!="")
			$this->Image($image_path, 50, 50, 100, '', '', $link, '', false, 300);
		else
			$this->Image($image_path, 50, 50, 100, '', '', '', '', false, 300);
	}
    function addPdf_to_pdf($file) {
		
		$pagecount = $this->setSourceFile($file);
		for ($i = 1; $i <= $pagecount; $i++) 
		{
			$tplidx = $this->ImportPage($i);
			$size = $this->getTemplatesize($tplidx);
			if ($size['width'] > $size['height']) {
                $this->AddPage('L', array($size['width'], $size['height']));
            } else {
                $this->AddPage('P', array($size['width'], $size['height']));
            }
			//$this->AddPage($specs['height'] > $specs['width'] ? 'P' : 'L');
			//$this->AddPage();
			$this->useTemplate($tplidx);
		}
     }
}

