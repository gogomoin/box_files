<?php
//============================================================+
// File name   : example_008.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 008 for TCPDF class
//               Include external UTF-8 text file
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

require_once 'ocr/autoload.php';
use thiagoalessio\TesseractOCR\TesseractOCR;

class Ocr_convertor
{   
	function convert_image($inputFileName)
	{
		try{
			$ocr = new TesseractOCR();
			$ocr->image($inputFileName);
			return $ocr->run();
		}
		catch(Exception $errors) {
			
		}
	}
}

