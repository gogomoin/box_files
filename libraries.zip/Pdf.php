<?php

require_once dirname(__FILE__) . '/tcpdf/tcpdf.php';

class Pdf extends TCPDF {
    protected $footer_text;
    public function __construct()
    {
        parent::__construct();
    }
    public function setFooterText($var){
        $this->footer_text = $var;
    }
    public function Header() {
        $headerData = $this->getHeaderData();
        $this->SetFont('helvetica', 10);
        $this->writeHTML($headerData['string']);
    }
    // Page footer
    public function Footer() {
        // Position at 15 mm from bottom
        $this->SetY(-15);
        // Set font
        $this->SetFont('helvetica', 'I', 8);
        // Page number
        $this->Cell(0, 10, $this->footer_text, 0, false, 'C', 0, '', 0, false, 'T', 'M');
    }
}