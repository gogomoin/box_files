<?php
//============================================================+
// File name   : example_008.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 008 for TCPDF class
//               Include external UTF-8 text file
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

require_once 'con_pdf/autoload.php';

class Pdf_convertor
{   
	function convert_pdf($file)
	{
		$parser = new \Smalot\PdfParser\Parser();
		// Parse pdf file using Parser library 
		$pdf = $parser->parseFile($file); 
		// Extract text from PDF 
		$textContent = $pdf->getText();
		return $textContent;
	}
}

