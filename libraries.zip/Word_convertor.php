<?php
require_once 'con_word/autoload.php';
require_once 'dompdf/autoload.inc.php';
require_once 'con_office/autoload.php';
//include 'con_new_pdf/autoload.php';
use NcJoes\OfficeConverter\OfficeConverter;
use Dompdf\Dompdf;
class Word_convertor
{   
	function convert_word($inputFileName,$ext)
	{
		echo $ext;
		if($ext=='docx')
			$phpWord = \PhpOffice\PhpWord\IOFactory::load($inputFileName, 'Word2007');
		else
			$phpWord = \PhpOffice\PhpWord\IOFactory::load($inputFileName, 'MsDoc');
		//$phpWord = \PhpOffice\PhpWord\IOFactory::load($inputFileName);
		$content='';
		foreach($phpWord->getSections() as $section) {
			foreach($section->getElements() as $element) {
				if (method_exists($element, 'getElements')) {
					foreach($element->getElements() as $childElement) {
						if (method_exists($childElement, 'getText')) {
							$content .= $childElement->getText() . ' ';
						}
						else if (method_exists($childElement, 'getContent')) {
							$content .= $childElement->getContent() . ' ';
						}
					}
				}
				else if (method_exists($element, 'getText')) {
					$content .= $element->getText() . ' ';
				}
			}
		}
		return $content;
	}
	
	function read_doc($filename) {
		$fileHandle = fopen($filename, "r");
		$line = @fread($fileHandle, filesize($filename));   
		$lines = explode(chr(0x0D),$line);
		$outtext = "";
		foreach($lines as $thisline)
		  {
			$pos = strpos($thisline, chr(0x00));
			if (($pos !== FALSE)||(strlen($thisline)==0))
			  {
			  } else {
				$outtext .= $thisline." ";
			  }
		  }
		 $outtext = preg_replace("/[^a-zA-Z0-9\s\,\.\-\n\r\t@\/\_\(\)]/","",$outtext);
		return $outtext;
	}
	/**Function to extract text*/
    function read_from_docx($filename,$ext) {
       

    //if its docx file
    if($ext == 'docx')
    	$dataFile = "word/document.xml";
		//else it must be odt file
	else
		$dataFile = "content.xml";     

    //Create a new ZIP archive object
    $zip = new ZipArchive;

    // Open the archive file
    if (true === $zip->open($filename)) {
        // If successful, search for the data file in the archive
        if (($index = $zip->locateName($dataFile)) !== false) {
            // Index found! Now read it to a string
            $text = $zip->getFromIndex($index);
            // Load XML from a string
            // Ignore errors and warnings
			$xml_handle = new DOMDocument();
			$xml_handle->loadXML($text, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
            //$xml = DOMDocument::loadXML($text, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
            // Remove XML formatting tags and return the text
            return strip_tags($xml_handle->saveXML());
        }
        //Close the archive file
        $zip->close();
    }
    // In case of failure return a message
    return "File not found";
}

	function convert_pdf_to_html($html)
	{
		$path=getcwd();
		$target_server_path=$path."/assets/uploads/pdf_files/temp_doc_".time().".pdf";
		$dompdf = new Dompdf();
		$dompdf->loadHtml($html);
		// (Optional) Setup the paper size and orientation
		$dompdf->setPaper('A4');
		// Render the HTML as PDF
		$dompdf->render();
		$output = $dompdf->output();
		file_put_contents($target_server_path, $output);
	}
	function convert_to_pdf($file_server_path,$filePath,$file_name)
	{
		//$path=getcwd();
        //$file_server_path=$path."/assets/uploads/user_files";
		//$filePath = $file_server_path."/1655366037488_2.docx";
        //$filePath = $file_server_path."/1.doc";
		//$target_server_path=$path."/assets/uploads/pdf_files/temp_doc_".time().".pdf";
		//$file_name="temp_doc_".time().".pdf";
		$converter = new OfficeConverter($filePath, $file_server_path);
		$converter->convertTo($file_name); //generates pdf file in same directory as test-file.docx
	}
	function doc_to_html($inputFileName,$target_file_name,$ext)
	{	
		\PhpOffice\PhpWord\Settings::setPdfRendererName(\PhpOffice\PhpWord\Settings::PDF_RENDERER_DOMPDF);
		\PhpOffice\PhpWord\Settings::setPdfRendererPath('.');
		\PhpOffice\PhpWord\Settings::setOutputEscapingEnabled(false);
		\PhpOffice\PhpWord\Settings::setDefaultPaper('A4');
		if($ext=='docx')
			$phpWord = \PhpOffice\PhpWord\IOFactory::load($inputFileName, 'Word2007');
		else
			$phpWord = \PhpOffice\PhpWord\IOFactory::load($inputFileName, 'MsDoc');
		$phpWord->save($target_file_name, 'PDF');
	}
	function pptx_to_text($input_file){
		$zip_handle = new ZipArchive;
		$output_text = "";
		if(true === $zip_handle->open($input_file)){
			$slide_number = 1; //loop through slide files
			while(($xml_index = $zip_handle->locateName("ppt/slides/slide".$slide_number.".xml")) !== false){
				$xml_datas = $zip_handle->getFromIndex($xml_index);
				$xml_handle = new DOMDocument();
				$xml_handle->loadXML($xml_datas, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
				$output_text .= strip_tags($xml_handle->saveXML());
				$slide_number++;
			}
			if($slide_number == 1){
				$output_text .="";
			}
			$zip_handle->close();
		}else{
		$output_text .="";
		}
		return $output_text;
	}
	function xlsx_to_text($input_file){
		$xml_filename = "xl/sharedStrings.xml"; //content file name
		$zip_handle = new ZipArchive;
		$output_text = "";
		if(true === $zip_handle->open($input_file)){
			if(($xml_index = $zip_handle->locateName($xml_filename)) !== false){
				$xml_datas = $zip_handle->getFromIndex($xml_index);
				$xml_handle = new DOMDocument();
				$xml_handle->loadXML($xml_datas, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
				$output_text = strip_tags($xml_handle->saveXML());
			}else{
				$output_text .="";
			}
			$zip_handle->close();
		}else{
		$output_text .="";
		}
		return $output_text;
	}
	/* function convert_pdf_to_text()
	{
		$parser = new \Smalot\PdfParser\Parser();
		$path=getcwd();
        $file_server_path=$path."/assets/uploads";
		$PDFfile = $file_server_path."/123.pdf";
		//$PDFfile = 'test.pdf';
		$PDF = $parser->parseFile($PDFfile);
		$PDFContent = $PDF->getText();
		echo($PDFContent);
	} */
	
}

