<?php

namespace NcJoes\OfficeConverter;

class OfficeConverterException extends \Exception
{
}
