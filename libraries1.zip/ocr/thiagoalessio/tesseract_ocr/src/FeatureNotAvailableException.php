<?php

namespace thiagoalessio\TesseractOCR;

class FeatureNotAvailableException extends TesseractOcrException
{
}
