<?php

namespace thiagoalessio\TesseractOCR;

class ImageNotFoundException extends TesseractOcrException
{
}
