<?php

namespace thiagoalessio\TesseractOCR;

class TesseractNotFoundException extends TesseractOcrException
{
}
