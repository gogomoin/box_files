<?php

namespace thiagoalessio\TesseractOCR;

abstract class TesseractOcrException extends \Exception
{
}
