<?php
//============================================================+
// File name   : example_008.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 008 for TCPDF class
//               Include external UTF-8 text file
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Include external UTF-8 text file
 * @author Nicola Asuni
 * @since 2008-03-04
 */
use setasign\Fpdi;

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');
require_once('fpdi2/src/autoload.php');

class Pdf extends Fpdi\Tcpdf\Fpdi
{
    var $files = array();
     function setFiles($files) {
          $this->files = $files;
     }
     function concat() {
            $this->AddPage();
            $this->Image('data/img1.jpg', 50, 50, 100, '', '', 'http://www.tcpdf.org', '', false, 300);
            //$this->Image('data/img1.jpg', 15, 140, 75, 113, 'JPG', 'http://www.tcpdf.org', '', true, 150, '', false, false, 1, false, false, false);
            

          foreach($this->files AS $file) 
          {
               $pagecount = $this->setSourceFile($file);
               for ($i = 1; $i <= $pagecount; $i++) 
               {
                    $tplidx = $this->ImportPage($i);
                    $s = $this->getTemplatesize($tplidx);
                    $this->AddPage();
                    $this->useTemplate($tplidx);
               }
          }
     }
}
$pdf =new Pdf();
$pdf->setFiles(array("data/logo.pdf","data/info.pdf"));
$pdf->concat();
//$pdf->Output("newpdf.pdf", "I");

// Output the file as forced download
$pdf->Output('theNewFile.pdf', 'D');

//============================================================+
// END OF FILE
//============================================================+
