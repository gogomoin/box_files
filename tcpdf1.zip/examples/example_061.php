<?php
//============================================================+
// File name   : example_061.php
// Begin       : 2010-05-24
// Last Update : 2014-01-25
//
// Description : Example 061 for TCPDF class
//               XHTML + CSS
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: XHTML + CSS
 * @author Nicola Asuni
 * @since 2010-05-25
 */

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');

// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 061');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 061', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', '', 10);

// add a page
$pdf->AddPage();

/* NOTE:
 * *********************************************************
 * You can load external XHTML using :
 *
 * $html = file_get_contents('/path/to/your/file.html');
 *
 * External CSS files will be automatically loaded.
 * Sometimes you need to fix the path of the external CSS.
 * *********************************************************
 */

// define some HTML content with style
$html = <<<EOF
<!-- EXAMPLE OF CSS STYLE -->

<style>
    
/*PDF Print css Start*/

.logo {
  max-width: 100%;
  max-height: 100px;
}
.dossier-preview-container {
  padding: 20px;
}
.pull-left {
  float: left !important;
}
.ml-10 {
  margin-left: 10px;
}
.pdf-print.text-success {
  color: #36c6d3 !important;
}
h1.pdf-print.text-success {
  font-size: 32px;
  font-weight: 100;
}
.font-green-sharp {
  color: #2ab4c0 !important;
}
h2.font-green-sharp {
  font-weight: 100;
  font-size: 30px;
}

.font-blue-madison {
  color: #578ebe !important;
}
h3.font-blue-madison {
  font-weight: 100;
  font-size: 26px;
}
.dossier-preview-container .qr-code {
  max-width: 100px;
  margin-top: -5px;
  margin-right: -5px;
}
.pull-right {
  float: right !important;
}
.ml-10 {
  margin-left: 10px;
}
.col-md-offset-4 {
  margin-left: 33.33333%;
}

.pull-right.teaser-image {
  max-height: 150px;
}
.bg-grey-cararra {
  background: #efefef !important;
}
.note {
  border-left: 5px solid #eee;
    border-left-color: rgb(238, 238, 238);
}
.border-after-green-sharp::after, .border-before-green-sharp::before, .border-green-sharp {
  border-color: #2ab4c0 !important;
}
.dossier-preview-container h3.block {
  font-weight: 500;
}
.dossier-preview-container h2, .dossier-preview-container h3 {
  margin-top: 10px;
}
.note {
  margin: 0 0 20px;
  padding: 15px 30px 15px 15px;
  box-shadow: 0 1px 3px rgba(0,0,0,.1),0 1px 2px rgba(0,0,0,.18);
}
.border-after-blue-sharp::after, .border-before-blue-sharp::before, .border-blue-sharp {
  border-color: #5c9bd1 !important;
}
.font-yellow-casablanca {
  color: #f2784b !important;
}
.border-after-yellow-casablanca::after, .border-before-yellow-casablanca::before, .border-yellow-casablanca {
  border-color: #f2784b !important;
}
.font-blue-sharp {
  color: #5c9bd1 !important;
}

.border-after-purple-sharp::after, .border-before-purple-sharp::before, .border-purple-sharp {
  border-color: #796799 !important;
}
.font-purple-sharp {
  color: #796799 !important;
}
blockquote {
  padding: 10px 20px;
  margin: 0 0 20px;
  font-size: 17.5px;
  border-left: 5px solid #c2c2c2;
}
.portlet.light {
  padding: 12px 20px 15px;
  background-color: #fff;
}
.portlet.light > .portlet-title {
  padding: 0;
  min-height: 48px;
}
.portlet > .portlet-title {
  border-bottom: 1px solid #eee;
  padding: 0;
  margin-bottom: 10px;
  min-height: 41px;
  -webkit-border-radius: 2px 2px 0 0;
  -moz-border-radius: 2px 2px 0 0;
  -ms-border-radius: 2px 2px 0 0;
  -o-border-radius: 2px 2px 0 0;
  border-radius: 2px 2px 0 0;
}
.portlet > .portlet-title > .caption {
  float: left;
  display: inline-block;
  font-size: 18px;
  line-height: 18px;
  padding: 10px 0;
}
.portlet.light > .portlet-title > .caption > .caption-subject {
  font-size: 16px;
}
.font-green-seagreen {
  color: #1ba39c !important;
}
.portlet.light > .portlet-title > .caption {
  color: #666;
  padding: 10px 0;
}
.uppercase {
  text-transform: uppercase !important;
}
.portlet.light .portlet-body {
  padding-top: 8px;
}
.portlet > .portlet-body {
  clear: both;
  -webkit-border-radius: 0 0 2px 2px;
  -moz-border-radius: 0 0 2px 2px;
  -ms-border-radius: 0 0 2px 2px;
  -o-border-radius: 0 0 2px 2px;
  border-radius: 0 0 2px 2px;
}
.dossier-preview-container ul.files {
  font-size: 15px;
  padding-left: 0;
  list-style-type: none;
}
.dossier-preview-container ul.files li {
  margin-right: 10px;
  margin-bottom: 5px;
  float: left;
}
.dossier-preview-container .download-link {
  font-size: 16px;
  height: 50px;
  line-height: 50px;
  padding-left: 60px;
  display: inline-block;
  vertical-align: center;
  background-size: contain;
  background-repeat: no-repeat;
  background-position: left center;
}

/*PDF Print css End*/

    
</style>

<!-- print pdf page start -->

<div class="portlet-body my-17">
    <div class="dossier-preview-container">
        <div class="row">
            <div class="col-xs-12 col-md-6">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="animated bounceInDown mb-10">
                            <img class="logo pull-left" src="https://test.proscola-app.com/uploads/common/ProScola.png" alt="" />

                            <div class="pull-left ml-10">
                                <strong>ProScola</strong><br />
                                <a href="mailto:jason.thompson@proscola.com">jason.thompson@proscola.com</a><br />
                                Bändelgasse 1, Basel 4057<br />
                                0041 78 69 67 63 9<br />
                            </div>

                            <div class="clearfix"></div>
                            
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="animated bounceInUp delay-1">
                            <h1 class="pdf-print text-success "><strong>Title:</strong> New English Lesson</h1>
                            <h2 class="font-green-sharp"><strong>Course:</strong> English 11</h2>
                            <h3 class="font-blue-madison"><strong>Teacher:</strong> Jason Thompson</h3>
                            <h4 class="font-purple-sharp"><strong>Language:</strong> English</h4>
                            <h4 class="font-purple-sharp"><strong>Estimated Time:</strong> 2 Hrs</h4>

                            <hr />
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-md-6">
                <div class="row">
                    <div class="col-xs-12 col-md-8 col-md-offset-4">
                        <div class="animated bounceInDown">
                            <div class="pull-right text-right ml-10">
                                <img src="https://test.proscola-app.com/uploads/dossiers/generated/56/ENG--202-2202011-qr-code.jpg" alt="" class="qr-code" />
                                <br />
                                <small>ENG--202-2202011</small>
                            </div>

                            <div class="pull-right text-right">
                                <div class="font-16">
                                    <strong>From:</strong>
                                    01/02/2022<br />

                                    <strong>To:</strong>
                                    03/02/2022<br />
                                </div>

                                <strong>Term:</strong>
                                2020-test
                            </div>

                            <div class="clearfix"></div>
                            <hr />
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="animated bounceInUp delay-1">
                            <div class="ml-10 pull-right">
                                <img src="assets/media/images/pdf-img1.png" class="pull-right teaser-image" />
                            </div>
                            <div class="clearfix"></div>
                            <div class=" teaser-text pull-right"><small>Hello</small></div>
                            <div class="clearfix"></div>
                            <hr />
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row mt-20">
            <div class="col-md-12">
                <div class="note border-green-sharp bg-grey-cararra animated bounceInLeft delay-2">
                    <h3 class="block font-green-sharp">Goals</h3>
                    Achievable<br />
                    Reachable<br />
                    Confident
                </div>

                <div class="note border-blue-sharp bg-grey-cararra animated bounceInLeft delay-2">
                    <h3 class="block font-blue-sharp">Path to Success</h3>
                    Work Hard<br />
                    Hard Working<br />
                    Excellent
                </div>

                <div class="note border-yellow-casablanca bg-grey-cararra animated bounceInRight delay-2">
                    <h3 class="block font-yellow-casablanca">Task</h3>
                    Outof Ordinary
                </div>
            </div>
            <div class="col-md-12">
                <div class="note border-purple-sharp bg-grey-cararra documents-container animated bounceInRight delay-2">
                    <h3 class="block font-purple-sharp">Documents</h3>

                    <blockquote>
                        <small>
                            Excellent
                        </small>
                    </blockquote>

                    <div class="portlet light">
                        <div class="portlet-title">
                            <div class="caption">
                                <i class="fa fa-files-o font-green-seagreen"></i>
                                <span class="caption-subject bold font-green-seagreen uppercase"> Links </span>
                            </div>
                        </div>
                        <div class="portlet-body">
                            Link 1:
                            <br />
                            <ol class="links">
                                <li class="font-green-seagreen animated bounceInRight" style="animation-delay: 1.5s;">
                                    <a
                                        href="http://proscola.com
"
                                        target="_blank"
                                        class="font-green-seagreen"
                                    >
                                        http://proscola.com
                                    </a>
                                    <br />
                                </li>
                            </ol>
                            Link 2:
                            <br />
                            <ol class="links">
                                <li class="font-green-seagreen animated bounceInRight" style="animation-delay: 1.5s;"><a href="http://proscola.org" target="_blank" class="font-green-seagreen">http://proscola.org</a><br /></li>
                            </ol>

                            <div class="clearfix"></div>
                        </div>
                    </div>

                    <div class="files-container">
                        <div class="portlet light">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="fa fa-files-o font-blue-steel"></i>
                                    <span class="caption-subject bold font-blue-steel uppercase"> Learning Materials </span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <ul class="files">
                                    <li class="animated bounceInRight" style="animation-delay: 1.5s;">
                                        <a
                                            href="#"
                                            class="download-link font-blue-steel"
                                            style="background-image: url('assets/media/images/png-img.png');"
                                        >
                                            1-rechtschreibung_926945.jpg
                                        </a>
                                    </li>
                                    <li class="animated bounceInRight" style="animation-delay: 1.8333333333333s;">
                                        <a
                                            href="#"
                                            class="download-link font-blue-steel"
                                            style="background-image: url('assets/media/images/pdf-img.png');"
                                        >
                                            4-Dehnung_Doppelkonsonanten.pdf
                                        </a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="files-container">
                        <div class="portlet light">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="fa fa-files-o font-red-thunderbird"></i>
                                    <span class="caption-subject bold font-red-thunderbird uppercase"> Solutions </span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <ul class="files">
                                    <li class="animated bounceInRight" style="animation-delay: 1.5s;">
                                        <a
                                            href="#"
                                            class="download-link font-red-thunderbird"
                                            style="background-image: url('assets/media/images/pdf-img.png');"
                                        >
                                            Devicesof CreativeWriting1.pdf
                                        </a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>

                    <div class="files-container">
                        <div class="portlet light">
                            <div class="portlet-title">
                                <div class="caption">
                                    <i class="fa fa-files-o font-yellow-casablanca"></i>
                                    <span class="caption-subject bold font-yellow-casablanca uppercase"> Evaluations </span>
                                </div>
                            </div>
                            <div class="portlet-body">
                                <ul class="files">
                                    <li class="animated bounceInRight" style="animation-delay: 1.5s;">
                                        <a
                                            href="#"
                                            class="download-link font-yellow-casablanca"
                                            style="background-image: url('assets/media/images/pdf-img.png');"
                                        >
                                            Devicesof CreativeWriting1.pdf
                                        </a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- print pdf page end -->
EOF;

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// add a page
$pdf->AddPage();

$html = '
<h1>HTML TIPS & TRICKS</h1>

<h3>REMOVE CELL PADDING</h3>
<pre>$pdf->SetCellPadding(0);</pre>
This is used to remove any additional vertical space inside a single cell of text.

<h3>REMOVE TAG TOP AND BOTTOM MARGINS</h3>
<pre>$tagvs = array(\'p\' => array(0 => array(\'h\' => 0, \'n\' => 0), 1 => array(\'h\' => 0, \'n\' => 0)));
$pdf->setHtmlVSpace($tagvs);</pre>
Since the CSS margin command is not yet implemented on TCPDF, you need to set the spacing of block tags using the following method.

<h3>SET LINE HEIGHT</h3>
<pre>$pdf->setCellHeightRatio(1.25);</pre>
You can use the following method to fine tune the line height (the number is a percentage relative to font height).

<h3>CHANGE THE PIXEL CONVERSION RATIO</h3>
<pre>$pdf->setImageScale(0.47);</pre>
This is used to adjust the conversion ratio between pixels and document units. Increase the value to get smaller objects.<br />
Since you are using pixel unit, this method is important to set theright zoom factor.<br /><br />
Suppose that you want to print a web page larger 1024 pixels to fill all the available page width.<br />
An A4 page is larger 210mm equivalent to 8.268 inches, if you subtract 13mm (0.512") of margins for each side, the remaining space is 184mm (7.244 inches).<br />
The default resolution for a PDF document is 300 DPI (dots per inch), so you have 7.244 * 300 = 2173.2 dots (this is the maximum number of points you can print at 300 DPI for the given width).<br />
The conversion ratio is approximatively 1024 / 2173.2 = 0.47 px/dots<br />
If the web page is larger 1280 pixels, on the same A4 page the conversion ratio to use is 1280 / 2173.2 = 0.59 pixels/dots';

// output the HTML content
$pdf->writeHTML($html, true, false, true, false, '');

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
$pdf->Output('example_061.pdf', 'I');

//============================================================+
// END OF FILE
//============================================================+
