<?php
//============================================================+
// File name   : example_008.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 008 for TCPDF class
//               Include external UTF-8 text file
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Include external UTF-8 text file
 * @author Nicola Asuni
 * @since 2008-03-04
 */
use setasign\Fpdi;

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');
require_once('fpdi2/src/autoload.php');

class Pdf extends Fpdi\Tcpdf\Fpdi
{
    /**
     * "Remembers" the template id of the imported page
     */
    public $tplId;

    /**
     * Draw an imported PDF logo on every page
     */
    function Header()
    {
        if ($this->tplId === null) {
            $this->numPages = $this->setSourceFile('data/info.pdf');
            $this->tplId = $this->importPage(1);
        }
        $this->useTemplate($this->tplId);
    }

    function Footer()
    {
        // emtpy method body
    }
}
// initiate PDF
$pdf = new PDF();
$pdf->setFontSubsetting(true);


// add a page
$pdf->AddPage();

// The new content
$pdf->SetFont("helvetica", "B", 14);
$pdf->Text(10,10,'Some text here');
$pdf->Image('data/img1.jpg', 50, 50, 100, '', '', 'http://www.tcpdf.org', '', false, 300);

$pdf->AddPage();

// THIS PUTS THE REMAINDER OF THE PAGES IN
if($pdf->numPages>1) {
    for($i=2;$i<=$pdf->numPages;$i++) {
        $pdf->endPage();
        $pdf->tplId = $pdf->importPage($i);
        $pdf->AddPage();
    }
}

// Output the file as forced download
$pdf->Output('theNewFile.pdf', 'D');

//============================================================+
// END OF FILE
//============================================================+
