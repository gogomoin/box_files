<?php

// uses FPDI to append another PDF file, watermarking each page with a message
class FPDI_AppendWithWatermark extends FPDI_with_annots {

    function AppendPDFWithWatermarkMessage($file, $message) {
        $pagecount = $this->setSourceFile($file);
        for ($i = 1; $i <= $pagecount; $i++) {
            $tplidx = $this->ImportPage($i);
            $s = $this->getTemplatesize($tplidx);
            $this->AddPage('P', array($s['w'], $s['h']));
            $this->useTemplate($tplidx);

            // watermark (a message printed vertically along the left margin)
            $this->SetAutoPageBreak(FALSE);
            $this->SetXY(6, -28);
            $this->Rotate(90);
            $this->SetTextColor(102, 102, 102);
            $this->SetFont('Arial', '', 8);
            $this->Cell(0, 5, utf8_decode($message),'',1,'L');
            $this->Rotate(0); // outputs Q to balance "q" added by the previous call to Rotate
        }
    }

}

// combines FPDI_AppendWithWatermark and qpdf to watermark existing PDF files
function personalize_pdf($source_file, $output_file, $temp_file, $message, $debug_mode = FALSE) {
    setlocale(LC_CTYPE, "en_US.UTF-8"); // otherwise escapeshellarg() strips non-ASCII characters

    // see the comments in FPDI_with_annots as to why we have to run this
    $cmd = sprintf('qpdf --decrypt --stream-data=uncompress --force-version=1.4 %s %s', escapeshellarg($source_file), escapeshellarg($temp_file));
    $output = shell_exec($cmd);
    if (!file_exists($temp_file) || filesize($temp_file) == 0) {
        if ($debug_mode) die("Error occurred while running:\n$cmd\n\nOutput:\n$output");
        return FALSE;
    }

    $pdf = new FPDI_AppendWithWatermark();

    // make debugging easier by leaving the output file uncompressed
    if ($debug_mode) $pdf->SetCompression(FALSE);

    $pdf->AppendPDFWithWatermarkMessage($temp_file, $message);
    $pdf->Output($temp_file, 'F');

    if ($debug_mode) {
        // make debugging easier by omitting the final processing step
        copy($temp_file, $output_file);
    } else {
        $cmd = sprintf('qpdf --encrypt "" "" 40 --extract=n -- %s %s', escapeshellarg($temp_file), escapeshellarg($output_file));
        $output = shell_exec($cmd);
        if (!file_exists($output_file) || filesize($output_file) == 0) {
            if ($debug_mode) die("Error occurred while running:\n$cmd\n\nOutput:\n$output");
            return FALSE;
        }
    }
    return TRUE;
}
